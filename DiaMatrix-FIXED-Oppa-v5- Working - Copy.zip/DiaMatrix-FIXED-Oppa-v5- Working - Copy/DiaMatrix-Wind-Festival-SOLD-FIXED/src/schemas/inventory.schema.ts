import { z } from 'zod';
import { branchCodeSchema, designCodeSchema, caratKeySchema } from './common.schema.js';

export const stockQuerySchema = z.object({
  outlet: branchCodeSchema.optional(),
  design: designCodeSchema.optional(),
  carat: caratKeySchema.optional(),
});

export const salesQuerySchema = z.object({
  outlet: branchCodeSchema.optional(),
  design: designCodeSchema.optional(),
  periodMonths: z.coerce.number().int().min(1).max(36).default(9),
});

/** One row from parsed Excel stock/sold upload */
export const inventoryUploadRowSchema = z.object({
  outletCode: branchCodeSchema,
  designCode: designCodeSchema,
  caratKey: caratKeySchema.default('ALL'),
  qty: z.number().finite().nonnegative(),
  category: z.string().trim().max(120).optional(),
});

export const inventoryUploadBodySchema = z.object({
  kind: z.enum(['stock', 'sold']),
  periodMonths: z.number().int().min(1).max(36).optional(),
  sourceFile: z.string().max(255).optional(),
  rows: z.array(inventoryUploadRowSchema).min(1).max(50_000),
});

export type InventoryUploadBody = z.infer<typeof inventoryUploadBodySchema>;
