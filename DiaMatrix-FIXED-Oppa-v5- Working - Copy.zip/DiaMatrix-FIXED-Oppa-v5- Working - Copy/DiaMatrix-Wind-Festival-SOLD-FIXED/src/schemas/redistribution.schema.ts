import { z } from 'zod';
import { festivalLogicSchema, salesTimeframeSchema } from './common.schema.js';

export const redistributionReportBodySchema = z.object({
  timeframe: salesTimeframeSchema.default('3M'),
  logic: festivalLogicSchema.default('hybrid'),
  /** Optional design filter — empty = all */
  design: z.string().trim().optional(),
  branch: z.string().trim().optional(),
  ctsFrom: z.string().trim().optional(),
  ctsTo: z.string().trim().optional(),
});

export type RedistributionReportBody = z.infer<typeof redistributionReportBodySchema>;
