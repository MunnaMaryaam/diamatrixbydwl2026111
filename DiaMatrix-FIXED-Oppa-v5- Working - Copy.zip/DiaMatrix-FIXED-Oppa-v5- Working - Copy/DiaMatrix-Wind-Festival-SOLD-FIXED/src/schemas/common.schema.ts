import { z } from 'zod';
import { SALES_TIMEFRAMES, FESTIVAL_LOGICS } from '../config/constants.js';

export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(200).default(50),
});

export const branchCodeSchema = z
  .string()
  .trim()
  .min(2)
  .max(12)
  .transform((s) => s.toUpperCase());

export const designCodeSchema = z
  .string()
  .trim()
  .min(1)
  .max(64)
  .transform((s) => s.toUpperCase().replace(/\s+/g, ''));

export const salesTimeframeSchema = z.enum(SALES_TIMEFRAMES);

export const festivalLogicSchema = z.enum(
  FESTIVAL_LOGICS.map((l) => l.id) as [string, ...string[]],
);

export const caratKeySchema = z
  .string()
  .regex(/^\d+(\.\d{1,2})?$|^ALL$/, 'Carat must be like 0.05 or ALL');
