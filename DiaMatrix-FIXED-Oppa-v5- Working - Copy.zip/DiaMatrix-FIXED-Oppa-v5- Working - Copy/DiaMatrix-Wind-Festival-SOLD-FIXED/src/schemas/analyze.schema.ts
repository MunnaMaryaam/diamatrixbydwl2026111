import { z } from 'zod';

export const analyzeOutletSchema = z.object({
  outlet: z
    .string()
    .trim()
    .min(2)
    .max(12)
    .transform((s) => s.toUpperCase()),
  have: z.number().finite().nonnegative(),
  sales: z.number().finite().nonnegative().default(0),
});

export const analyzeBodySchema = z.object({
  outlets: z.array(analyzeOutletSchema).min(1).max(500),
  festivalStock: z.number().finite().nonnegative().optional().default(0),
  logic: z.enum(['contribution', 'baseline', 'hybrid', 'coverage']).default('contribution'),
  salesMonths: z.number().int().min(1).max(36).optional().default(9),
  keepMinHave: z.number().int().min(0).max(10).optional().default(1),
});

export type AnalyzeBody = z.infer<typeof analyzeBodySchema>;
