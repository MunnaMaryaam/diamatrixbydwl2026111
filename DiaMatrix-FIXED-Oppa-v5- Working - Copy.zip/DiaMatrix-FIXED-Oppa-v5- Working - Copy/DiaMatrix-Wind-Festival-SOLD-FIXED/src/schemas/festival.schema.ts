import { z } from 'zod';
import { festivalLogicSchema, designCodeSchema } from './common.schema.js';

export const schemeDesignInputSchema = z.object({
  design: designCodeSchema,
  stock: z.number().int().nonnegative(),
  gWt: z.number().finite().optional(),
  nWt: z.number().finite().optional(),
  dWt: z.number().finite().optional(),
});

export const festivalAllocateBodySchema = z.object({
  logic: festivalLogicSchema.default('hybrid'),
  salesMonths: z.number().int().min(1).max(36).default(9),
  scheme: z.array(schemeDesignInputSchema).min(1),
  /** Optional: pre-parsed sold maps design → outlet → carat → qty */
  soldByDesign: z
    .record(z.record(z.record(z.number().finite().nonnegative())))
    .optional(),
  /** Optional: pre-parsed stock maps design → outlet → carat → qty */
  stockByDesign: z
    .record(z.record(z.record(z.number().finite().nonnegative())))
    .optional(),
});

export type FestivalAllocateBody = z.infer<typeof festivalAllocateBodySchema>;
