import { z } from 'zod';

/** Login accepts existing short passwords (e.g. seeded owner). New passwords use stricter rules elsewhere. */
export const loginBodySchema = z.object({
  username: z.string().trim().min(2).max(64),
  password: z.string().min(4).max(128),
});

export type LoginBody = z.infer<typeof loginBodySchema>;

export const mfaSendBodySchema = z.object({
  mfaToken: z.string().min(16).max(128),
  method: z.enum(['email', 'sms']),
});

export type MfaSendBody = z.infer<typeof mfaSendBodySchema>;

export const mfaVerifyBodySchema = z.object({
  mfaToken: z.string().min(16).max(128),
  code: z.string().trim().min(4).max(12),
  method: z.enum(['totp', 'email', 'sms']).optional(),
});

export type MfaVerifyBody = z.infer<typeof mfaVerifyBodySchema>;
