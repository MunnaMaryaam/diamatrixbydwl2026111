# Owner account + MFA (Shahadat)

## Seeded credentials (backend)

On server start, `user.repository` seeds:

| Field    | Default                         | Override env        |
|----------|---------------------------------|---------------------|
| username | `shahadat`                      | `OWNER_USERNAME`    |
| password | `000000` (scrypt-hashed)        | `OWNER_PASSWORD`    |
| email    | `shahadat@diamatrix.app`        | `OWNER_EMAIL`       |
| phone    | (empty)                         | `OWNER_PHONE`       |

Password is **never** stored in plaintext — only a scrypt hash.

## Login flow

1. `POST /api/v1/auth/login` `{ username, password }`
2. If password OK → `{ mfaRequired: true, mfaToken, methods, emailHint, phoneHint }`
3. Email + SMS OTP auto-sent when those channels exist
4. User enters **Google Authenticator (TOTP)** code **or** email/SMS OTP
5. `POST /api/v1/auth/login/mfa/verify` `{ mfaToken, code, method? }`
6. Returns `{ token, user }` JWT (12h)

Resend OTP: `POST /api/v1/auth/login/mfa/send` `{ mfaToken, method: "email"|"sms" }`

## Google Authenticator setup

Dev only: `GET /api/v1/auth/totp-setup` returns secret + `otpauth://` URI.

Or check server console on startup for:

```
[DiaMatrix] Owner MFA setup (Google Authenticator):
  Username : shahadat
  TOTP secret: ...
  otpauth URI: otpauth://totp/...
```

Add account in Google Authenticator / Authy with that secret.

## Production email / SMS

Set:

```
OWNER_EMAIL=you@company.com
OWNER_PHONE=+8801XXXXXXXXX
MFA_EMAIL_WEBHOOK_URL=https://your-mail-webhook
MFA_SMS_WEBHOOK_URL=https://your-sms-webhook
JWT_SECRET=<long-random-secret>
```

In development, OTP codes are printed to the **server console**.

## Security notes

- MFA is **mandatory** for owner/admin.
- JWT required on protected routes after MFA.
- Rotate `OWNER_PASSWORD` via env before production; keep password ≥ 8 chars in prod.
