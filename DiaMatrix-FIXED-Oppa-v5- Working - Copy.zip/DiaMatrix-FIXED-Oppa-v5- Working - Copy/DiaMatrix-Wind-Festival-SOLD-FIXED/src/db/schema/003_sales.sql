-- DiaMatrix: sales facts (period contribution)
create table if not exists public.sales_facts (
  id uuid primary key default gen_random_uuid(),
  outlet_code text not null references public.outlets(code),
  design_code text not null,
  carat_key text not null default 'ALL',
  qty numeric not null check (qty >= 0),
  period_months int not null default 9 check (period_months between 1 and 36),
  as_of timestamptz not null default now(),
  source_file text,
  created_at timestamptz not null default now()
);

create index if not exists sales_outlet_design_idx
  on public.sales_facts (outlet_code, design_code, carat_key);
