-- DiaMatrix: festival schemes
create table if not exists public.festival_schemes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  file_name text,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.festival_scheme_designs (
  id uuid primary key default gen_random_uuid(),
  scheme_id uuid not null references public.festival_schemes(id) on delete cascade,
  design_code text not null,
  stock_pcs int not null check (stock_pcs >= 0),
  g_wt numeric,
  n_wt numeric,
  d_wt numeric,
  unique (scheme_id, design_code)
);
