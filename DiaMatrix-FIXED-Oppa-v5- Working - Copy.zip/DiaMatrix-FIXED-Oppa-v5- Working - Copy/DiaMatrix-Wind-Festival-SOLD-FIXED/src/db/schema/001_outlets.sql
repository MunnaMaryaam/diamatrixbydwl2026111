-- DiaMatrix: outlets
create table if not exists public.outlets (
  code text primary key,
  name text not null,
  is_warehouse boolean not null default false,
  is_excluded boolean not null default false,
  parent_code text references public.outlets(code),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists outlets_active_idx on public.outlets (active) where active = true;
