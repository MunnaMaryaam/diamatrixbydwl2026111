-- DiaMatrix: app users + MFA
create table if not exists public.app_users (
  id uuid primary key default gen_random_uuid(),
  username text not null unique,
  name text not null,
  role text not null default 'readonly'
    check (role in ('owner', 'admin', 'merchandising', 'branch', 'readonly')),
  is_owner boolean not null default false,
  branch_code text references public.outlets(code),
  password_hash text not null,
  email text,
  phone text,
  mfa_enabled boolean not null default true,
  totp_secret text,
  totp_confirmed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.mfa_challenges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.app_users(id) on delete cascade,
  method text not null check (method in ('totp', 'email', 'sms')),
  code_hash text,
  expires_at timestamptz not null,
  attempts int not null default 0,
  consumed boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists mfa_challenges_user_idx on public.mfa_challenges(user_id);
