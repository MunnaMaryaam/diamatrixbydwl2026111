-- DiaMatrix: inventory positions (closing stock)
create table if not exists public.inventory_positions (
  id uuid primary key default gen_random_uuid(),
  outlet_code text not null references public.outlets(code),
  design_code text not null,
  category text,
  carat_key text not null default 'ALL',
  qty numeric not null check (qty >= 0),
  as_of timestamptz not null default now(),
  source_file text,
  created_at timestamptz not null default now()
);

create index if not exists inv_outlet_design_idx
  on public.inventory_positions (outlet_code, design_code, carat_key);
