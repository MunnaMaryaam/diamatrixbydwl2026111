-- DiaMatrix: transfer orders
create table if not exists public.transfer_orders (
  id text primary key,
  design_code text not null,
  carat_key text,
  from_outlet text not null references public.outlets(code),
  to_outlet text not null references public.outlets(code),
  qty numeric not null check (qty > 0),
  priority text not null default 'MEDIUM'
    check (priority in ('MEDIUM', 'HIGH', 'CRITICAL')),
  status text not null default 'RECOMMENDED'
    check (status in ('RECOMMENDED', 'APPROVED', 'DISPATCHED', 'CANCELLED')),
  reason text,
  logic text,
  created_at timestamptz not null default now()
);

create index if not exists transfer_status_idx on public.transfer_orders (status);
