import { createApp } from './app.js';
import { env } from './config/env.js';
import { logger } from './lib/logger.js';
import { APP_NAME, APP_SLOGAN } from './config/constants.js';

const app = createApp();

app.listen(env.PORT, () => {
  logger.info(`${APP_NAME} server listening`, {
    port: env.PORT,
    prefix: env.API_PREFIX,
    slogan: APP_SLOGAN,
    env: env.NODE_ENV,
  });
});
