/** DiaMatrix domain constants */

export const APP_NAME = 'DiaMatrix';
export const APP_SLOGAN = 'See every outlet. Move every piece.';

/** Warehouse / non-retail codes — never treated as showrooms */
export const WAREHOUSE_CODES = ['DWL'] as const;

/** Excluded from retail matrix (online, fair, etc.) */
export const EXCLUDED_OUTLET_CODES = ['ONL', 'ONLS', 'FAIR', 'WEB'] as const;

export type FestivalLogic = 'contribution' | 'baseline' | 'hybrid' | 'coverage';

export const FESTIVAL_LOGICS: { id: FestivalLogic; label: string }[] = [
  { id: 'contribution', label: 'Contribution' },
  { id: 'baseline', label: '3-Month Baseline' },
  { id: 'hybrid', label: 'Hybrid' },
  { id: 'coverage', label: 'Coverage' },
];

export const SALES_TIMEFRAMES = ['1M', '3M', '6M', '9M', '1Y', '2Y'] as const;
export type SalesTimeframe = (typeof SALES_TIMEFRAMES)[number];

/** 1 bhori (BD jewelry) ≈ 11.664 grams */
export const BHORI_TO_GRAM = 11.664;
export const TROY_OZ_TO_GRAM = 31.1034768;
