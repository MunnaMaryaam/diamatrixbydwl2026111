import { redistributionService } from './redistribution.service.js';
import { inventoryService } from './inventory.service.js';
import type { RedistributionReportBody } from '../schemas/redistribution.schema.js';

export class ReportService {
  async cockpit(body: RedistributionReportBody) {
    const [report, sellThrough] = await Promise.all([
      redistributionService.buildReport(body),
      inventoryService.sellThroughSummary(),
    ]);
    return {
      ...report,
      sellThrough,
      reminders: report.transfers.slice(0, 5).map((t) => ({
        title: `Dispatch Transfer: ${t.designCode} (${t.fromOutlet} → ${t.toOutlet})`,
        detail: t.reason,
        severity: 'high' as const,
      })),
    };
  }
}

export const reportService = new ReportService();
