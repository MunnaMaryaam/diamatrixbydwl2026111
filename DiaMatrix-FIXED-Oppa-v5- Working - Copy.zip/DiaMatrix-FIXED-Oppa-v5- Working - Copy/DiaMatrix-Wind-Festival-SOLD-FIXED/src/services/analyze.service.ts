import type { AnalyzeBody } from '../schemas/analyze.schema.js';

export interface AnalyzeOutletResult {
  outlet: string;
  have: number;
  sales: number;
  share: number;
  deserve: number;
  target: number;
  shortage: number;
  surplus: number;
  move: number;
}

export interface AnalyzeResult {
  logic: string;
  pool: number;
  totalHave: number;
  totalSales: number;
  totalMoveIn: number;
  totalMoveOut: number;
  outlets: AnalyzeOutletResult[];
}

function roundToTotal(weights: number[], total: number): number[] {
  if (weights.length === 0) return [];
  const sumW = weights.reduce((a, b) => a + b, 0);
  if (sumW <= 0 || total <= 0) return weights.map(() => 0);
  const raw = weights.map((w) => (w / sumW) * total);
  const floors = raw.map((x) => Math.floor(x));
  let rem = total - floors.reduce((a, b) => a + b, 0);
  const order = raw
    .map((x, i) => ({ i, frac: x - Math.floor(x) }))
    .sort((a, b) => b.frac - a.frac);
  const out = [...floors];
  for (let k = 0; k < order.length && rem > 0; k++) {
    out[order[k].i]++;
    rem--;
  }
  return out;
}

function buildDeserve(
  sales: number[],
  haves: number[],
  pool: number,
  logic: string,
  salesMonths: number,
): number[] {
  const n = sales.length;
  const salesTotal = sales.reduce((a, b) => a + b, 0);
  const shares = sales.map((s) => (salesTotal > 0 ? s / salesTotal : 1 / n));

  if (logic === 'coverage') {
    if (pool >= n) {
      const residual = pool - n;
      return shares.map((sh) => 1 + residual * sh);
    }
    const order = sales
      .map((s, i) => ({ s, i }))
      .sort((a, b) => b.s - a.s)
      .map((x) => x.i);
    const t = Array(n).fill(0);
    for (let k = 0; k < Math.floor(pool); k++) t[order[k % n]]++;
    return t;
  }

  if (logic === 'baseline') {
    const months = Math.max(1, salesMonths);
    return sales.map((s, i) => {
      const monthly = s / months;
      let ideal = monthly * 3;
      if (s > 0 && haves[i] === 0) ideal = Math.max(ideal, 1);
      if (shares[i] >= 0.15) ideal *= 1.2;
      return ideal;
    });
  }

  const contribution = shares.map((sh) => sh * pool);

  if (logic === 'hybrid') {
    const baseline = buildDeserve(sales, haves, pool, 'baseline', salesMonths);
    return contribution.map((c, i) => Math.max(c, baseline[i]));
  }

  return contribution;
}

export function analyzeHaveVsDeserve(body: AnalyzeBody): AnalyzeResult {
  const outlets = body.outlets;
  const haves = outlets.map((o) => o.have);
  const sales = outlets.map((o) => o.sales);
  const totalHave = haves.reduce((a, b) => a + b, 0);
  const totalSales = sales.reduce((a, b) => a + b, 0);
  const pool = totalHave + (body.festivalStock || 0);
  const n = outlets.length;

  const salesTotal = totalSales;
  const shares = sales.map((s) => (salesTotal > 0 ? s / salesTotal : 1 / n));

  let deserveRaw = buildDeserve(sales, haves, pool, body.logic, body.salesMonths);

  if (body.logic === 'hybrid' || body.logic === 'baseline') {
    const sumD = deserveRaw.reduce((a, b) => a + b, 0);
    if (sumD > 0 && pool > 0) {
      const factor = Math.min(1, pool / sumD);
      deserveRaw = deserveRaw.map((d) => d * factor);
    }
  }

  const targets = roundToTotal(
    deserveRaw.map((d) => Math.max(0, d)),
    Math.floor(pool),
  );

  const keepMin = body.keepMinHave ?? 1;
  const rows: AnalyzeOutletResult[] = outlets.map((o, i) => {
    const have = haves[i];
    const target = targets[i];
    const deserve = Math.round(deserveRaw[i] * 1000) / 1000;
    const shortage = Math.max(0, target - have);
    const surplus = Math.max(0, have - target);
    const move = target - have;
    return {
      outlet: o.outlet,
      have,
      sales: sales[i],
      share: Math.round(shares[i] * 10000) / 10000,
      deserve,
      target,
      shortage,
      surplus,
      move,
    };
  });

  if (keepMin > 0) {
    for (const r of rows) {
      if (r.move < 0 && r.have + r.move < keepMin) {
        r.move = Math.min(0, keepMin - r.have);
        r.surplus = Math.max(0, r.have - keepMin);
      }
    }
  }

  const totalMoveIn = rows.reduce((s, r) => s + Math.max(0, r.move), 0);
  const totalMoveOut = rows.reduce((s, r) => s + Math.max(0, -r.move), 0);

  return {
    logic: body.logic,
    pool,
    totalHave,
    totalSales,
    totalMoveIn,
    totalMoveOut,
    outlets: rows,
  };
}
