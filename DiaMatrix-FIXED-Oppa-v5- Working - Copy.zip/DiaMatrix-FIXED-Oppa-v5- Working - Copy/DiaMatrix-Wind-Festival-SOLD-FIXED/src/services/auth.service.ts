import { UnauthorizedError } from '../lib/errors.js';
import type { AuthUser } from '../models/user.model.js';
import type { LoginBody, MfaVerifyBody, MfaSendBody } from '../schemas/auth.schema.js';
import { env } from '../config/env.js';
import {
  ensureOwnerSeed,
  findByUsername,
  findById,
  checkPassword,
  asAuthUser,
  getOwnerTotpSetup,
} from '../repositories/user.repository.js';
import {
  startMfaChallenge,
  sendOtp,
  verifyMfa,
  type MfaMethod,
} from './mfa.service.js';
import { verifyJwt } from '../lib/crypto.js';
import { logger } from '../lib/logger.js';

export type LoginResult =
  | {
      mfaRequired: true;
      mfaToken: string;
      methods: MfaMethod[];
      emailHint?: string;
      phoneHint?: string;
      message: string;
    }
  | {
      mfaRequired: false;
      token: string;
      user: AuthUser;
    };

/**
 * Auth service with mandatory MFA for owner/admin accounts.
 * Owner Shahadat is seeded on startup (password from OWNER_PASSWORD or default).
 */
export class AuthService {
  constructor() {
    const owner = ensureOwnerSeed();
    const setup = getOwnerTotpSetup();
    logger.info('Owner account ready', {
      username: owner.username,
      email: owner.email,
      mfaEnabled: owner.mfaEnabled,
      totpUri: env.NODE_ENV === 'production' ? '[redacted]' : setup.uri,
      totpSecret: env.NODE_ENV === 'production' ? '[redacted]' : setup.secret,
    });
    if (env.NODE_ENV !== 'production') {
      console.log('\n[DiaMatrix] Owner MFA setup (Google Authenticator):');
      console.log(`  Username : ${setup.username}`);
      console.log(`  TOTP secret: ${setup.secret}`);
      console.log(`  otpauth URI: ${setup.uri}`);
      console.log('  Scan the secret in Google Authenticator / Authy.\n');
    }
  }

  async login(body: LoginBody): Promise<LoginResult> {
    const user = findByUsername(body.username);
    if (!user || !checkPassword(user, body.password)) {
      throw new UnauthorizedError('Invalid username or password');
    }

    // Owner / admin: always require MFA
    if (user.mfaEnabled || user.isOwner || user.role === 'admin' || user.role === 'owner') {
      const challenge = startMfaChallenge(user);
      return {
        mfaRequired: true,
        mfaToken: challenge.mfaToken,
        methods: challenge.methods,
        emailHint: challenge.emailHint,
        phoneHint: challenge.phoneHint,
        message:
          'Password accepted. Enter the code from Google Authenticator, or the code sent to your email/phone.',
      };
    }

    // Non-MFA accounts (rare): issue session directly
    const { signJwt } = await import('../lib/crypto.js');
    const token = signJwt(
      {
        sub: user.id,
        username: user.username,
        role: user.role,
        isOwner: user.isOwner,
      },
      env.JWT_SECRET,
    );
    return { mfaRequired: false, token, user: asAuthUser(user) };
  }

  async sendMfaCode(body: MfaSendBody) {
    return sendOtp(body.mfaToken, body.method);
  }

  async verifyMfa(body: MfaVerifyBody) {
    return verifyMfa(body.mfaToken, body.code, body.method);
  }

  async me(user: AuthUser): Promise<AuthUser> {
    return user;
  }

  /** Resolve Bearer JWT → AuthUser */
  resolveToken(token: string): AuthUser | null {
    const body = verifyJwt(token, env.JWT_SECRET);
    if (!body || typeof body.sub !== 'string') return null;
    const u = findById(body.sub);
    return u ? asAuthUser(u) : null;
  }

  getTotpSetupForOwner() {
    return getOwnerTotpSetup();
  }
}

export const authService = new AuthService();
