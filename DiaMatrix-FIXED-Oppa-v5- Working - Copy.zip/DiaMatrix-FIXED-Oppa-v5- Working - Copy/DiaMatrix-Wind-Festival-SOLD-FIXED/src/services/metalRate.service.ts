import { env } from '../config/env.js';
import { TROY_OZ_TO_GRAM } from '../config/constants.js';
import { formatDateBD } from '../lib/dates.js';

export interface MetalRateRow {
  label: string;
  purity: number | null;
  perGramBdt: number;
}

export interface MetalRateBlock {
  source: string;
  updatedAt: string;
  usdPerOz?: number;
  usdBdt?: number;
  rates: MetalRateRow[];
}

export interface MetalRatesPayload {
  bangladesh: MetalRateBlock;
  international: MetalRateBlock | null;
  fetchedAt: string;
}

const BAJUS_FALLBACK: MetalRateBlock = {
  source: 'BAJUS reference (snapshot)',
  updatedAt: '05-10-2026',
  rates: [
    { label: '22 KT', purity: 22, perGramBdt: 19640 },
    { label: '21 KT', purity: 21, perGramBdt: 18760 },
    { label: '18 KT', purity: 18, perGramBdt: 16110 },
    { label: 'Platinum', purity: null, perGramBdt: 15500 },
  ],
};

let cache: { at: number; payload: MetalRatesPayload } | null = null;

export class MetalRateService {
  async getRates(): Promise<MetalRatesPayload> {
    const ttl = env.METAL_RATE_CACHE_TTL_SEC * 1000;
    if (cache && Date.now() - cache.at < ttl) return cache.payload;

    const international = await this.fetchInternational();
    const payload: MetalRatesPayload = {
      bangladesh: BAJUS_FALLBACK,
      international,
      fetchedAt: new Date().toISOString(),
    };
    cache = { at: Date.now(), payload };
    return payload;
  }

  private async fetchInternational(): Promise<MetalRateBlock | null> {
    try {
      const cb = await fetch('https://api.coinbase.com/v2/prices/XAU-USD/spot', {
        headers: { Accept: '*/*' },
      });
      if (!cb.ok) return null;
      const json = (await cb.json()) as { data?: { amount?: string } };
      const usdPerOz = Number(json?.data?.amount);
      if (!Number.isFinite(usdPerOz) || usdPerOz <= 0) return null;

      let usdBdt = 122.5;
      try {
        const fx = await fetch('https://open.er-api.com/v6/latest/USD', {
          headers: { Accept: '*/*' },
        });
        if (fx.ok) {
          const fxJson = (await fx.json()) as { rates?: { BDT?: number } };
          if (fxJson?.rates?.BDT) usdBdt = Number(fxJson.rates.BDT);
        }
      } catch {
        /* keep default */
      }

      const pure = (usdPerOz / TROY_OZ_TO_GRAM) * usdBdt;
      const karat = (k: number) => Math.round(pure * (k / 24));

      return {
        source: 'International spot (Coinbase XAU) + USD/BDT FX',
        updatedAt: formatDateBD(new Date()),
        usdPerOz: Math.round(usdPerOz * 100) / 100,
        usdBdt: Math.round(usdBdt * 100) / 100,
        rates: [
          { label: '24 KT', purity: 24, perGramBdt: karat(24) },
          { label: '22 KT', purity: 22, perGramBdt: karat(22) },
          { label: '21 KT', purity: 21, perGramBdt: karat(21) },
          { label: '18 KT', purity: 18, perGramBdt: karat(18) },
        ],
      };
    } catch {
      return null;
    }
  }
}

export const metalRateService = new MetalRateService();
