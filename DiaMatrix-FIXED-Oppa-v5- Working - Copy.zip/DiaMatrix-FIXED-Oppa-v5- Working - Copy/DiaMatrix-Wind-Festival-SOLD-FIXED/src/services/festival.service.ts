import type { FestivalLogic } from '../config/constants.js';
import type { FestivalAllocateBody } from '../schemas/festival.schema.js';
import type { FestivalAllocateResult } from '../models/festival.model.js';

/**
 * Festival scheme allocation — Target − Have (+IN / −OUT).
 * Mirrors DiaMatrix coverage/hybrid behaviour at design level for bootstrap.
 */
export class FestivalService {
  allocate(body: FestivalAllocateBody): FestivalAllocateResult {
    const logic = body.logic as FestivalLogic;
    const warnings: string[] = [];
    const outletSet = new Set<string>();

    for (const d of body.scheme) {
      const sold = body.soldByDesign?.[d.design];
      const stock = body.stockByDesign?.[d.design];
      if (!sold) warnings.push(`${d.design}: no matching sold file — using equal share`);
      if (!stock) warnings.push(`${d.design}: no stock breakdown — design-level allocation`);
      if (sold) Object.keys(sold).forEach((o) => outletSet.add(o));
      if (stock) Object.keys(stock).forEach((o) => outletSet.add(o));
    }

    if (outletSet.size === 0) {
      // Default sample outlets if nothing uploaded
      ['BCT', 'CTG', 'GUL', 'MIR', 'RUP'].forEach((o) => outletSet.add(o));
      warnings.push('No outlets in sold/stock — using default retail set');
    }

    const outlets = [...outletSet].sort();
    const moves: Record<string, Record<string, number>> = {};
    outlets.forEach((o) => {
      moves[o] = {};
    });

    for (const s of body.scheme) {
      const stockMap = body.stockByDesign?.[s.design] || {};
      const soldMap = body.soldByDesign?.[s.design] || {};

      const haves = outlets.map((o) => {
        const byCarat = stockMap[o] || {};
        return Object.values(byCarat).reduce((a, b) => a + b, 0);
      });
      const solds = outlets.map((o) => {
        const byCarat = soldMap[o] || {};
        return Object.values(byCarat).reduce((a, b) => a + b, 0);
      });
      const salesTotal = solds.reduce((a, b) => a + b, 0);
      const haveTotal = haves.reduce((a, b) => a + b, 0);
      const pool = haveTotal + s.stock;

      let targets: number[];
      if (logic === 'coverage') {
        // ≥1 each when pool allows, then residual by sales share
        const n = outlets.length;
        if (pool >= n) {
          const residual = pool - n;
          targets = outlets.map((_, i) => {
            const share = salesTotal > 0 ? solds[i] / salesTotal : 1 / n;
            return 1 + Math.round(residual * share);
          });
        } else {
          // Top sellers get 1
          const order = outlets
            .map((_, i) => i)
            .sort((a, b) => solds[b] - solds[a]);
          targets = outlets.map(() => 0);
          for (let k = 0; k < pool; k++) targets[order[k % order.length]]++;
        }
      } else {
        // contribution / hybrid simplified: sales share of pool
        targets = outlets.map((_, i) => {
          const share = salesTotal > 0 ? solds[i] / salesTotal : 1 / outlets.length;
          return Math.round(pool * share);
        });
      }

      // Fit sum(targets) to pool
      let diff = pool - targets.reduce((a, b) => a + b, 0);
      let t = 0;
      while (diff !== 0 && t < targets.length * 4) {
        const idx = t % targets.length;
        if (diff > 0) {
          targets[idx]++;
          diff--;
        } else if (targets[idx] > 0) {
          targets[idx]--;
          diff++;
        }
        t++;
      }

      outlets.forEach((o, i) => {
        moves[o][s.design] = Math.round(targets[i] - haves[i]);
      });
    }

    return {
      logic,
      outlets,
      designs: body.scheme.map((s) => s.design),
      moves,
      warnings,
    };
  }
}

export const festivalService = new FestivalService();
