import { inventoryRepository } from '../repositories/inventory.repository.js';
import type { InventoryUploadBody } from '../schemas/inventory.schema.js';

export class InventoryService {
  getStock(filters: { outlet?: string; design?: string; carat?: string }) {
    return inventoryRepository.getStock(filters);
  }

  getSales(filters: { outlet?: string; design?: string; periodMonths?: number }) {
    return inventoryRepository.getSales(filters);
  }

  async upload(body: InventoryUploadBody) {
    return inventoryRepository.upsertUpload(body);
  }

  /**
   * Sell-through = Sold ÷ (Sold + Closing retail).
   * Closing excludes warehouse when isWarehouse flags are available upstream.
   */
  async sellThroughSummary(): Promise<{
    totalSold: number;
    totalClosingRetail: number;
    sellThroughPct: number;
  }> {
    const [stock, sales] = await Promise.all([
      inventoryRepository.getStock({}),
      inventoryRepository.getSales({}),
    ]);
    const totalClosingRetail = stock.reduce((s, r) => s + r.qty, 0);
    const totalSold = sales.reduce((s, r) => s + r.qty, 0);
    const denom = totalSold + totalClosingRetail;
    const sellThroughPct = denom > 0 ? (totalSold / denom) * 100 : 0;
    return {
      totalSold,
      totalClosingRetail,
      sellThroughPct: Math.round(sellThroughPct * 10) / 10,
    };
  }
}

export const inventoryService = new InventoryService();
