import type { RedistributionReportBody } from '../schemas/redistribution.schema.js';
import { inventoryRepository } from '../repositories/inventory.repository.js';
import { outletRepository } from '../repositories/outlet.repository.js';

export interface TransferSuggestion {
  designCode: string;
  caratKey: string;
  fromOutlet: string;
  toOutlet: string;
  qty: number;
  reason: string;
}

export interface RedistributionReport {
  timeframe: string;
  logic: string;
  totalSold: number;
  totalStock: number;
  sellThroughPct: number;
  totalMoveIn: number;
  totalMoveOut: number;
  transfers: TransferSuggestion[];
  warnings: string[];
}

/**
 * Closed redistribution: every Move OUT is matched by Move IN.
 * Retail donors never go below 1 pc on the shelf.
 */
export class RedistributionService {
  async buildReport(body: RedistributionReportBody): Promise<RedistributionReport> {
    const [stock, sales, retail] = await Promise.all([
      inventoryRepository.getStock({
        design: body.design?.toUpperCase() || undefined,
        outlet: body.branch?.toUpperCase() || undefined,
      }),
      inventoryRepository.getSales({
        design: body.design?.toUpperCase() || undefined,
        outlet: body.branch?.toUpperCase() || undefined,
      }),
      outletRepository.listRetail(),
    ]);

    const retailCodes = new Set(retail.map((o) => o.code));
    const stockByKey = new Map<string, number>();
    const salesByKey = new Map<string, number>();

    for (const r of stock) {
      if (!retailCodes.has(r.outletCode) && outletRepository.isWarehouse(r.outletCode)) continue;
      if (outletRepository.isExcluded(r.outletCode)) continue;
      const k = `${r.outletCode}|${r.designCode}|${r.caratKey}`;
      stockByKey.set(k, (stockByKey.get(k) || 0) + r.qty);
    }
    for (const r of sales) {
      if (outletRepository.isExcluded(r.outletCode)) continue;
      const k = `${r.outletCode}|${r.designCode}|${r.caratKey}`;
      salesByKey.set(k, (salesByKey.get(k) || 0) + r.qty);
    }

    const totalStock = [...stockByKey.values()].reduce((a, b) => a + b, 0);
    const totalSold = [...salesByKey.values()].reduce((a, b) => a + b, 0);
    const denom = totalSold + totalStock;
    const sellThroughPct = denom > 0 ? Math.round((totalSold / denom) * 1000) / 10 : 0;

    // Group by design|carat
    const designs = new Set<string>();
    for (const k of stockByKey.keys()) designs.add(k.split('|').slice(1).join('|'));
    for (const k of salesByKey.keys()) designs.add(k.split('|').slice(1).join('|'));

    const transfers: TransferSuggestion[] = [];
    let totalMoveIn = 0;
    let totalMoveOut = 0;

    for (const designCarat of designs) {
      const [designCode, caratKey] = designCarat.includes('|')
        ? (designCarat.split('|') as [string, string])
        : [designCarat, 'ALL'];

      const outlets = [...retailCodes];
      const haves = outlets.map((o) => stockByKey.get(`${o}|${designCode}|${caratKey}`) || 0);
      const solds = outlets.map((o) => salesByKey.get(`${o}|${designCode}|${caratKey}`) || 0);
      const pool = haves.reduce((a, b) => a + b, 0);
      if (pool === 0 && solds.every((s) => s === 0)) continue;

      const salesTotal = solds.reduce((a, b) => a + b, 0);
      // Contribution targets compressed to pool; keep ≥1 when pool allows
      const raw = outlets.map((_, i) =>
        salesTotal > 0 ? (solds[i] / salesTotal) * pool : pool / outlets.length,
      );
      const targets = raw.map((t) => Math.max(0, Math.round(t)));
      // Adjust sum to pool
      let diff = pool - targets.reduce((a, b) => a + b, 0);
      let i = 0;
      while (diff !== 0 && i < targets.length * 3) {
        const idx = i % targets.length;
        if (diff > 0) {
          targets[idx]++;
          diff--;
        } else if (targets[idx] > 0) {
          targets[idx]--;
          diff++;
        }
        i++;
      }

      const donors: { outlet: string; qty: number }[] = [];
      const receivers: { outlet: string; qty: number }[] = [];

      outlets.forEach((o, idx) => {
        const net = targets[idx] - haves[idx];
        if (net > 0) receivers.push({ outlet: o, qty: net });
        else if (net < 0) {
          const excess = -net;
          const maxGive = Math.max(0, haves[idx] - 1); // never empty retail shelf
          const give = Math.min(excess, maxGive);
          if (give > 0) donors.push({ outlet: o, qty: give });
        }
      });

      donors.sort((a, b) => b.qty - a.qty);
      receivers.sort((a, b) => b.qty - a.qty);

      let di = 0;
      for (const rec of receivers) {
        while (rec.qty > 0 && di < donors.length) {
          const donor = donors[di];
          const qty = Math.min(donor.qty, rec.qty);
          if (qty < 1) {
            di++;
            continue;
          }
          transfers.push({
            designCode,
            caratKey,
            fromOutlet: donor.outlet,
            toOutlet: rec.outlet,
            qty,
            reason: `${body.logic} target — donor keeps ≥1 pc`,
          });
          totalMoveIn += qty;
          totalMoveOut += qty;
          donor.qty -= qty;
          rec.qty -= qty;
          if (donor.qty === 0) di++;
        }
      }
    }

    const warnings: string[] = [];
    if (stock.length === 0) warnings.push('No stock positions loaded');
    if (sales.length === 0) warnings.push('No sales facts loaded — equal share used where needed');

    return {
      timeframe: body.timeframe,
      logic: body.logic,
      totalSold,
      totalStock,
      sellThroughPct,
      totalMoveIn,
      totalMoveOut,
      transfers,
      warnings,
    };
  }
}

export const redistributionService = new RedistributionService();
