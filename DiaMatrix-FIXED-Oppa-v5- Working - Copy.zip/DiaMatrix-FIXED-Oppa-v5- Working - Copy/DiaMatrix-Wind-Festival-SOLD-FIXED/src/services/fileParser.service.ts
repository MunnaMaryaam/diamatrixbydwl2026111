import ExcelJS from 'exceljs';
import { parse as csvParse } from 'csv-parse/sync';
import {
  mapHeaders,
  cellToNumber,
  cellToString,
  type CanonicalField,
} from '../lib/columnMapper.js';

export type ParseKind = 'stock' | 'sold' | 'scheme' | 'auto';

export interface ParsedInventoryRow {
  outletCode: string;
  designCode: string;
  caratKey: string;
  qty: number;
  category?: string;
  gWt?: number;
  nWt?: number;
  dWt?: number;
  raw?: Record<string, unknown>;
}

export interface ParseResult {
  kind: ParseKind;
  sourceName: string;
  sheetName?: string;
  headers: string[];
  mapping: Partial<Record<CanonicalField, number>>;
  confidence: Record<string, number>;
  rows: ParsedInventoryRow[];
  skipped: number;
  warnings: string[];
}

export interface ParseOptions {
  kind?: ParseKind;
  sheetName?: string;
  minConfidence?: number;
}

function isEmptyRow(cells: unknown[]): boolean {
  return cells.every((c) => c === null || c === undefined || String(c).trim() === '');
}

function normalizeCarat(v: unknown): string {
  const s = cellToString(v);
  if (!s) return 'ALL';
  const n = Number(s.replace(/,/g, ''));
  if (Number.isFinite(n) && n > 0) {
    return String(Math.round(n * 100) / 100);
  }
  return s.toUpperCase().replace(/\s+/g, '') || 'ALL';
}

function normalizeDesign(v: unknown): string {
  return cellToString(v).toUpperCase().replace(/\s+/g, '');
}

function normalizeOutlet(v: unknown): string {
  return cellToString(v).toUpperCase().replace(/\s+/g, '');
}

function matrixFromCsv(buf: Buffer): { headers: string[]; rows: unknown[][] } {
  const text = buf.toString('utf8');
  const records = csvParse(text, {
    relax_column_count: true,
    skip_empty_lines: true,
    trim: true,
    bom: true,
  }) as unknown[][];
  if (!records.length) return { headers: [], rows: [] };
  const headers = records[0].map((h) => cellToString(h));
  const rows = records.slice(1).filter((r) => !isEmptyRow(r));
  return { headers, rows };
}

async function matrixFromExcel(
  buf: Buffer,
  sheetName?: string,
): Promise<{ headers: string[]; rows: unknown[][]; sheetName: string }> {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buf as unknown as ExcelJS.Buffer);
  const sheet =
    (sheetName && wb.getWorksheet(sheetName)) ||
    wb.worksheets.find((ws) => ws.actualRowCount > 1) ||
    wb.worksheets[0];
  if (!sheet) return { headers: [], rows: [], sheetName: '' };

  const matrix: unknown[][] = [];
  sheet.eachRow({ includeEmpty: false }, (row) => {
    const values = row.values as unknown[];
    const cells = values.slice(1).map((v) => {
      if (v && typeof v === 'object' && 'result' in (v as object)) {
        return (v as { result: unknown }).result;
      }
      if (v && typeof v === 'object' && 'text' in (v as object)) {
        return (v as { text: string }).text;
      }
      return v ?? '';
    });
    matrix.push(cells);
  });

  if (!matrix.length) return { headers: [], rows: [], sheetName: sheet.name };
  const headers = matrix[0].map((h) => cellToString(h));
  const rows = matrix.slice(1).filter((r) => !isEmptyRow(r));
  return { headers, rows, sheetName: sheet.name };
}

function detectKind(
  mapping: Partial<Record<CanonicalField, number>>,
  headers: string[],
  forced?: ParseKind,
): ParseKind {
  if (forced && forced !== 'auto') return forced;
  const joined = headers.map((h) => h.toLowerCase()).join('|');
  if (/sold|sale|sales/.test(joined) || mapping.sold !== undefined) return 'sold';
  if (/stock|closing|on.?hand|balance/.test(joined) || mapping.stock !== undefined) return 'stock';
  if (mapping.qty !== undefined && mapping.design !== undefined) return 'stock';
  return 'auto';
}

function requiredFields(kind: ParseKind): CanonicalField[] {
  if (kind === 'scheme') return ['design', 'qty'];
  return ['outlet', 'design', 'qty'];
}

function optionalFields(kind: ParseKind): CanonicalField[] {
  const base: CanonicalField[] = ['carat', 'category', 'gWt', 'nWt', 'dWt', 'sku', 'date', 'branch'];
  if (kind === 'sold') return [...base, 'sold', 'pcs'];
  if (kind === 'stock') return [...base, 'stock', 'pcs'];
  return [...base, 'sold', 'stock', 'pcs'];
}

function pickQty(
  cells: unknown[],
  mapping: Partial<Record<CanonicalField, number>>,
  kind: ParseKind,
): number {
  const order: CanonicalField[] =
    kind === 'sold'
      ? ['sold', 'qty', 'pcs', 'stock']
      : kind === 'stock'
        ? ['stock', 'qty', 'pcs', 'sold']
        : ['qty', 'pcs', 'stock', 'sold'];
  for (const f of order) {
    const idx = mapping[f];
    if (idx !== undefined) {
      const n = cellToNumber(cells[idx]);
      if (n >= 0) return n;
    }
  }
  return 0;
}

function pickOutlet(
  cells: unknown[],
  mapping: Partial<Record<CanonicalField, number>>,
): string {
  for (const f of ['outlet', 'branch'] as CanonicalField[]) {
    const idx = mapping[f];
    if (idx !== undefined) {
      const s = normalizeOutlet(cells[idx]);
      if (s) return s;
    }
  }
  return '';
}

function pickDesign(
  cells: unknown[],
  mapping: Partial<Record<CanonicalField, number>>,
): string {
  for (const f of ['design', 'sku'] as CanonicalField[]) {
    const idx = mapping[f];
    if (idx !== undefined) {
      const s = normalizeDesign(cells[idx]);
      if (s) return s;
    }
  }
  return '';
}

function rowsFromMatrix(
  headers: string[],
  matrix: unknown[][],
  kind: ParseKind,
  minConfidence: number,
): Omit<ParseResult, 'sourceName' | 'sheetName'> {
  const required = requiredFields(kind);
  const optional = optionalFields(kind);
  const { mapping, confidence } = mapHeaders(headers, required, optional);
  const warnings: string[] = [];

  for (const f of required) {
    if (mapping[f] === undefined) {
      if (f === 'outlet' && mapping.branch !== undefined) {
        mapping.outlet = mapping.branch;
        confidence.outlet = confidence.branch ?? 70;
      } else if (f === 'qty' && (mapping.pcs !== undefined || mapping.sold !== undefined || mapping.stock !== undefined)) {
        mapping.qty = mapping.pcs ?? mapping.sold ?? mapping.stock;
        confidence.qty = 70;
      } else {
        warnings.push(`Missing column for "${f}" (auto-detect failed)`);
      }
    } else if ((confidence[f] ?? 0) < minConfidence) {
      warnings.push(`Low confidence mapping for "${f}" (${confidence[f]})`);
    }
  }

  const rows: ParsedInventoryRow[] = [];
  let skipped = 0;

  for (const cells of matrix) {
    const outletCode = pickOutlet(cells, mapping);
    const designCode = pickDesign(cells, mapping);
    const qty = pickQty(cells, mapping, kind);

    if (!designCode || (kind !== 'scheme' && !outletCode)) {
      skipped++;
      continue;
    }
    if (qty < 0) {
      skipped++;
      continue;
    }

    const caratIdx = mapping.carat;
    const catIdx = mapping.category;
    const gIdx = mapping.gWt;
    const nIdx = mapping.nWt;
    const dIdx = mapping.dWt;

    const row: ParsedInventoryRow = {
      outletCode: outletCode || 'SCHEME',
      designCode,
      caratKey: caratIdx !== undefined ? normalizeCarat(cells[caratIdx]) : 'ALL',
      qty,
    };
    if (catIdx !== undefined) {
      const c = cellToString(cells[catIdx]);
      if (c) row.category = c;
    }
    if (gIdx !== undefined) row.gWt = cellToNumber(cells[gIdx]);
    if (nIdx !== undefined) row.nWt = cellToNumber(cells[nIdx]);
    if (dIdx !== undefined) row.dWt = cellToNumber(cells[dIdx]);

    rows.push(row);
  }

  return {
    kind,
    headers,
    mapping,
    confidence,
    rows,
    skipped,
    warnings,
  };
}

export class FileParserService {
  async parseBuffer(
    buf: Buffer,
    sourceName: string,
    options: ParseOptions = {},
  ): Promise<ParseResult> {
    const name = sourceName.toLowerCase();
    const isCsv = name.endsWith('.csv') || name.endsWith('.txt');
    let headers: string[];
    let matrix: unknown[][];
    let sheetName: string | undefined;

    if (isCsv) {
      const m = matrixFromCsv(buf);
      headers = m.headers;
      matrix = m.rows;
    } else {
      const m = await matrixFromExcel(buf, options.sheetName);
      headers = m.headers;
      matrix = m.rows;
      sheetName = m.sheetName;
    }

    if (!headers.length) {
      return {
        kind: options.kind || 'auto',
        sourceName,
        sheetName,
        headers: [],
        mapping: {},
        confidence: {},
        rows: [],
        skipped: 0,
        warnings: ['File has no header row'],
      };
    }

    const kind = detectKind(
      mapHeaders(headers, ['outlet', 'design', 'qty'], ['sold', 'stock']).mapping,
      headers,
      options.kind,
    );
    const partial = rowsFromMatrix(
      headers,
      matrix,
      kind,
      options.minConfidence ?? 60,
    );

    return {
      ...partial,
      sourceName,
      sheetName,
    };
  }

  async parseStock(buf: Buffer, sourceName: string, sheetName?: string): Promise<ParseResult> {
    return this.parseBuffer(buf, sourceName, { kind: 'stock', sheetName });
  }

  async parseSold(buf: Buffer, sourceName: string, sheetName?: string): Promise<ParseResult> {
    return this.parseBuffer(buf, sourceName, { kind: 'sold', sheetName });
  }

  async parseScheme(buf: Buffer, sourceName: string, sheetName?: string): Promise<ParseResult> {
    return this.parseBuffer(buf, sourceName, { kind: 'scheme', sheetName });
  }

  aggregateByOutletDesign(rows: ParsedInventoryRow[]): Map<string, number> {
    const map = new Map<string, number>();
    for (const r of rows) {
      const key = `${r.outletCode}|${r.designCode}|${r.caratKey}`;
      map.set(key, (map.get(key) || 0) + r.qty);
    }
    return map;
  }

  toNestedMaps(
    rows: ParsedInventoryRow[],
  ): Record<string, Record<string, Record<string, number>>> {
    const out: Record<string, Record<string, Record<string, number>>> = {};
    for (const r of rows) {
      if (!out[r.designCode]) out[r.designCode] = {};
      if (!out[r.designCode][r.outletCode]) out[r.designCode][r.outletCode] = {};
      const prev = out[r.designCode][r.outletCode][r.caratKey] || 0;
      out[r.designCode][r.outletCode][r.caratKey] = prev + r.qty;
    }
    return out;
  }
}

export const fileParserService = new FileParserService();
