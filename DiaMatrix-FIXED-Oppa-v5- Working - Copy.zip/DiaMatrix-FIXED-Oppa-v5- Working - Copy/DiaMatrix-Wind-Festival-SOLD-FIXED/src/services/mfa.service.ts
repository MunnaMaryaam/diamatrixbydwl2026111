import { logger } from '../lib/logger.js';
import {
  randomNumericCode,
  randomToken,
  sha256Hex,
  signJwt,
  verifyJwt,
  verifyTotp,
} from '../lib/crypto.js';
import { env } from '../config/env.js';
import type { StoredUser } from '../repositories/user.repository.js';
import { asAuthUser, findById } from '../repositories/user.repository.js';
import { UnauthorizedError, ValidationError } from '../lib/errors.js';

export type MfaMethod = 'totp' | 'email' | 'sms';

interface Challenge {
  id: string;
  userId: string;
  methods: MfaMethod[];
  /** method → code hash (for email/sms). TOTP verified against user secret. */
  codeHashes: Partial<Record<'email' | 'sms', string>>;
  expiresAt: number;
  attempts: number;
}

const challenges = new Map<string, Challenge>();
const MFA_TTL_MS = 5 * 60 * 1000;
const MAX_ATTEMPTS = 5;

function availableMethods(user: StoredUser): MfaMethod[] {
  const methods: MfaMethod[] = [];
  if (user.totpSecret && user.totpConfirmed) methods.push('totp');
  if (user.email) methods.push('email');
  if (user.phone) methods.push('sms');
  // Always allow at least TOTP if MFA is on; if no channels, force totp enrollment path
  if (methods.length === 0 && user.mfaEnabled) methods.push('totp');
  return methods;
}

/** After password OK: create MFA challenge and return opaque mfaToken. */
export function startMfaChallenge(user: StoredUser): {
  mfaToken: string;
  methods: MfaMethod[];
  emailHint?: string;
  phoneHint?: string;
} {
  const methods = availableMethods(user);
  const id = randomToken(24);
  challenges.set(id, {
    id,
    userId: user.id,
    methods,
    codeHashes: {},
    expiresAt: Date.now() + MFA_TTL_MS,
    attempts: 0,
  });

  // Auto-send email + SMS OTP when those channels exist (owner wants code on login attempt)
  if (methods.includes('email')) {
    void sendOtp(id, 'email');
  }
  if (methods.includes('sms')) {
    void sendOtp(id, 'sms');
  }

  return {
    mfaToken: id,
    methods,
    emailHint: user.email ? maskEmail(user.email) : undefined,
    phoneHint: user.phone ? maskPhone(user.phone) : undefined,
  };
}

function maskEmail(email: string): string {
  const [local, domain] = email.split('@');
  if (!domain) return '***';
  const vis = local.slice(0, Math.min(2, local.length));
  return `${vis}***@${domain}`;
}

function maskPhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.length < 4) return '***';
  return `***${digits.slice(-4)}`;
}

export async function sendOtp(
  mfaToken: string,
  method: 'email' | 'sms',
): Promise<{ sent: boolean; hint?: string }> {
  const ch = challenges.get(mfaToken);
  if (!ch || ch.expiresAt < Date.now()) {
    throw new UnauthorizedError('MFA session expired. Sign in again.');
  }
  if (!ch.methods.includes(method)) {
    throw new ValidationError(`MFA method ${method} is not available for this account.`);
  }
  const user = findById(ch.userId);
  if (!user) throw new UnauthorizedError('User not found.');

  const code = randomNumericCode(6);
  ch.codeHashes[method] = sha256Hex(`${ch.id}:${method}:${code}`);

  if (method === 'email') {
    await deliverEmail(user, code);
    return { sent: true, hint: user.email ? maskEmail(user.email) : undefined };
  }
  await deliverSms(user, code);
  return { sent: true, hint: user.phone ? maskPhone(user.phone) : undefined };
}

async function deliverEmail(user: StoredUser, code: string): Promise<void> {
  const to = user.email;
  if (!to) {
    logger.warn('MFA email skipped — no email on user', { userId: user.id });
    return;
  }
  // Production: wire SMTP / Resend / SES via env
  // OWNER_NOTIFY_EMAIL can receive a copy so the owner always sees login codes
  const notifyExtra = process.env.OWNER_NOTIFY_EMAIL?.trim();
  logger.info('MFA email OTP (dev delivery — configure SMTP for production)', {
    to,
    notifyExtra: notifyExtra || null,
    code, // visible in server logs in development only
    username: user.username,
  });
  if (env.NODE_ENV !== 'production') {
    console.log(`\n[DiaMatrix MFA] Email OTP for ${user.username} → ${to}: ${code}\n`);
  }
  // Optional webhook-style hook
  const webhook = process.env.MFA_EMAIL_WEBHOOK_URL?.trim();
  if (webhook) {
    try {
      await fetch(webhook, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to,
          subject: 'DiaMatrix login code',
          text: `Your DiaMatrix verification code is ${code}. It expires in 5 minutes.`,
          code,
          username: user.username,
        }),
      });
    } catch (err) {
      logger.error('MFA email webhook failed', { err: String(err) });
    }
  }
}

async function deliverSms(user: StoredUser, code: string): Promise<void> {
  const to = user.phone;
  if (!to) {
    logger.warn('MFA SMS skipped — no phone on user', { userId: user.id });
    return;
  }
  logger.info('MFA SMS OTP (dev delivery — configure Twilio for production)', {
    to: maskPhone(to),
    code,
    username: user.username,
  });
  if (env.NODE_ENV !== 'production') {
    console.log(`\n[DiaMatrix MFA] SMS OTP for ${user.username} → ${to}: ${code}\n`);
  }
  const webhook = process.env.MFA_SMS_WEBHOOK_URL?.trim();
  if (webhook) {
    try {
      await fetch(webhook, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to,
          text: `DiaMatrix code: ${code}. Expires in 5 minutes.`,
          code,
          username: user.username,
        }),
      });
    } catch (err) {
      logger.error('MFA SMS webhook failed', { err: String(err) });
    }
  }
}

export function verifyMfa(
  mfaToken: string,
  code: string,
  method?: MfaMethod,
): { token: string; user: ReturnType<typeof asAuthUser> } {
  const ch = challenges.get(mfaToken);
  if (!ch || ch.expiresAt < Date.now()) {
    challenges.delete(mfaToken);
    throw new UnauthorizedError('MFA session expired. Sign in again.');
  }
  if (ch.attempts >= MAX_ATTEMPTS) {
    challenges.delete(mfaToken);
    throw new UnauthorizedError('Too many MFA attempts. Sign in again.');
  }
  ch.attempts += 1;

  const user = findById(ch.userId);
  if (!user) throw new UnauthorizedError('User not found.');

  const tryMethods: MfaMethod[] = method
    ? [method]
    : ch.methods;

  let ok = false;
  for (const m of tryMethods) {
    if (m === 'totp') {
      if (user.totpSecret && verifyTotp(user.totpSecret, code)) {
        ok = true;
        break;
      }
    } else {
      const expected = ch.codeHashes[m];
      if (expected && expected === sha256Hex(`${ch.id}:${m}:${String(code).replace(/\s/g, '')}`)) {
        ok = true;
        break;
      }
    }
  }

  if (!ok) {
    throw new UnauthorizedError('Invalid verification code.');
  }

  challenges.delete(mfaToken);
  const sessionToken = signJwt(
    {
      sub: user.id,
      username: user.username,
      role: user.role,
      isOwner: user.isOwner,
    },
    env.JWT_SECRET,
    60 * 60 * 12,
  );

  return { token: sessionToken, user: asAuthUser(user) };
}

/** Short-lived token proving password step passed (alternative to opaque id). */
export function issuePasswordProof(userId: string): string {
  return signJwt({ sub: userId, stage: 'mfa' }, env.JWT_SECRET, 5 * 60);
}

export function readPasswordProof(token: string): string | null {
  const body = verifyJwt(token, env.JWT_SECRET);
  if (!body || body.stage !== 'mfa' || typeof body.sub !== 'string') return null;
  return body.sub;
}
