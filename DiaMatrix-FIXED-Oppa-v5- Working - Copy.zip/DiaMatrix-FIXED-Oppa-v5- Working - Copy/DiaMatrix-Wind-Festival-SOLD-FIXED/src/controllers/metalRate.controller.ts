import type { Request, Response, NextFunction } from 'express';
import { metalRateService } from '../services/metalRate.service.js';
import { ok } from '../types/api.js';

export async function getRates(_req: Request, res: Response, next: NextFunction) {
  try {
    const data = await metalRateService.getRates();
    res.json(ok(data));
  } catch (e) {
    next(e);
  }
}
