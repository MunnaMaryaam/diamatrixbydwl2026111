import type { Request, Response, NextFunction } from 'express';
import { festivalService } from '../services/festival.service.js';
import { ok } from '../types/api.js';
import type { FestivalAllocateBody } from '../schemas/festival.schema.js';

export async function allocate(req: Request, res: Response, next: NextFunction) {
  try {
    const data = festivalService.allocate(req.body as FestivalAllocateBody);
    res.json(ok(data));
  } catch (e) {
    next(e);
  }
}
