import type { Request, Response } from 'express';
import { APP_NAME, APP_SLOGAN } from '../config/constants.js';
import { isSupabaseConfigured } from '../config/supabase.js';
import { ok } from '../types/api.js';

export function health(_req: Request, res: Response) {
  res.json(
    ok({
      app: APP_NAME,
      slogan: APP_SLOGAN,
      status: 'ok',
      supabase: isSupabaseConfigured(),
      time: new Date().toISOString(),
    }),
  );
}
