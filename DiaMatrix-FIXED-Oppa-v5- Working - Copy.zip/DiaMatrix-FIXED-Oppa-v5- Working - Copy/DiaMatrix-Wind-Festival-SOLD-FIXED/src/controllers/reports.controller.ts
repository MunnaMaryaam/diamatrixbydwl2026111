import type { Request, Response, NextFunction } from 'express';
import { reportService } from '../services/report.service.js';
import { ok } from '../types/api.js';
import type { RedistributionReportBody } from '../schemas/redistribution.schema.js';

export async function cockpit(req: Request, res: Response, next: NextFunction) {
  try {
    const body = (Object.keys(req.body || {}).length ? req.body : req.query) as RedistributionReportBody;
    const data = await reportService.cockpit({
      timeframe: body.timeframe || '3M',
      logic: body.logic || 'hybrid',
      design: body.design,
      branch: body.branch,
      ctsFrom: body.ctsFrom,
      ctsTo: body.ctsTo,
    });
    res.json(ok(data));
  } catch (e) {
    next(e);
  }
}
