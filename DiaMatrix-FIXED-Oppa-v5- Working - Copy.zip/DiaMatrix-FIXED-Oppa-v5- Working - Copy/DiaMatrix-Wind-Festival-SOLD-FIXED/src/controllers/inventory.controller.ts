import type { Request, Response, NextFunction } from 'express';
import { inventoryService } from '../services/inventory.service.js';
import { ok } from '../types/api.js';
import type { InventoryUploadBody } from '../schemas/inventory.schema.js';

export async function getStock(req: Request, res: Response, next: NextFunction) {
  try {
    const data = await inventoryService.getStock({
      outlet: req.query.outlet as string | undefined,
      design: req.query.design as string | undefined,
      carat: req.query.carat as string | undefined,
    });
    res.json(ok(data));
  } catch (e) {
    next(e);
  }
}

export async function getSales(req: Request, res: Response, next: NextFunction) {
  try {
    const data = await inventoryService.getSales({
      outlet: req.query.outlet as string | undefined,
      design: req.query.design as string | undefined,
      periodMonths: req.query.periodMonths
        ? Number(req.query.periodMonths)
        : undefined,
    });
    res.json(ok(data));
  } catch (e) {
    next(e);
  }
}

export async function upload(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await inventoryService.upload(req.body as InventoryUploadBody);
    res.status(201).json(ok(result));
  } catch (e) {
    next(e);
  }
}

export async function sellThrough(_req: Request, res: Response, next: NextFunction) {
  try {
    const data = await inventoryService.sellThroughSummary();
    res.json(ok(data));
  } catch (e) {
    next(e);
  }
}
