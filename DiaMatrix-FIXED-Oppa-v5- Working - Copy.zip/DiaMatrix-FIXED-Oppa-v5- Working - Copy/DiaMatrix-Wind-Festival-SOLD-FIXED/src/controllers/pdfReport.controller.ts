import type { Request, Response, NextFunction } from 'express';
import { labelPdfToExcelBuffer } from '../shared/label-pdf-report/node.js';
import { ValidationError } from '../lib/errors.js';
import { ok } from '../types/api.js';

/** POST /pdf-report/to-excel   multipart field "file" (PDF).   ?format=json → parsed data only */
export async function pdfToExcel(req: Request, res: Response, next: NextFunction) {
  try {
    const file = (req as Request & { file?: Express.Multer.File }).file;
    if (!file?.buffer) throw new ValidationError('Multipart file field "file" is required');
    if (file.buffer.subarray(0, 5).toString('latin1') !== '%PDF-') {
      throw new ValidationError('The uploaded file is not a PDF');
    }

    const includeDesign = req.query.includeDesign === '1' || req.query.includeDesign === 'true';
    const { xlsx, report } = await labelPdfToExcelBuffer(file.buffer, { includeDesign });

    if (req.query.format === 'json') {
      const { images: _images, ...rest } = report;
      res.json(ok(rest));
      return;
    }

    const base = (file.originalname || 'Branch_Report').replace(/\.pdf$/i, '').replace(/[^\w.-]+/g, '_');
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${base}_Branch_Report.xlsx"`);
    res.setHeader('X-Card-Count', String(report.sections.reduce((a, s) => a + s.cards.length, 0)));
    res.setHeader('X-Warning-Count', String(report.warnings.length));
    res.send(xlsx);
  } catch (e) {
    next(e);
  }
}
