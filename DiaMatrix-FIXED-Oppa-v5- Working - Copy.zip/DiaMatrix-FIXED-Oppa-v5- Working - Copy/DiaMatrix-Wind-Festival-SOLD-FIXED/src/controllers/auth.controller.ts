import type { Request, Response, NextFunction } from 'express';
import { authService } from '../services/auth.service.js';
import { ok } from '../types/api.js';
import type { LoginBody, MfaSendBody, MfaVerifyBody } from '../schemas/auth.schema.js';
import { env } from '../config/env.js';

export async function login(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await authService.login(req.body as LoginBody);
    res.json(ok(result));
  } catch (e) {
    next(e);
  }
}

export async function mfaSend(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await authService.sendMfaCode(req.body as MfaSendBody);
    res.json(ok(result));
  } catch (e) {
    next(e);
  }
}

export async function mfaVerify(req: Request, res: Response, next: NextFunction) {
  try {
    const result = await authService.verifyMfa(req.body as MfaVerifyBody);
    res.json(ok(result));
  } catch (e) {
    next(e);
  }
}

export async function me(req: Request, res: Response, next: NextFunction) {
  try {
    const user = await authService.me(req.user!);
    res.json(ok({ authenticated: true, user }));
  } catch (e) {
    next(e);
  }
}

/** Dev-only: show owner TOTP enrollment details (never in production). */
export async function totpSetup(_req: Request, res: Response, next: NextFunction) {
  try {
    if (env.NODE_ENV === 'production') {
      res.status(404).json({ ok: false, error: { code: 'NOT_FOUND', message: 'Not found' } });
      return;
    }
    res.json(ok(authService.getTotpSetupForOwner()));
  } catch (e) {
    next(e);
  }
}
