import type { Request, Response, NextFunction } from 'express';
import { fileParserService } from '../services/fileParser.service.js';
import { ok } from '../types/api.js';
import { ValidationError } from '../lib/errors.js';

export async function parseUpload(req: Request, res: Response, next: NextFunction) {
  try {
    const file = (req as Request & { file?: Express.Multer.File }).file;
    if (!file?.buffer) {
      throw new ValidationError('Multipart file field "file" is required');
    }
    const kind = (req.body?.kind as string) || 'auto';
    const sheetName = req.body?.sheetName as string | undefined;
    const result = await fileParserService.parseBuffer(file.buffer, file.originalname || 'upload', {
      kind: kind as 'stock' | 'sold' | 'scheme' | 'auto',
      sheetName,
    });
    res.json(
      ok({
        ...result,
        nested: fileParserService.toNestedMaps(result.rows),
      }),
    );
  } catch (e) {
    next(e);
  }
}
