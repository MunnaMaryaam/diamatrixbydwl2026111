import type { Request, Response, NextFunction } from 'express';
import { analyzeHaveVsDeserve } from '../services/analyze.service.js';
import { ok } from '../types/api.js';
import type { AnalyzeBody } from '../schemas/analyze.schema.js';

export async function analyze(req: Request, res: Response, next: NextFunction) {
  try {
    const data = analyzeHaveVsDeserve(req.body as AnalyzeBody);
    res.json(ok(data));
  } catch (e) {
    next(e);
  }
}
