import type { Request, Response, NextFunction } from 'express';
import { redistributionService } from '../services/redistribution.service.js';
import { ok } from '../types/api.js';
import type { RedistributionReportBody } from '../schemas/redistribution.schema.js';

export async function report(req: Request, res: Response, next: NextFunction) {
  try {
    const data = await redistributionService.buildReport(req.body as RedistributionReportBody);
    res.json(ok(data));
  } catch (e) {
    next(e);
  }
}
