/**
 * Browser wiring (Vite app):  pdfjs-dist + exceljs (exceljs is already used in this project)
 *   npm i pdfjs-dist
 */
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import * as ExcelJS from 'exceljs';
import {
  buildLabelWorkbook,
  imageToRgba,
  parseLabelPdf,
  type EncodedImage,
  type LabelImage,
  type LabelReport,
} from './core';

(pdfjsLib as any).GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

async function encodePng(img: LabelImage): Promise<EncodedImage> {
  const rgba = imageToRgba(img);
  const data = new ImageData(rgba as any, img.width, img.height);
  let blob: Blob;
  if (typeof OffscreenCanvas !== 'undefined') {
    const canvas = new OffscreenCanvas(img.width, img.height);
    canvas.getContext('2d')!.putImageData(data, 0, 0);
    blob = await canvas.convertToBlob({ type: 'image/png' });
  } else {
    const canvas = document.createElement('canvas');
    canvas.width = img.width;
    canvas.height = img.height;
    canvas.getContext('2d')!.putImageData(data, 0, 0);
    blob = await new Promise<Blob>((res, rej) =>
      canvas.toBlob((b) => (b ? res(b) : rej(new Error('PNG encode failed'))), 'image/png'),
    );
  }
  return { buffer: await blob.arrayBuffer(), extension: 'png' };
}

/** Step 1 — read the PDF. Cheap; show the summary to the user. */
export async function readLabelPdf(file: File): Promise<LabelReport> {
  return parseLabelPdf(pdfjsLib as any, await file.arrayBuffer());
}

/** Step 2 — build the Excel file from a parsed report. */
export async function buildLabelExcelBlob(
  report: LabelReport,
  opts: { includeDesign?: boolean; title?: string } = {},
): Promise<Blob> {
  const wb = await buildLabelWorkbook(ExcelJS as any, report, { encodeImage: encodePng, ...opts });
  const buf = await wb.xlsx.writeBuffer();
  return new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

export function downloadBlob(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
