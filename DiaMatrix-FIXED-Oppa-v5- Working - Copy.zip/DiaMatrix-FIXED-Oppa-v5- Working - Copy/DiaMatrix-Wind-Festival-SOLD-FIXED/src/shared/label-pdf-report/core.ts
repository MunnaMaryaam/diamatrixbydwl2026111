/**
 * Label-PDF → Branch-wise Excel report (core, environment independent).
 *
 * Input : the "D.NOSEPIN"-style label PDF (cards grouped by branch; every card has
 *         image, barcode, carat, net/gross weight, price, design code + date).
 * Output: a parsed `LabelReport` and an ExcelJS workbook (Image · Barcode · Carat ·
 *         Gross Wt · Net Wt · Price) grouped branch-wise with formula totals.
 *
 * pdfjs-dist and exceljs are INJECTED so the same code runs in the browser and in Node:
 *   - browser wiring : ./browser.ts
 *   - node wiring    : ./node.ts
 */
import type * as ExcelNS from 'exceljs';

/* ───────────────────────────── types ───────────────────────────── */

export interface PdfJsLike {
  getDocument: (src: Record<string, unknown>) => { promise: Promise<any> };
  OPS: Record<string, number>;
}

export interface LabelImage {
  width: number;
  height: number;
  /** 1 = packed 1-bit gray, 3 = RGB, 4 = RGBA (pdf.js ImageKind) */
  kind: 1 | 2 | 3;
  data: Uint8Array | Uint8ClampedArray;
}

export interface LabelCard {
  branch: string;
  category: string;
  barcode: string;
  price: number | null;
  carat: number | null;
  /** Upper rotated value on the label (e.g. 0.26) */
  netWt: number | null;
  /** Lower rotated value on the label (e.g. .2634) */
  grossWt: number | null;
  designCode: string;
  designDate: string;
  imageKey: string | null;
  page: number;
}

export interface LabelSection {
  branch: string;
  category: string;
  /** Count printed in the PDF section header (used to cross-check) */
  declaredCount: number | null;
  cards: LabelCard[];
}

export interface LabelReport {
  runOn: string;
  pageCount: number;
  sections: LabelSection[];
  images: Map<string, LabelImage>;
  warnings: string[];
}

export interface ParseOptions {
  /** Minimum header font size (pt) that identifies BRANCH / CATEGORY lines. Default 10.5 */
  headerMinFontSize?: number;
  /** Header lines must start left of this x (pt). Default 20 */
  headerMaxX?: number;
}

/* ───────────────────────────── helpers ───────────────────────────── */

interface Piece {
  str: string;
  x: number;
  y: number;
  size: number;
  rotated: boolean;
}
interface Placement {
  name: string;
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}
interface Header {
  y: number;
  branch: string;
  category: string;
  declaredCount: number | null;
}

const NUM_RE = /^\d*\.\d+$/;
const BARCODE_RE = /^\d{8,14}$/;
const PRICE_RE = /^(\d{1,3}(,\d{3})+|\d{3,7})$/;

const toU8 = (d: ArrayBuffer | Uint8Array): Uint8Array =>
  d instanceof Uint8Array ? new Uint8Array(d) : new Uint8Array(d);

function mul(a: number[], b: number[]): number[] {
  return [
    a[0] * b[0] + a[1] * b[2],
    a[0] * b[1] + a[1] * b[3],
    a[2] * b[0] + a[3] * b[2],
    a[2] * b[1] + a[3] * b[3],
    a[4] * b[0] + a[5] * b[2] + b[4],
    a[4] * b[1] + a[5] * b[3] + b[5],
  ];
}

/** Two independent 32-bit hashes → collision-safe key for de-duplicating identical images */
function hashImage(img: LabelImage): string {
  let h1 = 0x811c9dc5;
  let h2 = 5381;
  const d = img.data;
  for (let i = 0; i < d.length; i++) {
    h1 = Math.imul(h1 ^ d[i], 0x01000193);
    h2 = (Math.imul(h2, 33) + d[i]) | 0;
  }
  return `${img.width}x${img.height}-${(h1 >>> 0).toString(16)}${(h2 >>> 0).toString(16)}`;
}

async function getPageObj(page: any, name: string): Promise<any> {
  const store = name.startsWith('g_') ? page.commonObjs : page.objs;
  return new Promise((resolve) => store.get(name, resolve));
}

/** Convert a pdf.js image object into RGBA bytes (for PNG encoders). */
export function imageToRgba(img: LabelImage): Uint8ClampedArray {
  const { width: w, height: h, data } = img;
  const out = new Uint8ClampedArray(w * h * 4);
  if (img.kind === 3) {
    out.set(data.subarray(0, w * h * 4));
  } else if (img.kind === 2) {
    for (let i = 0, j = 0; i < w * h; i++, j += 3) {
      out[i * 4] = data[j];
      out[i * 4 + 1] = data[j + 1];
      out[i * 4 + 2] = data[j + 2];
      out[i * 4 + 3] = 255;
    }
  } else {
    const rowBytes = Math.ceil(w / 8);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const bit = (data[y * rowBytes + (x >> 3)] >> (7 - (x & 7))) & 1;
        const v = bit ? 255 : 0;
        const o = (y * w + x) * 4;
        out[o] = out[o + 1] = out[o + 2] = v;
        out[o + 3] = 255;
      }
    }
  }
  return out;
}

/* ───────────────────────────── PDF → LabelReport ───────────────────────────── */

export async function parseLabelPdf(
  pdfjs: PdfJsLike,
  pdf: ArrayBuffer | Uint8Array,
  opts: ParseOptions = {},
): Promise<LabelReport> {
  const headerMinSize = opts.headerMinFontSize ?? 10.5;
  const headerMaxX = opts.headerMaxX ?? 20;
  const OPS = pdfjs.OPS;

  const doc = await pdfjs.getDocument({
    data: toU8(pdf),
    useSystemFonts: true,
    disableFontFace: true,
    isImageDecoderSupported: false,
    verbosity: 0,
  }).promise;

  const warnings: string[] = [];
  const images = new Map<string, LabelImage>();
  const sections: LabelSection[] = [];
  const sectionIndex = new Map<string, LabelSection>();
  let runOn = '';
  let carry: Header | null = null;

  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);

    /* ---- text ---- */
    const tc = await page.getTextContent();
    const pieces: Piece[] = [];
    for (const it of tc.items as any[]) {
      if (typeof it.str !== 'string') continue;
      const str = it.str.trim();
      if (!str) continue;
      const t = it.transform as number[];
      const size = Math.hypot(t[0], t[1]);
      pieces.push({ str, x: t[4], y: t[5], size, rotated: Math.abs(t[1]) > Math.abs(t[0]) });
    }

    const runPiece = pieces.find((s) => /^Report run on/i.test(s.str));
    if (runPiece && !runOn) {
      runOn = pieces
        .filter((s) => Math.abs(s.y - runPiece.y) < 1 && !s.rotated)
        .sort((a, b) => a.x - b.x)
        .map((s) => s.str)
        .join(' ');
    }

    /* ---- images (with position) ---- */
    const ops = await page.getOperatorList();
    let ctm = [1, 0, 0, 1, 0, 0];
    const stack: number[][] = [];
    const placements: Placement[] = [];
    for (let i = 0; i < ops.fnArray.length; i++) {
      const fn = ops.fnArray[i];
      const args = ops.argsArray[i];
      if (fn === OPS.save) stack.push(ctm.slice());
      else if (fn === OPS.restore) ctm = stack.pop() ?? ctm;
      else if (fn === OPS.transform) ctm = mul(args as number[], ctm);
      else if (fn === OPS.paintImageXObject) {
        const xs = [ctm[4], ctm[4] + ctm[0], ctm[4] + ctm[2], ctm[4] + ctm[0] + ctm[2]];
        const ys = [ctm[5], ctm[5] + ctm[1], ctm[5] + ctm[3], ctm[5] + ctm[1] + ctm[3]];
        placements.push({
          name: args[0] as string,
          x0: Math.min(...xs),
          x1: Math.max(...xs),
          y0: Math.min(...ys),
          y1: Math.max(...ys),
        });
      }
    }

    const nameToKey = new Map<string, string>();
    for (const name of new Set(placements.map((pl) => pl.name))) {
      const obj = await getPageObj(page, name);
      if (!obj || !obj.data) {
        warnings.push(`Page ${p}: image ${name} could not be decoded.`);
        continue;
      }
      const img: LabelImage = { width: obj.width, height: obj.height, kind: obj.kind, data: obj.data };
      const key = hashImage(img);
      if (!images.has(key)) images.set(key, img);
      nameToKey.set(name, key);
    }

    /* ---- section headers (BRANCH line + CATEGORY line + counts) ---- */
    const hdrItems = pieces
      .filter((s) => !s.rotated && s.size >= headerMinSize && s.x < headerMaxX && /[A-Za-z]/.test(s.str))
      .sort((a, b) => b.y - a.y);
    const headers: Header[] = [];
    for (let i = 0; i < hdrItems.length; ) {
      const a = hdrItems[i];
      const b = hdrItems[i + 1];
      const paired = b && a.y - b.y > 5 && a.y - b.y < 25;
      const catY = paired ? b.y : a.y;
      const nums = pieces
        .filter((s) => !s.rotated && s.size >= headerMinSize && Math.abs(s.y - catY) < 1.5 && s.x > 100 && /^\d+$/.test(s.str))
        .sort((m, n) => m.x - n.x);
      headers.push({
        y: a.y,
        branch: a.str,
        category: paired ? b.str : '',
        declaredCount: nums.length ? Number(nums[0].str) : null,
      });
      i += paired ? 2 : 1;
    }
    for (const h of headers) {
      const k = `${h.branch}|${h.category}`;
      if (!sectionIndex.has(k)) {
        const s: LabelSection = { branch: h.branch, category: h.category, declaredCount: h.declaredCount, cards: [] };
        sectionIndex.set(k, s);
        sections.push(s);
      }
    }

    /* ---- cards: one per image ---- */
    if (placements.length) {
      const lefts = [...new Set(placements.map((pl) => Math.round(pl.x0 * 10) / 10))].sort((a, b) => a - b);
      let pitch = 0;
      for (let i = 1; i < lefts.length; i++) {
        const d = lefts[i] - lefts[i - 1];
        if (d > 5 && (pitch === 0 || d < pitch)) pitch = d;
      }
      if (!pitch) pitch = 76.5;

      // ascending: first header whose y is above the card = the nearest header above it
      const sortedHeaders = [...headers].sort((a, b) => a.y - b.y);
      const ordered = [...placements].sort((a, b) =>
        Math.abs(a.y0 - b.y0) > 3 ? b.y0 - a.y0 : a.x0 - b.x0,
      );

      for (const pl of ordered) {
        const h = pl.y1 - pl.y0;
        const lo = pl.y0 - 0.51 * h;
        const hi = pl.y0 + 1.38 * h;
        const inCard = pieces.filter((s) => {
          const refX = s.rotated ? s.x - 4 : s.x;
          return refX >= pl.x0 - 1 && refX < pl.x0 + pitch - 1 && s.y >= lo && s.y <= hi;
        });

        const horiz = inCard.filter((s) => !s.rotated);
        const barcodes = horiz.filter((s) => BARCODE_RE.test(s.str));
        const bc = barcodes.sort((a, b) => Math.abs(a.y - (pl.y0 - 0.4 * h)) - Math.abs(b.y - (pl.y0 - 0.4 * h)))[0];
        if (!bc) {
          warnings.push(`Page ${p}: an image at x=${pl.x0.toFixed(0)}, y=${pl.y0.toFixed(0)} has no barcode — skipped.`);
          continue;
        }
        const priceP = horiz
          .filter((s) => PRICE_RE.test(s.str) && s !== bc)
          .sort((a, b) => Math.abs(a.y - bc.y) - Math.abs(b.y - bc.y))[0];
        const caratP = horiz.find((s) => NUM_RE.test(s.str) && Math.abs(s.y - bc.y) < 2);
        const rot = inCard.filter((s) => s.rotated && NUM_RE.test(s.str)).sort((a, b) => b.y - a.y);
        const labelParts = horiz.filter((s) => s.y > pl.y1 - 0.2 * h).sort((a, b) => b.y - a.y || a.x - b.x);
        let label = '';
        for (const part of labelParts) label += label && !label.endsWith('-') ? ` ${part.str}` : part.str;
        const m = label.match(/^(.+?),\s*\((.+)\)$/);

        const header = sortedHeaders.find((hd) => hd.y > pl.y0 - 1) ?? carry;
        const branch = header?.branch ?? 'UNKNOWN';
        const category = header?.category ?? '';
        const key = `${branch}|${category}`;
        let sec = sectionIndex.get(key);
        if (!sec) {
          sec = { branch, category, declaredCount: null, cards: [] };
          sectionIndex.set(key, sec);
          sections.push(sec);
        }

        const net = rot.length ? Number(rot[0].str) : null;
        const gross = rot.length > 1 ? Number(rot[1].str) : null;
        if (rot.length < 2) warnings.push(`Barcode ${bc.str}: expected 2 weight values, found ${rot.length}.`);
        if (net !== null && gross !== null && gross < net) warnings.push(`Barcode ${bc.str}: gross (${gross}) is less than net (${net}).`);
        if (!priceP) warnings.push(`Barcode ${bc.str}: price not found.`);

        sec.cards.push({
          branch,
          category,
          barcode: bc.str,
          price: priceP ? Number(priceP.str.replace(/,/g, '')) : null,
          carat: caratP ? Number(caratP.str) : null,
          netWt: net,
          grossWt: gross,
          designCode: m ? m[1] : label,
          designDate: m ? m[2] : '',
          imageKey: nameToKey.get(pl.name) ?? null,
          page: p,
        });
      }
    }
    if (sortedHeadersLast(headers)) carry = sortedHeadersLast(headers);
    page.cleanup?.();
  }
  await doc.destroy?.();

  for (const s of sections) {
    if (s.declaredCount !== null && s.declaredCount !== s.cards.length) {
      warnings.push(`${s.branch}: PDF header says ${s.declaredCount} pcs but ${s.cards.length} cards were read.`);
    }
  }
  if (!sections.some((s) => s.cards.length)) warnings.push('No label cards were found in this PDF.');

  return { runOn, pageCount: doc.numPages, sections, images, warnings };
}

function sortedHeadersLast(h: Header[]): Header | null {
  return h.length ? [...h].sort((a, b) => a.y - b.y)[0] : null;
}

/* ───────────────────────────── LabelReport → Excel ───────────────────────────── */

export interface EncodedImage {
  /** Buffer (Node) or ArrayBuffer/Uint8Array (browser) — whatever ExcelJS accepts in that runtime */
  buffer: any;
  extension: 'png' | 'jpeg';
}

export interface WorkbookOptions {
  encodeImage: (img: LabelImage) => Promise<EncodedImage>;
  title?: string;
  /** Add "Design No" and "Design Date" columns (off by default) */
  includeDesign?: boolean;
  /** Image size in px inside the sheet. Default 70 */
  imageSize?: number;
}

export async function buildLabelWorkbook(
  ExcelJS: typeof ExcelNS,
  report: LabelReport,
  opts: WorkbookOptions,
): Promise<ExcelNS.Workbook> {
  const F = 'Arial';
  const size = opts.imageSize ?? 70;
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Branch Report', { views: [{ state: 'frozen', ySplit: 4 }] });

  const heads = ['Sl', 'Image', 'Barcode', 'Carat', 'Gross Wt (gm)', 'Net Wt (gm)', 'Price'];
  const widths = [15, 14, 18, 10, 16, 14, 12];
  if (opts.includeDesign) {
    heads.push('Design No', 'Design Date');
    widths.push(22, 14);
  }
  const L = (i: number) => String.fromCharCode(64 + i); // 1 → A
  const nCols = heads.length;
  widths.forEach((w, i) => (ws.getColumn(i + 1).width = w));

  const thin = { style: 'thin' as const, color: { argb: 'FF999999' } };
  const border = { top: thin, left: thin, bottom: thin, right: thin };
  const fill = (argb: string) => ({ type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb } });

  const title = opts.title ?? `${report.sections[0]?.category || 'Label'} - Branch Wise Report`;
  ws.getCell('A1').value = title;
  ws.getCell('A1').font = { name: F, bold: true, size: 14 };
  ws.getCell('A2').value = report.runOn || '';
  ws.getCell('A2').font = { name: F, italic: true, size: 9 };

  heads.forEach((h, i) => {
    const c = ws.getCell(4, i + 1);
    c.value = h;
    c.font = { name: F, bold: true, color: { argb: 'FFFFFFFF' } };
    c.fill = fill('FF1F3864');
    c.alignment = { horizontal: 'center', vertical: 'middle' };
    c.border = border;
  });
  ws.getRow(4).height = 22;

  const imageIds = new Map<string, number>();
  for (const [key, img] of report.images) {
    const enc = await opts.encodeImage(img);
    imageIds.set(key, wb.addImage({ buffer: enc.buffer, extension: enc.extension }));
  }

  const fmt = { carat: '0.00', wt: '0.00##', price: '#,##0' };
  let r = 5;
  const totalRows: number[] = [];
  const totals = { pcs: 0, carat: 0, gross: 0, net: 0, price: 0 };

  for (const sec of report.sections) {
    if (!sec.cards.length) continue;
    for (let c = 1; c <= nCols; c++) {
      const cell = ws.getCell(r, c);
      cell.fill = fill('FFD9E1F2');
      cell.border = border;
    }
    ws.getCell(r, 1).value = sec.branch;
    ws.getCell(r, 1).font = { name: F, bold: true, size: 12 };
    r++;
    const first = r;
    let sCarat = 0, sGross = 0, sNet = 0, sPrice = 0;

    sec.cards.forEach((card, idx) => {
      ws.getRow(r).height = size * 0.83;
      const vals: (string | number | null)[] = [idx + 1, null, card.barcode, card.carat, card.grossWt, card.netWt, card.price];
      if (opts.includeDesign) vals.push(card.designCode, card.designDate);
      vals.forEach((v, i) => {
        const c = ws.getCell(r, i + 1);
        c.value = v;
        c.font = { name: F, size: 10 };
        c.border = border;
        c.alignment = { horizontal: 'center', vertical: 'middle' };
      });
      ws.getCell(r, 4).numFmt = fmt.carat;
      ws.getCell(r, 5).numFmt = fmt.wt;
      ws.getCell(r, 6).numFmt = fmt.wt;
      ws.getCell(r, 7).numFmt = fmt.price;
      const id = card.imageKey ? imageIds.get(card.imageKey) : undefined;
      if (id !== undefined) {
        ws.addImage(id, {
          tl: { col: 1 + (14 * 7 - size) / 2 / (14 * 7), row: r - 1 + 0.07 } as any,
          ext: { width: size, height: size },
        });
      }
      sCarat += card.carat ?? 0;
      sGross += card.grossWt ?? 0;
      sNet += card.netWt ?? 0;
      sPrice += card.price ?? 0;
      r++;
    });
    const last = r - 1;

    const put = (col: number, formula: string, result: string | number, numFmt?: string) => {
      const c = ws.getCell(r, col);
      c.value = { formula, result } as any;
      if (numFmt) c.numFmt = numFmt;
    };
    ws.getCell(r, 1).value = `${sec.branch} Total`;
    put(3, `COUNTA(C${first}:C${last})`, sec.cards.length, '0" pcs"');
    put(4, `SUM(D${first}:D${last})`, sCarat, fmt.carat);
    put(5, `SUM(E${first}:E${last})`, sGross, '0.0000');
    put(6, `SUM(F${first}:F${last})`, sNet, fmt.wt);
    put(7, `SUM(G${first}:G${last})`, sPrice, fmt.price);
    for (let c = 1; c <= nCols; c++) {
      const cell = ws.getCell(r, c);
      cell.font = { name: F, bold: true };
      cell.fill = fill('FFF2F2F2');
      cell.border = border;
      cell.alignment = { horizontal: 'center' };
    }
    totalRows.push(r);
    totals.pcs += sec.cards.length;
    totals.carat += sCarat;
    totals.gross += sGross;
    totals.net += sNet;
    totals.price += sPrice;
    r += 2;
  }

  if (totalRows.length) {
    ws.getCell(r, 1).value = 'GRAND TOTAL';
    const sumOf = (col: string) => totalRows.map((t) => `${col}${t}`).join('+');
    const g = (col: number, formula: string, result: string | number, numFmt?: string) => {
      ws.getCell(r, col).value = { formula, result } as any;
      if (numFmt) ws.getCell(r, col).numFmt = numFmt;
    };
    g(3, sumOf('C'), totals.pcs, '0" pcs"');
    g(4, sumOf('D'), totals.carat, fmt.carat);
    g(5, sumOf('E'), totals.gross, '0.0000');
    g(6, sumOf('F'), totals.net, fmt.wt);
    g(7, sumOf('G'), totals.price, fmt.price);
    for (let c = 1; c <= nCols; c++) {
      const cell = ws.getCell(r, c);
      cell.font = { name: F, bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = fill('FF1F3864');
      cell.alignment = { horizontal: 'center' };
    }
    r += 2;
  }
  ws.getCell(r, 1).value =
    'Note: Gross Wt = lower weight printed on the label (e.g. .2634); Net Wt = upper weight (e.g. 0.26); Carat as printed on each label.';
  ws.getCell(r, 1).font = { name: F, italic: true, size: 9 };

  ws.pageSetup = { orientation: 'portrait', fitToPage: true, fitToWidth: 1, fitToHeight: 0 };
  return wb;
}
