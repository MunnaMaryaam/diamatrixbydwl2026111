/**
 * Node wiring (Express server / CLI):  pdfjs-dist (legacy build) + exceljs + pngjs
 *   npm i pdfjs-dist pngjs && npm i -D @types/pngjs
 */
import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import ExcelJS from 'exceljs';
import pngjs from 'pngjs';
import {
  buildLabelWorkbook,
  imageToRgba,
  parseLabelPdf,
  type LabelImage,
  type LabelReport,
  type ParseOptions,
} from './core.js';

function encodePng(img: LabelImage) {
  const png = new pngjs.PNG({ width: img.width, height: img.height });
  png.data = Buffer.from(imageToRgba(img).buffer);
  return Promise.resolve({ buffer: pngjs.PNG.sync.write(png), extension: 'png' as const });
}

export async function parseLabelPdfNode(pdf: Buffer | Uint8Array, opts?: ParseOptions): Promise<LabelReport> {
  return parseLabelPdf(pdfjs as any, pdf, opts);
}

export async function labelPdfToExcelBuffer(
  pdf: Buffer | Uint8Array,
  opts: { includeDesign?: boolean; title?: string } = {},
): Promise<{ xlsx: Buffer; report: LabelReport }> {
  const report = await parseLabelPdfNode(pdf);
  const wb = await buildLabelWorkbook(ExcelJS as any, report, { encodeImage: encodePng, ...opts });
  const xlsx = Buffer.from(await wb.xlsx.writeBuffer());
  return { xlsx, report };
}
