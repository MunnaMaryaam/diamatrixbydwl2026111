import { Router } from 'express';
import * as redistributionController from '../controllers/redistribution.controller.js';
import { validate } from '../middleware/validate.middleware.js';
import { authRequired } from '../middleware/auth.middleware.js';
import { redistributionReportBodySchema } from '../schemas/redistribution.schema.js';

const router = Router();

router.use(authRequired);
router.post(
  '/report',
  validate(redistributionReportBodySchema, 'body'),
  redistributionController.report,
);

export default router;
