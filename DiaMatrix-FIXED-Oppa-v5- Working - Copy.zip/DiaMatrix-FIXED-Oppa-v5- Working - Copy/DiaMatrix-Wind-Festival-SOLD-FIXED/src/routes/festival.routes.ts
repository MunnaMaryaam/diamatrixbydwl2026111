import { Router } from 'express';
import * as festivalController from '../controllers/festival.controller.js';
import { validate } from '../middleware/validate.middleware.js';
import { authRequired } from '../middleware/auth.middleware.js';
import { festivalAllocateBodySchema } from '../schemas/festival.schema.js';

const router = Router();

router.use(authRequired);
router.post(
  '/allocate',
  validate(festivalAllocateBodySchema, 'body'),
  festivalController.allocate,
);

export default router;
