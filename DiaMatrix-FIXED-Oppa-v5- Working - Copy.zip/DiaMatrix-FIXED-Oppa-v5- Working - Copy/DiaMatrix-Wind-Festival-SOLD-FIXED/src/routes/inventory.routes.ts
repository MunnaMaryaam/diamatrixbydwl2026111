import { Router } from 'express';
import * as inventoryController from '../controllers/inventory.controller.js';
import * as analyzeController from '../controllers/analyze.controller.js';
import * as fileParseController from '../controllers/fileParse.controller.js';
import multer from 'multer';
import { validate } from '../middleware/validate.middleware.js';
import { authRequired } from '../middleware/auth.middleware.js';
import {
  inventoryUploadBodySchema,
  stockQuerySchema,
  salesQuerySchema,
} from '../schemas/inventory.schema.js';
import { analyzeBodySchema } from '../schemas/analyze.schema.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

router.use(authRequired);

router.get('/stock', validate(stockQuerySchema, 'query'), inventoryController.getStock);
router.get('/sales', validate(salesQuerySchema, 'query'), inventoryController.getSales);
router.post('/upload', validate(inventoryUploadBodySchema, 'body'), inventoryController.upload);
router.get('/sell-through', inventoryController.sellThrough);
router.post('/analyze', validate(analyzeBodySchema, 'body'), analyzeController.analyze);
router.post('/parse', upload.single('file'), fileParseController.parseUpload);

export default router;
