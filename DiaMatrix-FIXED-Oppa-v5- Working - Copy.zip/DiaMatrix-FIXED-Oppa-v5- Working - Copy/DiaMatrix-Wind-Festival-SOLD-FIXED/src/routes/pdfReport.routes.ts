import { Router } from 'express';
import multer from 'multer';
import * as pdfReportController from '../controllers/pdfReport.controller.js';
import { authRequired } from '../middleware/auth.middleware.js';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

router.use(authRequired);
router.post('/to-excel', upload.single('file'), pdfReportController.pdfToExcel);

export default router;
