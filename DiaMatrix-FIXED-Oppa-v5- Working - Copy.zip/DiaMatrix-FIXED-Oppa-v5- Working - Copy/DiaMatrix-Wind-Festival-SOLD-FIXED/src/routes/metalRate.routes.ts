import { Router } from 'express';
import * as metalRateController from '../controllers/metalRate.controller.js';

const router = Router();

/** Public — no auth (header widget) */
router.get('/', metalRateController.getRates);

export default router;
