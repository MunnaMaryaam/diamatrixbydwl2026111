import { Router } from 'express';
import authRoutes from './auth.routes.js';
import inventoryRoutes from './inventory.routes.js';
import redistributionRoutes from './redistribution.routes.js';
import festivalRoutes from './festival.routes.js';
import reportsRoutes from './reports.routes.js';
import metalRateRoutes from './metalRate.routes.js';
import pdfReportRoutes from './pdfReport.routes.js';
import { health } from '../controllers/health.controller.js';

const router = Router();

router.get('/health', health);
router.use('/auth', authRoutes);
router.use('/inventory', inventoryRoutes);
router.use('/redistribution', redistributionRoutes);
router.use('/festival', festivalRoutes);
router.use('/reports', reportsRoutes);
router.use('/metal-rates', metalRateRoutes);
router.use('/pdf-report', pdfReportRoutes);

export default router;
