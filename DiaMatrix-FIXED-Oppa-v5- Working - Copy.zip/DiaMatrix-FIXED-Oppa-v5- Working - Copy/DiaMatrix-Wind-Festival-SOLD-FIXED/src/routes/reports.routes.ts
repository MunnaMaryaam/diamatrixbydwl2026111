import { Router } from 'express';
import * as reportsController from '../controllers/reports.controller.js';
import { authRequired } from '../middleware/auth.middleware.js';

const router = Router();

router.use(authRequired);
router.get('/cockpit', reportsController.cockpit);
router.post('/cockpit', reportsController.cockpit);

export default router;
