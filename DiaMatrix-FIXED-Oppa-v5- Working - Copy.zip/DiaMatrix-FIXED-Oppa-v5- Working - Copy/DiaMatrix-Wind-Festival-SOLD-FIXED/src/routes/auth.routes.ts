import { Router } from 'express';
import * as authController from '../controllers/auth.controller.js';
import { validate } from '../middleware/validate.middleware.js';
import { authRequired } from '../middleware/auth.middleware.js';
import {
  loginBodySchema,
  mfaSendBodySchema,
  mfaVerifyBodySchema,
} from '../schemas/auth.schema.js';

const router = Router();

router.post('/login', validate(loginBodySchema, 'body'), authController.login);
router.post('/login/mfa/send', validate(mfaSendBodySchema, 'body'), authController.mfaSend);
router.post('/login/mfa/verify', validate(mfaVerifyBodySchema, 'body'), authController.mfaVerify);
router.get('/me', authRequired, authController.me);
router.get('/totp-setup', authController.totpSetup);

export default router;
