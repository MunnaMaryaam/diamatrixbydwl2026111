import type { Request, Response, NextFunction } from 'express';
import { AppError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';
import { fail } from '../types/api.js';

export function errorMiddleware(
  err: unknown,
  req: Request,
  res: Response,
  _next: NextFunction,
) {
  if (err instanceof AppError) {
    if (err.statusCode >= 500) {
      logger.error(err.message, { code: err.code, requestId: req.requestId });
    }
    return res.status(err.statusCode).json(fail(err.code || 'ERROR', err.message, err.details));
  }

  logger.error('Unhandled error', {
    requestId: req.requestId,
    err: err instanceof Error ? err.message : String(err),
  });
  return res.status(500).json(fail('INTERNAL', 'Internal server error'));
}

export function notFoundMiddleware(req: Request, res: Response) {
  res.status(404).json(fail('NOT_FOUND', `Route not found: ${req.method} ${req.path}`));
}
