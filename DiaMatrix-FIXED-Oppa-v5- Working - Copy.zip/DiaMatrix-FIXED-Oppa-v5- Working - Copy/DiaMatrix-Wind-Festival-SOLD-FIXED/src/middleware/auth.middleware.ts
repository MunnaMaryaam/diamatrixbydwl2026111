import type { Request, Response, NextFunction } from 'express';
import { UnauthorizedError } from '../lib/errors.js';
import { authService } from '../services/auth.service.js';

/**
 * Require a valid session JWT issued after MFA.
 */
export function authRequired(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return next(new UnauthorizedError('Missing Bearer token'));
  }

  const token = header.slice(7);
  const user = authService.resolveToken(token);
  if (!user) {
    return next(new UnauthorizedError('Invalid or expired token'));
  }

  req.user = user;
  return next();
}

export function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (header?.startsWith('Bearer ')) {
    const user = authService.resolveToken(header.slice(7));
    if (user) req.user = user;
  }
  next();
}
