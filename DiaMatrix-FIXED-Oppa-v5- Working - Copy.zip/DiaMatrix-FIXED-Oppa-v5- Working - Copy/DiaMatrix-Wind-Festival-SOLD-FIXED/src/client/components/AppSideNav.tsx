import React, { useEffect, useRef, useState } from 'react';
import { BRAND, resolveBrandMark } from '../brand';
import { WhiteLabelSettings } from '../utils/settingsEngine';
import {
  Home,
  LayoutDashboard,
  Gem,
  ArrowRightLeft,
  PackagePlus,
  Building2,
  FileSpreadsheet,
  Files,
  Sparkles,
  History,
  Download,
  FileDown,
  Gauge,
  Grid3X3,
  TrendingUp,
  Shuffle,
  Gift,
  FilePlus2,
  ChevronRight,
  Boxes,
  Flame,
  ClipboardList,
  Layers,
  BarChart3,
  X,
  FileText,
  GitCompare,
} from 'lucide-react';

/** Matches Gateway pillars — filters side nav to related modules only. */
export type NavScope = 'analysis' | 'dashboard' | 'billing' | 'reports' | 'full';

export interface AppSideNavProps {
  activeView: string;
  /** guest/education → dashboard only */
  appMode?: 'full' | 'guest' | 'education';
  activeReport: string;
  /** When set, only show modules for this Gateway section */
  navScope?: NavScope;
  onNavigateView: (view: any, report?: any) => void;
  onExportExcel?: () => void;
  onExportPdf?: () => void;
  onOpenUploadHistory?: () => void;
  onOpenDailyUpload?: () => void;
  collapsed?: boolean;
  whiteLabel?: WhiteLabelSettings;
}

type NavItem = {
  id: string;
  label: string;
  hint?: string;
  icon: React.ComponentType<{ className?: string }>;
  view: string;
  report?: string;
};

type NavFolder = {
  id: string;
  title: string;
  subtitle: string;
  accent: string;
  headerBg: string;
  icon: React.ComponentType<{ className?: string }>;
  items: NavItem[];
};

const TOP_ITEMS: NavItem[] = [
  { id: 'gateway', label: 'Gateway (Home)', icon: Home, view: 'gateway' },
  { id: 'cockpit', label: 'Operations Cockpit', icon: LayoutDashboard, view: 'dashboard' },
  { id: 'option', label: 'Item Allocation Matrix', icon: Gem, view: 'option_allocation' },
];

const FOLDERS: NavFolder[] = [
  {
    id: 'inventory_audit',
    title: 'Inventory & Supply Chain Audit',
    subtitle: 'CORE OPERATIONS',
    accent: '#0D9488',
    headerBg: 'linear-gradient(135deg, #0F766E 0%, #115E59 50%, #0B2545 100%)',
    icon: Boxes,
    items: [
      { id: 'turn_rate', label: 'Style Inventory Matrix', hint: 'Hierarchical collapsible metal grid', icon: Layers, view: 'reports', report: 'stock_turn_rate' },
      { id: 'aging', label: 'Shelf Aging & Movement Report', hint: 'Aging buckets · dead stock tracker', icon: ArrowRightLeft, view: 'movement_aging' },
      { id: 'turn_rank', label: 'Stock Turn-Rate Ranking', hint: 'Top fast vs slow-moving showrooms', icon: Gauge, view: 'reports', report: 'stock_turn_rate' },
      { id: 'branches', label: 'Showrooms', hint: 'Branch-level stock snapshot', icon: Building2, view: 'reports', report: 'branches' },
      { id: 'weights', label: 'Design Analysis', hint: 'Weight / design performance', icon: Gem, view: 'reports', report: 'weights' },
    ],
  },
  {
    id: 'ai_procurement',
    title: 'AI Demand & Procurement Planning',
    subtitle: 'SOURCING TEAM',
    accent: '#D97706',
    headerBg: 'linear-gradient(135deg, #EA580C 0%, #C2410C 50%, #9A3412 100%)',
    icon: Flame,
    items: [
      { id: 'ai_forecast', label: 'AI Demand & Lost Opportunity', hint: 'Unmet shortage and revenue loss', icon: TrendingUp, view: 'reports', report: 'demand_booster' },
      { id: 'refill', label: 'Automated Purchase Order Advice', hint: 'AI restock orders from baseline gaps', icon: PackagePlus, view: 'reports', report: 'refill_demand' },
      { id: 'ai', label: 'AI Crossmatch Briefing', hint: 'Intelligence overlay on stock gaps', icon: Sparkles, view: 'reports', report: 'ai_crossmatch' },
    ],
  },
  {
    id: 'redistribution',
    title: 'Inter-Branch Redistribution Engine',
    subtitle: 'MERCHANDISING',
    accent: '#0D9488',
    headerBg: 'linear-gradient(135deg, #0F766E 0%, #134E4A 50%, #0B2545 100%)',
    icon: Shuffle,
    items: [
      { id: 'have_deserve', label: 'Have vs Deserve Gaps', hint: 'Real-time supply-demand gaps', icon: BarChart3, view: 'reports', report: 'movement_summary' },
      { id: 'smart_redistribution', label: 'Cross-Outlet Redistribution Logic', hint: 'Automated transfer optimization', icon: Shuffle, view: 'movement_aging' },
      { id: 'execution', label: 'Distribution Execution Pack', hint: 'Contribution · Baseline · Hybrid exports', icon: ArrowRightLeft, view: 'reports', report: 'execution' },
      { id: 'outlet_matrix', label: 'Outlet × Cts / Design', hint: 'Matrix cross-tab analysis', icon: Grid3X3, view: 'reports', report: 'outlet_design_matrix' },
    ],
  },
  {
    id: 'billing',
    title: 'Supplier Billing & Invoice Hub',
    subtitle: 'ACCOUNTS & PROCUREMENT',
    accent: '#1D4ED8',
    headerBg: 'linear-gradient(135deg, #1D4ED8 0%, #1E3A8A 50%, #0B2545 100%)',
    icon: ClipboardList,
    items: [
      { id: 'new_order', label: 'Refill Demand Purchase Order Generator', hint: 'Dynamic invoice · Diamond World branding', icon: FilePlus2, view: 'new_order' },
      { id: 'refill_archive', label: 'Historic PO Log & Print Archive', hint: 'Invoice management and print logs', icon: ClipboardList, view: 'reports', report: 'refill_demand' },
      { id: 'matrix', label: 'Master Excel Matrix Workbook', hint: 'Full export hub · multi-sheet', icon: FileSpreadsheet, view: 'reports', report: 'excel_sheet' },
    ],
  },
];

const BOTTOM_ITEMS: NavItem[] = [
  { id: 'festival_scheme', label: 'Festival Scheme', icon: Gift, view: 'festival_scheme' },
  { id: 'pdf_label_report', label: 'PDF Label Report', icon: FileText, view: 'pdf_label_report' },
  { id: 'stock_vs_sold_design', label: 'Stock vs Sold Design', icon: GitCompare, view: 'stock_vs_sold_design' },
];


/** Folder ids visible per Gateway scope */
const SCOPE_FOLDERS: Record<NavScope, string[] | 'all'> = {
  full: 'all',
  analysis: ['inventory_audit'],
  dashboard: [], // top items only (cockpit + option)
  billing: ['billing'],
  reports: ['inventory_audit', 'ai_procurement', 'redistribution'],
};

const SCOPE_TOP: Record<NavScope, string[] | 'all'> = {
  full: 'all',
  analysis: ['gateway'],
  dashboard: ['gateway', 'cockpit', 'option'],
  billing: ['gateway'],
  reports: ['gateway'],
};

const SCOPE_BOTTOM: Record<NavScope, string[] | 'all'> = {
  full: 'all',
  analysis: ['festival_scheme', 'pdf_label_report', 'stock_vs_sold_design'],
  dashboard: [],
  billing: [],
  reports: [],
};

const ALL_ITEMS: NavItem[] = [
  ...TOP_ITEMS,
  ...FOLDERS.flatMap((f) => f.items),
  ...BOTTOM_ITEMS,
];

function isActive(item: NavItem, activeView: string, activeReport: string) {
  if (item.view === 'dashboard') {
    return activeView === 'dashboard' || activeView === 'menu';
  }
  if (
    item.view === 'option_allocation' ||
    item.view === 'movement_aging' ||
    item.view === 'new_order' ||
    item.view === 'festival_scheme' ||
    item.view === 'pdf_label_report' ||
    item.view === 'stock_vs_sold_design'
  ) {
    return activeView === item.view;
  }
  if (item.report) {
    return activeView === 'reports' && activeReport === item.report;
  }
  return activeView === item.view;
}

function folderContainsActive(folder: NavFolder, activeView: string, activeReport: string) {
  return folder.items.some((item) => isActive(item, activeView, activeReport));
}

const POPUP_STYLE_ID = 'dmx-nav-popup-motion-v6';
function ensurePopupStyles() {
  if (typeof document === 'undefined') return;
  if (document.getElementById(POPUP_STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = POPUP_STYLE_ID;
  style.textContent = `
    /* Tally-pattern cascade panel — modern DiaMatrix skin */
    @keyframes dmxTallyIn {
      0% { opacity: 0; transform: translateX(-10px) scale(0.98); }
      100% { opacity: 1; transform: translateX(0) scale(1); }
    }
    #dmx-nav-popup-panel {
      position: fixed !important;
      z-index: 2200 !important;
      width: 280px !important;
      max-height: min(70vh, 460px) !important;
      animation: dmxTallyIn 0.16s cubic-bezier(0.2, 0.9, 0.3, 1) forwards;
      transform-origin: left center;
      background: #F8FCFF !important;
      border: 1px solid #7EC8E8 !important;
      border-radius: 6px !important;
      overflow: hidden !important;
      box-shadow:
        2px 2px 0 rgba(11, 37, 69, 0.06),
        0 10px 28px rgba(11, 37, 69, 0.14) !important;
      font-family: "Segoe UI", system-ui, -apple-system, sans-serif !important;
    }
    #dmx-nav-popup-panel .dmx-tally-head {
      background: linear-gradient(180deg, #0B6FB8 0%, #0B2545 100%);
      color: #fff;
      padding: 8px 12px;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.02em;
      border-bottom: 2px solid #14B4E8;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    #dmx-nav-popup-panel .dmx-tally-sub {
      font-size: 9px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: rgba(255,255,255,0.7);
      margin-top: 1px;
    }
    #dmx-nav-popup-panel .dmx-tally-body {
      padding: 4px 0;
      background: #F8FCFF;
    }
    #dmx-nav-popup-panel .dmx-tally-item {
      display: flex;
      align-items: center;
      gap: 8px;
      width: 100%;
      text-align: left;
      padding: 7px 12px;
      font-size: 12.5px;
      font-weight: 600;
      color: #0B2545;
      border: none;
      background: transparent;
      cursor: pointer;
      transition: background 0.1s ease;
    }
    #dmx-nav-popup-panel .dmx-tally-item:hover,
    #dmx-nav-popup-panel .dmx-tally-item:focus {
      background: #DDF3FC;
      outline: none;
    }
    #dmx-nav-popup-panel .dmx-tally-item.is-active {
      background: #B8E6F8;
      box-shadow: inset 3px 0 0 #0284C7;
      color: #0B6FB8;
    }
    #dmx-nav-popup-panel .dmx-tally-item.is-focused {
      background: #DDF3FC;
      outline: none;
    }
    #dmx-nav-popup-panel .dmx-tally-item.is-focused.is-active {
      background: #B8E6F8;
    }
    #dmx-nav-popup-panel .dmx-tally-item .dmx-tally-hint {
      display: block;
      font-size: 10px;
      font-weight: 500;
      color: #64748B;
      margin-top: 1px;
    }
    #dmx-nav-popup-panel .dmx-tally-foot {
      border-top: 1px solid #C5E4F5;
      padding: 5px 12px;
      font-size: 10px;
      color: #94A3B8;
      background: #EEF8FD;
      text-align: center;
    }
  `;
  document.head.appendChild(style);
}

export const AppSideNav: React.FC<AppSideNavProps> = ({
  activeView,
  activeReport,
  appMode = 'full',
  onNavigateView,
  onExportExcel,
  onExportPdf,
  onOpenUploadHistory,
  onOpenDailyUpload,
  whiteLabel,
  navScope = 'full',
}) => {
  const navRef = useRef<HTMLElement>(null);
  const popupRef = useRef<HTMLDivElement>(null);
  const [pointerInside, setPointerInside] = useState(false);
  const [clickedId, setClickedId] = useState<string | null>(null);
  const [activePopupId, setActivePopupId] = useState<string | null>(null);
  const [popupPos, setPopupPos] = useState<{ top: number; left: number }>({ top: 100, left: 230 });
  const [highlightIndex, setHighlightIndex] = useState(0);
  const folderBtnRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const letterBufferRef = useRef({ chars: '', at: 0 });

  useEffect(() => {
    ensurePopupStyles();
  }, []);

  const matchingIds = ALL_ITEMS.filter((i) => isActive(i, activeView, activeReport)).map((i) => i.id);
  const activeId = clickedId && matchingIds.includes(clickedId) ? clickedId : matchingIds[0];

  // Reset highlight when popup opens — prefer currently active report
  useEffect(() => {
    if (!activePopupId) return;
    const folder = FOLDERS.find((f) => f.id === activePopupId);
    if (!folder) return;
    const idx = folder.items.findIndex((item) => item.id === activeId);
    setHighlightIndex(idx >= 0 ? idx : 0);
  }, [activePopupId, activeId]);

  // Tally-style keyboard driver for cascade popup
  useEffect(() => {
    if (!activePopupId) return;
    const folder = FOLDERS.find((f) => f.id === activePopupId);
    if (!folder) return;
    const items = folder.items;

    const handleClick = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        popupRef.current &&
        !popupRef.current.contains(target) &&
        navRef.current &&
        !navRef.current.contains(target)
      ) {
        setActivePopupId(null);
      }
    };

    const handleKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        setActivePopupId(null);
        return;
      }

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setHighlightIndex((i) => (i + 1) % items.length);
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setHighlightIndex((i) => (i - 1 + items.length) % items.length);
        return;
      }
      if (e.key === 'Home') {
        e.preventDefault();
        setHighlightIndex(0);
        return;
      }
      if (e.key === 'End') {
        e.preventDefault();
        setHighlightIndex(items.length - 1);
        return;
      }
      if (e.key === 'Enter') {
        e.preventDefault();
        setHighlightIndex((i) => {
          const item = items[i];
          if (item) {
            setClickedId(item.id);
            setActivePopupId(null);
            onNavigateView(item.view, item.report);
          }
          return i;
        });
        return;
      }

      // Letter jump (Tally-style type-ahead)
      if (e.key.length === 1 && /[a-zA-Z0-9]/.test(e.key)) {
        e.preventDefault();
        const now = Date.now();
        const buf = letterBufferRef.current;
        if (now - buf.at > 800) buf.chars = '';
        buf.chars += e.key.toLowerCase();
        buf.at = now;
        const match = items.findIndex((it) =>
          it.label.toLowerCase().startsWith(buf.chars),
        );
        if (match >= 0) setHighlightIndex(match);
      }
    };

    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleKey);
    };
  }, [activePopupId, onNavigateView]);

  // Keep highlighted row visible while arrowing
  useEffect(() => {
    if (!activePopupId || !popupRef.current) return;
    const el = popupRef.current.querySelector(`[data-idx="${highlightIndex}"]`) as HTMLElement | null;
    el?.scrollIntoView({ block: 'nearest' });
  }, [highlightIndex, activePopupId]);

  useEffect(() => {
    setActivePopupId(null);
  }, [activeView, activeReport]);

  useEffect(() => {
    if (!pointerInside) return;
    const scrollWithArrowKeys = (event: KeyboardEvent) => {
      if (event.key !== 'ArrowUp' && event.key !== 'ArrowDown') return;
      const target = event.target as HTMLElement | null;
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;
      const nav = navRef.current;
      if (!nav || nav.scrollHeight <= nav.clientHeight) return;
      event.preventDefault();
      nav.scrollBy({ top: event.key === 'ArrowDown' ? 48 : -48, behavior: 'auto' });
    };
    window.addEventListener('keydown', scrollWithArrowKeys);
    return () => window.removeEventListener('keydown', scrollWithArrowKeys);
  }, [pointerInside]);

  const openPopup = (id: string) => {
    setActivePopupId((prev) => {
      if (prev === id) return null;
      const btn = folderBtnRefs.current[id];
      if (btn) {
        const r = btn.getBoundingClientRect();
        const left = Math.min(r.right + 8, window.innerWidth - 316);
        let top = r.top;
        // keep inside viewport
        const estH = 320;
        if (top + estH > window.innerHeight - 12) {
          top = Math.max(12, window.innerHeight - estH - 12);
        }
        setPopupPos({ top, left: Math.max(8, left) });
      }
      return id;
    });
  };

  const activeFolder = FOLDERS.find((f) => f.id === activePopupId) || null;
  const restrictedMode = appMode === 'guest' || appMode === 'education';
  const scope: NavScope = restrictedMode ? 'dashboard' : (navScope || 'full');

  const topAllow = SCOPE_TOP[scope];
  const folderAllow = SCOPE_FOLDERS[scope];
  const bottomAllow = SCOPE_BOTTOM[scope];

  const topItems =
    restrictedMode
      ? TOP_ITEMS.filter((it) => it.view === 'gateway' || it.view === 'dashboard')
      : topAllow === 'all'
        ? TOP_ITEMS
        : TOP_ITEMS.filter((it) => topAllow.includes(it.id));

  const folders =
    restrictedMode
      ? []
      : folderAllow === 'all'
        ? FOLDERS
        : FOLDERS.filter((f) => folderAllow.includes(f.id));

  const bottomItems =
    restrictedMode
      ? []
      : bottomAllow === 'all'
        ? BOTTOM_ITEMS
        : BOTTOM_ITEMS.filter((it) => bottomAllow.includes(it.id));


  const renderItem = (item: NavItem) => {
    const active = item.id === activeId;
    const Icon = item.icon;
    return (
      <button
        key={item.id}
        type="button"
        aria-current={active ? 'page' : undefined}
        onClick={() => {
          setClickedId(item.id);
          setActivePopupId(null);
          onNavigateView(item.view, item.report);
        }}
        className={`sw-nav-item dmx-menu-item group w-full flex items-center gap-2 rounded-xl text-left transition-all duration-150 px-3 py-2.5 text-[13px] font-bold ${
          active ? 'active' : ''
        }`}
      >
        <Icon className={`shrink-0 w-4 h-4 ${active ? 'text-white' : 'text-[#94A3B8] group-hover:text-white'}`} />
        <span className={`truncate leading-snug ${active ? 'text-white' : 'text-[#94A3B8] group-hover:text-white'}`}>
          {item.label}
        </span>
      </button>
    );
  };

  const action =
    'w-full flex items-center gap-2 rounded-lg px-3 py-2 text-[11px] font-semibold text-[#94A3B8] hover:bg-[rgba(2,132,199,0.18)] hover:text-white transition-colors';

  return (
    <>
      <aside
        className="sw-sidebar hidden md:block w-[220px] lg:w-[250px] shrink-0 border-r self-stretch relative"
        style={{
          backgroundColor: 'var(--brand-sidebar)',
          color: 'var(--brand-sidebar-fg)',
          borderColor: 'var(--brand-navy-deep)',
        }}
      >
        <div className="sticky top-[100px] flex max-h-[calc(100vh-100px)] min-h-0 flex-col">
          <div
            className="flex flex-col items-center px-4 pt-6 pb-4 overflow-visible"
            aria-label={whiteLabel?.companyName || BRAND.short}
          >
            <img
              src={resolveBrandMark(whiteLabel?.logoUrl)}
              alt={whiteLabel?.companyName || BRAND.short}
              className="dmx-logo-3d dmx-logo-spin w-[100px] h-[100px] object-contain shrink-0"
              draggable={false}
            />
          </div>

          <nav
            ref={navRef}
            onMouseEnter={() => setPointerInside(true)}
            onMouseLeave={() => setPointerInside(false)}
            className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-2.5 py-1 space-y-1"
            aria-label="Workspace navigation"
          >
            <div className="space-y-0.5 pb-1">
              {topItems.map((item) => renderItem(item))}
            </div>

            {folders.map((folder) => {
              const isPopupOpen = activePopupId === folder.id;
              const hasActive = folderContainsActive(folder, activeView, activeReport);
              const FolderIcon = folder.icon;
              return (
                <div key={folder.id} className="pt-1">
                  <button
                    type="button"
                    ref={(el) => { folderBtnRefs.current[folder.id] = el; }}
                    onClick={() => openPopup(folder.id)}
                    className={`w-full flex items-center gap-2 rounded-lg px-2.5 py-2.5 text-left transition-all duration-200 cursor-pointer ${
                      isPopupOpen || hasActive ? 'bg-white/10' : 'hover:bg-white/5'
                    }`}
                    aria-expanded={isPopupOpen}
                    aria-haspopup="menu"
                  >
                    <span
                      className="w-7 h-7 rounded-md flex items-center justify-center shrink-0"
                      style={{ background: `${folder.accent}22`, color: folder.accent }}
                    >
                      <FolderIcon className="w-4 h-4" />
                    </span>
                    <span className="flex-1 min-w-0">
                      <span
                        className={`block text-[12px] font-extrabold leading-tight truncate ${
                          isPopupOpen || hasActive ? 'text-white' : 'text-[#CBD5E1]'
                        }`}
                      >
                        {folder.title.split(' ').slice(0, 3).join(' ')}
                        {folder.title.split(' ').length > 3 ? '…' : ''}
                      </span>
                      <span className="block text-[9px] font-semibold uppercase tracking-wide text-[#64748B] truncate">
                        {folder.subtitle}
                      </span>
                    </span>
                    <ChevronRight
                      className={`w-4 h-4 shrink-0 transition-transform duration-300 ${
                        isPopupOpen ? 'rotate-90 text-white' : 'text-[#94A3B8]'
                      }`}
                    />
                  </button>
                </div>
              );
            })}

            <div className="pt-2 space-y-0.5 border-t border-white/10 mt-2">
              {bottomItems.map((item) => renderItem(item))}
            </div>
          </nav>

          <div className="p-3 border-t border-white/10 space-y-1">
            {onExportExcel && (
              <button type="button" onClick={onExportExcel} className={action}>
                <Download className="w-3.5 h-3.5 text-[#94A3B8]" />
                Export Excel
              </button>
            )}
            {onExportPdf && (
              <button type="button" onClick={onExportPdf} className={action}>
                <FileDown className="w-3.5 h-3.5 text-[#94A3B8]" />
                Export PDF
              </button>
            )}
            {onOpenUploadHistory && (
              <button type="button" onClick={onOpenUploadHistory} className={action}>
                <History className="w-3.5 h-3.5 text-[#94A3B8]" />
                Upload History
              </button>
            )}
            {onOpenDailyUpload && (
              <button
                type="button"
                onClick={onOpenDailyUpload}
                className="w-full mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] px-3 py-2.5 text-[12px] font-bold text-white shadow-md shadow-[rgba(2,132,199,0.25)] transition-colors cursor-pointer"
              >
                <Gem className="w-4 h-4" />
                Daily Intake
              </button>
            )}
          </div>
        </div>
      </aside>

      {activeFolder && (
        <div
          id="dmx-nav-popup-panel"
          ref={popupRef}
          role="menu"
          aria-label={activeFolder.title}
          style={{ top: popupPos.top, left: popupPos.left }}
        >
          {/* Tally-style title bar */}
          <div className="dmx-tally-head">
            <activeFolder.icon className="w-4 h-4 shrink-0 opacity-90" />
            <div className="min-w-0 flex-1">
              <div className="truncate leading-tight">{activeFolder.title}</div>
              <div className="dmx-tally-sub">{activeFolder.subtitle}</div>
            </div>
            <button
              type="button"
              onClick={() => setActivePopupId(null)}
              className="w-6 h-6 rounded flex items-center justify-center text-white/70 hover:text-white hover:bg-white/15 shrink-0"
              aria-label="Close"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Cascading option list — Tally Gateway pattern */}
          <div className="dmx-tally-body overflow-y-auto" style={{ maxHeight: 'min(52vh, 360px)' }}>
            {activeFolder.items.map((item, idx) => {
              const active = item.id === activeId;
              const focused = idx === highlightIndex;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  role="menuitem"
                  data-idx={idx}
                  onMouseEnter={() => setHighlightIndex(idx)}
                  onClick={() => {
                    setClickedId(item.id);
                    setActivePopupId(null);
                    onNavigateView(item.view, item.report);
                  }}
                  className={`dmx-tally-item ${active ? 'is-active' : ''} ${focused ? 'is-focused' : ''}`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0 opacity-70" />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate leading-tight">{item.label}</span>
                    {item.hint && <span className="dmx-tally-hint truncate">{item.hint}</span>}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="dmx-tally-foot">
            ↑↓ move · Enter open · type to jump · Esc close
          </div>
        </div>
      )}
    </>
  );
};
