import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import {
  BarChart3,
  LayoutDashboard,
  Receipt,
  Files,
  ArrowRight,
  Upload,
  ChevronDown,
  ChevronRight,
  PackagePlus,
  FileSpreadsheet,
  ClipboardList,
  Layers,
  ArrowRightLeft,
  Gauge,
  Building2,
  Gem,
  TrendingUp,
  Sparkles,
  Shuffle,
  Gift,
  FileText,
  Grid3X3,
  GitCompare,
} from 'lucide-react';
import { BRAND } from '../brand';
import type { WhiteLabelSettings } from '../utils/settingsEngine';
import { DiaMatrixParticleCanvas } from './DiaMatrixParticleCanvas';

export type GatewayMode = 'full' | 'guest' | 'education';

/** Which Gateway pillar the user entered — side nav filters to this scope. */
export type NavScope = 'analysis' | 'dashboard' | 'billing' | 'reports' | 'full';

type SubItem = {
  id: string;
  label: string;
  hint: string;
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
  /** Special: open daily upload modal */
  openUpload?: boolean;
  view?: string;
  report?: string;
};

type GatewaySection = {
  id: NavScope;
  label: string;
  hint: string;
  shortcut: string;
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
  children: SubItem[];
};

const SECTIONS: GatewaySection[] = [
  {
    id: 'analysis',
    label: 'Analysis',
    hint: 'Daily Intake · Festival · PDF Label · Stock vs Sold Design',
    shortcut: '1',
    icon: Upload,
    children: [
      {
        id: 'daily_upload',
        label: 'Daily Intake (Upload)',
        hint: 'Upload stock & sold files',
        icon: Upload,
        openUpload: true,
      },
      {
        id: 'festival',
        label: 'Festival Scheme',
        hint: 'Festival / exhibition planning',
        icon: Gift,
        view: 'festival_scheme',
      },
      {
        id: 'pdf_label',
        label: 'PDF Label Report',
        hint: 'Label sheet export',
        icon: FileText,
        view: 'pdf_label_report',
      },
      {
        id: 'stock_vs_sold_design',
        label: 'Stock vs Sold Design',
        hint: 'Image PDF · design qty · photo · move',
        icon: GitCompare,
        view: 'stock_vs_sold_design',
      },
    ],
  },
  {
    id: 'dashboard',
    label: 'Dashboard',
    hint: 'Operations Cockpit · live KPIs',
    shortcut: '2',
    icon: LayoutDashboard,
    children: [
      {
        id: 'cockpit',
        label: 'Operations Cockpit',
        hint: 'Live KPIs · reminders · tiles',
        icon: LayoutDashboard,
        view: 'dashboard',
      },
      {
        id: 'option_alloc',
        label: 'Item Allocation Matrix',
        hint: 'Option-wise allocation view',
        icon: Gem,
        view: 'option_allocation',
      },
      {
        id: 'turn_rank',
        label: 'Stock Turn-Rate Ranking',
        hint: 'Fast vs slow-moving showrooms',
        icon: Gauge,
        view: 'reports',
        report: 'stock_turn_rate',
      },
    ],
  },
  {
    id: 'billing',
    label: 'Billing',
    hint: 'Supplier PO · invoice · archive',
    shortcut: '3',
    icon: Receipt,
    children: [
      {
        id: 'po_gen',
        label: 'Purchase Order Generator',
        hint: 'Refill demand · dynamic invoice',
        icon: PackagePlus,
        view: 'new_order',
      },
      {
        id: 'po_archive',
        label: 'Historic PO Log & Print Archive',
        hint: 'Invoice management and print logs',
        icon: ClipboardList,
        view: 'reports',
        report: 'refill_demand',
      },
      {
        id: 'excel_matrix',
        label: 'Master Excel Matrix Workbook',
        hint: 'Multi-sheet export hub',
        icon: FileSpreadsheet,
        view: 'reports',
        report: 'excel_sheet',
      },
    ],
  },
  {
    id: 'reports',
    label: 'Reports',
    hint: 'Inventory · AI · redistribution',
    shortcut: '4',
    icon: Files,
    children: [
      {
        id: 'aging',
        label: 'Shelf Aging & Movement',
        hint: 'Aging buckets · dead stock',
        icon: ArrowRightLeft,
        view: 'movement_aging',
      },
      {
        id: 'design_analysis',
        label: 'Design Analysis',
        hint: 'Weight / design performance',
        icon: Gem,
        view: 'reports',
        report: 'weights',
      },
      {
        id: 'style_matrix',
        label: 'Style Inventory Matrix',
        hint: 'Hierarchical metal grid',
        icon: Layers,
        view: 'reports',
        report: 'stock_turn_rate',
      },
      {
        id: 'showrooms',
        label: 'Showrooms',
        hint: 'Branch-level stock snapshot',
        icon: Building2,
        view: 'reports',
        report: 'branches',
      },
      {
        id: 'demand',
        label: 'AI Demand & Lost Opportunity',
        hint: 'Unmet shortage and revenue loss',
        icon: TrendingUp,
        view: 'reports',
        report: 'demand_booster',
      },
      {
        id: 'ai_cross',
        label: 'AI Crossmatch Briefing',
        hint: 'Intelligence overlay on stock gaps',
        icon: Sparkles,
        view: 'reports',
        report: 'ai_crossmatch',
      },
      {
        id: 'have_deserve',
        label: 'Have vs Deserve Gaps',
        hint: 'Real-time supply-demand gaps',
        icon: BarChart3,
        view: 'reports',
        report: 'movement_summary',
      },
      {
        id: 'redistrib',
        label: 'Cross-Outlet Redistribution',
        hint: 'Automated transfer optimization',
        icon: Shuffle,
        view: 'movement_aging',
      },
      {
        id: 'execution',
        label: 'Distribution Execution Pack',
        hint: 'Contribution · Baseline · Hybrid',
        icon: ArrowRightLeft,
        view: 'reports',
        report: 'execution',
      },
      {
        id: 'outlet_matrix',
        label: 'Outlet × Design Matrix',
        hint: 'Matrix cross-tab analysis',
        icon: Grid3X3,
        view: 'reports',
        report: 'outlet_design_matrix',
      },
    ],
  },
];

export interface GatewayOfDiaMatrixProps {
  userName?: string;
  roleLabel?: string;
  whiteLabel?: WhiteLabelSettings;
  appMode: GatewayMode;
  onSelectView: (view: string, report?: string, scope?: NavScope) => void;
  onOpenAnalysisUpload: () => void;
  onSetMode: (mode: GatewayMode) => void;
}

export const GatewayOfDiaMatrix: React.FC<GatewayOfDiaMatrixProps> = ({
  userName,
  roleLabel,
  whiteLabel,
  appMode,
  onSelectView,
  onOpenAnalysisUpload,
}) => {
  const restricted = appMode === 'guest' || appMode === 'education';
  const visibleSections = restricted
    ? SECTIONS.filter((s) => s.id === 'dashboard')
    : SECTIONS;

  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [focusIdx, setFocusIdx] = useState(0);
  const [popupPos, setPopupPos] = useState<{ top: number; left: number }>({ top: 120, left: 400 });
  const listRef = useRef<HTMLDivElement>(null);
  const btnRefs = useRef<Record<string, HTMLButtonElement | null>>({});

  const openChild = useCallback(
    (section: GatewaySection, child: SubItem) => {
      if (restricted && section.id !== 'dashboard') return;
      if (child.openUpload) {
        onOpenAnalysisUpload();
        return;
      }
      if (child.view) {
        onSelectView(child.view, child.report, section.id);
      }
    },
    [restricted, onOpenAnalysisUpload, onSelectView],
  );

  const toggleSection = useCallback(
    (section: GatewaySection) => {
      if (restricted && section.id !== 'dashboard') return;
      setExpandedId((prev) => (prev === section.id ? null : section.id));
    },
    [restricted],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      const section = visibleSections[focusIdx];
      if (!section) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setFocusIdx((i) => Math.min(i + 1, visibleSections.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setFocusIdx((i) => Math.max(i - 1, 0));
      } else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggleSection(section);
      } else if (e.key >= '1' && e.key <= '4') {
        const idx = Number(e.key) - 1;
        if (visibleSections[idx]) {
          setFocusIdx(idx);
          toggleSection(visibleSections[idx]);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [focusIdx, visibleSections, toggleSection]);


  useLayoutEffect(() => {
    if (!expandedId) return;
    const el = btnRefs.current[expandedId];
    if (!el) return;
    const update = () => {
      const r = el.getBoundingClientRect();
      const panelW = 300;
      let left = r.right + 10;
      let top = r.top;
      // keep on screen
      if (left + panelW > window.innerWidth - 12) {
        left = Math.max(12, r.left - panelW - 10);
      }
      const maxTop = window.innerHeight - 80;
      if (top > maxTop) top = Math.max(12, maxTop - 200);
      if (top < 8) top = 8;
      setPopupPos({ top, left });
    };
    update();
    window.addEventListener('resize', update);
    window.addEventListener('scroll', update, true);
    return () => {
      window.removeEventListener('resize', update);
      window.removeEventListener('scroll', update, true);
    };
  }, [expandedId]);

  // Click outside closes popup
  useEffect(() => {
    if (!expandedId) return;
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node;
      const btn = btnRefs.current[expandedId];
      const panel = document.getElementById('dmx-gateway-flyout');
      if (btn?.contains(t) || panel?.contains(t)) return;
      setExpandedId(null);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [expandedId]);

  useEffect(() => {
    if (typeof document === 'undefined') return;
    if (document.getElementById('dmx-gateway-flyout-style')) return;
    const s = document.createElement('style');
    s.id = 'dmx-gateway-flyout-style';
    s.textContent = `
      @keyframes dmxFlyIn {
        from { opacity: 0; transform: translateX(-8px) scale(0.98); }
        to { opacity: 1; transform: translateX(0) scale(1); }
      }
    `;
    document.head.appendChild(s);
  }, []);

  const brandName = whiteLabel?.companyName || BRAND.name;

  return (
    <div className="flex h-full min-h-[calc(100vh-3.5rem)] w-full bg-[#F0F7FC]">
      <aside
        className="w-full md:w-[380px] lg:w-[400px] shrink-0 flex flex-col border-r border-[#BAE6FD] relative"
        style={{
          background: 'linear-gradient(180deg, #F8FCFF 0%, #E8F4FC 55%, #DFF0FA 100%)',
        }}
      >
        <div
          className="relative z-[3] px-4 pt-4 pb-3 border-b border-[#BAE6FD]"
          style={{
            background: 'linear-gradient(180deg, #FFFFFF 0%, #F0F9FF 100%)',
          }}
        >
          <h1 className="text-[17px] font-black text-[#0B2545] tracking-tight">
            Gateway of {BRAND.short || 'DiaMatrix'}
          </h1>
          <p className="text-[12px] font-semibold text-[#475569] mt-0.5 truncate">
            Signed in as {userName || 'User'}
            {roleLabel ? ` · ${roleLabel}` : ''}
          </p>
          <span className="inline-flex mt-2 items-center rounded-full bg-[#E0F2FE] border border-[#7DD3FC] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#0369A1]">
            Full Access
          </span>
        </div>

        <div
          className="relative z-[3] mx-3 mt-3 mb-2 rounded-xl overflow-hidden"
          style={{
            background: 'linear-gradient(165deg, #0EA5E9 0%, #0369A1 40%, #0B2545 100%)',
            boxShadow:
              '0 2px 0 rgba(255,255,255,0.35) inset, 0 -3px 0 rgba(0,0,0,0.3) inset, 0 16px 36px rgba(3,105,161,0.6), 0 6px 14px rgba(11,37,69,0.35)',
            border: '1px solid rgba(14,165,233,0.6)',
            filter: 'drop-shadow(0 10px 22px rgba(3, 105, 161, 0.5)) drop-shadow(0 4px 8px rgba(11, 37, 69, 0.3))',
          }}
        >
          <div
            className="pointer-events-none absolute inset-x-0 top-0 h-[50%] opacity-40"
            style={{ background: 'linear-gradient(180deg, rgba(255,255,255,0.35), transparent)' }}
          />
          <div className="relative z-[1] px-3.5 py-2.5 flex items-center justify-between">
            <span className="text-[13px] font-black text-white tracking-wide drop-shadow-sm">Main Menu</span>
            <span className="text-[10px] font-semibold text-sky-100/90">
              Analysis · Dashboard · Billing · Reports
            </span>
          </div>
        </div>

        <div ref={listRef} className="relative z-[3] flex-1 overflow-y-auto overflow-x-hidden px-5 py-4 space-y-4">
          {visibleSections.map((section, idx) => {
            const Icon = section.icon;
            const focused = idx === focusIdx;
            const expanded = expandedId === section.id;

            const active = focused || expanded;
            return (
              <div
                key={section.id}
                className="rounded-2xl"
                style={{
                  filter: active
                    ? 'drop-shadow(0 14px 28px rgba(2, 132, 199, 0.55)) drop-shadow(0 6px 12px rgba(11, 37, 69, 0.28)) drop-shadow(0 2px 4px rgba(2, 132, 199, 0.35))'
                    : 'drop-shadow(0 12px 24px rgba(15, 23, 42, 0.28)) drop-shadow(0 5px 10px rgba(15, 23, 42, 0.18)) drop-shadow(0 2px 4px rgba(15, 23, 42, 0.12))',
                }}
              >
                <button
                  type="button"
                  ref={(el) => {
                    btnRefs.current[section.id] = el;
                  }}
                  onClick={() => {
                    setFocusIdx(idx);
                    toggleSection(section);
                  }}
                  onMouseEnter={() => setFocusIdx(idx)}
                  className="relative w-full flex items-center gap-2.5 px-3.5 py-3 text-left rounded-2xl transition-all duration-200 active:scale-[0.985] active:translate-y-[1px]"
                  style={{
                    background: active
                      ? 'linear-gradient(165deg, #E0F2FE 0%, #7DD3FC 48%, #38BDF8 100%)'
                      : 'linear-gradient(180deg, #FFFFFF 0%, #F1F5F9 100%)',
                    border: active ? '1px solid #0284C7' : '1px solid #94A3B8',
                    boxShadow: active
                      ? '0 2px 0 rgba(255,255,255,0.7) inset, 0 -3px 0 rgba(3,105,161,0.4) inset, 0 16px 36px rgba(2,132,199,0.55), 0 8px 16px rgba(11,37,69,0.25), 0 2px 4px rgba(2,132,199,0.3)'
                      : '0 2px 0 rgba(255,255,255,1) inset, 0 -3px 0 rgba(15,23,42,0.12) inset, 0 14px 32px rgba(15,23,42,0.22), 0 6px 12px rgba(15,23,42,0.16), 0 2px 4px rgba(15,23,42,0.1)',
                    color: active ? '#0C4A6E' : '#0F172A',
                  }}
                >
                  <span
                    className="pointer-events-none absolute inset-x-3 top-0 h-[48%] rounded-t-2xl opacity-50"
                    style={{
                      background: active
                        ? 'linear-gradient(180deg, rgba(255,255,255,0.55), transparent)'
                        : 'linear-gradient(180deg, rgba(255,255,255,0.95), transparent)',
                    }}
                  />
                  <span
                    className="relative z-[1] w-7 h-7 rounded-lg flex items-center justify-center text-[12px] font-black shrink-0"
                    style={{
                      background: active
                        ? 'linear-gradient(165deg, #38BDF8 0%, #0284C7 55%, #0369A1 100%)'
                        : 'linear-gradient(180deg, #F8FAFC 0%, #E2E8F0 100%)',
                      color: active ? '#fff' : '#475569',
                      boxShadow: active
                        ? '0 1px 0 rgba(255,255,255,0.45) inset, 0 4px 12px rgba(2,132,199,0.55), 0 2px 4px rgba(11,37,69,0.25)'
                        : '0 1px 0 rgba(255,255,255,1) inset, 0 3px 8px rgba(15,23,42,0.18), 0 1px 3px rgba(15,23,42,0.12)',
                      border: active ? '1px solid #0369A1' : '1px solid #CBD5E1',
                    }}
                  >
                    {section.shortcut}
                  </span>
                  <Icon
                    className="relative z-[1] w-5 h-5 shrink-0"
                    style={{
                      color: active ? '#0369A1' : '#64748B',
                      filter: active ? 'drop-shadow(0 2px 3px rgba(2,132,199,0.35))' : undefined,
                    }}
                  />
                  <span className="relative z-[1] min-w-0 flex-1">
                    <span className="block text-[15px] font-black leading-tight truncate tracking-tight">
                      {section.label}
                    </span>
                    <span
                      className="block text-[11.5px] font-semibold truncate mt-0.5"
                      style={{ color: active ? '#0C4A6E' : '#64748B', opacity: active ? 0.95 : 0.88 }}
                    >
                      {section.hint}
                    </span>
                  </span>
                  {expanded ? (
                    <ChevronDown className="relative z-[1] w-4 h-4 shrink-0 text-[#0284C7]" />
                  ) : (
                    <ChevronRight
                      className="relative z-[1] w-4 h-4 shrink-0"
                      style={{ color: active ? '#0284C7' : '#94A3B8' }}
                    />
                  )}
                </button>


              </div>
            );
          })}
        </div>


        {/* Right-side flyout popup for expanded section */}
        {expandedId && (() => {
          const section = visibleSections.find((s) => s.id === expandedId);
          if (!section) return null;
          return (
            <div
              id="dmx-gateway-flyout"
              className="fixed z-[5000] w-[300px] max-h-[min(70vh,420px)] overflow-y-auto rounded-xl"
              style={{
                top: popupPos.top,
                left: popupPos.left,
                background: 'linear-gradient(180deg, #F8FCFF 0%, #E8F4FC 100%)',
                border: '1px solid #38BDF8',
                boxShadow:
                  '0 2px 0 rgba(255,255,255,0.85) inset, 0 16px 40px rgba(2,132,199,0.35), 0 8px 16px rgba(11,37,69,0.2)',
                animation: 'dmxFlyIn 0.15s ease-out',
              }}
            >
              <div
                className="sticky top-0 z-[1] px-3 py-2 text-[11px] font-black uppercase tracking-wider text-white"
                style={{
                  background: 'linear-gradient(90deg, #0369A1 0%, #0EA5E9 100%)',
                  boxShadow: '0 1px 0 rgba(255,255,255,0.25) inset, 0 4px 12px rgba(3,105,161,0.3)',
                }}
              >
                {section.label} modules
              </div>
              {section.children.map((child) => {
                const CIcon = child.icon;
                return (
                  <button
                    key={child.id}
                    type="button"
                    onClick={() => {
                      openChild(section, child);
                      setExpandedId(null);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2.5 text-left border-b border-sky-100 last:border-0 group transition-colors hover:bg-sky-100/80 active:scale-[0.99]"
                  >
                    <span
                      className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                      style={{
                        background: 'linear-gradient(165deg, #38BDF8 0%, #0284C7 100%)',
                        boxShadow:
                          '0 1px 0 rgba(255,255,255,0.4) inset, 0 4px 10px rgba(2,132,199,0.35)',
                      }}
                    >
                      <CIcon className="w-4 h-4 text-white" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-[13px] font-bold text-[#0B2545] truncate group-hover:text-[#0369A1]">
                        {child.label}
                      </span>
                      <span className="block text-[11px] font-medium text-[#64748B] truncate">
                        {child.hint}
                      </span>
                    </span>
                    <ArrowRight className="w-4 h-4 shrink-0 text-[#94A3B8] group-hover:text-[#0284C7] transition" />
                  </button>
                );
              })}
            </div>
          );
        })()}

        <div
          className="relative z-[3] border-t border-[#BAE6FD] px-3 py-2.5 text-[11px] text-[#475569] shrink-0 text-center font-semibold"
          style={{
            background: 'linear-gradient(180deg, #F0F9FF 0%, #E0F2FE 100%)',
          }}
        >
          Click a menu to expand · Enter toggles · Esc returns here from modules
        </div>
      </aside>

      <div className="hidden md:flex flex-1 relative overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'radial-gradient(ellipse at 50% 45%, #0a1a33, #040b18 75%)',
          }}
        />
        <DiaMatrixParticleCanvas className="z-[1]" />
      </div>
    </div>
  );
};
