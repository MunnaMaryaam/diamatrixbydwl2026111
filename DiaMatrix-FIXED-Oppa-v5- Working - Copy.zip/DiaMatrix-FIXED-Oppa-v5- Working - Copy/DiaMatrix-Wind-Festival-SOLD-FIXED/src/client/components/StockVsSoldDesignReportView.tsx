/**
 * Analysis → Stock vs Sold Design Report
 * Matches Design-wise Stock Analysis layout:
 *  - Summary breakdown (Move IN/OUT matrix)
 *  - Full report (Stk / Sold / Move per carat × branch)
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Upload,
  Download,
  Trash2,
  AlertTriangle,
  Loader2,
  Package,
  ShoppingBag,
  GitCompare,
  Layers,
  Gem,
  TrendingUp,
  Search,
} from 'lucide-react';
import { parseLabelPdfText } from '../pdfLabel/pdfLabelParser';
import {
  buildStockVsSoldDetailReport,
  enrichItemsWithDesignFromText,
  type StockVsSoldDetailReport,
  type DesignCardDetail,
} from '../pdfLabel/designMatch';
import { exportStockVsSoldExcel } from '../pdfLabel/stockVsSoldExport';
import type { PdfLabelReport } from '../pdfLabel/pdfLabelTypes';

async function loadPdfJs(): Promise<any> {
  // @ts-expect-error optional global
  let pdfjsLib = typeof window !== 'undefined' ? window.pdfjsLib : null;
  if (pdfjsLib) return pdfjsLib;
  await new Promise<void>((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load pdf.js'));
    document.head.appendChild(script);
  });
  // @ts-expect-error set by script
  pdfjsLib = window.pdfjsLib;
  if (!pdfjsLib) throw new Error('pdf.js not available');
  pdfjsLib.GlobalWorkerOptions.workerSrc =
    'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  return pdfjsLib;
}

async function extractTextFromPdf(pdf: any): Promise<string> {
  // Layout-preserving extract for Stock/Sold image reports.
  // Forces "BCT" / "D.RING" / qty onto separate lines so branch windows parse.
  const BRANCH_HDR =
    /^(BAC|BCT|BLY|BMK|BOG|BSL|CHU|CTG|CUM|DMD|DNM|DWL|GAZ|GUL|JAS|KBH|KHU|MIR|MOH|MYM|NAK|NAR|NOR|ONL|PCT|RAJ|RAN|RUP|SAV|SYL|UTT|BAR|COM|DIN|FAR|JES|KHL|TAN)$/i;
  const parts: string[] = [];
  for (let p = 1; p <= pdf.numPages; p++) {
    const page = await pdf.getPage(p);
    const content = await page.getTextContent();
    const items = (content.items as any[])
      .filter((it) => it.str && String(it.str).trim())
      .map((it) => ({
        str: String(it.str).trim(),
        x: Number(it.transform?.[4] ?? 0),
        y: Number(it.transform?.[5] ?? 0),
      }));
    // Top → bottom, left → right
    items.sort((a, b) => b.y - a.y || a.x - b.x);

    // Row cluster (tighter tolerance)
    const rows: { y: number; cells: { str: string; x: number }[] }[] = [];
    for (const it of items) {
      let row = rows.find((r) => Math.abs(r.y - it.y) <= 8);
      if (!row) {
        row = { y: it.y, cells: [] };
        rows.push(row);
      }
      row.cells.push({ str: it.str, x: it.x });
    }
    rows.sort((a, b) => b.y - a.y);

    parts.push(`---PAGE ${p}---`);
    for (const row of rows) {
      row.cells.sort((a, b) => a.x - b.x);
      const texts = row.cells.map((c) => c.str);
      const line = texts.join(' ');

      // Split branch headers out of mixed lines
      for (const cell of row.cells) {
        if (BRANCH_HDR.test(cell.str)) {
          parts.push(cell.str);
        }
      }
      if (/\bD\.?\s*[A-Z]{3,20}\b/i.test(line)) {
        const pm = line.match(/\bD\.?\s*([A-Z]{3,20})\b/i);
        parts.push(pm ? ('D.' + pm[1].toUpperCase()) : 'D.RING');
        const nums = line.match(/\b(\d{1,3})\s+(\d{1,4})\b/);
        if (nums) parts.push(`${nums[1]} ${nums[2]}`);
      }
      // Always keep full line for barcodes / designs
      if (line.trim()) parts.push(line.trim());
    }
    parts.push('');
  }
  // Normalize repeated spaces; keep newlines
  return parts.join('\n').replace(/[ \t]+/g, ' ');
}

async function extractImagesFromPdf(pdf: any, pdfjsLib: any, maxImages = 400): Promise<string[]> {
  const urls: string[] = [];
  const OPS = pdfjsLib.OPS || {};
  for (let p = 1; p <= pdf.numPages && urls.length < maxImages; p++) {
    const page = await pdf.getPage(p);
    try {
      const ops = await page.getOperatorList();
      const fns = ops.fnArray as number[];
      const args = ops.argsArray as any[];
      for (let i = 0; i < fns.length && urls.length < maxImages; i++) {
        if (fns[i] !== OPS.paintImageXObject && fns[i] !== OPS.paintInlineImageXObject) continue;
        const name = args[i]?.[0];
        if (!name || typeof name !== 'string') continue;
        try {
          const img = await new Promise<any>((resolve) => {
            const store = name.startsWith('g_') ? page.commonObjs : page.objs;
            store.get(name, resolve);
          });
          if (!img?.width || !img?.data || img.width < 40 || img.height < 40) continue;
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          if (!ctx) continue;
          const imageData = ctx.createImageData(img.width, img.height);
          const dst = imageData.data;
          const src = img.data;
          const kind = img.kind;
          if (kind === 3 || src.length >= img.width * img.height * 4) {
            for (let j = 0; j < Math.min(src.length, dst.length); j++) dst[j] = src[j];
          } else if (kind === 2 || src.length >= img.width * img.height * 3) {
            let s = 0;
            for (let j = 0; j < dst.length; j += 4) {
              dst[j] = src[s++];
              dst[j + 1] = src[s++];
              dst[j + 2] = src[s++];
              dst[j + 3] = 255;
            }
          } else continue;
          ctx.putImageData(imageData, 0, 0);
          urls.push(canvas.toDataURL('image/jpeg', 0.72));
        } catch {
          /* skip */
        }
      }
    } catch {
      /* skip */
    }
    page.cleanup?.();
  }
  return urls;
}

function attachImages(report: PdfLabelReport, images: string[]): PdfLabelReport {
  let idx = 0;
  const branches = report.branches.map((br) => ({
    ...br,
    items: br.items.map((it) => {
      const imageDataUrl = images[idx] || images[0] || it.imageDataUrl;
      idx++;
      return { ...it, imageDataUrl };
    }),
  }));
  return { ...report, branches };
}

/** Load tesseract.js — prefer package, fallback CDN */
async function loadTesseract(): Promise<any> {
  // @ts-expect-error optional global
  if (typeof window !== 'undefined' && window.Tesseract) return window.Tesseract;
  try {
    const mod = await import('tesseract.js');
    return mod.default || mod;
  } catch {
    /* fallback CDN */
  }
  await new Promise<void>((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load tesseract.js'));
    document.head.appendChild(script);
  });
  // @ts-expect-error set by script
  const T = window.Tesseract;
  if (!T) throw new Error('tesseract.js not available');
  return T;
}

/**
 * Render each PDF page → OCR → extract amount-like numbers (৳ 1,000 – 9,999,999).
 * Returns OCR text blob + list of prices in reading order.
 */
async function ocrPdfPagesForAmounts(
  pdf: any,
  onProgress?: (msg: string) => void,
): Promise<{ ocrText: string; prices: number[] }> {
  const Tesseract = await loadTesseract();
  const parts: string[] = [];
  const prices: number[] = [];
  const n = pdf.numPages;
  // Moderate scale — balance accuracy vs speed (~10 pages)
  const scale = 1.4;

  for (let p = 1; p <= n; p++) {
    onProgress?.(`OCR page ${p}/${n} (reading amounts from image)…`);
    const page = await pdf.getPage(p);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    const ctx = canvas.getContext('2d');
    if (!ctx) continue;
    await page.render({ canvasContext: ctx, viewport }).promise;

    try {
      const result = await Tesseract.recognize(canvas, 'eng', {
        logger: () => {},
      });
      const txt = (result?.data?.text || '') as string;
      if (txt.trim()) parts.push(txt);
      // 5–7 digit amounts (skip barcodes 11–14 digit handled elsewhere)
      const re = /\b([1-9]\d{3,6})\b/g;
      let m: RegExpExecArray | null;
      while ((m = re.exec(txt)) !== null) {
        const v = parseInt(m[1], 10);
        // Prefer jewelry price band: 1,000 – 99,99,999; exclude pure 4-digit years-ish if needed
        if (v >= 1000 && v <= 9999999) prices.push(v);
      }
    } catch {
      /* page OCR fail — continue */
    }
    page.cleanup?.();
  }

  return { ocrText: parts.join('\n'), prices };
}

/** Fill missing item.price from OCR price list (order-based within report). */
function applyOcrPricesToReport(
  report: PdfLabelReport,
  ocrPrices: number[],
): PdfLabelReport {
  if (!ocrPrices.length) return report;
  // Collect items that still have price 0
  const need: { brIdx: number; itIdx: number }[] = [];
  report.branches.forEach((br, bi) => {
    br.items.forEach((it, ii) => {
      if (!(it.price > 0)) need.push({ brIdx: bi, itIdx: ii });
    });
  });
  if (!need.length) return report;

  // Use unique-ish prices (keep order, drop obvious barcode-length already filtered)
  const pool = ocrPrices.filter((v) => v >= 5000); // jewelry usually ≥ 5k
  if (!pool.length) return report;

  let pi = 0;
  const branches = report.branches.map((br, bi) => {
    const items = br.items.map((it, ii) => {
      if (it.price > 0) return it;
      if (pi >= pool.length) return it;
      // only assign if this item is in need list for this index
      const isNeed = need.some((n) => n.brIdx === bi && n.itIdx === ii);
      if (!isNeed) return it;
      const price = pool[pi++];
      return { ...it, price };
    });
    const totalPrice = items.reduce((s, it) => s + (it.price || 0), 0);
    return { ...br, items, totalPrice };
  });

  return {
    ...report,
    branches,
    grandTotalPrice: branches.reduce((s, b) => s + b.totalPrice, 0),
  };
}

async function parsePdfFile(
  file: File,
  opts?: {
    /** Run page-image OCR for amounts (slower, ~10 pages) */
    ocrAmounts?: boolean;
    onProgress?: (msg: string) => void;
  },
): Promise<{
  report: PdfLabelReport | null;
  text: string;
  name: string;
  ocrPriceCount?: number;
}> {
  const pdfjsLib = await loadPdfJs();
  const buf = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
  opts?.onProgress?.('Extracting text layer…');
  let text = await extractTextFromPdf(pdf);

  // Count price-like numbers already in text layer
  const textPriceCount = (text.match(/\b[1-9]\d{4,6}\b/g) || []).length;

  let ocrPrices: number[] = [];
  // Auto OCR when requested, or when text layer has few prices vs barcodes
  const barcodeCount = (text.match(/\b\d{10,14}\b/g) || []).length;
  const shouldOcr =
    opts?.ocrAmounts === true ||
    (opts?.ocrAmounts !== false && barcodeCount > 20 && textPriceCount < barcodeCount * 0.3);

  if (shouldOcr) {
    try {
      const { ocrText, prices } = await ocrPdfPagesForAmounts(pdf, opts?.onProgress);
      ocrPrices = prices;
      if (ocrText.trim()) {
        text = text + '\n\n' + ocrText;
      }
    } catch (e) {
      console.warn('OCR failed, continuing with text layer only', e);
    }
  }

  opts?.onProgress?.('Parsing designs / branches…');
  const result = parseLabelPdfText(text);
  let report = result.ok && result.report ? result.report : null;
  if (report) {
    report = enrichItemsWithDesignFromText(report, text);
    if (ocrPrices.length) {
      report = applyOcrPricesToReport(report, ocrPrices);
    }
    try {
      opts?.onProgress?.('Attaching product images…');
      const images = await extractImagesFromPdf(pdf, pdfjsLib, report.grandTotalPcs + 20);
      if (images.length) report = attachImages(report, images);
    } catch {
      /* optional */
    }
  }
  return {
    report,
    text,
    name: file.name,
    ocrPriceCount: ocrPrices.length,
  };
}

function caratKey(c: number): string {
  if (!c || !Number.isFinite(c)) return '0.00';
  return c.toFixed(2);
}

type Cell = { stk: number; sold: number; amount: number };

/** Parse tag date like 27-JUL-22 / 14-SEP-26 → Date (2-digit year: 00-69 → 2000s) */
function parseInvoiceDate(code?: string): Date | null {
  if (!code) return null;
  const m = code.trim().toUpperCase().match(/^(\d{1,2})-([A-Z]{3})-(\d{2,4})$/);
  if (!m) return null;
  const months: Record<string, number> = {
    JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5,
    JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11,
  };
  const mon = months[m[2]];
  if (mon === undefined) return null;
  let year = parseInt(m[3], 10);
  if (year < 100) year += year >= 70 ? 1900 : 2000;
  const day = parseInt(m[1], 10);
  const d = new Date(year, mon, day);
  return Number.isNaN(d.getTime()) ? null : d;
}

function daysBetween(from: Date, to: Date): number {
  const ms = to.getTime() - from.getTime();
  return Math.max(0, Math.floor(ms / (24 * 60 * 60 * 1000)));
}

type AgingBucket = '0-30' | '31-60' | '61-90' | '90+';
function agingBucket(days: number): AgingBucket {
  if (days <= 30) return '0-30';
  if (days <= 60) return '31-60';
  if (days <= 90) return '61-90';
  return '90+';
}



const SVS_STORAGE_KEY = 'diamatrix.stockVsSold.v4';
type SvsPersisted = {
  report: StockVsSoldDetailReport;
  stockName: string;
  soldName: string;
  periodFrom: string;
  periodTo: string;
  periodPreset: string;
  distributionMode: string;
  savedAt: string;
};
function stripHeavyImages(report: StockVsSoldDetailReport): StockVsSoldDetailReport {
  const groups = (report.groups || []).map((g) => ({
    ...g,
    cards: (g.cards || []).map((c) => {
      const { imageDataUrl: _d, ...rest } = c as DesignCardDetail & { imageDataUrl?: string };
      return rest as DesignCardDetail;
    }),
  }));
  return { ...report, groups };
}
function saveSvsToStorage(payload: SvsPersisted) {
  try { localStorage.setItem(SVS_STORAGE_KEY, JSON.stringify(payload)); } catch (e) { console.warn(e); }
}
function loadSvsFromStorage(): SvsPersisted | null {
  try {
    const raw = localStorage.getItem(SVS_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as SvsPersisted) : null;
  } catch { return null; }
}
function clearSvsStorage() {
  try { localStorage.removeItem(SVS_STORAGE_KEY); } catch { /* */ }
}


export const StockVsSoldDesignReportView: React.FC = () => {
  const stockRef = useRef<HTMLInputElement>(null);
  const soldRef = useRef<HTMLInputElement>(null);

  const [stockName, setStockName] = useState('');
  const [soldName, setSoldName] = useState('');
  const [stockFile, setStockFile] = useState<File | null>(null);
  const [soldFile, setSoldFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<StockVsSoldDetailReport | null>(null);
  const [exporting, setExporting] = useState(false);
  /** summary = Move only · report = full Stk/Sold/Move — same as Design-wise Stock Analysis */
  const [panelMode, setPanelMode] = useState<'summary' | 'report' | 'aging'>('summary');
  const [selectedDesign, setSelectedDesign] = useState<string>('ALL');
  const [search, setSearch] = useState('');
  const [showOutlets, setShowOutlets] = useState(true);
  /**
   * Distribution mode — same 6 logics as Design-wise Stock Analysis:
   * contribution | baseline | hybrid | liquidity | demand_backup | coverage
   */
  const [distributionMode, setDistributionMode] = useState<
    'contribution' | 'baseline' | 'hybrid' | 'liquidity' | 'demand_backup' | 'coverage'
  >('contribution');
  /** Date period for the analysis window (set at upload time) */
  const [periodFrom, setPeriodFrom] = useState('');
  const [periodTo, setPeriodTo] = useState('');
  const [periodPreset, setPeriodPreset] = useState<'custom' | '1M' | '3M' | '6M' | '9M' | '1Y'>('custom');
  /**
   * Amount range filter (Stock price only — Sold PDFs usually have no amount on image).
   * Example: 100000–300000 = 1 lac to 3 lac rings.
   * Empty = no filter.
   */
  const [amountMin, setAmountMin] = useState('');
  const [amountMax, setAmountMax] = useState('');

  useEffect(() => {
    const saved = loadSvsFromStorage();
    if (!saved?.report) return;
    setReport(saved.report);
    setStockName(saved.stockName || '');
    setSoldName(saved.soldName || '');
    if (saved.periodFrom) setPeriodFrom(saved.periodFrom);
    if (saved.periodTo) setPeriodTo(saved.periodTo);
    if (saved.periodPreset) setPeriodPreset(saved.periodPreset as any);
    if (saved.distributionMode) setDistributionMode(saved.distributionMode as any);
  }, []);

  const reset = useCallback(() => {
    clearSvsStorage();
    setStockName('');
    setSoldName('');
    setStockFile(null);
    setSoldFile(null);
    setReport(null);
    setError(null);
    setSelectedDesign('ALL');
    setSearch('');
    setDistributionMode('contribution');
    setPeriodFrom('');
    setPeriodTo('');
    setPeriodPreset('custom');
    setAmountMin('');
    setAmountMax('');
    if (stockRef.current) stockRef.current.value = '';
    if (soldRef.current) soldRef.current.value = '';
  }, []);

  /**
   * Auto-detect which file is Stock vs Sold from PDF title text.
   * Fixes swapped uploads (e.g. file named Stock but title says Sold Report).
   */
  const detectRole = (text: string, fileName: string): 'stock' | 'sold' | 'unknown' => {
    const head = (text || '').slice(0, 800).toLowerCase();
    const name = (fileName || '').toLowerCase();
    if (/stock\s*report/.test(head) || /stock\s*report\s*\(\s*image\s*\)/.test(head)) return 'stock';
    if (/sold\s*report/.test(head)) return 'sold';
    if (/\bstock\b/.test(name) && !/\bsold\b/.test(name)) return 'stock';
    if (/\bsold\b/.test(name)) return 'sold';
    return 'unknown';
  };

  /** Auto period from filename: "9 Month", "3M", "6 month" etc. */
  const autoPeriodFromName = (name: string) => {
    const n = name.toLowerCase();
    const map: { re: RegExp; preset: '1M' | '3M' | '6M' | '9M' | '1Y'; months: number }[] = [
      { re: /\b1\s*y(ear)?\b|\b12\s*m/, preset: '1Y', months: 12 },
      { re: /\b9\s*m(onth)?s?\b/, preset: '9M', months: 9 },
      { re: /\b6\s*m(onth)?s?\b/, preset: '6M', months: 6 },
      { re: /\b3\s*m(onth)?s?\b/, preset: '3M', months: 3 },
      { re: /\b1\s*m(onth)?\b/, preset: '1M', months: 1 },
    ];
    for (const m of map) {
      if (m.re.test(n)) {
        const to = new Date();
        const from = new Date();
        from.setMonth(from.getMonth() - m.months);
        setPeriodPreset(m.preset);
        setPeriodFrom(from.toISOString().slice(0, 10));
        setPeriodTo(to.toISOString().slice(0, 10));
        return m.preset;
      }
    }
    return null;
  };

  const runMatch = useCallback(async (fileA: File, fileB: File) => {
    setLoading(true);
    setError(null);
    setReport(null);
    try {
      // --- Pass 1: quick text on both (no OCR) to detect roles ---
      setLoadingMsg('Auto-detecting Stock vs Sold…');
      const quickA = await parsePdfFile(fileA, { ocrAmounts: false });
      const quickB = await parsePdfFile(fileB, { ocrAmounts: false });
      const roleA = detectRole(quickA.text, fileA.name);
      const roleB = detectRole(quickB.text, fileB.name);

      let stockFile = fileA;
      let soldFile = fileB;
      let stockQuick = quickA;
      let soldQuick = quickB;
      let swapped = false;

      if (roleA === 'sold' && roleB === 'stock') {
        // boxes were swapped — fix automatically
        stockFile = fileB;
        soldFile = fileA;
        stockQuick = quickB;
        soldQuick = quickA;
        swapped = true;
      } else if (roleA === 'stock' && roleB === 'sold') {
        // correct as-is (fileA stock, fileB sold)
      } else if (roleA === 'sold' && roleB !== 'stock') {
        stockFile = fileB;
        soldFile = fileA;
        stockQuick = quickB;
        soldQuick = quickA;
        swapped = true;
      }

      // Auto period from sold filename (e.g. "Sold - 9 Month.pdf")
      autoPeriodFromName(soldFile.name);
      autoPeriodFromName(stockFile.name);

      // --- Pass 2: OCR amounts on Stock only ---
      setLoadingMsg('Stock PDF — OCR amounts from page images…');
      const stockParsed = await parsePdfFile(stockFile, {
        ocrAmounts: true,
        onProgress: (msg) => setLoadingMsg(`Stock: ${msg}`),
      });
      // Reuse sold quick parse (no OCR needed)
      const soldParsed = soldQuick;

      setLoadingMsg('Building matrix…');
      const matched = buildStockVsSoldDetailReport({
        stockReport: stockParsed.report,
        soldReport: soldParsed.report,
        stockText: stockParsed.text,
        soldText: soldParsed.text,
        stockFileName: stockParsed.name,
        soldFileName: soldParsed.name,
      });

      const notes: string[] = [];
      if (swapped) {
        notes.push('Auto-swapped files (PDF title said Stock/Sold opposite to box)');
        setStockName(stockFile.name);
        setSoldName(soldFile.name);
        setStockFile(stockFile);
        setSoldFile(soldFile);
      }
      if (matched.totalUnique === 0) {
        const stockBc = (stockParsed.text.match(/\b\d{10,14}\b/g) || []).length;
        const soldBc = (soldParsed.text.match(/\b\d{10,14}\b/g) || []).length;
        setError(
          `No design numbers found. Stock: ${stockParsed.text.length} chars / ${stockBc} barcodes` +
            (stockParsed.report ? ` / ${stockParsed.report.grandTotalPcs} pcs` : ' / parse failed') +
            `. Sold: ${soldParsed.text.length} chars / ${soldBc} barcodes` +
            (soldParsed.report ? ` / ${soldParsed.report.grandTotalPcs} pcs` : ' / parse failed') +
            '. PDF needs text layer with design codes (WLR/ILR/R####).',
        );
      } else {
        const stockPcs = stockParsed.report?.grandTotalPcs || 0;
        const soldPcs = soldParsed.report?.grandTotalPcs || 0;
        const ocrN = stockParsed.ocrPriceCount || 0;
        if (stockPcs < 10 || soldPcs < 10) {
          notes.push(`branch parse partial (Stock=${stockPcs}, Sold=${soldPcs} pcs)`);
        }
        if (ocrN > 0) notes.push(`OCR ${ocrN} amounts from Stock images`);
        if (notes.length) {
          setError(`Report ready (${matched.totalUnique} designs). ${notes.join(' · ')}.`);
        }
      }
      // Branch stock snapshot so user can verify PDF read (BCT should be ~51)
      try {
        const brLines: string[] = [];
        const srep = stockParsed.report;
        if (srep?.branches?.length) {
          const top = [...srep.branches]
            .sort((a, b) => (b.totalPcs || 0) - (a.totalPcs || 0))
            .slice(0, 8)
            .map((b) => `${b.branch}:${b.totalPcs}`)
            .join(' ');
          brLines.push(`Stock branches ${srep.grandTotalPcs || 0}pcs → ${top}`);
        }
        const soldBr = soldParsed.report;
        if (soldBr?.branches?.length) {
          brLines.push(`Sold ${soldBr.grandTotalPcs || 0}pcs`);
        }
        if (brLines.length) {
          setError((prev) =>
            prev ? `${prev} · ${brLines.join(' · ')}` : `Report ready. ${brLines.join(' · ')}`,
          );
        }
      } catch { /* ignore */ }
      setReport(matched);
      setSelectedDesign('ALL');
      setPanelMode('summary');
      saveSvsToStorage({
        report: stripHeavyImages(matched),
        stockName: stockParsed.name || 'Stock.pdf',
        soldName: soldParsed.name || 'Sold.pdf',
        periodFrom,
        periodTo,
        periodPreset,
        distributionMode,
        savedAt: new Date().toLocaleString(),
      });
    } catch (e: any) {
      setError(e?.message || 'Failed to process PDFs.');
    } finally {
      setLoading(false);
      setLoadingMsg('');
    }
  }, []);

  const onStock = (file: File | null) => {
    if (!file || !/\.pdf$/i.test(file.name)) {
      if (file) setError('Stock file must be PDF.');
      return;
    }
    setStockFile(file);
    setStockName(file.name);
    setError(null);
    if (soldFile) void runMatch(file, soldFile);
  };

  const onSold = (file: File | null) => {
    if (!file || !/\.pdf$/i.test(file.name)) {
      if (file) setError('Sold file must be PDF.');
      return;
    }
    setSoldFile(file);
    setSoldName(file.name);
    setError(null);
    if (stockFile) void runMatch(stockFile, file);
  };

  const allCards: DesignCardDetail[] = useMemo(() => {
    if (!report) return [];
    return report.groups.flatMap((g) => g.cards);
  }, [report]);

  const designOptions = useMemo(() => {
    if (!report) return [];
    const q = search.trim().toUpperCase();
    return report.groups
      .map((g) => g.design)
      .filter((d) => !q || d.includes(q));
  }, [report, search]);

  /**
   * Match key = Design (normalized). Amount comes from Stock tags only.
   * Amount range: keep designs whose stock unit price (avg of stock tags) falls in [min, max].
   * Sold tags have amount 0 — they follow the design if that design's stock is in range.
   * If a design has only sold (no stock), exclude it when amount filter is active.
   */
  const filteredCards = useMemo(() => {
    if (!allCards.length) return [];

    const minA = amountMin.trim() ? parseFloat(amountMin.replace(/,/g, '')) : null;
    const maxA = amountMax.trim() ? parseFloat(amountMax.replace(/,/g, '')) : null;
    const hasAmountFilter =
      (minA != null && Number.isFinite(minA)) || (maxA != null && Number.isFinite(maxA));

    // Per-design stock unit amount (average of stock tag prices)
    const designStockAmt = new Map<string, { sum: number; n: number }>();
    for (const c of allCards) {
      if (c.source !== 'stock') continue;
      const prev = designStockAmt.get(c.design) || { sum: 0, n: 0 };
      prev.sum += c.amount || 0;
      prev.n += 1;
      designStockAmt.set(c.design, prev);
    }

    const designInRange = (design: string): boolean => {
      if (!hasAmountFilter) return true;
      const info = designStockAmt.get(design);
      if (!info || info.n === 0) return false; // no stock amount → exclude when filtering by price
      const unit = info.sum / info.n;
      if (minA != null && Number.isFinite(minA) && unit < minA) return false;
      if (maxA != null && Number.isFinite(maxA) && unit > maxA) return false;
      return true;
    };

    let cards = allCards.filter((c) => designInRange(c.design));
    if (selectedDesign !== 'ALL') {
      cards = cards.filter((c) => c.design === selectedDesign);
    }
    return cards;
  }, [allCards, selectedDesign, amountMin, amountMax]);

  /**
   * Image-wise matrix:
   * - ALL designs → each column = Design name, cell qty from images
   * - One design → each column = Amount ৳
   * Sub-cols always: Sold | Stock | Move
   * Rule: each card/image = 1 qty
   */
  const matrix = useMemo(() => {
    const useAmountCols = selectedDesign !== 'ALL';
    const colSet = new Set<string>();
    const branchSet = new Set<string>();
    const cells = new Map<string, Cell>();

    const amountKey = (amt: number): string => {
      if (!amt || !Number.isFinite(amt) || amt <= 0) return '0';
      return String(Math.round(amt / 1000) * 1000 || Math.round(amt));
    };

    for (const c of filteredCards) {
      const ck = useAmountCols
        ? amountKey(c.amount || 0)
        : (c.design || 'UNKNOWN').toUpperCase();
      colSet.add(ck);
      const br = (c.branch || 'UNK').toUpperCase();
      branchSet.add(br);
      const key = `${br}__${ck}`;
      const prev = cells.get(key) || { stk: 0, sold: 0, amount: 0 };
      if (c.source === 'stock') {
        prev.stk += 1;
        prev.amount += c.amount || 0;
      } else {
        prev.sold += 1;
      }
      cells.set(key, prev);
    }

    const columns = [...colSet].sort((a, b) =>
      useAmountCols ? parseFloat(a) - parseFloat(b) : a.localeCompare(b),
    );
    const branches = [...branchSet].sort((a, b) => {
      if (a === 'DWL') return -1;
      if (b === 'DWL') return 1;
      return a.localeCompare(b);
    });

    let totalStk = 0, totalSold = 0, totalIn = 0, totalOut = 0, totalAmount = 0, dwlStk = 0;
    const rows = branches.map((br) => {
      let rowStk = 0, rowSold = 0, rowIn = 0, rowOut = 0;
      const byCol: Record<string, Cell & { move: number }> = {};
      for (const col of columns) {
        const cell = cells.get(`${br}__${col}`) || { stk: 0, sold: 0, amount: 0 };
        const move = cell.sold - cell.stk;
        byCol[col] = { ...cell, move };
        rowStk += cell.stk;
        rowSold += cell.sold;
        if (move > 0) rowIn += move;
        else if (move < 0) rowOut += -move;
        totalAmount += cell.amount;
      }
      totalStk += rowStk;
      totalSold += rowSold;
      totalIn += rowIn;
      totalOut += rowOut;
      if (br === 'DWL') dwlStk = rowStk;
      return { branch: br, rowStk, rowSold, rowIn, rowOut, byCol };
    });

    return {
      columns,
      rows,
      totalStk,
      totalSold,
      totalIn,
      totalOut,
      totalAmount,
      dwlStk,
      caratLines: columns.length,
      designs: new Set(filteredCards.map((c) => c.design)).size,
      colMode: (useAmountCols ? 'amount' : 'design') as 'amount' | 'design',
      selectedDesignLabel: useAmountCols ? selectedDesign : '',
    };
  }, [filteredCards, selectedDesign, report]);

  /** Aging analysis from stock invoice dates (tag dates on images) */
  const aging = useMemo(() => {
    const asOf = new Date(); // report day
    const stockCards = (report?.groups || [])
      .flatMap((g) => g.cards || [])
      .filter((c) => c.source === 'stock');

    type Row = {
      design: string;
      branch: string;
      barcode: string;
      invoiceDate: string;
      days: number;
      bucket: AgingBucket;
      amount: number;
      dead: boolean;
    };
    const rows: Row[] = [];
    for (const c of stockCards) {
      const inv = c.invoiceDate || '';
      const d = parseInvoiceDate(inv);
      if (!d) {
        rows.push({
          design: c.design,
          branch: c.branch,
          barcode: c.barcode,
          invoiceDate: inv || '—',
          days: -1,
          bucket: '90+',
          amount: c.amount || 0,
          dead: false,
        });
        continue;
      }
      const days = daysBetween(d, asOf);
      const bucket = agingBucket(days);
      rows.push({
        design: c.design,
        branch: c.branch,
        barcode: c.barcode,
        invoiceDate: inv,
        days,
        bucket,
        amount: c.amount || 0,
        dead: days > 90,
      });
    }

    // Design-level summary (top = design)
    const byDesign = new Map<string, {
      design: string;
      pcs: number;
      deadPcs: number;
      maxDays: number;
      avgDays: number;
      amount: number;
      branches: Set<string>;
      dated: number;
    }>();
    for (const r of rows) {
      const prev = byDesign.get(r.design) || {
        design: r.design,
        pcs: 0,
        deadPcs: 0,
        maxDays: 0,
        avgDays: 0,
        amount: 0,
        branches: new Set<string>(),
        dated: 0,
      };
      prev.pcs += 1;
      if (r.dead) prev.deadPcs += 1;
      if (r.days >= 0) {
        prev.maxDays = Math.max(prev.maxDays, r.days);
        prev.avgDays += r.days;
        prev.dated += 1;
      }
      prev.amount += r.amount || 0;
      prev.branches.add(r.branch);
      byDesign.set(r.design, prev);
    }
    const designRows = [...byDesign.values()]
      .map((d) => ({
        ...d,
        avgDays: d.dated ? Math.round(d.avgDays / d.dated) : 0,
        branchList: [...d.branches].sort().join(', '),
      }))
      .sort((a, b) => b.maxDays - a.maxDays || b.deadPcs - a.deadPcs);

    const withDate = rows.filter((r) => r.days >= 0);
    const dead = withDate.filter((r) => r.dead);
    const b0 = withDate.filter((r) => r.bucket === '0-30').length;
    const b1 = withDate.filter((r) => r.bucket === '31-60').length;
    const b2 = withDate.filter((r) => r.bucket === '61-90').length;
    const b3 = withDate.filter((r) => r.bucket === '90+').length;

    return {
      rows: rows.sort((a, b) => b.days - a.days),
      designRows,
      totalStock: stockCards.length,
      dated: withDate.length,
      undated: stockCards.length - withDate.length,
      deadPcs: dead.length,
      deadAmount: dead.reduce((s, r) => s + (r.amount || 0), 0),
      buckets: { '0-30': b0, '31-60': b1, '61-90': b2, '90+': b3 },
      asOf: asOf.toLocaleDateString(),
    };
  }, [report]);

  const handleExport = async () => {
    if (!report) return;
    setExporting(true);
    try {
      await exportStockVsSoldExcel(report);
    } catch (e: any) {
      setError(e?.message || 'Export failed.');
    } finally {
      setExporting(false);
    }
  };

  const dropBox = (
    kind: 'stock' | 'sold',
    name: string,
    ref: React.RefObject<HTMLInputElement | null>,
    onFile: (f: File | null) => void,
    color: string,
    Icon: React.ComponentType<{ className?: string }>,
  ) => (
    <div
      className="flex-1 rounded-xl border-2 border-dashed p-3 text-center"
      style={{ borderColor: name ? color : '#CBD5E1', background: name ? `${color}12` : '#F8FAFC' }}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        onFile(e.dataTransfer.files?.[0] || null);
      }}
    >
      <input
        ref={ref as any}
        type="file"
        accept="application/pdf,.pdf"
        className="hidden"
        onChange={(e) => onFile(e.target.files?.[0] || null)}
      />
      <div className="mx-auto w-9 h-9 rounded-lg flex items-center justify-center text-white mb-1.5" style={{ background: color }}>
        <Icon className="w-4 h-4" />
      </div>
      <p className="text-[12px] font-bold text-[#0B2545]">{kind === 'stock' ? 'Stock PDF' : 'Sold PDF'}</p>
      <p className="text-[10px] text-slate-500 truncate px-2">{name || 'Drop or click'}</p>
      <button
        type="button"
        onClick={() => ref.current?.click()}
        className="mt-1.5 inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-bold text-white"
        style={{ background: color }}
      >
        <Upload className="w-3 h-3" />
        {name ? 'Replace' : 'Upload'}
      </button>
    </div>
  );

  const moveCell = (move: number, summaryOnly: boolean) => {
    if (move === 0) {
      return <span className="text-[#94a3b8]">–</span>;
    }
    if (move > 0) {
      return (
        <span className="inline-block min-w-[2rem] rounded px-1 py-0.5 bg-emerald-100 text-emerald-800 font-bold tabular-nums">
          +{move}
        </span>
      );
    }
    return (
      <span className="inline-block min-w-[2rem] rounded px-1 py-0.5 bg-rose-100 text-rose-800 font-bold tabular-nums">
        {move}
      </span>
    );
  };

  return (
    <div className="p-3 sm:p-4 space-y-3 max-w-[1600px] mx-auto">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h2 className="text-[15px] font-black text-[#0f2744] flex items-center gap-2">
            <GitCompare className="w-4 h-4 text-[#0284C7]" />
            Stock vs Sold · Design Report
          </h2>
          <p className="text-[11px] text-[#6a6d70]">
            Analysis · Image PDF · Branch left · Carat top · Stk / Sold / Move — same layout as Design-wise Stock Analysis
          </p>
        </div>
        <div className="flex gap-2">
          {report && (
            <button
              type="button"
              disabled={exporting}
              onClick={() => void handleExport()}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#0284C7] hover:bg-[#0369A1] text-white text-[11px] font-bold px-3 py-1.5 disabled:opacity-60"
            >
              {exporting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
              Export Excel
            </button>
          )}
          <button
            type="button"
            onClick={reset}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#d0d7de] bg-white text-[#32363a] text-[11px] font-bold px-3 py-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear
          </button>
        </div>
      </div>

      {/* Period + Distribution — always visible BEFORE upload */}
      <div className="rounded-xl border border-[#d0d7de] bg-white px-3 py-2.5 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-black uppercase tracking-wide text-slate-500">
              Period
            </span>
            <select
              value={periodPreset}
              onChange={(e) => {
                const v = e.target.value as typeof periodPreset;
                setPeriodPreset(v);
                if (v === 'custom') return;
                const to = new Date();
                const from = new Date();
                const months =
                  v === '1M' ? 1 : v === '3M' ? 3 : v === '6M' ? 6 : v === '9M' ? 9 : 12;
                from.setMonth(from.getMonth() - months);
                setPeriodFrom(from.toISOString().slice(0, 10));
                setPeriodTo(to.toISOString().slice(0, 10));
              }}
              className="rounded-lg border border-[#d0d7de] px-2 py-1.5 text-[12px] font-semibold bg-white"
            >
              <option value="custom">Custom</option>
              <option value="1M">1M</option>
              <option value="3M">3M</option>
              <option value="6M">6M</option>
              <option value="9M">9M</option>
              <option value="1Y">1Y</option>
            </select>
            <input
              type="date"
              value={periodFrom}
              onChange={(e) => {
                setPeriodFrom(e.target.value);
                setPeriodPreset('custom');
              }}
              className="rounded-lg border border-[#d0d7de] px-2 py-1.5 text-[12px] w-[132px]"
              title="From date"
            />
            <span className="text-[11px] text-slate-400 font-bold">→</span>
            <input
              type="date"
              value={periodTo}
              onChange={(e) => {
                setPeriodTo(e.target.value);
                setPeriodPreset('custom');
              }}
              className="rounded-lg border border-[#d0d7de] px-2 py-1.5 text-[12px] w-[132px]"
              title="To date"
            />
          </div>

          <div className="h-6 w-px bg-[#d0d7de] hidden sm:block" />

          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-black uppercase tracking-wide text-slate-500">
              Distribution
            </span>
            <select
              value={distributionMode}
              onChange={(e) =>
                setDistributionMode(
                  e.target.value as
                    | 'contribution'
                    | 'baseline'
                    | 'hybrid'
                    | 'liquidity'
                    | 'demand_backup'
                    | 'coverage',
                )
              }
              className="rounded-lg border border-[#d0d7de] px-2 py-1.5 text-[12px] font-semibold bg-white min-w-[220px]"
              title="Same 6 modes as Design-wise Stock Analysis"
            >
              <option value="contribution">① Sales Contribution</option>
              <option value="baseline">② 3-Month Baseline</option>
              <option value="hybrid">③ Hybrid</option>
              <option value="liquidity">④ Capital Liquidity</option>
              <option value="demand_backup">⑤ Demand-Backup</option>
              <option value="coverage">⑥ Universal Coverage</option>
            </select>
          </div>

          <div className="h-6 w-px bg-[#d0d7de] hidden sm:block" />

          {/* Amount range — Stock price only (e.g. 1 lac – 3 lac) */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-black uppercase tracking-wide text-slate-500">
              Amount (Stock)
            </span>
            <input
              type="number"
              inputMode="numeric"
              placeholder="Min e.g. 100000"
              value={amountMin}
              onChange={(e) => setAmountMin(e.target.value)}
              className="rounded-lg border border-[#d0d7de] px-2 py-1.5 text-[12px] w-[120px]"
              title="Minimum stock unit amount (৳)"
            />
            <span className="text-[11px] text-slate-400 font-bold">–</span>
            <input
              type="number"
              inputMode="numeric"
              placeholder="Max e.g. 300000"
              value={amountMax}
              onChange={(e) => setAmountMax(e.target.value)}
              className="rounded-lg border border-[#d0d7de] px-2 py-1.5 text-[12px] w-[120px]"
              title="Maximum stock unit amount (৳)"
            />
            {(amountMin || amountMax) && (
              <button
                type="button"
                onClick={() => {
                  setAmountMin('');
                  setAmountMax('');
                }}
                className="text-[10px] font-bold text-rose-600 hover:underline"
              >
                Clear
              </button>
            )}
          </div>
        </div>
        <p className="mt-1.5 text-[10px] text-slate-500">
          Match = <b>Design</b> · Amount = <b>Stock only</b> (Sold image-এ amount থাকে না) · Outlet-wise +{' '}
          <b>DWL warehouse</b> · Example filter: 100000–300000 (১–৩ লাখ)
        </p>
      </div>

      {/* Uploads */}
      <div className="flex flex-col sm:flex-row gap-2">
        {dropBox('stock', stockName, stockRef, onStock, '#0284C7', Package)}
        {dropBox('sold', soldName, soldRef, onSold, '#D97706', ShoppingBag)}
      </div>

      {loading && (
        <div className="flex items-center gap-2 rounded-lg bg-sky-50 border border-sky-100 px-3 py-2 text-[12px] text-sky-800">
          <Loader2 className="w-4 h-4 animate-spin" />
          {loadingMsg}
        </div>
      )}
      {error && (
        <div className="flex items-start gap-2 rounded-lg bg-rose-50 border border-rose-100 px-3 py-2 text-[12px] text-rose-800">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          {error}
        </div>
      )}

      {report && !loading && (
        <>
          {/* Toolbar — same pattern as Design-wise Stock Analysis */}
          <div className="flex flex-wrap items-center gap-2 bg-white border border-[#d0d7de] rounded-lg px-3 py-2">
            <button
              type="button"
              onClick={() => setPanelMode('summary')}
              className={`rounded-lg px-3 py-1.5 text-[12px] font-bold transition ${
                panelMode === 'summary'
                  ? 'bg-[#0B2545] text-white shadow'
                  : 'bg-[#f6f8fa] text-[#32363a] border border-[#d0d7de] hover:bg-white'
              }`}
            >
              Summary breakdown
            </button>
            <button
              type="button"
              onClick={() => setPanelMode('report')}
              className={`rounded-lg px-3 py-1.5 text-[12px] font-bold transition ${
                panelMode === 'report'
                  ? 'bg-[#0284C7] text-white shadow'
                  : 'bg-[#f6f8fa] text-[#32363a] border border-[#d0d7de] hover:bg-white'
              }`}
            >
              Full report
            </button>
            <button
              type="button"
              onClick={() => setPanelMode('aging')}
              className={`rounded-lg px-3 py-1.5 text-[12px] font-bold transition ${
                panelMode === 'aging'
                  ? 'bg-amber-600 text-white shadow'
                  : 'bg-[#f6f8fa] text-[#32363a] border border-[#d0d7de] hover:bg-white'
              }`}
            >
              Aging analysis
            </button>
            <label className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#32363a] ml-1 cursor-pointer">
              <input
                type="checkbox"
                checked={showOutlets}
                onChange={(e) => setShowOutlets(e.target.checked)}
                className="rounded border-slate-300"
              />
              Show outlets
            </label>

            {/* Distribution mode — mirrors Design-wise Stock Analysis */}
            <div className="flex items-center gap-1.5 ml-2 border-l border-[#d0d7de] pl-2">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                Distribution
              </span>
              <select
                value={distributionMode}
                onChange={(e) =>
                  setDistributionMode(
                    e.target.value as
                      | 'contribution'
                      | 'baseline'
                      | 'hybrid'
                      | 'liquidity'
                      | 'demand_backup'
                      | 'coverage',
                  )
                }
                className="rounded-lg border border-[#d0d7de] px-2 py-1 text-[11px] font-semibold bg-white min-w-[180px]"
                title="Same 6 modes as Design-wise Stock Analysis"
              >
                <option value="contribution">① Sales Contribution</option>
                <option value="baseline">② 3-Month Baseline</option>
                <option value="hybrid">③ Hybrid</option>
                <option value="liquidity">④ Capital Liquidity</option>
                <option value="demand_backup">⑤ Demand-Backup</option>
                <option value="coverage">⑥ Universal Coverage</option>
              </select>
            </div>

            {/* Date period — set at upload / analysis time */}
            <div className="flex items-center gap-1.5 border-l border-[#d0d7de] pl-2">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                Period
              </span>
              <select
                value={periodPreset}
                onChange={(e) => {
                  const v = e.target.value as typeof periodPreset;
                  setPeriodPreset(v);
                  if (v === 'custom') return;
                  const to = new Date();
                  const from = new Date();
                  const months = v === '1M' ? 1 : v === '3M' ? 3 : v === '6M' ? 6 : v === '9M' ? 9 : 12;
                  from.setMonth(from.getMonth() - months);
                  setPeriodFrom(from.toISOString().slice(0, 10));
                  setPeriodTo(to.toISOString().slice(0, 10));
                }}
                className="rounded-lg border border-[#d0d7de] px-2 py-1 text-[11px] font-semibold bg-white"
              >
                <option value="custom">Custom</option>
                <option value="1M">1M</option>
                <option value="3M">3M</option>
                <option value="6M">6M</option>
                <option value="9M">9M</option>
                <option value="1Y">1Y</option>
              </select>
              <input
                type="date"
                value={periodFrom}
                onChange={(e) => {
                  setPeriodFrom(e.target.value);
                  setPeriodPreset('custom');
                }}
                className="rounded-lg border border-[#d0d7de] px-1.5 py-1 text-[11px] w-[118px]"
                title="Period from"
              />
              <span className="text-[10px] text-slate-400">→</span>
              <input
                type="date"
                value={periodTo}
                onChange={(e) => {
                  setPeriodTo(e.target.value);
                  setPeriodPreset('custom');
                }}
                className="rounded-lg border border-[#d0d7de] px-1.5 py-1 text-[11px] w-[118px]"
                title="Period to"
              />
            </div>

            <div className="flex items-center gap-1.5 ml-auto">
              <div className="relative">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search design…"
                  className="rounded-lg border border-[#d0d7de] pl-7 pr-2 py-1 text-[11px] w-[140px]"
                />
              </div>
              <select
                value={selectedDesign}
                onChange={(e) => setSelectedDesign(e.target.value)}
                className="rounded-lg border border-[#d0d7de] px-2 py-1 text-[11px] font-semibold max-w-[180px]"
              >
                <option value="ALL">All designs</option>
                {designOptions.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* KPI strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
            {[
              { label: 'Designs', value: matrix.designs, icon: Layers, color: 'text-[#0B6FB8]' },
              { label: 'Carat lines', value: matrix.caratLines, icon: Gem, color: 'text-amber-700' },
              { label: 'Total Stock', value: matrix.totalStk, icon: Package, color: 'text-emerald-700' },
              { label: 'DWL Reserve', value: matrix.dwlStk, icon: Package, color: 'text-[#0B6FB8]' },
              { label: 'Total Sold', value: matrix.totalSold, icon: TrendingUp, color: 'text-blue-700' },
              {
                label: 'Refill Need',
                value: Math.max(0, matrix.totalSold - matrix.totalStk),
                icon: AlertTriangle,
                color: 'text-red-700',
              },
              { label: 'Move IN', value: matrix.totalIn, icon: TrendingUp, color: 'text-emerald-700' },
              { label: 'Move OUT', value: matrix.totalOut, icon: AlertTriangle, color: 'text-rose-700' },
            ].map((k) => (
              <div key={k.label} className="bg-white border border-[#d0d7de] px-3 py-2 rounded-lg">
                <div className="text-[10px] font-semibold text-[#6a6d70] uppercase tracking-wide flex items-center gap-1">
                  <k.icon className={`w-3 h-3 ${k.color}`} />
                  {k.label}
                </div>
                <div className="text-lg font-bold text-[#29445F] font-mono tabular-nums">
                  {k.value.toLocaleString()}
                </div>
              </div>
            ))}
          </div>

          {/* ===== SUMMARY BREAKDOWN ===== */}
          {panelMode === 'summary' && (
            <div className="bg-white border border-[#d0d7de] overflow-hidden rounded-lg select-text">
              <div className="px-3 py-2 bg-[#f6f8fa] border-b border-[#d0d7de] flex flex-wrap items-center justify-between gap-2">
                <div className="text-[12px] font-bold text-[#0f2744]">
                  Summary breakdown — Move IN / OUT
                  <span className="ml-2 text-[11px] font-medium text-[#6a6d70]">
                    Carat across top · Outlet left · only move cells
                    {selectedDesign !== 'ALL' ? ` · design = ${selectedDesign}` : ''}
                  </span>
                </div>
                <div className="text-[11px] font-semibold text-[#32363a]">
                  <span className="text-emerald-700">IN +{matrix.totalIn.toLocaleString()}</span>
                  <span className="mx-1.5 text-[#94a3b8]">·</span>
                  <span className="text-rose-700">OUT −{matrix.totalOut.toLocaleString()}</span>
                  <span className="mx-1.5 text-[#94a3b8]">·</span>
                  <span>{matrix.rows.length} outlets</span>
                </div>
              </div>
              <div className="overflow-auto max-h-[min(65vh,560px)]">
                <table className="w-full text-[11px] border-collapse">
                  <thead className="sticky top-0 z-[1]">
                    <tr className="bg-[#e8eef5]">
                      <th className="px-2 py-1.5 text-left font-bold text-[#0f2744] border border-[#c5d0dc] sticky left-0 bg-[#e8eef5] z-[2]">
                        Branch
                      </th>
                      {matrix.columns.map((c) => (
                        <th
                          key={c}
                          className="px-1.5 py-1.5 text-center font-bold text-[#0f2744] border border-[#c5d0dc] min-w-[3rem]"
                        >
                          {c}
                        </th>
                      ))}
                      <th className="px-2 py-1.5 text-center font-bold text-emerald-800 border border-[#c5d0dc] bg-emerald-50">
                        IN
                      </th>
                      <th className="px-2 py-1.5 text-center font-bold text-rose-800 border border-[#c5d0dc] bg-rose-50">
                        OUT
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {matrix.rows
                      .filter((r) => showOutlets || r.branch === 'DWL')
                      .map((r) => (
                        <tr key={r.branch} className={r.branch === 'DWL' ? 'bg-[#f0f7ff]' : ''}>
                          <td className="px-2 py-1 font-bold text-[#0B6FB8] border border-[#d0d7de] sticky left-0 bg-inherit z-[1]">
                            {r.branch}
                          </td>
                          {matrix.columns.map((c) => {
                            const cell = r.byCol[c];
                            const move = cell?.move || 0;
                            return (
                              <td
                                key={c}
                                className={`px-1 py-1 text-center border border-[#d0d7de] ${
                                  move > 0 ? 'bg-emerald-50' : move < 0 ? 'bg-rose-50' : ''
                                }`}
                              >
                                {moveCell(move, true)}
                              </td>
                            );
                          })}
                          <td className="px-2 py-1 text-center font-bold text-emerald-800 border border-[#d0d7de] bg-emerald-50/50 tabular-nums">
                            {r.rowIn ? `+${r.rowIn}` : '–'}
                          </td>
                          <td className="px-2 py-1 text-center font-bold text-rose-800 border border-[#d0d7de] bg-rose-50/50 tabular-nums">
                            {r.rowOut ? `−${r.rowOut}` : '–'}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
              <div className="px-3 py-1.5 bg-[#f6f8fa] border-t border-[#d0d7de] text-[10px] text-[#6a6d70]">
                Green = Move IN (sold &gt; stock) · Pink = Move OUT (stock &gt; sold) · Amount from Stock only
              </div>
            </div>
          )}

          {/* ===== FULL REPORT ===== */}
          {panelMode === 'report' && (
            <div className="bg-white border border-[#d0d7de] overflow-hidden rounded-lg">
              {/* Design on TOP (always visible) */}
              <div className="svs-report-banner px-3 py-2.5 bg-gradient-to-r from-[#0B2545] to-[#0B6FB8] text-white select-text">
                <div className="text-[10px] font-bold uppercase tracking-wider">
                  Design
                </div>
                <div className="text-[18px] font-black font-mono tracking-wide">
                  {selectedDesign === 'ALL' ? 'ALL DESIGNS' : selectedDesign}
                </div>
                <div className="mt-1 text-[12px] font-semibold flex flex-wrap gap-3">
                  <span>Stk {matrix.totalStk}</span>
                  <span>Sold {matrix.totalSold}</span>
                  <span className="text-emerald-200 font-bold">Move IN +{matrix.totalIn}</span>
                  <span className="text-rose-200 font-bold">Move OUT −{matrix.totalOut}</span>
                  {matrix.dwlStk > 0 && <span>DWL {matrix.dwlStk}</span>}
                  <span className="text-sky-100">
                    · {distributionMode === 'contribution' ? '① Contribution' :
                       distributionMode === 'baseline' ? '② Baseline' :
                       distributionMode === 'hybrid' ? '③ Hybrid' :
                       distributionMode === 'liquidity' ? '④ Liquidity' :
                       distributionMode === 'demand_backup' ? '⑤ Demand-Backup' :
                       '⑥ Coverage'}
                  </span>
                </div>
              </div>
              <div className="px-3 py-1.5 bg-[#f6f8fa] border-b border-[#d0d7de] flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#6a6d70]">
                <span>
                  Outlet left · Design top · Sold / Stock / Move · Contrib % = outlet sold ÷ total sold
                </span>
                <span>Green = Move IN · Pink = Move OUT</span>
              </div>
              <div className="overflow-auto max-h-[min(65vh,560px)]">
                <table className="w-full text-[10px] border-collapse">
                  <thead className="sticky top-0 z-[1]">
                    <tr className="bg-[#e8eef5]">
                      <th
                        rowSpan={2}
                        className="px-2 py-1 text-left font-bold text-[#0f2744] border border-[#c5d0dc] sticky left-0 bg-[#e8eef5] z-[2]"
                      >
                        Outlet
                      </th>
                      <th rowSpan={2} className="px-1.5 py-1 text-center font-bold border border-[#c5d0dc]">
                        T.Stock
                      </th>
                      <th rowSpan={2} className="px-1.5 py-1 text-center font-bold border border-[#c5d0dc]">
                        T.Sold
                      </th>
                      <th rowSpan={2} className="px-1.5 py-1 text-center font-bold border border-[#c5d0dc]" title="Sales contribution % of total sold">
                        Contrib%
                      </th>
                      <th rowSpan={2} className="px-1.5 py-1 text-center font-bold border border-[#c5d0dc]" title="Average unit amount from Stock">
                        Avg৳
                      </th>
                      <th rowSpan={2} className="px-1.5 py-1 text-center font-bold border border-[#c5d0dc] text-emerald-700">
                        IN
                      </th>
                      <th rowSpan={2} className="px-1.5 py-1 text-center font-bold border border-[#c5d0dc] text-rose-700">
                        OUT
                      </th>
                      {matrix.columns.map((c) => (
                        <th
                          key={c}
                          colSpan={3}
                          className="px-1 py-1 text-center font-bold text-[#0f2744] border border-[#c5d0dc]"
                        >
                          {matrix.colMode === 'amount' ? (
                            <span title="Amount (৳)">{Number(c).toLocaleString()}</span>
                          ) : (
                            <span className="font-mono text-[10px]" title={c}>{c}</span>
                          )}
                        </th>
                      ))}
                    </tr>
                    <tr className="bg-[#f0f4f8]">
                      {matrix.columns.map((c) => (
                        <React.Fragment key={c}>
                          <th className="px-1 py-0.5 text-center font-semibold border border-[#c5d0dc] text-[#64748b]">
                            Sold
                          </th>
                          <th className="px-1 py-0.5 text-center font-semibold border border-[#c5d0dc] text-[#64748b]">
                            Stock
                          </th>
                          <th className="px-1 py-0.5 text-center font-semibold border border-[#c5d0dc] text-[#64748b]">
                            Move
                          </th>
                        </React.Fragment>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {matrix.rows
                      .filter((r) => showOutlets || r.branch === 'DWL')
                      .map((r) => {
                        const contrib =
                          matrix.totalSold > 0
                            ? Math.round((r.rowSold / matrix.totalSold) * 1000) / 10
                            : 0;
                        // Avg amount for this branch from stock cards in filtered set
                        let amtSum = 0;
                        let amtN = 0;
                        for (const c of filteredCards) {
                          if ((c.branch || '').toUpperCase() !== r.branch) continue;
                          if (c.source !== 'stock' || !(c.amount > 0)) continue;
                          amtSum += c.amount;
                          amtN += 1;
                        }
                        const avgAmt = amtN > 0 ? Math.round(amtSum / amtN) : 0;
                        return (
                        <tr key={r.branch} className={r.branch === 'DWL' ? 'bg-[#f0f7ff]' : 'hover:bg-slate-50'}>
                          <td className="px-2 py-1 font-bold text-[#0B6FB8] border border-[#d0d7de] sticky left-0 bg-white z-[1]">
                            {r.branch}
                          </td>
                          <td className="px-1.5 py-1 text-center font-bold border border-[#d0d7de] tabular-nums">
                            {r.rowStk || '–'}
                          </td>
                          <td className="px-1.5 py-1 text-center font-bold border border-[#d0d7de] tabular-nums">
                            {r.rowSold || '–'}
                          </td>
                          <td className="px-1.5 py-1 text-center border border-[#d0d7de] tabular-nums text-[#0B2545] font-semibold">
                            {contrib > 0 ? `${contrib}%` : '–'}
                          </td>
                          <td className="px-1.5 py-1 text-center border border-[#d0d7de] tabular-nums text-slate-600">
                            {avgAmt > 0 ? avgAmt.toLocaleString() : '–'}
                          </td>
                          <td className="px-1.5 py-1 text-center font-bold border border-[#d0d7de] tabular-nums text-emerald-700">
                            {r.rowIn > 0 ? `+${r.rowIn}` : '–'}
                          </td>
                          <td className="px-1.5 py-1 text-center font-bold border border-[#d0d7de] tabular-nums text-rose-700">
                            {r.rowOut > 0 ? `−${r.rowOut}` : '–'}
                          </td>
                          {matrix.columns.map((c) => {
                            const cell = r.byCol[c] || { stk: 0, sold: 0, move: 0, amount: 0 };
                            return (
                              <React.Fragment key={c}>
                                <td className="px-1 py-1 text-center border border-[#d0d7de] tabular-nums">
                                  {cell.sold || '–'}
                                </td>
                                <td className="px-1 py-1 text-center border border-[#d0d7de] tabular-nums">
                                  {cell.stk || '–'}
                                </td>
                                <td
                                  className={`px-1 py-1 text-center border border-[#d0d7de] ${
                                    cell.move > 0 ? 'bg-emerald-50' : cell.move < 0 ? 'bg-rose-50' : ''
                                  }`}
                                >
                                  {moveCell(cell.move, false)}
                                </td>
                              </React.Fragment>
                            );
                          })}
                        </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {panelMode === 'aging' && (
            <div className="space-y-3">
              <div className="rounded-lg border border-amber-200 bg-amber-50/80 px-3 py-2 text-[12px] text-amber-950">
                <strong>Aging analysis</strong> — Stock tag invoice date থেকে আজ পর্যন্ত কতদিন পড়ে আছে।
                <span className="font-bold text-rose-700"> ৯০+ দিন (৩ মাস+)</span> = Dead / Stuck stock.
                As of: {aging.asOf}
                {aging.undated > 0 && (
                  <span className="ml-2 text-slate-600">
                    · {aging.undated} pcs date নেই
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                <div className="rounded-lg border border-[#d0d7de] bg-white px-3 py-2">
                  <div className="text-[10px] font-bold text-slate-500 uppercase">Stock pcs</div>
                  <div className="text-lg font-black text-[#0B2545]">{aging.totalStock}</div>
                </div>
                <div className="rounded-lg border border-[#d0d7de] bg-white px-3 py-2">
                  <div className="text-[10px] font-bold text-slate-500 uppercase">With date</div>
                  <div className="text-lg font-black text-[#0B2545]">{aging.dated}</div>
                </div>
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2">
                  <div className="text-[10px] font-bold text-emerald-700 uppercase">0–30d</div>
                  <div className="text-lg font-black text-emerald-800">{aging.buckets['0-30']}</div>
                </div>
                <div className="rounded-lg border border-sky-200 bg-sky-50 px-3 py-2">
                  <div className="text-[10px] font-bold text-sky-700 uppercase">31–60d</div>
                  <div className="text-lg font-black text-sky-800">{aging.buckets['31-60']}</div>
                </div>
                <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2">
                  <div className="text-[10px] font-bold text-amber-700 uppercase">61–90d</div>
                  <div className="text-lg font-black text-amber-800">{aging.buckets['61-90']}</div>
                </div>
                <div className="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2">
                  <div className="text-[10px] font-bold text-rose-700 uppercase">90+ Dead</div>
                  <div className="text-lg font-black text-rose-800">
                    {aging.buckets['90+']}
                    {aging.deadAmount > 0 && (
                      <span className="text-[11px] font-semibold ml-1">
                        · ৳{aging.deadAmount.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Design on top — summary by design */}
              <div className="rounded-xl border border-[#d0d7de] bg-white overflow-hidden">
                <div className="px-3 py-2 bg-[#0B2545] text-white text-[12px] font-bold">
                  Design-wise aging (max days · dead pcs)
                </div>
                <div className="overflow-x-auto max-h-[420px] overflow-y-auto">
                  <table className="min-w-full text-[11px] border-collapse">
                    <thead className="sticky top-0 z-[1] bg-[#f0f4f8]">
                      <tr>
                        <th className="px-2 py-1.5 text-left border border-[#c5d0dc]">Design</th>
                        <th className="px-2 py-1.5 text-center border border-[#c5d0dc]">Pcs</th>
                        <th className="px-2 py-1.5 text-center border border-[#c5d0dc]">Dead (90+)</th>
                        <th className="px-2 py-1.5 text-center border border-[#c5d0dc]">Max days</th>
                        <th className="px-2 py-1.5 text-center border border-[#c5d0dc]">Avg days</th>
                        <th className="px-2 py-1.5 text-right border border-[#c5d0dc]">Amount ৳</th>
                        <th className="px-2 py-1.5 text-left border border-[#c5d0dc]">Outlet(s)</th>
                        <th className="px-2 py-1.5 text-center border border-[#c5d0dc]">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {aging.designRows.map((d) => (
                        <tr
                          key={d.design}
                          className={d.deadPcs > 0 ? 'bg-rose-50/60 hover:bg-rose-50' : 'hover:bg-slate-50'}
                        >
                          <td className="px-2 py-1 border border-[#d0d7de] font-mono font-semibold text-[#0B2545]">
                            {d.design}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-center tabular-nums">
                            {d.pcs}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-center tabular-nums font-bold text-rose-700">
                            {d.deadPcs || '–'}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-center tabular-nums">
                            {d.maxDays || '–'}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-center tabular-nums">
                            {d.avgDays || '–'}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-right tabular-nums">
                            {d.amount > 0 ? d.amount.toLocaleString() : '–'}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-slate-600">
                            {d.branchList}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-center">
                            {d.deadPcs > 0 ? (
                              <span className="inline-block rounded px-1.5 py-0.5 text-[10px] font-bold bg-rose-100 text-rose-800">
                                DEAD / STUCK
                              </span>
                            ) : d.maxDays > 60 ? (
                              <span className="inline-block rounded px-1.5 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800">
                                AGING
                              </span>
                            ) : (
                              <span className="inline-block rounded px-1.5 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800">
                                OK
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                      {aging.designRows.length === 0 && (
                        <tr>
                          <td colSpan={8} className="px-3 py-6 text-center text-slate-500">
                            Stock date পাওয়া যায়নি — Stock PDF আবার আপলোড করুন (tag date থাকতে হবে)।
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Piece-level detail */}
              <div className="rounded-xl border border-[#d0d7de] bg-white overflow-hidden">
                <div className="px-3 py-2 bg-slate-800 text-white text-[12px] font-bold">
                  Piece-level (barcode) — oldest first
                </div>
                <div className="overflow-x-auto max-h-[320px] overflow-y-auto">
                  <table className="min-w-full text-[11px] border-collapse">
                    <thead className="sticky top-0 z-[1] bg-[#f0f4f8]">
                      <tr>
                        <th className="px-2 py-1.5 text-left border border-[#c5d0dc]">Design</th>
                        <th className="px-2 py-1.5 text-left border border-[#c5d0dc]">Outlet</th>
                        <th className="px-2 py-1.5 text-left border border-[#c5d0dc]">Barcode</th>
                        <th className="px-2 py-1.5 text-center border border-[#c5d0dc]">Invoice date</th>
                        <th className="px-2 py-1.5 text-center border border-[#c5d0dc]">Days</th>
                        <th className="px-2 py-1.5 text-center border border-[#c5d0dc]">Bucket</th>
                        <th className="px-2 py-1.5 text-right border border-[#c5d0dc]">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {aging.rows.slice(0, 500).map((r, i) => (
                        <tr
                          key={`${r.barcode}-${i}`}
                          className={r.dead ? 'bg-rose-50/70' : 'hover:bg-slate-50'}
                        >
                          <td className="px-2 py-1 border border-[#d0d7de] font-mono">{r.design}</td>
                          <td className="px-2 py-1 border border-[#d0d7de] font-semibold text-[#0B6FB8]">
                            {r.branch}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] font-mono text-slate-600">
                            {r.barcode || '–'}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-center">
                            {r.invoiceDate}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-center tabular-nums font-bold">
                            {r.days >= 0 ? r.days : '–'}
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-center">
                            <span
                              className={`inline-block rounded px-1.5 py-0.5 text-[10px] font-bold ${
                                r.bucket === '90+'
                                  ? 'bg-rose-100 text-rose-800'
                                  : r.bucket === '61-90'
                                    ? 'bg-amber-100 text-amber-800'
                                    : r.bucket === '31-60'
                                      ? 'bg-sky-100 text-sky-800'
                                      : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {r.days >= 0 ? r.bucket : 'N/A'}
                            </span>
                          </td>
                          <td className="px-2 py-1 border border-[#d0d7de] text-right tabular-nums">
                            {r.amount > 0 ? r.amount.toLocaleString() : '–'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {!report && !loading && !error && (
        <div className="rounded-lg border border-dashed border-[#d0d7de] bg-[#f6f8fa] py-10 text-center text-[13px] text-[#6a6d70]">
          <p className="font-bold text-[#0f2744] mb-1">Upload Stock PDF + Sold PDF</p>
          Summary · Full report · Aging analysis (invoice date → dead stock 90+ days)
        </div>
      )}
    </div>
  );
};

export default StockVsSoldDesignReportView;
