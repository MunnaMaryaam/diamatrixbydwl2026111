import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate, useSearch } from '@tanstack/react-router';
import { useAIInsightsStore } from './store/aiInsightsStore';
import { DEFAULT_RAW_RECORDS, DEFAULT_PERIOD } from './data/defaultDataset';
import { calculateRedistributionReport } from './utils/redistributionEngine';
import { RawInventoryRecord, SalesTimeframe, AllocationMode, AuthUser, SpecialMonth } from './types';
import {
  ReportFilterBar,
  ReportFilters,
  EMPTY_FILTERS,
  applyReportFilters
} from './components/ReportFilterBar';
import { learnFromRecords, applyIdentityToRecords } from './utils/dataIdentityEngine';
import { restoreSession, setCurrentSession, logoutCurrentSession } from './utils/authEngine';
import { AppSettings, getStoredSettings, applyThemeToDocument } from './utils/settingsEngine';
import { ErpStatusBar } from './components/ErpStatusBar';
import { AboutLuminaModal } from './components/AboutLuminaModal';
import { DemoDataBanner } from './components/DemoDataBanner';
import { LuminaSplash } from './components/LuminaSplash';
import { LoginPortal } from './components/LoginPortal';
import { GatewayOfDiaMatrix, type GatewayMode, type NavScope } from './components/GatewayOfDiaMatrix';
import { UserManagementModal } from './components/UserManagementModal';
import { SettingsModal } from './components/SettingsModal';
import { OptionWiseAllocationView } from './components/OptionWiseAllocationView';
import { MovementAndAgingReportView } from './components/MovementAndAgingReportView';
import { RefillDemandReport } from './components/RefillDemandReport';
import { ExcelReportSheetView } from './components/ExcelReportSheetView';
import { OutletDesignMatrixReport } from './components/OutletDesignMatrixReport';
import { MovementSummaryView } from './components/MovementSummaryView';
import { BranchSummaryTable } from './components/BranchSummaryTable';
import { DesignWiseStockAnalysis } from './components/DesignWiseStockAnalysis';
import { DemandOpportunityAnalysis } from './components/DemandOpportunityAnalysis';
import { AICrossmatchReportView } from './components/AICrossmatchReportView';
import { StockTurnRateDashboard } from './components/StockTurnRateDashboard';
import { AllReportsHub, ReportKey } from './components/AllReportsHub';
import { OperationsDataDrawer } from './components/OperationsDataDrawer';
import { AIAssistantDrawer } from './components/AIAssistantDrawer';
import { BranchDetailModal } from './components/BranchDetailModal';
import { ProductLocationModal } from './components/ProductLocationModal';
import { DailyDualFileUploadModal } from './components/DailyDualFileUploadModal';
import { UploadHistoryPanel } from './components/UploadHistoryPanel';
import { NetSuiteTopHeader } from './components/NetSuiteTopHeader';
import { AppSideNav } from './components/AppSideNav';
import { NewOrderView } from './components/NewOrderView';
import { OPEN_NEW_ORDER_EVENT } from './utils/refillOrderStore';
import { NetSuiteHomeDashboard } from './components/NetSuiteHomeDashboard';
import { FestivalSchemeView } from './festival/FestivalSchemeView';
import { PdfLabelReportView } from './pdfLabel/PdfLabelReportView';
import { StockVsSoldDesignReportView } from './components/StockVsSoldDesignReportView';
import { BRAND } from './brand';
import { saveDailySnapshot } from './utils/dailyStorageEngine';
import {
  bootstrapInventoryFromIdb,
  saveWorkingDataset,
  mergeRecordsAppend,
  ImportMode,
} from './utils/indexedDbEngine';
import {
  exportStyledExcelReport,
  exportReportPdf,
} from './utils/styledReportExport';
import {
  LayoutDashboard,
  FileSpreadsheet,
  ArrowRightLeft,
  Flame,
  Building2,
  Gem,
  ShieldCheck,
  PackagePlus,
  Files,
  Clock,
  Activity,
  SlidersHorizontal,
  ChevronRight,
  TrendingUp,
  FolderLock,
  Home,
  LayoutGrid,
  Sparkles,
  History,
  FileDown,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { installCloudSync, syncWithCloud } from './utils/cloudSync';

// Start watching shared settings as early as possible (does nothing when Supabase is not configured).
installCloudSync();

/** URL slugs for the two AI report pages that can be opened by link. */
const DEEP_LINKS: Record<string, { view: string; report?: string }> = {
  'demand-forecasting': { view: 'reports', report: 'demand_booster' },
  'stock-redistribution': { view: 'movement_aging' },
};

function deepLinkSlug(view: string, report?: string): string | undefined {
  return Object.keys(DEEP_LINKS).find(
    (slug) => DEEP_LINKS[slug].view === view && (DEEP_LINKS[slug].report ?? undefined) === (report ?? undefined),
  );
}

export default function App() {
  // Authentication & System Settings state
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // After sign-in: pull shared data from Supabase and push local changes. Reload once if new data arrived.
  React.useEffect(() => {
    if (!currentUser) return;
    let cancelled = false;
    void syncWithCloud().then(({ changed }) => {
      if (cancelled || !changed) return;
      const last = Number(sessionStorage.getItem('dmx.cloud.lastReload') || 0);
      if (Date.now() - last < 30000) return; // never loop
      sessionStorage.setItem('dmx.cloud.lastReload', String(Date.now()));
      window.location.reload();
    });
    return () => { cancelled = true; };
  }, [currentUser?.id]);

  React.useEffect(() => {
    const splashStartedAt = Date.now();
    let timeoutId: number | undefined;
    let cancelled = false;
    restoreSession().then(setCurrentUser).finally(() => {
      const remainingSplashTime = Math.max(0, 4000 - (Date.now() - splashStartedAt));
      timeoutId = window.setTimeout(() => {
        if (!cancelled) setAuthLoading(false);
      }, remainingSplashTime);
    });
    return () => {
      cancelled = true;
      if (timeoutId !== undefined) window.clearTimeout(timeoutId);
    };
  }, []);
  const [isUserManagementOpen, setIsUserManagementOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [appSettings, setAppSettings] = useState<AppSettings>(() => getStoredSettings());

  // Apply theme on initial load or settings change
  React.useEffect(() => {
    applyThemeToDocument(appSettings.theme);
  }, [appSettings.theme]);

  const [rawRecords, setRawRecords] = useState<RawInventoryRecord[]>(DEFAULT_RAW_RECORDS);
  /** demo = built-in sample; upload = user file; empty = cleared */
  const [dataSource, setDataSource] = useState<'demo' | 'upload' | 'empty'>('demo');
  const [lastUploadAt, setLastUploadAt] = useState<string | null>(null);
  const [demoBannerDismissed, setDemoBannerDismissed] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [period, setPeriod] = useState<string>(DEFAULT_PERIOD);
  const [selectedTimeframe, setSelectedTimeframe] = useState<SalesTimeframe>('3M');
  /** Festival / Exhibition / Promotion months marked at upload — excluded from normal average */
  const [specialMonths, setSpecialMonths] = useState<SpecialMonth[]>([]);
  const runInsights = useAIInsightsStore((state) => state.runInsights);

  // Keeps the insights store aligned with the working dataset for every path that
  // replaces it (initial load, restore from history). No-ops if already computed.
  useEffect(() => {
    runInsights(rawRecords, specialMonths, 'sync');
  }, [rawRecords, specialMonths, runInsights]);

  // TanStack Router deep links: /?view=demand-forecasting or /?view=stock-redistribution
  const navigate = useNavigate();
  const { view: urlView } = useSearch({ strict: false }) as { view?: string };
  useEffect(() => {
    const target = urlView ? DEEP_LINKS[urlView] : undefined;
    if (!target) return;
    setActiveView(target.view as typeof activeView);
    if (target.report) setActiveReport(target.report as typeof activeReport);
  }, [urlView]);

  /** Keeps the address bar in sync with sidebar clicks on the two linkable reports. */
  const syncUrl = (view: string, report?: string) => {
    const slug = deepLinkSlug(view, report);
    void navigate({ to: '/', search: slug ? { view: slug } : {} });
  };
  // 3 analysis modes: contribution | baseline | hybrid — switches full-app distribution
  const [allocationMode, setAllocationMode] = useState<AllocationMode>('contribution');

  // Primary Navigation View - default to 'dashboard' (Overview Scorecard) matching user's reference layout
  const [activeView, setActiveView] = useState<
    'gateway' | 'menu' | 'dashboard' | 'option_allocation' | 'movement_aging' | 'consignment_shipment' | 'reports' | 'festival_scheme' | 'pdf_label_report' | 'stock_vs_sold_design' | 'new_order'
  >('gateway');

  const [visitedStockVsSold, setVisitedStockVsSold] = useState(false);
  const [visitedPdfLabel, setVisitedPdfLabel] = useState(false);
  useEffect(() => {
    if (activeView === 'stock_vs_sold_design') setVisitedStockVsSold(true);
    if (activeView === 'pdf_label_report') setVisitedPdfLabel(true);
  }, [activeView]);
  const [navScope, setNavScope] = useState<NavScope>('full');
  /** full = normal; guest = read-only; education = guided demo */
  const [appMode, setAppMode] = useState<GatewayMode>('full');
  const isRestrictedMode = appMode === 'guest' || appMode === 'education';
  const openDailyUpload = () => {
    if (isRestrictedMode) return;
    setIsDailyUploadOpen(true);
  };

  // Guest / Educational: only gateway + dashboard
  useEffect(() => {
    if (!isRestrictedMode) return;
    if (activeView !== 'gateway' && activeView !== 'dashboard' && activeView !== 'menu') {
      setActiveView('dashboard');
    }
  }, [isRestrictedMode, activeView]);

  // "Requisition" button in Refill Demand -> jump to the New Order page
  useEffect(() => {
    const open = () => setActiveView('new_order');
    window.addEventListener(OPEN_NEW_ORDER_EVENT, open);
    return () => window.removeEventListener(OPEN_NEW_ORDER_EVENT, open);
  }, []);

  // Tally-style: Escape returns to Gateway (except on gateway / login)
  useEffect(() => {
    const onEsc = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (activeView === 'gateway') return;
      // Don't steal Esc from open dialogs
      if (document.querySelector('[role="dialog"], [aria-modal="true"]')) return;
      e.preventDefault();
      setActiveView('gateway');
      setNavScope('full');
    };
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, [activeView]);

  // Sub-report selection when in 'reports' mode:
  // 'ai_crossmatch' = AI Mode report; all others = Manual engine views
  const [activeReport, setActiveReport] = useState<
    | 'refill_demand'
    | 'excel_sheet'
    | 'outlet_design_matrix'
    | 'movement_summary'
    | 'branches'
    | 'weights'
    | 'demand_booster'
    | 'ai_crossmatch'
    | 'execution'
    | 'stock_turn_rate'
  >('refill_demand');
  /** manual = Apply & Distribution engine UI; ai = AI Crossmatch Report */
  const [analysisMode, setAnalysisMode] = useState<'manual' | 'ai'>('manual');

  // Universal item selector. No product is hard-coded as the default.
  const [selectedWeightFilter, setSelectedWeightFilter] = useState<string>('');
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>('');

  // NetSuite-style Stock & Sold filters (Branch ID, Cts range, Category)
  // All reports regenerate against the filtered slice of uploaded data.
  const [reportFilters, setReportFilters] = useState<ReportFilters>(EMPTY_FILTERS);

  const filteredRecords = useMemo(
    () => applyReportFilters(rawRecords, reportFilters),
    [rawRecords, reportFilters]
  );

  // Inspection Modals
  const [inspectingBranch, setInspectingBranch] = useState<string | null>(null);
  const [inspectingProduct, setInspectingProduct] = useState<string | null>(null);

  // Drawers & Modals
  const [isOperationsFolderOpen, setIsOperationsFolderOpen] = useState(false);
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState(false);
  const [isDailyUploadOpen, setIsDailyUploadOpen] = useState(false);
  const [isUploadHistoryOpen, setIsUploadHistoryOpen] = useState(false);

  // Global Escape handling: close the top-most app layer without changing navigation.
  // Nested dialogs (for example Column Mapper inside Daily Intake) handle Escape
  // themselves first and stop propagation so only the nested layer closes.
  React.useEffect(() => {
    const handleGlobalEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;

      if (isSettingsOpen) {
        event.preventDefault();
        setIsSettingsOpen(false);
        return;
      }
      if (isUserManagementOpen) {
        event.preventDefault();
        setIsUserManagementOpen(false);
        return;
      }
      if (isDailyUploadOpen) {
        event.preventDefault();
        setIsDailyUploadOpen(false);
        return;
      }
      if (isAiDrawerOpen) {
        event.preventDefault();
        setIsAiDrawerOpen(false);
        return;
      }
      if (isOperationsFolderOpen) {
        event.preventDefault();
        setIsOperationsFolderOpen(false);
        return;
      }
      if (isUploadHistoryOpen) {
        event.preventDefault();
        setIsUploadHistoryOpen(false);
        return;
      }
      if (isAboutOpen) {
        event.preventDefault();
        setIsAboutOpen(false);
        return;
      }
      if (inspectingProduct !== null) {
        event.preventDefault();
        setInspectingProduct(null);
        return;
      }
      if (inspectingBranch !== null) {
        event.preventDefault();
        setInspectingBranch(null);
      }
    };

    window.addEventListener('keydown', handleGlobalEscape);
    return () => window.removeEventListener('keydown', handleGlobalEscape);
  }, [
    isSettingsOpen,
    isUserManagementOpen,
    isDailyUploadOpen,
    isAiDrawerOpen,
    isOperationsFolderOpen,
    isUploadHistoryOpen,
    isAboutOpen,
    inspectingProduct,
    inspectingBranch,
  ]);

  // Analytical Report calculation — always from filtered upload data + timeframe
  // Production workflow:
  // 1) After upload → CATEGORY-wise report by default
  // 2) User filters Style/SKU or Sub Category → only THAT design's report
  // 3) Only style sheets (no category layer) → design keys required
  // Excel layout unchanged; filter only selects which design rows appear.
  const hasDesignLayer = useMemo(
    () => rawRecords.some((r) => !!(r.itemCode || r.variant || '').trim()),
    [rawRecords],
  );
  const hasCategoryLayer = useMemo(
    () => rawRecords.some((r) => !(r.itemCode || r.variant || '').trim()),
    [rawRecords],
  );
  const designFilterActive = !!(reportFilters.subCategory || reportFilters.styleCode || '').trim();
  const designModeActive =
    designFilterActive ||
    (hasDesignLayer && !hasCategoryLayer);
  // Exact trailing-S filter (MOHS, BCTS) → keep individual outlet in matrix
  const preserveTrailingS = /^[a-zA-Z]{2,4}s$/i.test(reportFilters.branchId.trim());
  const report = useMemo(() => {
    return calculateRedistributionReport(
      filteredRecords,
      period,
      undefined,
      undefined,
      undefined,
      selectedTimeframe,
      allocationMode,
      specialMonths,
      designModeActive,
      preserveTrailingS
    );
  }, [
    filteredRecords,
    period,
    selectedTimeframe,
    allocationMode,
    specialMonths,
    designModeActive,
    preserveTrailingS,
  ]);
  // Pure category-layer report for Design-wise "Main Category" tab + Excel sheet 01
  const categoryReport = useMemo(() => {
    if (!hasCategoryLayer) return undefined;
    // Always compute category layer when category data exists (for Excel sheet 01)
    return calculateRedistributionReport(
      filteredRecords,
      period,
      undefined,
      undefined,
      undefined,
      selectedTimeframe,
      allocationMode,
      specialMonths,
      false, // always category mode
      preserveTrailingS
    );
  }, [
    filteredRecords,
    period,
    selectedTimeframe,
    allocationMode,
    specialMonths,
    preserveTrailingS,
    hasCategoryLayer,
  ]);
  // Design-layer report ALWAYS when style sheets exist — used for Excel design sheets
  // even when screen is showing category (designModeActive=false)
  const designReport = useMemo(() => {
    if (!hasDesignLayer) return undefined;
    return calculateRedistributionReport(
      filteredRecords,
      period,
      undefined,
      undefined,
      undefined,
      selectedTimeframe,
      allocationMode,
      specialMonths,
      true, // always design mode
      preserveTrailingS
    );
  }, [
    filteredRecords,
    period,
    selectedTimeframe,
    allocationMode,
    specialMonths,
    preserveTrailingS,
    hasDesignLayer,
  ]);

  /** Parse "DD-MM-YYYY to DD-MM-YYYY" (or ISO) and return approximate month span. */
  const inferMonthsFromPeriod = (periodText: string): number | null => {
    const p = periodText.trim();
    // Match DD-MM-YYYY to DD-MM-YYYY or YYYY-MM-DD to YYYY-MM-DD
    const m1 = p.match(/(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})\s*(?:to|-|–|—)\s*(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/i);
    if (m1) {
      // DD-MM-YYYY
      const from = new Date(Number(m1[3]), Number(m1[2]) - 1, Number(m1[1]));
      const to = new Date(Number(m1[6]), Number(m1[5]) - 1, Number(m1[4]));
      if (!isNaN(from.getTime()) && !isNaN(to.getTime())) {
        const days = Math.abs(to.getTime() - from.getTime()) / (1000 * 60 * 60 * 24);
        return Math.max(1, Math.round(days / 30.44));
      }
    }
    const m2 = p.match(/(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})\s*(?:to|-|–|—)\s*(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/i);
    if (m2) {
      const from = new Date(Number(m2[1]), Number(m2[2]) - 1, Number(m2[3]));
      const to = new Date(Number(m2[4]), Number(m2[5]) - 1, Number(m2[6]));
      if (!isNaN(from.getTime()) && !isNaN(to.getTime())) {
        const days = Math.abs(to.getTime() - from.getTime()) / (1000 * 60 * 60 * 24);
        return Math.max(1, Math.round(days / 30.44));
      }
    }
    return null;
  };

  const monthsToTimeframe = (months: number): SalesTimeframe => {
    if (months <= 1) return '1M';
    if (months <= 4) return '3M';
    if (months <= 7) return '6M';
    if (months <= 10) return '9M'; // 8–10 months → 9M (your 01-01 to 22-09 case)
    if (months <= 18) return '1Y';
    return '2Y';
  };

  
  // Load permanent inventory from IndexedDB (no re-upload needed next day)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { records, meta } = await bootstrapInventoryFromIdb();
        if (cancelled || !records.length) return;
        setRawRecords(records);
        if (meta?.period) {
          setPeriod(meta.period);
        }
        console.info(
          `[DiaMatrix] Restored ${records.length} rows from IndexedDB`,
          meta?.label || ''
        );
      } catch (e) {
        console.warn('IndexedDB bootstrap skipped', e);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleImportRecords = (
    newRecords: RawInventoryRecord[],
    newPeriod?: string,
    newSpecialMonths?: SpecialMonth[],
    importMode: ImportMode = 'replace'
  ) => {
    // Intelligent identity: remember branch / cents / product shortcuts from this upload
    // so the next unorganized file still maps to the same unique names
    learnFromRecords(newRecords);
    let normalized = applyIdentityToRecords(newRecords);
    if (importMode === 'append') {
      // rawRecords from closure is current working set restored from IDB
      normalized = mergeRecordsAppend(rawRecords, normalized);
    }
    const nextRecords = [...normalized];
    const nextSpecialMonths = newSpecialMonths && newSpecialMonths.length > 0 ? newSpecialMonths : [];
    setRawRecords(nextRecords);
    // Push the parsed dataset straight into the AI engines; results land in the insights store.
    useAIInsightsStore.getState().runInsights(nextRecords, nextSpecialMonths, 'upload');
    setDataSource(normalized.length > 0 ? 'upload' : 'empty');
    setLastUploadAt(
      new Date().toLocaleString([], {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    );
    setDemoBannerDismissed(false);
    if (newPeriod) setPeriod(newPeriod);
    // Always update special months on import (empty array clears previous tags)
    setSpecialMonths(nextSpecialMonths);

    // Infer SalesTimeframe from actual date span OR keyword so "9 month" data shows as 9M
    if (newPeriod) {
      const p = newPeriod.toLowerCase();
      const monthsFromDates = inferMonthsFromPeriod(newPeriod);

      if (monthsFromDates != null) {
        setSelectedTimeframe(monthsToTimeframe(monthsFromDates));
      } else if (p.includes('9 month') || p.includes('9m') || p.includes('nine month')) {
        setSelectedTimeframe('9M');
      } else if (p.includes('6 month') || p.includes('6m') || p.includes('180')) {
        setSelectedTimeframe('6M');
      } else if (p.includes('2 year') || p.includes('2y') || p.includes('730')) {
        setSelectedTimeframe('2Y');
      } else if (p.includes('1 year') || p.includes('1y') || p.includes('ytd') || p.includes('365')) {
        setSelectedTimeframe('1Y');
      } else if (p.includes('1 month') || p.includes('1m') || p.includes('30 day') || p.includes('7 day') || p.includes('15 day')) {
        setSelectedTimeframe('1M');
      } else {
        setSelectedTimeframe('3M');
      }
    }

    if (newRecords.length > 0) {
      const weights = Array.from(new Set(newRecords.map(r => r.weight))).sort((a, b) => {
        const na = parseFloat(a);
        const nb = parseFloat(b);
        if (!isNaN(na) && !isNaN(nb)) return na - nb;
        return a.localeCompare(b);
      });
      setSelectedWeightFilter(weights[0] || '');
    } else {
      setSelectedWeightFilter('');
    }
    setSelectedBranchFilter('');
    setInspectingBranch(null);
    setInspectingProduct(null);
    // New upload → reset NetSuite filters so full dataset is visible
    setReportFilters(EMPTY_FILTERS);
    // Land on Operations Cockpit (dashboard) so AI Intelligence alerts recompute live immediately
    setActiveView('dashboard');
    setActiveReport('excel_sheet');
    setIsDailyUploadOpen(false);

    // Persist for Upload History → reopen previous analysis later
    if (normalized.length > 0) {
      try {
        saveDailySnapshot(
          normalized,
          undefined,
          `Upload ${newPeriod || period} · ${normalized.length} rows`
        );
      } catch {
        /* quota — ignore */
      }
      // Permanent IndexedDB working set (survives restart — append next day)
      void saveWorkingDataset(normalized, {
        mode: 'replace', // already merged in-memory when importMode was append
        label:
          importMode === 'append'
            ? `Appended ${new Date().toLocaleDateString()} · ${normalized.length} rows`
            : `Upload ${newPeriod || period} · ${normalized.length} rows`,
        period: newPeriod || period,
      }).catch((e) => console.warn('IndexedDB save failed', e));
    }
  };

  const handleBranchSelect = (branch: string) => {
    setSelectedBranchFilter(branch);
    setInspectingBranch(branch);
  };

  const handleWeightSelect = (weight: string) => {
    setSelectedWeightFilter(weight);
    setInspectingProduct(weight);
  };

  const handleNavigateFromAlert = (tab: string) => {
    if (tab === 'option_allocation') {
      setActiveView('option_allocation');
    } else if (tab === 'movement_aging') {
      setActiveView('movement_aging');
    } else if (tab === 'consignment_shipment' || tab === 'refill_demand' || tab === 'procurement') {
      setActiveView('reports');
      setActiveReport('refill_demand');
    } else if (tab === 'redistribution') {
      setActiveView('reports');
      setActiveReport('movement_summary');
    } else if (tab === 'excel_sheet' || tab === 'matrix') {
      setActiveView('reports');
      setActiveReport('excel_sheet');
    } else if (tab === 'branches') {
      setActiveView('reports');
      setActiveReport('branches');
    } else {
      setActiveView('dashboard');
    }
  };

  const handleResetData = () => {
    setRawRecords(DEFAULT_RAW_RECORDS);
    setDataSource('demo');
    setLastUploadAt(null);
    setDemoBannerDismissed(false);
    setPeriod(DEFAULT_PERIOD);
    setSelectedBranchFilter('');
    setSelectedWeightFilter(DEFAULT_RAW_RECORDS[0]?.weight || '');
    setSelectedTimeframe('1Y');
  };

  /** Software-format Excel: colours, borders, merged headers, wrap text */
  const handleExportExcel = () => {
    exportStyledExcelReport(report, period, allocationMode);
  };

  /** Print → Save as PDF (landscape, colour matrix) */
  const handleExportPdf = () => {
    exportReportPdf(report, period, allocationMode);
  };

  // Authentication Gate: require an active server-side session.
  if (authLoading) {
    return <LuminaSplash message="Securing session…" />;
  }

  if (!currentUser) {
    return (
      <LoginPortal
        onLoginSuccess={(user) => {
          setAppMode('full');
          setCurrentUser(user);
          setCurrentSession(user);
          setActiveView('gateway');
        }}
        onEnterMode={(mode) => {
          setAppMode(mode);
          const synthetic = {
            id: mode === 'guest' ? 'guest-local' : 'education-local',
            username: mode === 'guest' ? 'guest' : 'student',
            name: mode === 'guest' ? 'Guest User' : 'Education User',
            role: mode === 'guest' ? 'guest' : 'education',
            isOwner: false,
            status: 'active',
          } as AuthUser;
          setCurrentUser(synthetic);
          setCurrentSession(synthetic);
          setActiveView('gateway');
        }}
      />
    );
  }

  // Dynamic header information matching the reference image layout
  const headerInfo = {
    dashboard: {
      title: '2026 Universal Jewelry Stock Redistribution & Operations',
      subtitle: `Portfolio Scorecard | Reporting Period: ${period} | Refreshed Live System`
    },
    option_allocation: {
      title: 'Universal Item Stock Allocation & Redistribution Matrix',
      subtitle: `Portfolio Scorecard | Sales Contribution, 3-Month Coverage & Protected Company Reserve`
    },
    movement_aging: {
      title: 'Inventory Velocity, Movement & Aging Analytics',
      subtitle: `Portfolio Scorecard | Dormant Stock, Aging Brackets & Turnover Velocity`
    },
    new_order: {
      title: 'New Order',
      subtitle: `Purchase Orders | Auto requisitions from Refill Demand and manual orders`
    },
    consignment_shipment: {
      title: 'Refill Demand Report',
      subtitle: `Portfolio Scorecard | Showroom Replenishment by Carat / Design Breakdown`
    },
    festival_scheme: {
      title: 'Festival Scheme — Puja Stock Distribution',
      subtitle: `Portfolio Scorecard | Outlet × Design × Carat weight allocation · Contribution · 3-Month Baseline · Hybrid`
    },
    stock_vs_sold_design: {
      title: 'Stock vs Sold · Design Report',
      subtitle: 'Image PDF match · photo · barcode · amount · weight · carat · move in/out'
    },
    pdf_label_report: {
      title: 'PDF Label Report — Branch Wise Excel',
      subtitle: `Upload tag/label PDF (D.NOSEPIN style) · extract barcode · carat · weight · price · download Excel`
    },
    gateway: {
      title: `Gateway of ${BRAND.short}`,
      subtitle: `Select workspace · analysis · guest or educational mode`
    },
    menu: {
      title: 'Enterprise ERP Modules Directory',
      subtitle: `Portfolio Scorecard | Central Launchpad & Operational Services`
    },
    reports: {
      refill_demand: {
        title: 'Refill Demand Report',
        subtitle: `Portfolio Scorecard | Replenishment by Carat · Design breakdown when style sheets uploaded`
      },
      excel_sheet: {
        title: 'Master Allocation Matrix',
        subtitle: `Portfolio Scorecard | Branch × (Carat · Design) matrix from uploaded stock & sold`
      },
      outlet_design_matrix: {
        title: 'Outlet × Cts / Design Matrix',
        subtitle: `Portfolio Scorecard | Outlet-wise stock, sold, contribution and movement across Cts / Design`
      },
      movement_summary: {
        title: 'Movement Summary & Transfer Orders',
        subtitle: `Portfolio Scorecard | Recommended Stock Balancing Actions & Inter-Branch Transfers`
      },
      branches: {
        title: 'Retail Showrooms & Branch Balance Ratios',
        subtitle: `Portfolio Scorecard | Overstock Risk, Deficit Assessment & Outlet Performance`
      },
      weights: {
        title: 'Design-wise Stock Analysis',
        subtitle: `Portfolio Scorecard | High-Turn, Low-Turn, Stock Coverage & Aging Segments`
      },
      demand_booster: {
        title: 'Demand Booster & Sales Opportunity Analytics',
        subtitle: `Portfolio Scorecard | High-Demand Outlets vs. Dormant Outlet Redistribution`
      },
      execution: {
        title: 'Execution Report',
        subtitle: `Portfolio Scorecard | Contribution · 3-Month Baseline · Hybrid distribution options`
      },
      stock_turn_rate: {
        title: 'Stock Turn Rate Dashboard',
        subtitle: `Portfolio Scorecard | Sales ÷ Current Stock · Fast / Slow Outlet Ranking`
      }
    }[activeReport] || {
      title: 'Analytical Reports Suite',
      subtitle: `Portfolio Scorecard | Universal Multi-Item Inventory Intelligence`
    }
  }[activeView];

  return (
    <div className="software-shell min-h-screen flex flex-col selection:bg-[#0284C7] selection:text-white">
      
      {/* 1. Classic ERP top toolbar */}
      <NetSuiteTopHeader
        activeView={activeView}
        activeReport={activeReport}
        onNavigateView={(view, report) => {
          if (isRestrictedMode) {
            setActiveView(view === 'gateway' ? 'gateway' : 'dashboard');
            return;
          }
          const standalone = new Set([
            'dashboard', 'option_allocation', 'movement_aging', 'new_order',
            'festival_scheme', 'pdf_label_report', 'stock_vs_sold_design', 'consignment_shipment', 'menu', 'gateway',
          ]);
          if (standalone.has(view)) {
            setActiveView(view as any);
            if (report) setActiveReport(report as any);
          } else if (report) {
            setActiveReport(report as any);
            setActiveView('reports');
          } else {
            setActiveView(view as any);
          }
        }}
        selectedTimeframe={selectedTimeframe}
        onTimeframeChange={setSelectedTimeframe}
        allocationMode={allocationMode}
        onAllocationModeChange={setAllocationMode}
        period={period}
        onPeriodChange={setPeriod}
        onOpenDailyUpload={openDailyUpload}
        onExportExcel={() => { if (!isRestrictedMode) handleExportExcel(); }}
        onExportPdf={() => { if (!isRestrictedMode) handleExportPdf(); }}
        onOpenUploadHistory={() => { if (!isRestrictedMode) setIsUploadHistoryOpen(true); }}
        onToggleAICopilot={() => { if (!isRestrictedMode) setIsAiDrawerOpen(!isAiDrawerOpen); }}
        isAiDrawerOpen={isAiDrawerOpen}
        onOpenOperations={() => { if (!isRestrictedMode) setIsOperationsFolderOpen(true); }}
        onOpenUserManagement={() => { if (!isRestrictedMode && currentUser?.isOwner) setIsUserManagementOpen(true); }}
        onOpenSettings={() => { if (!isRestrictedMode && currentUser?.isOwner) setIsSettingsOpen(true); }}
        currentUser={currentUser}
        onLogout={() => {
          void logoutCurrentSession().finally(() => {
            setCurrentUser(null);
            setCurrentSession(null);
          });
        }}
        onQuickSearchBranch={(branch) => {
          setInspectingBranch(branch);
        }}
        theme={appSettings.theme}
        onThemeChange={(theme) => {
          setAppSettings((prev) => ({ ...prev, theme }));
        }}
      />

      {/* Demo dataset warning — real ERP never hides that sample data is loaded */}
      <DemoDataBanner
        visible={dataSource === 'demo' && !demoBannerDismissed}
        onUpload={openDailyUpload}
        onDismiss={() => setDemoBannerDismissed(true)}
      />

      {/* Body: left module nav + main content */}
      <div className="flex flex-1 min-h-0 w-full">
        {activeView !== 'gateway' && (
        <AppSideNav
          activeView={activeView}
          activeReport={activeReport}
          appMode={appMode}
          navScope={navScope}
          onNavigateView={(view, reportKey) => {
            if (isRestrictedMode) {
              setActiveView(view === 'gateway' ? 'gateway' : 'dashboard');
              setNavScope('dashboard');
              return;
            }
            if (view === 'gateway') setNavScope('full');
            setActiveView(view as any);
            if (reportKey) {
              setActiveReport(reportKey as any);
              if (view !== 'dashboard' && view !== 'option_allocation' && view !== 'movement_aging' && view !== 'new_order' && view !== 'festival_scheme' && view !== 'pdf_label_report' && view !== 'stock_vs_sold_design') {
                setActiveView('reports');
              }
            }
            syncUrl(view, reportKey);
          }}
          onExportExcel={isRestrictedMode ? undefined : handleExportExcel}
          onExportPdf={isRestrictedMode ? undefined : handleExportPdf}
          onOpenUploadHistory={isRestrictedMode ? undefined : () => setIsUploadHistoryOpen(true)}
          onOpenDailyUpload={isRestrictedMode ? undefined : openDailyUpload}
        />
        )}

      {/* 2. MAIN APPLICATION CONTENT AREA — fill remaining width next to sidebar (no max-width so zoom-out stays dense) */}
      <main className="flex-1 w-full min-w-0 overflow-x-hidden">

        {/* SAP-style filter bar — hidden on All Reports (hub has its own filter panel) */}
        {activeView !== 'gateway' && activeView !== 'reports' && activeView !== 'festival_scheme' && activeView !== 'pdf_label_report' && activeView !== 'stock_vs_sold_design' && !isRestrictedMode && (
          <div className="px-2 sm:px-4 pt-2">
            <ReportFilterBar
              rawRecords={rawRecords}
              filters={reportFilters}
              onFiltersChange={setReportFilters}
              filteredCount={filteredRecords.length}
              totalCount={rawRecords.length}
            />
          </div>
        )}
        
        {/* VIEW 0: Gateway of DiaMatrix — Tally-style post-login hub */}
        {activeView === 'gateway' && (
          <GatewayOfDiaMatrix
            userName={currentUser?.name || currentUser?.username}
            roleLabel={currentUser?.isOwner ? 'Owner' : currentUser?.role}
            whiteLabel={appSettings.whiteLabel}
            appMode={appMode}
            onSelectView={(view, report, scope) => {
              if (isRestrictedMode) {
                setActiveView(view === 'gateway' ? 'gateway' : 'dashboard');
                setNavScope('dashboard');
                return;
              }
              if (scope) setNavScope(scope);
              // Standalone modules — never treat as Analysis / generic reports shell
              const standalone = new Set([
                'dashboard',
                'option_allocation',
                'movement_aging',
                'new_order',
                'festival_scheme',
                'pdf_label_report',
                'consignment_shipment',
                'menu',
                'gateway',
              ]);
              if (standalone.has(view)) {
                setActiveView(view as any);
                if (report) setActiveReport(report as any);
              } else if (report) {
                setActiveReport(report as any);
                setActiveView('reports');
              } else {
                setActiveView(view as any);
              }
              syncUrl(view, report);
            }}
            onOpenAnalysisUpload={openDailyUpload}
            onSetMode={setAppMode}
          />
        )}

        {/* VIEW 1: NETSUITE HOME DASHBOARD (3-Column Layout: Reminders, Tiles, KPIs, Trends) */}
        {(activeView === 'dashboard' || activeView === 'menu') && (
          <NetSuiteHomeDashboard
            report={report}
            rawRecords={filteredRecords}
            readOnly={isRestrictedMode}
            onNavigateView={(view, subReport) => {
              // Guest / Educational: view-only dashboard — block all module navigation
              if (isRestrictedMode) return;
              setActiveView(view);
              if (subReport) {
                setActiveReport(subReport);
              }
            }}
            onSelectBranch={isRestrictedMode ? undefined : handleBranchSelect}
            onSelectWeight={isRestrictedMode ? undefined : handleWeightSelect}
            selectedTimeframe={selectedTimeframe}
            onTimeframeChange={setSelectedTimeframe}
            onOpenDailyUpload={openDailyUpload}
          />
        )}

        {/* SUB-VIEW CONTAINER (When viewing deep modules: Option Allocation, Movement, Consignment, Reports) */}
        {activeView !== 'gateway' && activeView !== 'dashboard' && activeView !== 'menu' && (
          <div className="p-3 sm:p-5 space-y-4">
            
            {/* Quick Navigation Breadcrumb & Back to Gateway */}
            <div className="rounded-xl p-2.5 flex items-center justify-between border border-[#A9D9F0] bg-[#E8F4FC] shadow-sm">
              <div className="flex items-center gap-2 text-xs">
                <button
                  onClick={() => setActiveView('gateway')}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#14B4E8] hover:bg-[#0C94D0] text-white font-bold cursor-pointer transition-colors"
                >
                  <Home className="w-3.5 h-3.5" />
                  <span>← Gateway (Home)</span>
                </button>
                <span className="text-[#64748B]">|</span>
                <span className="text-[#4F6B88]">
                  Active Module: <strong className="text-[#0284C7] uppercase font-mono">{activeView.replace('_', ' ')}</strong>
                </span>
              </div>

              {selectedBranchFilter && (
                <div className="flex items-center gap-1.5 bg-[#f1f5f9] border border-[#cbd5e1] rounded px-2.5 py-0.5 text-xs text-[#334155]">
                  <span>Filter: <strong>{selectedBranchFilter}</strong></span>
                  <button
                    onClick={() => setSelectedBranchFilter('')}
                    className="ml-1 text-rose-600 hover:text-rose-800 font-bold cursor-pointer"
                  >
                    ×
                  </button>
                </div>
              )}
            </div>

            {/* VIEW 2: OPTION-WISE ALLOCATION & TRANSFER ENGINE */}
            {activeView === 'option_allocation' && (
              <OptionWiseAllocationView
                report={report}
                selectedWeight={selectedWeightFilter}
                selectedTimeframe={selectedTimeframe}
                onTimeframeChange={setSelectedTimeframe}
                allocationMode={allocationMode}
                onAllocationModeChange={setAllocationMode}
                onSelectBranch={handleBranchSelect}
                onSelectWeight={(w) => setSelectedWeightFilter(w)}
                onBackToHome={() => setActiveView('gateway')}
              />
            )}

            {/* VIEW: FESTIVAL SCHEME — standalone module with its own uploads (does not use Daily Upload data) */}
            {activeView === 'festival_scheme' && <FestivalSchemeView />}

            {/* VIEW: PDF LABEL REPORT — tag/label PDF → branch-wise Excel (under Festival Scheme in sidebar) */}
            {(activeView === 'pdf_label_report' || visitedPdfLabel) && (
              <div className={activeView === 'pdf_label_report' ? '' : 'hidden'} aria-hidden={activeView !== 'pdf_label_report'}>
                <PdfLabelReportView />
              </div>
            )}

            {(activeView === 'stock_vs_sold_design' || visitedStockVsSold) && (
              <div className={activeView === 'stock_vs_sold_design' ? '' : 'hidden'} aria-hidden={activeView !== 'stock_vs_sold_design'}>
                <StockVsSoldDesignReportView />
              </div>
            )}

            {/* VIEW 3: UNIFIED MOVEMENT & AGING ANALYSIS */}
            {activeView === 'movement_aging' && (
              <MovementAndAgingReportView
                report={report}
                rawRecords={filteredRecords}
                onSelectBranch={handleBranchSelect}
                onSelectWeight={handleWeightSelect}
                onBackToHome={() => setActiveView('gateway')}
              />
            )}

            {/* VIEW: NEW ORDER (purchase orders / requisitions) */}
            {activeView === 'new_order' && <NewOrderView report={report} />}

            {/* VIEW 4: Refill Demand only (consignment removed — same as refill) */}
            {activeView === 'consignment_shipment' && (
              <RefillDemandReport
                report={report}
                onSelectBranch={handleBranchSelect}
                onSelectWeight={handleWeightSelect}
              />
            )}

            {/* VIEW 5: ALL REPORTS HUB */}
            {activeView === 'reports' && (
              <div className="space-y-4">
                <AllReportsHub
                  rawRecords={rawRecords}
                  filters={reportFilters}
                  onFiltersChange={setReportFilters}
                  period={period}
                  activeReport={activeReport as ReportKey}
                  filteredCount={filteredRecords.length}
                  totalCount={rawRecords.length}
                  selectedTimeframe={selectedTimeframe}
                  specialMonths={specialMonths}
                  onSelectReport={(key, mode) => {
                    setActiveReport(key);
                    setAnalysisMode(mode === 'ai' || key === 'ai_crossmatch' ? 'ai' : 'manual');
                  }}
                />

                {activeReport === 'ai_crossmatch' && (
                  <AICrossmatchReportView
                    report={report}
                    onSwitchToManual={() => {
                      setAnalysisMode('manual');
                      setActiveReport('excel_sheet');
                    }}
                  />
                )}

                {activeReport === 'refill_demand' && (
                  <RefillDemandReport report={report} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />
                )}
                {activeReport === 'excel_sheet' && <ExcelReportSheetView report={report} allocationMode={allocationMode} onAllocationModeChange={setAllocationMode} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />}
                {activeReport === 'outlet_design_matrix' && <OutletDesignMatrixReport report={report} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />}
                {activeReport === 'movement_summary' && <MovementSummaryView report={report} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />}
                {activeReport === 'branches' && <BranchSummaryTable report={report} onSelectBranch={handleBranchSelect} />}
                {activeReport === 'weights' && (
                  <DesignWiseStockAnalysis
                    report={report}
                    categoryReport={categoryReport}
                    designReport={designReport}
                    allocationMode={allocationMode}
                    onSelectWeight={handleWeightSelect}
                  />
                )}
                {activeReport === 'demand_booster' && <DemandOpportunityAnalysis report={report} rawRecords={filteredRecords} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />}
                {activeReport === 'stock_turn_rate' && (
                  <StockTurnRateDashboard
                    report={report}
                    onSelectBranch={handleBranchSelect}
                    onNavigate={(view, subReport) => {
                      setActiveView(view as any);
                      if (subReport) setActiveReport(subReport);
                    }}
                  />
                )}
              </div>
            )}

          </div>
        )}

      </main>
      </div>{/* end body flex: side nav + main */}

      {/* Classic ERP status bar (replaces marketing footer inside console) */}
      <ErpStatusBar
        userName={currentUser?.name}
        userRole={currentUser?.role}
        period={period}
        rowCount={filteredRecords.length}
        branchCount={report.branchSummaries?.length || 0}
        skuCount={report.weightSummaries?.length || 0}
        timeframe={selectedTimeframe}
        allocationMode={allocationMode}
        theme={appSettings.theme}
        dataSource={dataSource}
        lastUploadAt={lastUploadAt}
        onAbout={() => setIsAboutOpen(true)}
      />

      <AboutLuminaModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />

      {/* User Management & Access Control Modal */}
      <UserManagementModal
        isOpen={isUserManagementOpen}
        onClose={() => setIsUserManagementOpen(false)}
        currentUser={currentUser}
      />

      {/* Settings, Theme & Account Preferences Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currentUser={currentUser}
        onUserUpdated={(updated) => {
          setCurrentUser(updated);
        }}
        settings={appSettings}
        onSettingsUpdated={(newSettings) => {
          setAppSettings(newSettings);
        }}
        onOpenUserManagement={() => {
          setIsSettingsOpen(false);
          setIsUserManagementOpen(true);
        }}
        onResetToDefaults={() => {
          handleResetData();
          setIsSettingsOpen(false);
        }}
        rawRecordsCount={rawRecords.length}
      />

      {/* Operations & Data Center (Drawer / Folder Mode) */}
      <OperationsDataDrawer
        isOpen={isOperationsFolderOpen}
        onClose={() => setIsOperationsFolderOpen(false)}
        report={report}
        rawRecords={rawRecords}
        onImportRecords={handleImportRecords}
        onNavigateTab={(tab) => {
          handleNavigateFromAlert(tab);
        }}
      />

      {/* Daily Dual File Upload Modal (Current Stock + Sold Out) */}
      <DailyDualFileUploadModal
        isOpen={isDailyUploadOpen}
          existingRecordCount={rawRecords.length}
        onClose={() => setIsDailyUploadOpen(false)}
        onImportRecords={handleImportRecords}
        onOpenAiMode={() => {
          setActiveView('reports');
          setAnalysisMode('ai');
          setActiveReport('ai_crossmatch');
        }}
        currentPeriod={period}
      />

      <UploadHistoryPanel
        isOpen={isUploadHistoryOpen}
        onClose={() => setIsUploadHistoryOpen(false)}
        onRestore={(records, label, periodHint) => {
          handleImportRecords(records, periodHint || period);
          setLastUploadAt(`History: ${label}`);
        }}
      />

      {/* Movement Analysis AI Copilot Drawer */}
      <AIAssistantDrawer
        isOpen={isAiDrawerOpen}
        onClose={() => setIsAiDrawerOpen(false)}
        report={report}
      />

      {/* Branch 360° Comprehensive Report Modal */}
      <BranchDetailModal
        branchName={inspectingBranch}
        onClose={() => setInspectingBranch(null)}
        report={report}
        onSelectProduct={(w) => {
          setInspectingBranch(null);
          setInspectingProduct(w);
        }}
        onSelectAnotherBranch={(b) => setInspectingBranch(b)}
      />

      {/* Product Location Tracker Modal */}
      <ProductLocationModal
        productWeight={inspectingProduct}
        onClose={() => setInspectingProduct(null)}
        report={report}
        onSelectBranch={(b) => {
          setInspectingProduct(null);
          setInspectingBranch(b);
        }}
        onSelectAnotherProduct={(w) => setInspectingProduct(w)}
      />

    </div>
  );
}
