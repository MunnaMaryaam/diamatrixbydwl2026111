import { createFileRoute } from "@tanstack/react-router";
import App from "@/lumina/App";

/**
 * Optional deep link: /?view=demand-forecasting or /?view=stock-redistribution
 * opens the matching report directly (see DEEP_LINKS in lumina/App.tsx).
 */
export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): { view?: string } => ({
    view: typeof search.view === "string" ? search.view : undefined,
  }),
  component: Home,
});

function Home() {
  return <App />;
}
