# Festival Scheme module

Sidebar → **Festival Scheme**. Standalone — does not use Daily Upload data.

## Files
- `src/client/lumina/festival/festivalParsers.ts` — scheme / sold / stock parsers
- `src/client/lumina/festival/festivalEngine.ts` — Have vs Deserve (Contribution / Baseline / Hybrid)
- `src/client/lumina/festival/festivalExport.ts` — weight-wise Excel download
- `src/client/lumina/festival/FestivalSchemeView.tsx` — UI

## 1) Scheme file (your Puja list)

Columns (S/L and P.IMAGE optional):

| S/L | P.IMAGE | DESIGN NO | STOCK |
|-----|---------|-----------|-------|
| 1   | (img)   | E654      | 20    |
| 2   | (img)   | WER18-09117 | 22  |
| …   | …       | …         | …     |

- Required: **DESIGN NO** + **STOCK** (or QTY / PCS)
- Hyphen codes OK: `WER18-09117`, `IPSER20-07017`
- TOTAL row is ignored

## 2) Sold files (one per design — multi-upload)

File name should include the design code:
- `E384 - 9 Month - Sold.xlsx` → design **E384**
- `R4014CS - 9 Month - Sold.xlsx` → design **R4014CS** (trailing letters kept)
- `WER18-09117 - Sold.xlsx`

| Branch | 0.03 | 0.05 | 0.07 | 0.10 |
|--------|------|------|------|------|
| RUP    | 45   | 95   | 30   | 7    |
| SAV    | 107  | 236  | 49   | 7    |

- Carat headers must be **numbers**
- Branch label: Branch / Brnch
- Set **Sales months** in UI (default 9)
- Multiple sold files supported — each design uses its own sold contribution; designs without a matching sold file fall back to equal share

## 3) Stock files (one per design — multi-upload)

File name must include design code:
- `E654 - Stock.xlsx`
- `WER18-09117_Stock.xlsx`

| Category Name | Brnch | 0.03 | 0.05 | 0.07 | Total |
|---------------|-------|------|------|------|-------|
| Diamond Earring | RUP | 2 | 5 | 1 | 8 |
| | DWL | 10 | 20 | 5 | 35 |

- Header: **Category Name**
- **DWL** = warehouse (info only)

## Design search
Use the **Design** dropdown on the report toolbar to filter to one design, or pick “All designs”.

## Reports (two)
1. **Summary** — Branch (left) × Design (top). Under each design: **Stock** (existing Have), **Sales**, **Move** (+IN light teal / −OUT light red). No carat / cent columns.
2. **Breakdown** — Outlet × Design × Carat matrix (full weight-wise allocation).

### Coverage logic
- Pool = existing outlet stock + festival stock (or **only existing total stock** if no scheme uploaded).
- Phase 1: every outlet aims for **≥1 pc**, sorted by sales high → low (if pool short, only top sellers get the 1).
- Phase 2: leftover by sales share.
- **Move = Target − Have**:
  - Target 1, Have 1 → blank (0)
  - Target 2, Have 1 → **+1** (IN, light teal)
  - Target 2, Have 3 → **−1** (OUT, light red)

Excel download has the same two sheets plus a flat Carat Detail list.

## Upload order
1. Scheme → 2. Sold (multiple) → 3. Stock (multiple) → pick logic → optional design filter → download Excel

## Session persistence
Uploads (scheme / sold / stock), logic, months, and design filter are saved in **browser localStorage**.
- Navigate to Cockpit / Home and back → report stays as-is.
- **Clear all uploads** (or wiping site data) resets everything.
- Full browser refresh keeps the data; only explicit clear removes it.
