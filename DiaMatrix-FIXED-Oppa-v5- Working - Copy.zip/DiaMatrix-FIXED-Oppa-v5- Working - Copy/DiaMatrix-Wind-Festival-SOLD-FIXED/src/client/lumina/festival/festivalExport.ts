import * as ExcelJS from 'exceljs';
import { caratLabel, type FestivalIndex } from './festivalEngine';
import { FESTIVAL_LOGICS, type FestivalLogic, type FestivalResult } from './festivalTypes';

const HEAD = 'FF1F4E78';
const HEAD_ALT = 'FF2E75B6';
const TOTAL_FILL = 'FFDDEBF7';
const STOCK_FILL = 'FFFFF2CC';
/** Match UI: +IN → teal-50 / teal-800 ; −OUT → rose-50 / rose-800 */
const MOVE_IN_FILL = 'FFF0FDFA';
const MOVE_IN_FONT = 'FF115E59';
const MOVE_OUT_FILL = 'FFFFF1F2';
const MOVE_OUT_FONT = 'FF9F1239';

const colLetter = (n: number): string => {
  let s = '';
  for (let x = n; x > 0; x = Math.floor((x - 1) / 26)) s = String.fromCharCode(65 + ((x - 1) % 26)) + s;
  return s;
};

function fillCell(cell: ExcelJS.Cell, argb: string) {
  cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb } };
}

/** Colour a Move cell like the on-screen report: light teal (+IN) / light rose (−OUT). */
function styleMoveCell(cell: ExcelJS.Cell, move: number) {
  cell.font = { name: 'Arial', bold: true };
  cell.numFmt = '+0;-0;"–"';
  cell.alignment = { horizontal: 'center' };
  if (move > 0) {
    fillCell(cell, MOVE_IN_FILL);
    cell.font = { name: 'Arial', bold: true, color: { argb: MOVE_IN_FONT } };
  } else if (move < 0) {
    fillCell(cell, MOVE_OUT_FILL);
    cell.font = { name: 'Arial', bold: true, color: { argb: MOVE_OUT_FONT } };
  }
}

/** Builds the Festival Scheme workbook (Summary + Breakdown) and triggers a browser download. */
export async function exportFestivalExcel(
  result: FestivalResult,
  idx: FestivalIndex,
  logic: FestivalLogic,
): Promise<void> {
  const logicLabel = FESTIVAL_LOGICS.find((l) => l.id === logic)?.label ?? logic;
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DiaMatrix — Festival Scheme';

  // Sales lookup: outlet|design (Move = Target − Have, same as on-screen report)
  const salesMap = new Map<string, number>();
  result.rows.forEach((r) => {
    const k = `${r.outlet}|${r.design}`;
    salesMap.set(k, (salesMap.get(k) || 0) + r.sales);
  });

  // =====================================================================
  // Sheet 1: Summary — Branch × Design (Stock / Sales / Move as +IN / −OUT)
  // =====================================================================
  const ws = wb.addWorksheet('Festival Summary');
  ws.getCell('A1').value = 'Festival Scheme — Summary (Branch × Design)';
  ws.getCell('A1').font = { name: 'Arial', bold: true, size: 13 };
  ws.getCell('A2').value = `Logic: ${logicLabel}  ·  Budget = festival stock · Move = Target − Have (+IN / −OUT)`;
  ws.getCell('A2').font = { name: 'Arial', italic: true, size: 10 };

  const HR1 = 4;
  const HR2 = 5;
  const FIRST = 6;

  ws.getCell(HR1, 1).value = 'Branch';
  ws.mergeCells(HR1, 1, HR2, 1);
  fillCell(ws.getCell(HR1, 1), HEAD);

  type Group = {
    design: string;
    start: number;
    stockCol: number;
    salesCol: number;
    moveCol: number;
  };
  const groups: Group[] = [];
  let col = 2;
  result.designs.forEach((d) => {
    const stockCol = col;
    const salesCol = col + 1;
    const moveCol = col + 2;
    groups.push({ design: d.design, start: stockCol, stockCol, salesCol, moveCol });
    col += 3;
  });
  const totalMoveCol = col;
  const lastCol = totalMoveCol;

  groups.forEach((g, gi) => {
    const argb = gi % 2 === 0 ? HEAD : HEAD_ALT;
    ws.getCell(HR1, g.start).value = g.design;
    ws.mergeCells(HR1, g.start, HR1, g.moveCol);
    ws.getCell(HR2, g.stockCol).value = 'Stock';
    ws.getCell(HR2, g.salesCol).value = 'Sales';
    ws.getCell(HR2, g.moveCol).value = 'Move (+/−)';
    for (let c = g.start; c <= g.moveCol; c++) {
      fillCell(ws.getCell(HR1, c), argb);
      fillCell(ws.getCell(HR2, c), argb);
    }
  });

  ws.getCell(HR1, totalMoveCol).value = 'Net Move';
  ws.mergeCells(HR1, totalMoveCol, HR2, totalMoveCol);
  fillCell(ws.getCell(HR1, totalMoveCol), HEAD);

  for (let r = HR1; r <= HR2; r++) {
    for (let c = 1; c <= lastCol; c++) {
      const cell = ws.getCell(r, c);
      cell.font = { name: 'Arial', bold: true, color: { argb: 'FFFFFFFF' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    }
  }

  result.outlets.forEach((o, i) => {
    const r = FIRST + i;
    ws.getCell(r, 1).value = o;
    ws.getCell(r, 1).font = { name: 'Arial', bold: true };
    let rowMove = 0;
    groups.forEach((g) => {
      const stock = idx.have(o, g.design);
      const sales = salesMap.get(`${o}|${g.design}`) || 0;
      // Same formula as on-screen Summary: Move = Target − Have (+IN / −OUT / 0)
      const target = idx.target(logic, o, g.design);
      const move = Math.round(target - stock);
      ws.getCell(r, g.stockCol).value = stock;
      ws.getCell(r, g.salesCol).value = sales;
      ws.getCell(r, g.moveCol).value = move;
      styleMoveCell(ws.getCell(r, g.moveCol), move);
      rowMove += move;
    });
    ws.getCell(r, totalMoveCol).value = rowMove;
    styleMoveCell(ws.getCell(r, totalMoveCol), rowMove);
    for (let c = 2; c <= lastCol; c++) {
      if (c === totalMoveCol || groups.some((g) => g.moveCol === c)) continue;
      ws.getCell(r, c).alignment = { horizontal: 'center' };
    }
  });

  const LAST = FIRST + result.outlets.length - 1;
  const TOT = LAST + 1;
  ws.getCell(TOT, 1).value = 'Total';
  for (let c = 2; c <= lastCol; c++) {
    const L = colLetter(c);
    ws.getCell(TOT, c).value = { formula: `SUM(${L}${FIRST}:${L}${LAST})` };
    ws.getCell(TOT, c).alignment = { horizontal: 'center' };
  }
  for (let c = 1; c <= lastCol; c++) {
    fillCell(ws.getCell(TOT, c), TOTAL_FILL);
    ws.getCell(TOT, c).font = { name: 'Arial', bold: true };
  }
  groups.forEach((g) => {
    ws.getCell(TOT, g.moveCol).numFmt = '+0;-0;"–"';
  });
  ws.getCell(TOT, totalMoveCol).numFmt = '+0;-0;"–"';

  // Conditional formatting on all Move columns (data + Total) so colours match the UI report
  const moveCols = [...groups.map((g) => g.moveCol), totalMoveCol];
  moveCols.forEach((c) => {
    const range = `${colLetter(c)}${FIRST}:${colLetter(c)}${TOT}`;
    ws.addConditionalFormatting({
      ref: range,
      rules: [
        {
          type: 'cellIs',
          operator: 'greaterThan',
          formulae: ['0'],
          style: {
            fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: MOVE_IN_FILL } },
            font: { bold: true, color: { argb: MOVE_IN_FONT } },
          },
        },
        {
          type: 'cellIs',
          operator: 'lessThan',
          formulae: ['0'],
          style: {
            fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: MOVE_OUT_FILL } },
            font: { bold: true, color: { argb: MOVE_OUT_FONT } },
          },
        },
      ],
    });
  });

  ws.getColumn(1).width = 14;
  for (let c = 2; c <= lastCol; c++) ws.getColumn(c).width = 9;
  ws.views = [{ state: 'frozen', xSplit: 1, ySplit: HR2 }];

  // =====================================================================
  // Sheet 2: Breakdown — Outlet × Design × Carat matrix
  // =====================================================================
  const wb2 = wb.addWorksheet('Breakdown Carat');
  wb2.getCell('A1').value = 'Festival Scheme — Breakdown (Outlet × Design × Carat)';
  wb2.getCell('A1').font = { name: 'Arial', bold: true, size: 13 };
  wb2.getCell('A2').value = `Logic: ${logicLabel}`;
  wb2.getCell('A2').font = { name: 'Arial', italic: true, size: 10 };

  const BHR1 = 4;
  const BHR2 = 5;
  const BSTOCK = 6;
  const BFIRST = 7;

  wb2.getCell(BHR1, 1).value = 'Outlet';
  wb2.getCell(BHR1, 2).value = 'Contribution %';
  wb2.mergeCells(BHR1, 1, BHR2, 1);
  wb2.mergeCells(BHR1, 2, BHR2, 2);

  type BGroup = { design: string; start: number; carats: { key: string; col: number }[]; total: number };
  const bgroups: BGroup[] = [];
  let bcol = 3;
  result.designs.forEach((d) => {
    const carats = d.carats.map((c) => ({ key: c, col: bcol++ }));
    bgroups.push({ design: d.design, start: carats[0]?.col ?? bcol, carats, total: bcol++ });
  });
  const bTotalCol = bcol;
  const bHaveCol = bcol + 1;
  const bOverCol = bcol + 2;
  const bLastCol = bOverCol;

  bgroups.forEach((g, gi) => {
    const argb = gi % 2 === 0 ? HEAD : HEAD_ALT;
    wb2.getCell(BHR1, g.start).value = g.design;
    wb2.mergeCells(BHR1, g.start, BHR1, g.total);
    g.carats.forEach((c) => (wb2.getCell(BHR2, c.col).value = Number(c.key) || caratLabel(c.key)));
    wb2.getCell(BHR2, g.total).value = 'Total';
    for (let c = g.start; c <= g.total; c++) {
      fillCell(wb2.getCell(BHR1, c), argb);
      fillCell(wb2.getCell(BHR2, c), argb);
    }
  });
  [
    [bTotalCol, 'Total new pcs'],
    [bHaveCol, 'Existing stock (Have)'],
    [bOverCol, 'Overstock pcs'],
  ].forEach(([c, label]) => {
    wb2.getCell(BHR1, c as number).value = label as string;
    wb2.mergeCells(BHR1, c as number, BHR2, c as number);
    fillCell(wb2.getCell(BHR1, c as number), HEAD);
  });
  fillCell(wb2.getCell(BHR1, 1), HEAD);
  fillCell(wb2.getCell(BHR1, 2), HEAD);
  for (let r = BHR1; r <= BHR2; r++) {
    for (let c = 1; c <= bLastCol; c++) {
      const cell = wb2.getCell(r, c);
      cell.font = { name: 'Arial', bold: true, color: { argb: 'FFFFFFFF' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      if (r === BHR2 && typeof cell.value === 'number') cell.numFmt = '0.00';
    }
  }

  // stock row
  wb2.getCell(BSTOCK, 1).value = 'Stock to distribute';
  bgroups.forEach((g, gi) => {
    const d = result.designs[gi];
    g.carats.forEach((c) => (wb2.getCell(BSTOCK, c.col).value = d.caratStock[c.key] || 0));
    wb2.getCell(BSTOCK, g.total).value = d.stock;
  });
  wb2.getCell(BSTOCK, bTotalCol).value = result.designs.reduce((s, d) => s + d.stock, 0);
  for (let c = 1; c <= bLastCol; c++) {
    const cell = wb2.getCell(BSTOCK, c);
    fillCell(cell, STOCK_FILL);
    cell.font = { name: 'Arial', bold: true };
    if (c > 2) cell.alignment = { horizontal: 'center' };
  }

  // outlet rows
  result.outlets.forEach((o, i) => {
    const r = BFIRST + i;
    wb2.getCell(r, 1).value = o;
    wb2.getCell(r, 2).value = result.outletShare[o] || 0;
    wb2.getCell(r, 2).numFmt = '0.00%';
    let newTotal = 0;
    let haveTotal = 0;
    bgroups.forEach((g) => {
      let designTotal = 0;
      g.carats.forEach((c) => {
        const v = idx.pcs(logic, o, g.design, c.key);
        designTotal += v;
        wb2.getCell(r, c.col).value = v;
        haveTotal += idx.have(o, g.design, c.key);
      });
      wb2.getCell(r, g.total).value = designTotal;
      wb2.getCell(r, g.total).font = { name: 'Arial', bold: true };
      fillCell(wb2.getCell(r, g.total), TOTAL_FILL);
      newTotal += designTotal;
    });
    wb2.getCell(r, bTotalCol).value = newTotal;
    wb2.getCell(r, bHaveCol).value = haveTotal;
    const over = idx.overstock(logic, o);
    wb2.getCell(r, bOverCol).value = over;
    if (over > 0) {
      fillCell(wb2.getCell(r, bOverCol), MOVE_OUT_FILL);
      wb2.getCell(r, bOverCol).font = { name: 'Arial', bold: true, color: { argb: MOVE_OUT_FONT } };
    }
    for (let c = 3; c <= bLastCol; c++) wb2.getCell(r, c).alignment = { horizontal: 'center' };
    wb2.getCell(r, bTotalCol).font = { name: 'Arial', bold: true };
  });

  const BLAST = BFIRST + result.outlets.length - 1;
  const BTOT = BLAST + 1;
  const BCHECK = BTOT + 1;
  wb2.getCell(BTOT, 1).value = 'Total';
  wb2.getCell(BCHECK, 1).value = 'Check (stock - allocated)';
  for (let c = 3; c <= bLastCol; c++) {
    const L = colLetter(c);
    wb2.getCell(BTOT, c).value = { formula: `SUM(${L}${BFIRST}:${L}${BLAST})` };
    wb2.getCell(BTOT, c).alignment = { horizontal: 'center' };
    if (c <= bTotalCol) {
      wb2.getCell(BCHECK, c).value = { formula: `${L}${BSTOCK}-${L}${BTOT}` };
      wb2.getCell(BCHECK, c).numFmt = '0;-0;"OK"';
      wb2.getCell(BCHECK, c).alignment = { horizontal: 'center' };
      wb2.getCell(BCHECK, c).font = { name: 'Arial', italic: true, size: 9 };
    }
  }
  wb2.getCell(BTOT, 2).value = { formula: `SUM(B${BFIRST}:B${BLAST})` };
  wb2.getCell(BTOT, 2).numFmt = '0.00%';
  for (let c = 1; c <= bLastCol; c++) {
    fillCell(wb2.getCell(BTOT, c), TOTAL_FILL);
    wb2.getCell(BTOT, c).font = { name: 'Arial', bold: true };
  }
  wb2.getColumn(1).width = 24;
  wb2.getColumn(2).width = 14;
  for (let c = 3; c <= bLastCol; c++) wb2.getColumn(c).width = 8;
  wb2.getColumn(bHaveCol).width = 12;
  wb2.views = [{ state: 'frozen', xSplit: 2, ySplit: BHR2 + 1 }];

  // =====================================================================
  // Sheet 3: Carat Detail (flat list)
  // =====================================================================
  const wd = wb.addWorksheet('Carat Detail');
  const headers = [
    'Outlet',
    'Design',
    'Carat (ct)',
    'Have (existing)',
    'Sales (carat)',
    'Contribution %',
    'Target',
    'New pcs',
    'Status',
    'Overstock pcs',
  ];
  wd.addRow(headers);
  wd.getRow(1).eachCell((cell) => {
    fillCell(cell, HEAD);
    cell.font = { name: 'Arial', bold: true, color: { argb: 'FFFFFFFF' } };
    cell.alignment = { horizontal: 'center', wrapText: true };
  });
  result.rows.forEach((r) => {
    const pcs = r.pcs[logic];
    const over = r.overstock[logic] || 0;
    const status = pcs > 0 ? 'Move IN' : r.have > r.target[logic] ? 'Overstock' : 'OK';
    const row = wd.addRow([
      r.outlet,
      r.design,
      Number(r.carat) || caratLabel(r.carat),
      r.have,
      r.sales,
      r.share,
      r.target[logic],
      pcs,
      status,
      over,
    ]);
    // Col 8 = New pcs, Col 9 = Status, Col 10 = Overstock
    if (pcs > 0) {
      fillCell(row.getCell(8), MOVE_IN_FILL);
      row.getCell(8).font = { name: 'Arial', bold: true, color: { argb: MOVE_IN_FONT } };
      fillCell(row.getCell(9), MOVE_IN_FILL);
      row.getCell(9).font = { name: 'Arial', bold: true, color: { argb: MOVE_IN_FONT } };
    } else if (status === 'Overstock' || over > 0) {
      fillCell(row.getCell(9), MOVE_OUT_FILL);
      row.getCell(9).font = { name: 'Arial', bold: true, color: { argb: MOVE_OUT_FONT } };
      if (over > 0) {
        fillCell(row.getCell(10), MOVE_OUT_FILL);
        row.getCell(10).font = { name: 'Arial', bold: true, color: { argb: MOVE_OUT_FONT } };
      }
    }
  });
  wd.getColumn(3).numFmt = '0.00';
  wd.getColumn(6).numFmt = '0.00%';
  [10, 12, 10, 14, 12, 14, 10, 10, 11, 13].forEach((w, i) => (wd.getColumn(i + 1).width = w));
  wd.views = [{ state: 'frozen', ySplit: 1 }];
  wd.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: headers.length } };

  // ---------------- download ----------------
  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Festival_Scheme_${logicLabel.replace(/\s+/g, '_')}.xlsx`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
