import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Download, FileSpreadsheet, Gift, Trash2, Upload, AlertTriangle, CheckCircle2, RotateCcw } from 'lucide-react';
import {
  parseFestivalScheme,
  parseFestivalSold,
  parseFestivalStock,
} from './festivalParsers';
import { caratLabel, computeFestivalAllocation, indexFestivalResult } from './festivalEngine';
import { exportFestivalExcel } from './festivalExport';
import {
  FESTIVAL_LOGICS,
  type DesignStockFile,
  type FestivalLogic,
  type SchemeDesign,
  type SoldData,
} from './festivalTypes';

/**
 * Festival Scheme module.
 * Fully separate from the Daily Upload pipeline: it has its own file inputs and keeps its
 * data in local component state only — it never reads or writes the working dataset.
 */

const readBuffer = (file: File): Promise<ArrayBuffer> => file.arrayBuffer();
const fmt = (n: number) => (n === 0 ? '–' : n.toLocaleString());

/** Persist uploads + settings so navigating to Cockpit/Home and back keeps the report. */
const FESTIVAL_STORAGE_KEY = 'diamatrix.festivalScheme.v1';

interface FestivalPersisted {
  scheme: SchemeDesign[];
  schemeFile: string;
  soldFiles: SoldData[];
  stockFiles: DesignStockFile[];
  logic: FestivalLogic;
  salesMonths: number;
  designQuery: string;
  reportMode: 'summary' | 'breakdown';
}

function loadFestivalState(): FestivalPersisted | null {
  try {
    const raw = localStorage.getItem(FESTIVAL_STORAGE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw) as FestivalPersisted;
    if (!data || typeof data !== 'object') return null;
    return {
      scheme: Array.isArray(data.scheme) ? data.scheme : [],
      schemeFile: typeof data.schemeFile === 'string' ? data.schemeFile : '',
      soldFiles: Array.isArray(data.soldFiles) ? data.soldFiles : [],
      stockFiles: Array.isArray(data.stockFiles) ? data.stockFiles : [],
      logic: data.logic || 'hybrid',
      salesMonths: typeof data.salesMonths === 'number' && data.salesMonths > 0 ? data.salesMonths : 9,
      designQuery: typeof data.designQuery === 'string' ? data.designQuery : '',
      reportMode: data.reportMode === 'breakdown' ? 'breakdown' : 'summary',
    };
  } catch {
    return null;
  }
}

function saveFestivalState(state: FestivalPersisted) {
  try {
    const hasData =
      state.scheme.length > 0 || state.soldFiles.length > 0 || state.stockFiles.length > 0;
    if (!hasData) {
      localStorage.removeItem(FESTIVAL_STORAGE_KEY);
      return;
    }
    localStorage.setItem(FESTIVAL_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // quota / private mode — ignore
  }
}

function clearFestivalStorage() {
  try {
    localStorage.removeItem(FESTIVAL_STORAGE_KEY);
  } catch {
    /* ignore */
  }
}

interface UploadCardProps {
  title: string;
  hint: string;
  accept?: string;
  multiple?: boolean;
  loaded: React.ReactNode;
  onFiles: (files: File[]) => void;
}

const isSpreadsheet = (f: File) =>
  /\.(xlsx|xls|csv)$/i.test(f.name) ||
  /spreadsheet|excel|csv/i.test(f.type);

const UploadCard: React.FC<UploadCardProps> = ({ title, hint, multiple, loaded, onFiles }) => {
  const ref = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const dragDepth = useRef(0);

  const takeFiles = (list: FileList | File[]) => {
    const all = Array.from(list).filter(isSpreadsheet);
    if (!all.length) return;
    onFiles(multiple ? all : all.slice(0, 1));
  };

  return (
    <div
      className={`rounded-xl border-2 bg-white p-3 shadow-sm flex flex-col gap-2 transition-colors ${
        dragging
          ? 'border-[#14B4E8] bg-[#E8F7FD] ring-2 ring-[#14B4E8]/40'
          : 'border-[#A9D9F0]'
      }`}
      onDragEnter={(e) => {
        e.preventDefault();
        e.stopPropagation();
        dragDepth.current += 1;
        setDragging(true);
      }}
      onDragOver={(e) => {
        e.preventDefault();
        e.stopPropagation();
        e.dataTransfer.dropEffect = 'copy';
      }}
      onDragLeave={(e) => {
        e.preventDefault();
        e.stopPropagation();
        dragDepth.current -= 1;
        if (dragDepth.current <= 0) {
          dragDepth.current = 0;
          setDragging(false);
        }
      }}
      onDrop={(e) => {
        e.preventDefault();
        e.stopPropagation();
        dragDepth.current = 0;
        setDragging(false);
        if (e.dataTransfer.files?.length) takeFiles(e.dataTransfer.files);
      }}
    >
      <div className="flex items-center justify-between gap-2">
        <div>
          <div className="text-[13px] font-extrabold text-[#0A1728]">{title}</div>
          <div className="text-[11px] text-[#64748B]">{hint}</div>
        </div>
        <button
          type="button"
          onClick={() => ref.current?.click()}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[#14B4E8] hover:bg-[#0C94D0] text-white text-xs font-bold cursor-pointer"
        >
          <Upload className="w-3.5 h-3.5" />
          {multiple ? 'Add files' : 'Choose file'}
        </button>
      </div>
      <input
        ref={ref}
        type="file"
        accept=".xlsx,.xls,.csv"
        multiple={multiple}
        className="hidden"
        onChange={(e) => {
          const files = Array.from(e.target.files || []);
          e.target.value = '';
          if (files.length) takeFiles(files);
        }}
      />
      <div
        className={`rounded-lg border border-dashed px-2 py-2 text-center text-[11px] ${
          dragging
            ? 'border-[#14B4E8] text-[#0C94D0] font-bold'
            : 'border-[#CBD5E1] text-[#94A3B8]'
        }`}
      >
        {dragging
          ? multiple
            ? 'Drop files here…'
            : 'Drop file here…'
          : multiple
            ? 'or drag & drop .xlsx / .xls / .csv files here'
            : 'or drag & drop a .xlsx / .xls / .csv file here'}
      </div>
      <div className="text-[12px] text-[#334155]">{loaded}</div>
    </div>
  );
};

export const FestivalSchemeView: React.FC = () => {
  const saved = useMemo(() => loadFestivalState(), []);
  const [scheme, setScheme] = useState<SchemeDesign[]>(() => saved?.scheme ?? []);
  const [schemeFile, setSchemeFile] = useState(() => saved?.schemeFile ?? '');
  const [soldFiles, setSoldFiles] = useState<SoldData[]>(() => saved?.soldFiles ?? []);
  const [stockFiles, setStockFiles] = useState<DesignStockFile[]>(() => saved?.stockFiles ?? []);
  const [logic, setLogic] = useState<FestivalLogic>(() => saved?.logic ?? 'hybrid');
  const [salesMonths, setSalesMonths] = useState(() => saved?.salesMonths ?? 9);
  const [designQuery, setDesignQuery] = useState(() => saved?.designQuery ?? '');
  const [reportMode, setReportMode] = useState<'summary' | 'breakdown'>(() => saved?.reportMode ?? 'summary');
  const [errors, setErrors] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  // Keep report alive across Cockpit / Home navigation (until Clear all or storage wipe)
  useEffect(() => {
    saveFestivalState({
      scheme,
      schemeFile,
      soldFiles,
      stockFiles,
      logic,
      salesMonths,
      designQuery,
      reportMode,
    });
  }, [scheme, schemeFile, soldFiles, stockFiles, logic, salesMonths, designQuery, reportMode]);

  const clearAll = () => {
    setScheme([]);
    setSchemeFile('');
    setSoldFiles([]);
    setStockFiles([]);
    setErrors([]);
    setDesignQuery('');
    clearFestivalStorage();
  };

  const hasUploads = scheme.length > 0 || soldFiles.length > 0 || stockFiles.length > 0;

  const run = async (label: string, fn: () => Promise<void>) => {
    setBusy(true);
    try {
      await fn();
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setErrors((prev) => [...prev, `${label}: ${msg}`]);
    } finally {
      setBusy(false);
    }
  };

  const onScheme = (files: File[]) =>
    run(files[0].name, async () => {
      const list = parseFestivalScheme(await readBuffer(files[0]));
      setScheme(list);
      setSchemeFile(files[0].name);
      setErrors([]);
    });
  const onSold = (files: File[]) =>
    run('Sold files', async () => {
      const parsed: SoldData[] = [];
      const bad: string[] = [];
      for (const f of files) {
        try {
          parsed.push(parseFestivalSold(await readBuffer(f), f.name));
        } catch (err) {
          bad.push(`${f.name}: ${err instanceof Error ? err.message : String(err)}`);
        }
      }
      setSoldFiles((prev) => {
        // Replace by design code when present; otherwise append
        const next = [...prev];
        for (const p of parsed) {
          if (p.design) {
            const i = next.findIndex((x) => x.design && x.design.toUpperCase() === p.design.toUpperCase());
            if (i >= 0) next[i] = p;
            else next.push(p);
          } else {
            next.push(p);
          }
        }
        return next;
      });
      setErrors(bad);
    });
  const onStock = (files: File[]) =>
    run('Stock files', async () => {
      const parsed: DesignStockFile[] = [];
      const bad: string[] = [];
      for (const f of files) {
        try {
          parsed.push(parseFestivalStock(await readBuffer(f), f.name));
        } catch (err) {
          bad.push(`${f.name}: ${err instanceof Error ? err.message : String(err)}`);
        }
      }
      setStockFiles((prev) => {
        const names = new Set(parsed.map((p) => p.design));
        return [...prev.filter((p) => !names.has(p.design)), ...parsed];
      });
      setErrors(bad);
    });

  const result = useMemo(
    () =>
      scheme.length || stockFiles.length || soldFiles.length
        ? computeFestivalAllocation(scheme, stockFiles, soldFiles, { salesMonths })
        : null,
    [scheme, stockFiles, soldFiles, salesMonths],
  );
  const idx = useMemo(() => (result ? indexFestivalResult(result) : null), [result]);
  const logicInfo = FESTIVAL_LOGICS.find((l) => l.id === logic)!;

  /** Design filter — empty = all; otherwise exact design from the dropdown. */
  const visibleDesigns = useMemo(() => {
    if (!result) return [];
    const q = designQuery.trim().toUpperCase();
    if (!q) return result.designs;
    return result.designs.filter((d) => d.design.toUpperCase() === q);
  }, [result, designQuery]);

  const totals = useMemo(() => {
    if (!result || !idx) return null;
    const byCarat = new Map<string, number>();
    const byDesign = new Map<string, number>();
    let grand = 0;
    let have = 0;
    let over = 0;
    result.outlets.forEach((o) => {
      visibleDesigns.forEach((d) => {
        d.carats.forEach((c) => {
          const v = idx.pcs(logic, o, d.design, c);
          byCarat.set(`${d.design}|${c}`, (byCarat.get(`${d.design}|${c}`) || 0) + v);
          byDesign.set(d.design, (byDesign.get(d.design) || 0) + v);
          grand += v;
          have += idx.have(o, d.design, c);
        });
      });
      // Overstock still summed only over visible designs' have vs target is heavy; keep outlet-level for now
      over += idx.overstock(logic, o);
    });
    return { byCarat, byDesign, grand, have, over };
  }, [result, idx, logic, visibleDesigns]);

  /** Branch × Design rollup (no carat): Stock / Sales / Move = Target − Have (+IN / −OUT / blank). */
  const branchDesignSummary = useMemo(() => {
    if (!result || !idx) return null;
    const salesMap = new Map<string, number>();
    result.rows.forEach((r) => {
      const k = `${r.outlet}|${r.design}`;
      salesMap.set(k, (salesMap.get(k) || 0) + r.sales);
    });
    return {
      salesMap,
      rows: result.outlets.map((o) => ({
        outlet: o,
        cells: visibleDesigns.map((d) => {
          const have = idx.have(o, d.design);
          const target = idx.target(logic, o, d.design);
          // Net move: Target − Have
          //   Target 1, Have 1 → 0 (blank)
          //   Target 2, Have 1 → +1 (IN)
          //   Target 2, Have 3 → −1 (OUT)
          const move = Math.round(target - have);
          return {
            design: d.design,
            stock: have,
            sales: salesMap.get(`${o}|${d.design}`) || 0,
            move,
          };
        }),
      })),
    };
  }, [result, idx, logic, visibleDesigns]);

  const fmtMove = (n: number) => {
    if (n === 0) return '–';
    if (n > 0) return `+${n.toLocaleString()}`;
    return n.toLocaleString();
  };

  const stockTotal = visibleDesigns.reduce((s, d) => s + d.stock, 0);
  const schemeStockTotal = scheme.reduce((s, d) => s + d.stock, 0);
  const th = 'border border-[#0F3A5F] px-1.5 py-1 text-center text-[11px] font-bold text-white whitespace-nowrap';
  const td = 'border-b border-[#E2E8F0] px-1.5 py-1 text-center text-[12px] tabular-nums';

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="rounded-xl border border-[#A9D9F0] bg-gradient-to-r from-[#0A1728] to-[#0F3A5F] p-4 text-white flex flex-wrap items-center gap-3">
        <Gift className="w-6 h-6 text-[#14B4E8]" />
        <div className="flex-1 min-w-[220px]">
          <h2 className="text-base font-extrabold tracking-wide">Festival Scheme</h2>
          <p className="text-[12px] text-slate-300">
            Puja / festival stock distribution — outlet × design × carat weight, by Contribution, 3-Month Baseline or Hybrid.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-[11px] text-slate-300">
            Separate module · uses its own uploads, does not touch Daily Upload data
          </div>
          {hasUploads && (
            <button
              type="button"
              onClick={clearAll}
              className="inline-flex items-center gap-1.5 rounded-md border border-rose-300 bg-rose-50 px-2.5 py-1 text-[11px] font-bold text-rose-700 hover:bg-rose-100 hover:border-rose-400 cursor-pointer"
              title="Clear all uploaded scheme / sold / stock files and start fresh"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Clear all uploads
            </button>
          )}
        </div>
      </div>

      {/* Uploads */}
      <div className="grid gap-3 md:grid-cols-3">
        <UploadCard
          title="1. Festival scheme stock"
          hint="DESIGN NO + STOCK (pcs to distribute), e.g. Nosepin.xlsx"
          onFiles={onScheme}
          loaded={
            scheme.length ? (
              <span className="inline-flex items-center gap-1.5 text-emerald-700 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {schemeFile}: {scheme.length} designs · {schemeStockTotal.toLocaleString()} pcs
                <button
                  type="button"
                  aria-label="Remove scheme file"
                  onClick={() => {
                    setScheme([]);
                    setSchemeFile('');
                  }}
                  className="text-rose-600 hover:text-rose-800 cursor-pointer ml-0.5"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </span>
            ) : (
              <span className="text-[#94A3B8]">Not loaded</span>
            )
          }
        />
        <UploadCard
          title="2. Sold files (contribution)"
          hint="One per design (filename = design code), e.g. E384 - 9 Month - Sold.xlsx"
          multiple
          onFiles={onSold}
          loaded={
            soldFiles.length ? (
              <div className="flex flex-wrap gap-1.5">
                {soldFiles.map((f) => (
                  <span
                    key={f.id}
                    className="inline-flex items-center gap-1 rounded-full bg-[#E8F4FC] border border-[#A9D9F0] px-2 py-0.5 text-[11px] font-semibold text-[#0A4B73]"
                  >
                    <FileSpreadsheet className="w-3 h-3" />
                    {f.design || f.fileName}
                    <button
                      type="button"
                      aria-label={`Remove sold ${f.design || f.fileName}`}
                      onClick={() => setSoldFiles((prev) => prev.filter((p) => p.id !== f.id))}
                      className="text-rose-600 hover:text-rose-800 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            ) : (
              <span className="text-[#94A3B8]">Not loaded</span>
            )
          }
        />
        <UploadCard
          title="3. Stock breakdown files"
          hint="One file per design (outlet × carat), e.g. E384 - Stock.xlsx"
          multiple
          onFiles={onStock}
          loaded={
            stockFiles.length ? (
              <div className="flex flex-wrap gap-1.5">
                {stockFiles.map((f) => (
                  <span
                    key={f.id}
                    className="inline-flex items-center gap-1 rounded-full bg-[#E8F4FC] border border-[#A9D9F0] px-2 py-0.5 text-[11px] font-semibold text-[#0A4B73]"
                  >
                    <FileSpreadsheet className="w-3 h-3" />
                    {f.design}
                    <button
                      type="button"
                      aria-label={`Remove ${f.design}`}
                      onClick={() => setStockFiles((prev) => prev.filter((p) => p.id !== f.id))}
                      className="text-rose-600 hover:text-rose-800 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            ) : (
              <span className="text-[#94A3B8]">Not loaded</span>
            )
          }
        />
      </div>

      {busy && <div className="text-xs text-[#0284C7] font-semibold">Reading file…</div>}
      {errors.length > 0 && (
        <div className="rounded-lg border border-rose-300 bg-rose-50 p-2.5 text-xs text-rose-800 space-y-0.5">
          {errors.map((e, i) => (
            <div key={i} className="flex items-start gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              {e}
            </div>
          ))}
        </div>
      )}
      {result && result.warnings.length > 0 && (
        <div className="rounded-lg border border-amber-300 bg-amber-50 p-2.5 text-xs text-amber-900 space-y-0.5">
          {result.warnings.map((w, i) => (
            <div key={i} className="flex items-start gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              {w}
            </div>
          ))}
        </div>
      )}

      {/* Controls */}
      <div className="rounded-xl border border-[#A9D9F0] bg-white p-3 shadow-sm flex flex-wrap items-end gap-4">
        <label className="flex flex-col gap-1 text-[11px] font-bold text-[#4F6B88]">
          Select Logic
          <select
            value={logic}
            onChange={(e) => setLogic(e.target.value as FestivalLogic)}
            className="rounded-md border-2 border-[#14B4E8] bg-yellow-100 px-3 py-1.5 text-sm font-extrabold text-[#0A1728] cursor-pointer"
          >
            {FESTIVAL_LOGICS.map((l) => (
              <option key={l.id} value={l.id}>
                {l.label}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-[11px] font-bold text-[#4F6B88]">
          Months in sold file
          <input
            type="number"
            min={1}
            max={36}
            value={salesMonths}
            onChange={(e) => setSalesMonths(Math.max(1, Number(e.target.value) || 1))}
            className="w-24 rounded-md border border-[#A9D9F0] px-2 py-1.5 text-sm text-[#0A1728]"
          />
        </label>
        <label className="flex flex-col gap-1 text-[11px] font-bold text-[#4F6B88] min-w-[200px]">
          Design
          <select
            value={designQuery}
            onChange={(e) => setDesignQuery(e.target.value)}
            className="rounded-md border-2 border-[#14B4E8] bg-white px-3 py-1.5 text-sm font-bold text-[#0A1728] cursor-pointer"
          >
            <option value="">All designs</option>
            {(result?.designs || scheme).map((d) => (
              <option key={d.design} value={d.design}>
                {d.design}
                {'stock' in d ? ` (${d.stock} pcs)` : ''}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-[11px] font-bold text-[#4F6B88]">
          Report
          <div className="inline-flex rounded-md border-2 border-[#14B4E8] overflow-hidden">
            <button
              type="button"
              onClick={() => setReportMode('summary')}
              className={`px-3 py-1.5 text-sm font-extrabold cursor-pointer ${
                reportMode === 'summary'
                  ? 'bg-[#14B4E8] text-white'
                  : 'bg-white text-[#0A1728] hover:bg-[#E8F7FD]'
              }`}
            >
              Summary
            </button>
            <button
              type="button"
              onClick={() => setReportMode('breakdown')}
              className={`px-3 py-1.5 text-sm font-extrabold cursor-pointer border-l-2 border-[#14B4E8] ${
                reportMode === 'breakdown'
                  ? 'bg-[#14B4E8] text-white'
                  : 'bg-white text-[#0A1728] hover:bg-[#E8F7FD]'
              }`}
            >
              Breakdown
            </button>
          </div>
        </label>
        <p className="flex-1 min-w-[200px] text-[11px] text-[#4F6B88]">{logicInfo.description}</p>
        <button
          type="button"
          disabled={!result || !idx || visibleDesigns.length === 0}
          onClick={() => result && idx && void exportFestivalExcel(result, idx, logic)}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white text-xs font-bold cursor-pointer disabled:cursor-not-allowed"
        >
          <Download className="w-4 h-4" />
          Download Excel
        </button>
      </div>

      {/* Report */}
      {!result || !idx || !totals ? (
        <div className="rounded-xl border border-dashed border-[#A9D9F0] bg-white p-10 text-center text-sm text-[#64748B]">
          Upload scheme and/or stock & sold files to generate the report. Without festival budget, total existing stock is used as the pool — Move still shows Target − Have (redistribution).
        </div>
      ) : visibleDesigns.length === 0 ? (
        <div className="rounded-xl border border-dashed border-amber-300 bg-amber-50 p-8 text-center text-sm text-amber-900">
          No design selected. Choose a design from the dropdown, or pick “All designs”.
        </div>
      ) : (
        <>
        {/* Summary: Branch × Design — Stock / Sales / Move IN (no carat) */}
        {reportMode === 'summary' && (
        <div className="rounded-xl border border-[#A9D9F0] bg-white shadow-sm overflow-hidden">
          <div className="px-3 py-2 border-b border-[#E2E8F0] flex items-center justify-between gap-2">
            <div className="text-[13px] font-extrabold text-[#0A1728]">
              Summary — Branch × Design ({logicInfo.label})
            </div>
            <div className="text-[11px] text-[#64748B]">
              Budget = festival stock (or total existing stock if no scheme) · Stock = Have · Sales = share · Move = Target − Have → <span className="text-teal-700 font-bold">+IN</span> / <span className="text-rose-700 font-bold">−OUT</span> / blank
            </div>
          </div>
          <div className="overflow-auto max-h-[50vh]">
            <table className="border-collapse text-[12px]" data-testid="festival-branch-summary">
              <thead className="sticky top-0 z-20">
                <tr>
                  <th rowSpan={2} className={`${th} bg-[#1F4E78] sticky left-0 z-30 min-w-[90px] text-left`}>
                    Branch
                  </th>
                  {visibleDesigns.map((d, i) => (
                    <th
                      key={d.design}
                      colSpan={3}
                      className={`${th} ${i % 2 ? 'bg-[#2E75B6]' : 'bg-[#1F4E78]'}`}
                    >
                      {d.design}
                    </th>
                  ))}
                  <th rowSpan={2} className={`${th} bg-[#1F4E78]`}>Net Move</th>
                </tr>
                <tr>
                  {visibleDesigns.map((d, i) => (
                    <React.Fragment key={d.design}>
                      <th className={`${th} ${i % 2 ? 'bg-[#2E75B6]' : 'bg-[#1F4E78]'}`}>Stock</th>
                      <th className={`${th} ${i % 2 ? 'bg-[#2E75B6]' : 'bg-[#1F4E78]'}`}>Sales</th>
                      <th className={`${th} ${i % 2 ? 'bg-[#2E75B6]' : 'bg-[#1F4E78]'}`}>Move</th>
                    </React.Fragment>
                  ))}
                </tr>
              </thead>
              <tbody>
                {branchDesignSummary?.rows.map((row) => {
                  const rowMove = row.cells.reduce((s, c) => s + c.move, 0);
                  return (
                    <tr key={row.outlet} className="hover:bg-[#F1F8FD]">
                      <td className={`${td} sticky left-0 z-10 bg-white text-left font-bold`}>{row.outlet}</td>
                      {row.cells.map((c) => (
                        <React.Fragment key={c.design}>
                          <td className={td}>{fmt(c.stock)}</td>
                          <td className={td}>{fmt(c.sales)}</td>
                          <td
                            className={`${td} font-bold ${
                              c.move > 0
                                ? 'text-teal-800 bg-teal-50'
                                : c.move < 0
                                  ? 'text-rose-800 bg-rose-50'
                                  : ''
                            }`}
                          >
                            {fmtMove(c.move)}
                          </td>
                        </React.Fragment>
                      ))}
                      <td
                        className={`${td} font-extrabold ${
                          rowMove > 0
                            ? 'text-teal-800 bg-teal-50'
                            : rowMove < 0
                              ? 'text-rose-800 bg-rose-50'
                              : ''
                        }`}
                      >
                        {fmtMove(rowMove)}
                      </td>
                    </tr>
                  );
                })}
                <tr className="bg-[#DDEBF7] font-extrabold">
                  <td className={`${td} sticky left-0 z-10 bg-[#DDEBF7] text-left`}>Total</td>
                  {visibleDesigns.map((d) => {
                    const stock =
                      branchDesignSummary?.rows.reduce(
                        (s, r) => s + (r.cells.find((c) => c.design === d.design)?.stock || 0),
                        0,
                      ) || 0;
                    const sales =
                      branchDesignSummary?.rows.reduce(
                        (s, r) => s + (r.cells.find((c) => c.design === d.design)?.sales || 0),
                        0,
                      ) || 0;
                    const move =
                      branchDesignSummary?.rows.reduce(
                        (s, r) => s + (r.cells.find((c) => c.design === d.design)?.move || 0),
                        0,
                      ) || 0;
                    return (
                      <React.Fragment key={d.design}>
                        <td className={td}>{fmt(stock)}</td>
                        <td className={td}>{fmt(sales)}</td>
                        <td
                          className={`${td} font-bold ${
                            move > 0
                              ? 'text-teal-800 bg-teal-50'
                              : move < 0
                                ? 'text-rose-800 bg-rose-50'
                                : ''
                          }`}
                        >
                          {fmtMove(move)}
                        </td>
                      </React.Fragment>
                    );
                  })}
                  <td
                    className={`${td} font-extrabold ${(() => {
                      const net =
                        branchDesignSummary?.rows.reduce(
                          (s, r) => s + r.cells.reduce((ss, c) => ss + c.move, 0),
                          0,
                        ) || 0;
                      return net > 0
                        ? 'text-teal-800 bg-teal-50'
                        : net < 0
                          ? 'text-rose-800 bg-rose-50'
                          : '';
                    })()}`}
                  >
                    {fmtMove(
                      branchDesignSummary?.rows.reduce(
                        (s, r) => s + r.cells.reduce((ss, c) => ss + c.move, 0),
                        0,
                      ) || 0,
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        )}

        {/* Breakdown: Outlet × Design × Carat */}
        {reportMode === 'breakdown' && (
        <div className="rounded-xl border border-[#A9D9F0] bg-white shadow-sm overflow-hidden">
          <div className="px-3 py-2 border-b border-[#E2E8F0] text-[13px] font-extrabold text-[#0A1728]">
            Breakdown — Outlet × Design × Carat
          </div>
          <div className="overflow-auto max-h-[70vh]">
            <table className="border-collapse text-[12px]" data-testid="festival-matrix">
              <thead className="sticky top-0 z-20">
                <tr>
                  <th rowSpan={2} className={`${th} bg-[#1F4E78] sticky left-0 z-30 min-w-[84px]`}>Outlet</th>
                  <th rowSpan={2} className={`${th} bg-[#1F4E78] sticky left-[84px] z-30 min-w-[70px]`}>Contrib. %</th>
                  {visibleDesigns.map((d, i) => (
                    <th
                      key={d.design}
                      colSpan={d.carats.length + 1}
                      className={`${th} ${i % 2 ? 'bg-[#2E75B6]' : 'bg-[#1F4E78]'}`}
                    >
                      {d.design}
                    </th>
                  ))}
                  <th rowSpan={2} className={`${th} bg-[#1F4E78]`}>Total new pcs</th>
                  <th rowSpan={2} className={`${th} bg-[#1F4E78]`}>Existing (Have)</th>
                  <th rowSpan={2} className={`${th} bg-[#1F4E78]`}>Overstock</th>
                </tr>
                <tr>
                  {visibleDesigns.map((d, i) => (
                    <React.Fragment key={d.design}>
                      {d.carats.map((c) => (
                        <th key={c} className={`${th} ${i % 2 ? 'bg-[#2E75B6]' : 'bg-[#1F4E78]'}`}>
                          {caratLabel(c)}
                        </th>
                      ))}
                      <th className={`${th} ${i % 2 ? 'bg-[#2E75B6]' : 'bg-[#1F4E78]'}`}>Total</th>
                    </React.Fragment>
                  ))}
                </tr>
                <tr className="bg-[#FFF2CC] font-bold">
                  <td className={`${td} sticky left-0 z-10 bg-[#FFF2CC] text-left`}>Stock to distribute</td>
                  <td className={`${td} sticky left-[84px] z-10 bg-[#FFF2CC]`} />
                  {visibleDesigns.map((d) => (
                    <React.Fragment key={d.design}>
                      {d.carats.map((c) => (
                        <td key={c} className={`${td} bg-[#FFF2CC]`}>{fmt(d.caratStock[c] || 0)}</td>
                      ))}
                      <td className={`${td} bg-[#FFF2CC]`}>{fmt(d.stock)}</td>
                    </React.Fragment>
                  ))}
                  <td className={`${td} bg-[#FFF2CC]`}>{fmt(stockTotal)}</td>
                  <td className={`${td} bg-[#FFF2CC]`} />
                  <td className={`${td} bg-[#FFF2CC]`} />
                </tr>
              </thead>
              <tbody>
                {result.outlets.map((o) => {
                  const rowTotal = visibleDesigns.reduce((s, d) => s + idx.pcs(logic, o, d.design), 0);
                  const haveTotal = visibleDesigns.reduce((s, d) => s + idx.have(o, d.design), 0);
                  return (
                    <tr key={o} className="hover:bg-[#F1F8FD]">
                      <td className={`${td} sticky left-0 z-10 bg-white text-left font-bold`}>{o}</td>
                      <td className={`${td} sticky left-[84px] z-10 bg-white`}>
                        {((result.outletShare[o] || 0) * 100).toFixed(2)}%
                      </td>
                      {visibleDesigns.map((d) => (
                        <React.Fragment key={d.design}>
                          {d.carats.map((c) => (
                            <td key={c} className={td}>{fmt(idx.pcs(logic, o, d.design, c))}</td>
                          ))}
                          <td className={`${td} font-bold bg-[#DDEBF7]`}>{fmt(idx.pcs(logic, o, d.design))}</td>
                        </React.Fragment>
                      ))}
                      <td className={`${td} font-extrabold`}>{fmt(rowTotal)}</td>
                      <td className={td}>{fmt(haveTotal)}</td>
                      <td className={td}>{fmt(Math.round(idx.overstock(logic, o)))}</td>
                    </tr>
                  );
                })}
                <tr className="bg-[#DDEBF7] font-extrabold">
                  <td className={`${td} sticky left-0 z-10 bg-[#DDEBF7] text-left`}>Total</td>
                  <td className={`${td} sticky left-[84px] z-10 bg-[#DDEBF7]`}>100%</td>
                  {visibleDesigns.map((d) => (
                    <React.Fragment key={d.design}>
                      {d.carats.map((c) => (
                        <td key={c} className={td}>{fmt(totals.byCarat.get(`${d.design}|${c}`) || 0)}</td>
                      ))}
                      <td className={td}>{fmt(totals.byDesign.get(d.design) || 0)}</td>
                    </React.Fragment>
                  ))}
                  <td className={td}>{fmt(totals.grand)}</td>
                  <td className={td}>{fmt(totals.have)}</td>
                  <td className={td}>{fmt(Math.round(totals.over))}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div className="flex flex-wrap items-center gap-3 px-3 py-2 border-t border-[#E2E8F0] text-[11px] text-[#4F6B88]">
            {totals.grand === stockTotal ? (
              <span className="inline-flex items-center gap-1 text-emerald-700 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" /> All {stockTotal.toLocaleString()} pcs allocated — check OK
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-rose-700 font-bold">
                <AlertTriangle className="w-3.5 h-3.5" /> Allocated {totals.grand} of {stockTotal}
              </span>
            )}
            <span>
              Live stock per design &amp; carat = existing outlet stock (Have) + festival stock. DWL, online and invalid
              outlet codes are excluded; sub-store codes are merged into the parent outlet.
            </span>
          </div>
        </div>
        )}
        </>
      )}
    </div>
  );
};

export default FestivalSchemeView;
