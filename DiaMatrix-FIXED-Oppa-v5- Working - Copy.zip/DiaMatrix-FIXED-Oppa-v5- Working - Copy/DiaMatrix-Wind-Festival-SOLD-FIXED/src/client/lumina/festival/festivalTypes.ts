/**
 * Festival Scheme — shared types.
 *
 * This module is intentionally self-contained: it has its own uploads, its own
 * parsers and its own engine. It never reads from or writes to the Daily
 * Upload / working-dataset pipeline.
 */

export type FestivalLogic = 'contribution' | 'baseline' | 'hybrid' | 'coverage';

export const FESTIVAL_LOGICS: { id: FestivalLogic; label: string; description: string }[] = [
  {
    id: 'contribution',
    label: 'Contribution',
    description:
      'Have vs Deserve: Deserve = Sales Contribution % × Live Stock (existing outlet stock + festival stock). Move IN = Deserve − Have.',
  },
  {
    id: 'baseline',
    label: '3-Month Baseline',
    description:
      'Ideal demand = avg monthly sales × 3 (+20% for high performers, stock-out safety when stock is 0). Move IN = Ideal − Have.',
  },
  {
    id: 'hybrid',
    label: 'Hybrid',
    description:
      'Target = max(Contribution, 3-Month Baseline), compressed to the live stock. Move IN = Target − Have.',
  },
  {
    id: 'coverage',
    label: 'Coverage',
    description:
      'Coverage: every outlet aims for ≥1 pc (priority = highest sales → lowest when short). Pool = existing stock + festival stock (or only existing if no scheme). Move = Target − Have → +IN / −OUT / blank. Leftover after 1-each goes by sales share.',
  },
];

/** Carat weights are keyed as fixed 2-decimal strings, e.g. "0.05". */
export type CaratKey = string;
export const ALL_CARAT_KEY: CaratKey = 'ALL';

/** One design row from the Puja / Festival scheme stock file. */
export interface SchemeDesign {
  design: string;
  /** Pieces to distribute for this design. */
  stock: number;
  gWt?: number;
  nWt?: number;
  dWt?: number;
  mrp?: number;
  fixedPrice?: number;
}

/** outlet → carat → qty */
export type OutletCaratMap = Record<string, Record<CaratKey, number>>;

export interface SoldData {
  id: string;
  fileName: string;
  /** Design code detected from file name (e.g. E384 from "E384 - 9 Month - Sold.xlsx"). Empty = global/all designs. */
  design: string;
  carats: CaratKey[];
  sales: OutletCaratMap;
}

export interface DesignStockFile {
  id: string;
  fileName: string;
  /** Design code, detected from the file name (editable in the UI). */
  design: string;
  category: string;
  carats: CaratKey[];
  /** Retail outlet stock (DWL / online / invalid codes excluded). */
  stock: OutletCaratMap;
  /** DWL warehouse stock per carat — information only. */
  warehouse: Record<CaratKey, number>;
}

export interface FestivalSettings {
  /** Number of months covered by the sold file (default 9). */
  salesMonths: number;
}

export interface FestivalCell {
  have: number;
  sales: number;
  /** Outlet's sales contribution for this carat (0–1). */
  share: number;
  target: Record<FestivalLogic, number>;
  pcs: Record<FestivalLogic, number>;
  overstock: Record<FestivalLogic, number>;
}

export interface FestivalRow extends FestivalCell {
  design: string;
  carat: CaratKey;
  outlet: string;
}

export interface FestivalDesignMeta {
  design: string;
  stock: number;
  carats: CaratKey[];
  /** Festival pcs per carat (split by existing carat mix). */
  caratStock: Record<CaratKey, number>;
  hasStockFile: boolean;
  scheme: SchemeDesign;
}

export interface FestivalResult {
  outlets: string[];
  designs: FestivalDesignMeta[];
  rows: FestivalRow[];
  /** outlet → share of total sold qty (0–1). */
  outletShare: Record<string, number>;
  warnings: string[];
}

export interface FestivalInputsState {
  scheme: SchemeDesign[];
  schemeFileName: string;
  /** One or more sold files — per-design (design set) or global (design empty). */
  soldFiles: SoldData[];
  stockFiles: DesignStockFile[];
  salesMonths: number;
  logic: FestivalLogic;
}
