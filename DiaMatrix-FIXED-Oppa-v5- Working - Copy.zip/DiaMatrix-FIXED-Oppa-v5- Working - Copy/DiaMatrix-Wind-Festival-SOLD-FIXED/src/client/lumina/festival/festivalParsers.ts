import * as XLSX from 'xlsx';
import { isExcludedOutlet, mergeOutletToParent } from '../utils/dataIdentityEngine';
import {
  ALL_CARAT_KEY,
  type CaratKey,
  type DesignStockFile,
  type OutletCaratMap,
  type SchemeDesign,
  type SoldData,
} from './festivalTypes';

type Row = unknown[];

const text = (v: unknown): string => (v === null || v === undefined ? '' : String(v).trim());
const num = (v: unknown): number | null => {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v === 'string') {
    const n = Number(v.replace(/,/g, '').trim());
    return v.trim() !== '' && Number.isFinite(n) ? n : null;
  }
  return null;
};

export const caratKey = (value: number): CaratKey => value.toFixed(2);

function sheetRows(buffer: ArrayBuffer, sheetName?: string): { rows: Row[]; sheetNames: string[] } {
  const wb = XLSX.read(buffer, { type: 'array' });
  const name = sheetName ?? wb.SheetNames[0];
  const ws = wb.Sheets[name];
  const rows = ws
    ? (XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null, blankrows: false }) as Row[])
    : [];
  return { rows, sheetNames: wb.SheetNames };
}

/**
 * Normalise an outlet code using the same rules as the rest of DiaMatrix
 * (trailing-S sub-stores merge into the parent, FAIR / online are excluded).
 * Returns 'DWL' for the warehouse and null for excluded / invalid codes.
 */
export function normalizeFestivalOutlet(raw: unknown): string | null {
  const up = text(raw).toUpperCase();
  if (!up) return null;
  if (up === 'DWL') return 'DWL';
  if (isExcludedOutlet(up)) return null;
  // JAS (Jashore) is a main outlet — its trailing "S" is part of the code, not a sub-store suffix.
  if (up === 'JAS') return 'JAS';
  const parent = mergeOutletToParent(up);
  // Sub-store of a merged pair (SAVS → SAV → RUP): resolve one more level, JAS stays as is.
  return parent === 'JAS' ? parent : mergeOutletToParent(parent);
}

const addTo = (map: OutletCaratMap, outlet: string, carat: CaratKey, qty: number) => {
  if (!map[outlet]) map[outlet] = {};
  map[outlet][carat] = (map[outlet][carat] || 0) + qty;
};

/** Numeric carat headers of a row → column index → carat key.
 *  Accepts real numbers and numeric strings ("0.08", "0.11") from Excel exports.
 */
function caratColumns(row: Row): Map<number, CaratKey> {
  const cols = new Map<number, CaratKey>();
  row.forEach((cell, idx) => {
    const n = num(cell);
    // Skip Total column and non-carat values; carat weights are typically 0.01–5.00
    if (n !== null && n > 0 && n < 5) cols.set(idx, caratKey(n));
  });
  return cols;
}

/** Sold file: supports both
 *  (A) DiaMatrix export style:
 *      Row N:   … | Range | … | 0.11 | 0.12 | …   (carat weights)
 *      Row N+1: … | Total |
 *      Row N+2: Category Name | … | Branch | … | Qty | Qty | …
 *  (B) Flat: Category Name | Brnch | carats… | Total
 *  (C) Range / Branch row with numeric carat headers only
 */
export function parseFestivalSold(buffer: ArrayBuffer, fileName: string): SoldData {
  const { rows } = sheetRows(buffer);

  // Prefer "Category Name" as the label row (data starts after it)
  let labelIdx = rows.findIndex((r) => text(r[0]).toLowerCase() === 'category name');
  if (labelIdx < 0) labelIdx = rows.findIndex((r) => r.some((c) => text(c).toLowerCase() === 'range'));
  if (labelIdx < 0) labelIdx = rows.findIndex((r) => caratColumns(r).size >= 1);
  if (labelIdx < 0) throw new Error('Sold file: carat header row not found (need Category Name / Brnch / carats).');

  // Carats may sit on the label row itself, or 1–2 rows above it (DiaMatrix Range row)
  let cols = caratColumns(rows[labelIdx]);
  let caratRowIdx = labelIdx;
  if (cols.size === 0) {
    for (let back = 1; back <= 3 && labelIdx - back >= 0; back++) {
      const candidate = caratColumns(rows[labelIdx - back]);
      if (candidate.size > 0) {
        cols = candidate;
        caratRowIdx = labelIdx - back;
        break;
      }
    }
  }
  if (cols.size === 0) throw new Error('Sold file: no carat columns found.');

  // Branch column: look on label row first, then nearby rows
  let branchCol = -1;
  for (let i = Math.max(0, labelIdx - 2); i <= Math.min(rows.length - 1, labelIdx + 2) && branchCol < 0; i++) {
    const idx = rows[i].findIndex((c) =>
      ['branch', 'brnch', 'outlet', 'store', 'range'].includes(text(c).toLowerCase()),
    );
    if (idx >= 0) branchCol = idx;
  }
  if (branchCol < 0) branchCol = 1; // DiaMatrix export fallback

  // Data rows start after the Category Name / label row
  const dataStart = labelIdx + 1;
  const sales: OutletCaratMap = {};
  for (let i = dataStart; i < rows.length; i++) {
    const first = text(rows[i][0]);
    if (first.toLowerCase().startsWith('total')) continue;
    // Also skip rows whose only non-empty cell looks like a total label in col 2
    const mid = text(rows[i][2]);
    if (mid.toLowerCase().startsWith('total')) continue;
    const outlet = normalizeFestivalOutlet(rows[i][branchCol]);
    if (!outlet || outlet === 'DWL') continue;
    cols.forEach((key, idx) => {
      const qty = num(rows[i][idx]);
      if (qty !== null && qty > 0) addTo(sales, outlet, key, qty);
    });
  }
  if (Object.keys(sales).length === 0) throw new Error('Sold file: no outlet rows found.');
  const design = designFromFileName(fileName);
  return {
    id: `${fileName}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    fileName,
    design,
    carats: Array.from(new Set(cols.values())).sort(),
    sales,
  };
}

/** Design code from file name: "E654 - Stock.xlsx", "WER18-09117_Stock.xlsx",
 *  "E384 - 9 Month - Sold.xlsx", "NP7SD10 - Stock.xlsx".
 *  Keeps hyphenated Puja scheme codes (WER18-09117, IPSER20-07017) intact.
 *  Strips noise tokens (stock/sold/scheme/month/qty/…) so only the design code remains.
 */
export function designFromFileName(fileName: string): string {
  const base = fileName.replace(/\.[^.]+$/, '');
  const up = base.toUpperCase();
  // Prefer longest design-code match:
  //   - letters + digits + optional trailing letters (R4014CS, NP7SD10, KR604888)
  //   - optional hyphen segments (WER18-09117, IPSER20-07017, WLR25-12016)
  // No trailing \b — hyphenated codes would otherwise stop at the first segment.
  const codeMatch = up.match(/\b([A-Z]{1,12}\d+[A-Z0-9]*(?:-[A-Z0-9]+)*)/);
  if (codeMatch) return codeMatch[1];
  // Fallback: strip known noise words then normalize
  const cleaned = base
    .replace(/[-_\s]*(stock|sold|scheme|month|months|qty|quantity|pcs|piece|pieces|report|export).*$/i, '')
    .trim();
  const normalized = cleaned.toUpperCase().replace(/\s+/g, '');
  if (/^[A-Z0-9]+(?:-[A-Z0-9]+)*$/.test(normalized)) return normalized;
  const m = normalized.match(/[A-Z]{1,12}\d+[A-Z0-9]*(?:-[A-Z0-9]+)*/);
  return m ? m[0] : normalized;
}

/** Stock breakdown file: "Category Name | Brnch | carats… | Total". Design from file name. */
export function parseFestivalStock(buffer: ArrayBuffer, fileName: string): DesignStockFile {
  const { rows } = sheetRows(buffer);
  // Find header: prefers "Category Name" in first cell; else any row with 2+ numeric carat headers
  let headerIdx = rows.findIndex((r) => text(r[0]).toLowerCase() === 'category name');
  if (headerIdx < 0) {
    headerIdx = rows.findIndex((r) => caratColumns(r).size >= 2);
  }
  if (headerIdx < 0) throw new Error('Stock file: "Category Name" header row not found.');
  const cols = caratColumns(rows[headerIdx]);
  if (cols.size === 0) throw new Error('Stock file: no carat columns found.');

  // Branch column: labeled Brnch/Branch, else column 1
  const headerLower = rows[headerIdx].map((c) => text(c).toLowerCase());
  let branchCol = headerLower.findIndex((h) => h === 'brnch' || h === 'branch' || h === 'outlet' || h === 'store');
  if (branchCol < 0) branchCol = 1;

  const stock: OutletCaratMap = {};
  const warehouse: Record<CaratKey, number> = {};
  let category = '';
  for (let i = headerIdx + 1; i < rows.length; i++) {
    const first = text(rows[i][0]);
    if (first.toLowerCase().startsWith('total')) continue;
    if (first && !category) category = first;
    const outlet = normalizeFestivalOutlet(rows[i][branchCol]);
    if (!outlet) continue;
    cols.forEach((key, idx) => {
      const qty = num(rows[i][idx]);
      if (qty === null || qty <= 0) return;
      if (outlet === 'DWL') warehouse[key] = (warehouse[key] || 0) + qty;
      else addTo(stock, outlet, key, qty);
    });
  }
  return {
    id: `${fileName}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    fileName,
    design: designFromFileName(fileName),
    category,
    carats: Array.from(new Set(cols.values())).sort(),
    stock,
    warehouse,
  };
}

/** Scheme file: DESIGN NO + STOCK (Puja format with S/L, P.IMAGE also OK). Scans every sheet. */
export function parseFestivalScheme(buffer: ArrayBuffer): SchemeDesign[] {
  const wb = XLSX.read(buffer, { type: 'array' });
  const merged = new Map<string, SchemeDesign>();

  const normHeader = (c: unknown) => text(c).toLowerCase().replace(/[\s._-]+/g, '');

  wb.SheetNames.forEach((name) => {
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[name], {
      header: 1,
      raw: true,
      defval: null,
      blankrows: false,
    }) as Row[];
    // Accept "DESIGN NO", "Design No.", "Design No", "designno"
    const headerIdx = rows.findIndex((r) =>
      r.some((c) => {
        const h = normHeader(c);
        return h === 'designno' || h === 'design' || h === 'designcode' || h === 'styleno';
      }),
    );
    if (headerIdx < 0) return;
    const header = rows[headerIdx].map(normHeader);
    const col = (...names: string[]) => header.findIndex((h) => names.includes(h));
    const designCol = col('designno', 'design', 'designcode', 'styleno');
    const stockCol = col('stock', 'qty', 'pcs', 'quantity', 'pieces');
    if (designCol < 0 || stockCol < 0) return;
    const gCol = col('gwt');
    const nCol = col('nwt');
    const dCol = col('dwt');
    const mrpCol = col('mrp');
    const fixedCol = col('fixedprice', 'fixed', 'price');

    for (let i = headerIdx + 1; i < rows.length; i++) {
      // Keep hyphens in design codes (WER18-09117); strip spaces only
      const design = text(rows[i][designCol]).toUpperCase().replace(/\s+/g, '');
      const stock = num(rows[i][stockCol]);
      // Skip TOTAL / TOTAL= rows and empty design / image-only rows
      if (!design || design.startsWith('TOTAL') || design === 'S/L' || stock === null || stock < 0) continue;
      const prev = merged.get(design);
      const pick = (c: number) => (c >= 0 ? (num(rows[i][c]) ?? undefined) : undefined);
      merged.set(design, {
        design,
        stock: Math.round(stock),
        gWt: pick(gCol) ?? prev?.gWt,
        nWt: pick(nCol) ?? prev?.nWt,
        dWt: pick(dCol) ?? prev?.dWt,
        mrp: pick(mrpCol) ?? prev?.mrp,
        fixedPrice: pick(fixedCol) ?? prev?.fixedPrice,
      });
    }
  });

  const list = Array.from(merged.values());
  if (list.length === 0) throw new Error('Scheme file: no "DESIGN NO" / "STOCK" rows found. Use columns DESIGN NO and STOCK (S/L and P.IMAGE optional).');
  return list;
}

export { ALL_CARAT_KEY };
