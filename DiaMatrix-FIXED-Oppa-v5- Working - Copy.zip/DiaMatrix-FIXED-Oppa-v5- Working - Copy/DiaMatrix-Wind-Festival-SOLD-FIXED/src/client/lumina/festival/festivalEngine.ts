import { calculateIdealDemandBackup, safeDiv, safeNonNeg } from '../utils/redistributionEngine';
import {
  ALL_CARAT_KEY,
  FESTIVAL_LOGICS,
  type CaratKey,
  type DesignStockFile,
  type FestivalDesignMeta,
  type FestivalLogic,
  type FestivalResult,
  type FestivalRow,
  type FestivalSettings,
  type SchemeDesign,
  type SoldData,
} from './festivalTypes';

/**
 * Festival Scheme allocation engine.
 *
 * For every design × carat the engine runs DiaMatrix's "Have vs Deserve" logic:
 *   Live stock (pool) = existing retail outlet stock (Have) + festival stock for that carat
 *   Target (Deserve)  = per logic (contribution / 3-month baseline / hybrid)
 *   Move IN           = max(0, Target − Have), fitted to the festival stock that is available
 * Whole pieces only; the allocated pieces always add up exactly to the festival stock.
 */

const LOGICS: FestivalLogic[] = FESTIVAL_LOGICS.map((l) => l.id);
const emptyByLogic = (): Record<FestivalLogic, number> => ({
  contribution: 0,
  baseline: 0,
  hybrid: 0,
  coverage: 0,
});

/** Largest-remainder rounding of non-negative exact values to integers that sum to `total`. */
function roundToTotal(exact: number[], total: number, tieBreak: number[]): number[] {
  const out = exact.map((v) => Math.max(0, Math.floor(v)));
  let remaining = total - out.reduce((s, v) => s + v, 0);
  const order = exact
    .map((v, i) => ({ i, frac: v - Math.floor(v), tie: tieBreak[i] ?? 0 }))
    .sort((a, b) => b.frac - a.frac || b.tie - a.tie || a.i - b.i);
  for (let k = 0; remaining > 0 && order.length; k++, remaining--) out[order[k % order.length].i] += 1;
  // Safety: if floors overshoot (floating point), take back from the largest.
  while (remaining < 0) {
    let big = 0;
    out.forEach((v, i) => {
      if (v > out[big]) big = i;
    });
    if (out[big] <= 0) break;
    out[big] -= 1;
    remaining += 1;
  }
  return out;
}

/** Same compression / rounding steps as DiaMatrix's allocation target builder. */
function buildTargets(
  outlets: { stock: number; sales: number; share: number }[],
  pool: number,
  months: number,
  logic: FestivalLogic,
): number[] {
  const n = outlets.length;
  const totalSales = outlets.reduce((s, o) => s + o.sales, 0);
  const averageMonthlySales = safeDiv(totalSales, months * Math.max(1, n), 0);

  // Coverage: every outlet should end with ≥1 pc when pool allows
  const minPerOutlet = logic === 'coverage' && pool >= n ? 1 : 0;
  const residualPool = Math.max(0, pool - minPerOutlet * n);

  const raw = outlets.map((o) => {
    const avgMonthly = safeDiv(o.sales, months, 0);
    const demand = calculateIdealDemandBackup({
      salesAvgMonthly: avgMonthly,
      isHighPerformer: avgMonthly > averageMonthlySales,
      currentStock: o.stock,
    });
    const baseline = safeNonNeg(demand.totalIdealDemand, 0);
    const contribution = pool * o.share;
    let target: number;
    if (logic === 'contribution') target = contribution;
    else if (logic === 'baseline') target = baseline;
    else if (logic === 'coverage') {
      // Every outlet aims for ≥1; extra by sales share when pool allows
      if (pool >= n) target = 1 + residualPool * o.share;
      else target = 1; // short pool — allocator ranks by sales
    } else target = Math.max(contribution, baseline); // hybrid
    if (o.stock <= 0 && o.sales > 0 && target < 1) target = 1;
    return safeNonNeg(target, 0);
  });

  const rawTotal = raw.reduce((s, v) => s + v, 0);
  const compression = rawTotal > pool && rawTotal > 0 ? pool / rawTotal : 1;
  const exact = raw.map((v) => v * compression);
  const targetTotal = Math.min(Math.floor(pool), Math.max(0, Math.round(rawTotal * compression)));
  return roundToTotal(
    exact,
    targetTotal,
    outlets.map((o) => o.sales),
  );
}

/** Give the festival stock to outlets: need first (scaled if short), leftovers by sales contribution. */
function allocateFestivalStock(
  need: number[],
  share: number[],
  sales: number[],
  festivalStock: number,
): number[] {
  if (festivalStock <= 0) return need.map(() => 0);
  const needTotal = need.reduce((s, v) => s + v, 0);
  const scale = needTotal > 0 ? Math.min(1, festivalStock / needTotal) : 0;
  const leftover = Math.max(0, festivalStock - needTotal);
  const shareTotal = share.reduce((s, v) => s + v, 0) || 1;
  const exact = need.map((v, i) => v * scale + (leftover * share[i]) / shareTotal);
  return roundToTotal(exact, festivalStock, sales);
}

/**
 * Coverage allocation:
 *   Phase 1 — give 1 pc to every outlet, sorted by sales descending (top → bottom).
 *             If festival stock is short, highest-sales outlets get the 1 pc first.
 *   Phase 2 — leftover pcs go to higher-sales outlets by sales share.
 * Works even when festivalStock is 0 (returns all zeros; Stock/Sales still shown in report).
 */
function allocateCoverageStock(
  haves: number[],
  share: number[],
  sales: number[],
  festivalStock: number,
): number[] {
  const n = haves.length;
  const out = haves.map(() => 0);
  if (festivalStock <= 0) return out;

  // Phase 1 — 1 pc to EVERY outlet, highest sales first when stock is short
  const bySales = haves
    .map((_, i) => ({ i, sales: sales[i] || 0 }))
    .sort((a, b) => b.sales - a.sales || a.i - b.i);

  let remaining = festivalStock;
  for (const u of bySales) {
    if (remaining <= 0) break;
    out[u.i] = 1;
    remaining -= 1;
  }

  // Phase 2 — leftover by sales share (prefers higher-sales outlets)
  if (remaining > 0) {
    const shareTotal = share.reduce((s, v) => s + v, 0) || 1;
    const extra = roundToTotal(
      share.map((s) => (remaining * s) / shareTotal),
      remaining,
      sales,
    );
    for (let i = 0; i < n; i++) out[i] += extra[i];
  }
  return out;
}

/** Pick the best sold file for a design: exact design match, else a global (no design) file, else null. */
function soldForDesign(soldFiles: SoldData[], design: string): SoldData | null {
  const up = design.toUpperCase();
  const exact = soldFiles.find((s) => s.design && s.design.toUpperCase() === up);
  if (exact) return exact;
  const global = soldFiles.find((s) => !s.design);
  return global || null;
}

export function computeFestivalAllocation(
  scheme: SchemeDesign[],
  stockFiles: DesignStockFile[],
  soldFiles: SoldData[],
  settings: FestivalSettings,
): FestivalResult {
  const warnings: string[] = [];
  const months = Math.max(1, safeNonNeg(settings.salesMonths, 9) || 9);
  const soldList = soldFiles || [];

  // If no scheme (no festival budget), still build report from stock + sold files
  // so Stock / Sales columns are visible; Move IN will be 0.
  let effectiveScheme = scheme;
  if (!effectiveScheme.length && (stockFiles.length > 0 || soldList.length > 0)) {
    const designSet = new Set<string>();
    stockFiles.forEach((f) => f.design && designSet.add(f.design));
    soldList.forEach((s) => s.design && designSet.add(s.design));
    effectiveScheme = Array.from(designSet)
      .sort()
      .map((design) => ({ design, stock: 0 }));
    if (effectiveScheme.length) {
      warnings.push('No festival scheme stock loaded — using total existing stock as pool. Move = Target − Have (redistribution).');
    }
  }

  // ---- outlets (retail only) — union of every sold + stock file ----------------
  const outletSet = new Set<string>();
  soldList.forEach((s) => Object.keys(s.sales).forEach((o) => outletSet.add(o)));
  stockFiles.forEach((f) => Object.keys(f.stock).forEach((o) => outletSet.add(o)));

  // Global outlet sales (sum across all sold files) for ranking / fallback share
  const outletSales: Record<string, number> = {};
  outletSet.forEach((o) => {
    outletSales[o] = soldList.reduce(
      (sum, s) => sum + Object.values(s.sales[o] || {}).reduce((a, b) => a + b, 0),
      0,
    );
  });
  const outlets = Array.from(outletSet).sort((a, b) => outletSales[b] - outletSales[a] || a.localeCompare(b));
  const grandSales = outlets.reduce((s, o) => s + outletSales[o], 0);
  const outletShare: Record<string, number> = {};
  outlets.forEach((o) => {
    outletShare[o] = grandSales > 0 ? outletSales[o] / grandSales : 1 / Math.max(1, outlets.length);
  });

  if (soldList.length === 0) warnings.push('Sold file not loaded — outlets share the stock equally.');
  if (outlets.length === 0) {
    warnings.push('No outlets found. Upload sold and/or stock breakdown files.');
    return { outlets, designs: [], rows: [], outletShare, warnings };
  }

  const designs: FestivalDesignMeta[] = [];
  const rows: FestivalRow[] = [];

  effectiveScheme.forEach((s) => {
    const file = stockFiles.find((f) => f.design.toUpperCase() === s.design.toUpperCase());
    const sold = soldForDesign(soldList, s.design);
    const carats: CaratKey[] = file ? [...file.carats] : [ALL_CARAT_KEY];
    if (!file) warnings.push(`${s.design}: no stock breakdown file — allocated at design level (no carat split).`);
    if (!sold && soldList.length > 0) {
      warnings.push(`${s.design}: no matching sold file — using equal share for this design.`);
    }

    // Per-design outlet totals from the matched sold file
    const designOutletSales: Record<string, number> = {};
    outlets.forEach((o) => {
      designOutletSales[o] = Object.values(sold?.sales[o] || {}).reduce((a, b) => a + b, 0);
    });
    const designGrand = outlets.reduce((sum, o) => sum + designOutletSales[o], 0);
    const designShare: Record<string, number> = {};
    outlets.forEach((o) => {
      designShare[o] =
        designGrand > 0 ? designOutletSales[o] / designGrand : outletShare[o];
    });

    // ---- split the design's festival stock across carats (existing carat mix) ----
    const have = (outlet: string, carat: CaratKey) => (file ? file.stock[outlet]?.[carat] || 0 : 0);
    let mixWeights = carats.map((c) => outlets.reduce((sum, o) => sum + have(o, c), 0));
    if (mixWeights.every((w) => w === 0)) {
      mixWeights = carats.map((c) => outlets.reduce((sum, o) => sum + (sold?.sales[o]?.[c] || 0), 0));
    }
    if (mixWeights.every((w) => w === 0)) mixWeights = carats.map(() => 1);
    const mixTotal = mixWeights.reduce((a, b) => a + b, 0);
    const caratPcs = roundToTotal(
      mixWeights.map((w) => (s.stock * w) / mixTotal),
      s.stock,
      mixWeights,
    );
    const caratStock: Record<CaratKey, number> = {};
    carats.forEach((c, i) => (caratStock[c] = caratPcs[i]));
    designs.push({ design: s.design, stock: s.stock, carats, caratStock, hasStockFile: !!file, scheme: s });

    // ---- Coverage at DESIGN level (so carat split cannot leave outlets uncovered) ----
    const designHaves = outlets.map((o) => carats.reduce((sum, c) => sum + have(o, c), 0));
    const designSalesArr = outlets.map((o) => designOutletSales[o]);
    const designSharesArr = outlets.map((o) => designShare[o]);
    const designPool = designHaves.reduce((a, b) => a + b, 0) + s.stock;
    const coverageTargets = buildTargets(
      outlets.map((_, i) => ({ stock: designHaves[i], sales: designSalesArr[i], share: designSharesArr[i] })),
      designPool,
      months,
      'coverage',
    );
    const coverageGiven = allocateCoverageStock(designHaves, designSharesArr, designSalesArr, s.stock);
    // Split each outlet's coverage pcs across carats by that outlet's existing carat mix (or sales mix / equal)
    const coverageByCarat: Record<string, number[]> = {};
    carats.forEach((c) => (coverageByCarat[c] = outlets.map(() => 0)));
    outlets.forEach((_, oi) => {
      const total = coverageGiven[oi];
      if (total <= 0) return;
      let weights = carats.map((c) => have(outlets[oi], c));
      if (weights.every((w) => w === 0)) {
        weights = carats.map((c) => (c === ALL_CARAT_KEY ? designOutletSales[outlets[oi]] : sold?.sales[outlets[oi]]?.[c] || 0));
      }
      if (weights.every((w) => w === 0)) weights = carats.map(() => 1);
      const wSum = weights.reduce((a, b) => a + b, 0);
      const split = roundToTotal(
        weights.map((w) => (total * w) / wSum),
        total,
        weights,
      );
      carats.forEach((c, ci) => {
        coverageByCarat[c][oi] = split[ci];
      });
    });

    // ---- per carat allocation ----
    carats.forEach((carat) => {
      const festival = caratStock[carat];
      const haves = outlets.map((o) => have(o, carat));
      const sales = outlets.map((o) =>
        carat === ALL_CARAT_KEY ? designOutletSales[o] : sold?.sales[o]?.[carat] || 0,
      );
      const caratSalesTotal = sales.reduce((a, b) => a + b, 0);
      const shares = outlets.map((o, i) =>
        caratSalesTotal > 0 ? sales[i] / caratSalesTotal : designShare[o],
      );
      const pool = haves.reduce((a, b) => a + b, 0) + festival;

      const cells = outlets.map((o, i) => ({
        have: haves[i],
        sales: sales[i],
        share: shares[i],
        target: emptyByLogic(),
        pcs: emptyByLogic(),
        overstock: emptyByLogic(),
      }));

      const isFirstCarat = carat === carats[0];
      LOGICS.forEach((logic) => {
        if (logic === 'coverage') {
          // Design-level coverage already computed; use per-carat slice.
          // Overstock is design-level — record it only on the first carat row to avoid double-count.
          cells.forEach((cell, i) => {
            cell.target[logic] = isFirstCarat ? coverageTargets[i] : 0;
            cell.pcs[logic] = coverageByCarat[carat][i];
            cell.overstock[logic] = isFirstCarat
              ? Math.max(0, designHaves[i] - coverageTargets[i])
              : 0;
          });
          return;
        }
        const targets = buildTargets(
          outlets.map((_, i) => ({ stock: haves[i], sales: sales[i], share: shares[i] })),
          pool,
          months,
          logic,
        );
        const need = targets.map((t, i) => Math.max(0, t - haves[i]));
        const given = allocateFestivalStock(need, shares, sales, festival);
        cells.forEach((cell, i) => {
          cell.target[logic] = targets[i];
          cell.pcs[logic] = given[i];
          cell.overstock[logic] = Math.max(0, haves[i] - targets[i]);
        });
      });

      outlets.forEach((o, i) => rows.push({ design: s.design, carat, outlet: o, ...cells[i] }));
    });
  });

  return { outlets, designs, rows, outletShare, warnings };
}

/** Fast lookup helpers for the report tables. */
export interface FestivalIndex {
  pcs: (logic: FestivalLogic, outlet: string, design: string, carat?: CaratKey) => number;
  have: (outlet: string, design: string, carat?: CaratKey) => number;
  /** Sum of target across carats for design (Coverage stores design-level target only on first carat). */
  target: (logic: FestivalLogic, outlet: string, design: string, carat?: CaratKey) => number;
  overstock: (logic: FestivalLogic, outlet: string) => number;
}

export function indexFestivalResult(result: FestivalResult): FestivalIndex {
  const byKey = new Map<string, FestivalRow>();
  const byDesign = new Map<string, FestivalRow[]>();
  const byOutlet = new Map<string, FestivalRow[]>();
  result.rows.forEach((r) => {
    byKey.set(`${r.outlet}|${r.design}|${r.carat}`, r);
    const dk = `${r.outlet}|${r.design}`;
    byDesign.set(dk, [...(byDesign.get(dk) || []), r]);
    byOutlet.set(r.outlet, [...(byOutlet.get(r.outlet) || []), r]);
  });
  return {
    pcs: (logic, outlet, design, carat) =>
      carat
        ? byKey.get(`${outlet}|${design}|${carat}`)?.pcs[logic] || 0
        : (byDesign.get(`${outlet}|${design}`) || []).reduce((s, r) => s + r.pcs[logic], 0),
    have: (outlet, design, carat) =>
      carat
        ? byKey.get(`${outlet}|${design}|${carat}`)?.have || 0
        : (byDesign.get(`${outlet}|${design}`) || []).reduce((s, r) => s + r.have, 0),
    target: (logic, outlet, design, carat) =>
      carat
        ? byKey.get(`${outlet}|${design}|${carat}`)?.target[logic] || 0
        : (byDesign.get(`${outlet}|${design}`) || []).reduce((s, r) => s + r.target[logic], 0),
    overstock: (logic, outlet) =>
      (byOutlet.get(outlet) || []).reduce((s, r) => s + r.overstock[logic], 0),
  };
}

export const caratLabel = (key: CaratKey): string => (key === ALL_CARAT_KEY ? 'All' : key);
