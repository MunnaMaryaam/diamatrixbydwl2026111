/**
 * Demand Forecast Engine
 *
 * Produces natural-language, category-level demand alerts from the working
 * inventory dataset. Designed to recompute instantly whenever the parent
 * passes a new `records` array (e.g. after DailyDualFileUploadModal →
 * universalParser → onImportRecords → setRawRecords).
 */

import type { RawInventoryRecord, SpecialMonth } from '../types';

export interface DemandForecastResult {
  category: string;
  alertLevel: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'INFO';
  alert: string;
  predictedIncreasePercentage: number;
  predictedMonthlyDemand: number;
  confidence: number;
  eventName?: string;
  upcomingMonth: string;
}

interface CategoryAgg {
  category: string;
  totalStock: number;
  totalSold: number;
  sales3M: number;
  sales6M: number;
  sales1Y: number;
  lineCount: number;
  avgAgeDays: number;
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

function nextMonthLabel(from = new Date()): string {
  const d = new Date(from.getFullYear(), from.getMonth() + 1, 1);
  return `${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}`;
}

function isUsable(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? n : 0;
}

function aggregateByCategory(records: RawInventoryRecord[]): CategoryAgg[] {
  const map = new Map<string, CategoryAgg>();

  for (const r of records) {
    const cat =
      String(r.category || r.itemName || r.variant || r.weight || 'Uncategorized').trim() ||
      'Uncategorized';
    const existing = map.get(cat) || {
      category: cat,
      totalStock: 0,
      totalSold: 0,
      sales3M: 0,
      sales6M: 0,
      sales1Y: 0,
      lineCount: 0,
      avgAgeDays: 0,
    };

    existing.totalStock += isUsable(r.currentStock);
    existing.totalSold += isUsable(r.soldQty);
    existing.sales3M += isUsable(r.sales3M ?? r.soldQty);
    existing.sales6M += isUsable(r.sales6M ?? (r.soldQty ? r.soldQty * 1.8 : 0));
    existing.sales1Y += isUsable(r.sales1Y ?? (r.soldQty ? r.soldQty * 3.2 : 0));
    existing.avgAgeDays += isUsable(r.ageDays);
    existing.lineCount += 1;
    map.set(cat, existing);
  }

  return Array.from(map.values()).map((a) => ({
    ...a,
    avgAgeDays: a.lineCount > 0 ? a.avgAgeDays / a.lineCount : 0,
  }));
}

function matchSpecialMonth(
  specialMonths: SpecialMonth[],
  upcomingMonth: string,
): SpecialMonth | undefined {
  if (!specialMonths?.length) return undefined;
  const target = upcomingMonth.toLowerCase();
  return specialMonths.find((sm) => {
    const label = (sm.monthLabel || '').toLowerCase();
    return (
      label.includes(target) ||
      target.includes(label) ||
      MONTH_NAMES.some(
        (m) =>
          label.includes(m.toLowerCase()) &&
          target.includes(m.toLowerCase()),
      )
    );
  });
}

function buildAlert(
  agg: CategoryAgg,
  predictedMonthly: number,
  increasePct: number,
  coverMonths: number,
  special?: SpecialMonth,
): { level: DemandForecastResult['alertLevel']; text: string } {
  const cat = agg.category;

  if (special && increasePct > 15) {
    return {
      level: increasePct >= 40 || coverMonths < 0.6 ? 'CRITICAL' : 'HIGH',
      text: `Upcoming ${special.eventName || special.monthLabel} is expected to lift demand for ${cat} by ~${Math.round(increasePct)}%. Current cover is only ${coverMonths.toFixed(1)} months — consider pre-positioning stock.`,
    };
  }

  if (coverMonths < 0.5 && predictedMonthly > 2) {
    return {
      level: 'CRITICAL',
      text: `${cat} is projected to stock-out within ~${Math.max(7, Math.round(coverMonths * 30))} days at the forecasted run-rate of ${Math.round(predictedMonthly)} units/month. Urgent replenishment recommended.`,
    };
  }

  if (coverMonths < 1.2 && predictedMonthly > 1) {
    return {
      level: 'HIGH',
      text: `${cat} cover is thin (${coverMonths.toFixed(1)} months). Forecast demand ${Math.round(predictedMonthly)} units next month — review transfer or purchase options.`,
    };
  }

  if (increasePct >= 25) {
    return {
      level: 'MEDIUM',
      text: `${cat} shows rising demand trajectory (+${Math.round(increasePct)}% vs recent baseline). Monitor allocation and avoid overselling fast movers.`,
    };
  }

  if (agg.avgAgeDays > 150 && agg.totalStock > 0 && predictedMonthly < 1) {
    return {
      level: 'MEDIUM',
      text: `${cat} has aging inventory (avg ${Math.round(agg.avgAgeDays)} days) with soft forward demand. Consider redistribution or promotional push.`,
    };
  }

  return {
    level: 'INFO',
    text: `${cat} demand looks stable. Forecast ~${Math.round(predictedMonthly)} units next month with comfortable cover.`,
  };
}

/**
 * Main entry point used by AIIntelligencePanel.
 * Re-runs automatically when the parent `records` reference changes after upload.
 */
export function forecastTopCategories(
  records: RawInventoryRecord[],
  specialMonths: SpecialMonth[] = [],
  options: { maxCategories?: number } = {},
): DemandForecastResult[] {
  if (!records?.length) return [];

  const maxCategories = options.maxCategories ?? 12;
  const upcomingMonth = nextMonthLabel();
  const special = matchSpecialMonth(specialMonths, upcomingMonth);
  const specialBoost = special ? 1.35 : 1.0;

  const aggs = aggregateByCategory(records)
    .filter((a) => a.lineCount > 0)
    .sort((a, b) => b.sales3M + b.totalStock - (a.sales3M + a.totalStock));

  const results: DemandForecastResult[] = [];

  for (const agg of aggs.slice(0, maxCategories)) {
    // Baseline monthly demand from 3M run-rate (prefer longer history when present)
    const monthlyFrom3M = agg.sales3M / 3;
    const monthlyFrom6M = agg.sales6M / 6;
    const monthlyFrom1Y = agg.sales1Y / 12;
    const baseline =
      monthlyFrom3M > 0
        ? monthlyFrom3M * 0.55 + monthlyFrom6M * 0.3 + monthlyFrom1Y * 0.15
        : monthlyFrom6M > 0
          ? monthlyFrom6M * 0.7 + monthlyFrom1Y * 0.3
          : Math.max(agg.totalSold * 0.4, 0.5);

    const predictedMonthlyDemand = Math.max(0, baseline * specialBoost);
    const priorMonthly = Math.max(monthlyFrom3M || monthlyFrom6M || 0.1, 0.1);
    const predictedIncreasePercentage =
      ((predictedMonthlyDemand - priorMonthly) / priorMonthly) * 100;

    const coverMonths =
      predictedMonthlyDemand > 0 ? agg.totalStock / predictedMonthlyDemand : 99;

    // Confidence: more lines + longer history → higher confidence
    let confidence = 55;
    if (agg.lineCount >= 5) confidence += 10;
    if (agg.lineCount >= 15) confidence += 8;
    if (agg.sales6M > 0) confidence += 8;
    if (agg.sales1Y > 0) confidence += 7;
    if (special) confidence += 5;
    confidence = Math.min(96, Math.round(confidence));

    const { level, text } = buildAlert(
      agg,
      predictedMonthlyDemand,
      predictedIncreasePercentage,
      coverMonths,
      special,
    );

    results.push({
      category: agg.category,
      alertLevel: level,
      alert: text,
      predictedIncreasePercentage,
      predictedMonthlyDemand: Math.round(predictedMonthlyDemand * 10) / 10,
      confidence,
      eventName: special?.eventName,
      upcomingMonth,
    });
  }

  // Prefer actionable alerts first
  const rank = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, INFO: 1 } as const;
  return results.sort(
    (a, b) =>
      rank[b.alertLevel] - rank[a.alertLevel] ||
      Math.abs(b.predictedIncreasePercentage) - Math.abs(a.predictedIncreasePercentage),
  );
}

export default forecastTopCategories;
