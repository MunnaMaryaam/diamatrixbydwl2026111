import { AuthUser } from '../types';
import {
  getOfflineAuthSeal,
  setOfflineAuthSeal,
  clearOfflineAuthSeal,
  type OfflineCapabilityGrant,
} from './dailyStorageEngine';
import { isCloudConfigured, isNetworkError } from './supabaseClient';
import {
  cloudLogin,
  cloudRestore,
  cloudLogout,
  cloudSignup,
  cloudListUsers,
  cloudSetStatus,
  cloudDeleteUser,
  cloudUpdateOwnProfile,
  cloudChangeOwnPassword,
  cloudVerifyMfa,
  cloudConfirmTotpEnroll,
} from './cloudAuth';
import { loginIdentifierToEmail, getSupabase } from './supabaseClient';

const SESSION_SNAPSHOT_KEY = 'dwl_secure_session_snapshot';

/**
 * Offline demo accounts (built-in passwords) are for local development only.
 * They are OFF in production builds unless VITE_ALLOW_OFFLINE_LOGIN=true is set on purpose.
 */
const OFFLINE_LOGIN_ALLOWED: boolean = (() => {
  try {
    return (
      Boolean(import.meta.env.DEV) ||
      String(import.meta.env.VITE_ALLOW_OFFLINE_LOGIN || '').toLowerCase() === 'true'
    );
  } catch {
    return false;
  }
})();

/** HTTP statuses where the server answered and said "no": never fall back to offline login on these. */
const SERVER_REJECTED = new Set([400, 401, 403, 429]);

/** Application salt for local credential digests (not a server secret). */
const LOCAL_CRED_SALT = 'diamatrix-lumina-offline-rbac-v1';

/**
 * Offline owner accounts — ONLY pre-computed SHA-256 digests of
 * `${LOCAL_CRED_SALT}:${username}:${password}` are stored here.
 * Plaintext passwords are NEVER kept in source code.
 *
 * To add/rotate a local account: compute
 *   SHA-256("diamatrix-lumina-offline-rbac-v1:<username>:<password>")
 * and add the hex digest below. Digests only work when OFFLINE_LOGIN_ALLOWED is true
 * (DEV or explicit VITE_ALLOW_OFFLINE_LOGIN=true).
 */
const OWNER_USER_BASE: AuthUser = {
  id: 'owner-admin-1',
  username: 'admin',
  name: 'MD Shahadat Hossen',
  designation: 'System Owner & Master Administrator',
  role: 'admin',
  status: 'approved',
  isOwner: true,
  canEdit: true,
  canUpload: true,
  canExport: true,
  createdAt: '2026-09-21',
};

/** username → accepted credential digests (no plaintext passwords in source). */
const LOCAL_CREDENTIAL_DIGESTS: Record<string, { digests: string[]; user: AuthUser }> = {
  admin: {
    digests: [
      // offline DEV only — digests of known local passwords (plaintext not stored)
      'b4abd27126c9aedeee812d0813336c795da7c950b51ff84408ebcfe37ea4c89e', // 000000
      'b3ddd4858c6490d1188dcc6f9b859b3d20474e950fd24344fcb9936a532a5d2b', // 0000
      '8c8d759472bea25d70287087a4c47f9af0a094adcfecf1345b2022fae13f2ffa', // admin
    ],
    user: { ...OWNER_USER_BASE, username: 'admin' },
  },
  shahadat: {
    digests: [
      'c4619aaa2e69b6b6f70011d293b7aeaa66f2ca48873b0fca11dd59116a4c5e28', // 000000
      '25cc38bdcaf008123d6b91983a1bb18885f921b8c54f9b94236b8b47af8927e1', // 0000
    ],
    user: { ...OWNER_USER_BASE, username: 'shahadat' },
  },
};

async function sha256Hex(message: string): Promise<string> {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const data = new TextEncoder().encode(message);
    const buf = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(buf))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  // No weak fallback — offline auth requires Web Crypto (all modern browsers).
  throw new Error('Web Crypto API unavailable; offline credential check not possible.');
}

/**
 * Offline credential validator — compares salted digest only.
 * Never stores or compares plaintext passwords in source.
 */
export async function validateLocalCredentials(
  username: string,
  password: string,
): Promise<AuthUser | null> {
  if (!OFFLINE_LOGIN_ALLOWED) return null;
  const u = username.trim().toLowerCase();
  if (!u || !password) return null;
  const entry = LOCAL_CREDENTIAL_DIGESTS[u];
  if (!entry) return null;
  try {
    const material = `${LOCAL_CRED_SALT}:${u}:${password}`;
    const digest = await sha256Hex(material);
    if (!entry.digests.includes(digest)) return null;
    return { ...entry.user, username: entry.user.username || u };
  } catch {
    return null;
  }
}

/** Offline RBAC capability matrix for sealed sessions. */
export function capabilitiesForUser(user: AuthUser): OfflineCapabilityGrant {
  const role = (user.role || 'viewer').toLowerCase();
  const isAdmin = role === 'admin' || Boolean(user.isOwner);
  return {
    userId: user.id,
    username: user.username,
    role: user.role,
    grantedAt: Date.now(),
    canViewAnalytics: true,
    canEdit: Boolean(user.canEdit) || isAdmin,
    canUpload: Boolean(user.canUpload) || isAdmin,
    canExport: Boolean(user.canExport) || isAdmin,
    offlineFeatures: [
      'inventory_matrix',
      'have_vs_deserve',
      'movement_aging',
      'local_snapshots',
      'excel_pdf_export',
    ],
  };
}

const SESSION_TOKEN_KEY = 'dwl_session_token';

export function getSessionToken(): string | null {
  try {
    return sessionStorage.getItem(SESSION_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setSessionToken(token: string | null): void {
  try {
    if (!token) sessionStorage.removeItem(SESSION_TOKEN_KEY);
    else sessionStorage.setItem(SESSION_TOKEN_KEY, token);
  } catch {
    /* ignore */
  }
}

async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  let response: Response;
  const bearer = getSessionToken();
  try {
    response = await fetch(url, {
      ...options,
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        ...(bearer ? { Authorization: `Bearer ${bearer}` } : {}),
        ...(options.headers || {}),
      },
    });
  } catch {
    throw new Error('Could not reach the server. Check your internet connection and try again.');
  }

  const rawText = await response.text();
  let payload: any = {};
  try {
    payload = rawText ? JSON.parse(rawText) : {};
  } catch {
    payload = {};
  }

  if (!response.ok) {
    const msg =
      payload?.error?.message ||
      payload?.error ||
      `Server responded with an unexpected error (HTTP ${response.status}). Please verify the deployment is up to date.`;
    const err: Error & { status?: number } = new Error(typeof msg === 'string' ? msg : 'Request failed');
    err.status = response.status;
    throw err;
  }
  // Support both raw and { ok, data } envelopes
  if (payload && typeof payload === 'object' && 'data' in payload && payload.ok === true) {
    return payload.data as T;
  }
  return payload as T;
}

export function getCurrentSession(): AuthUser | null {
  try {
    const raw = sessionStorage.getItem(SESSION_SNAPSHOT_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setCurrentSession(user: AuthUser | null): void {
  try {
    if (!user) {
      sessionStorage.removeItem(SESSION_SNAPSHOT_KEY);
      clearOfflineAuthSeal();
    } else {
      sessionStorage.setItem(SESSION_SNAPSHOT_KEY, JSON.stringify(user));
      setOfflineAuthSeal(capabilitiesForUser(user));
    }
  } catch {
    /* session snapshot is a UI convenience */
  }
}

/** @deprecated — use validateLocalCredentials (async digest check). Sync plaintext path removed. */
function localLogin(_username: string, _password: string): AuthUser | null {
  return null;
}

export async function restoreSession(): Promise<AuthUser | null> {
  if (isCloudConfigured()) {
    try {
      const user = await cloudRestore();
      if (user) {
        setCurrentSession(user);
        return user;
      }
      // Signed out of the cloud: any cached session snapshot is stale.
      setCurrentSession(null);
      return null;
    } catch (err) {
      if (!isNetworkError(err)) return null;
      // Cloud unreachable: keep working from the cached session if there is one.
      return getCurrentSession();
    }
  }
  const cached = getCurrentSession();
  if (cached) return cached;
  try {
    const result = await request<{ authenticated: boolean; user?: AuthUser }>('/api/auth/me');
    if (!result.authenticated || !result.user) {
      return null;
    }
    setCurrentSession(result.user);
    return result.user;
  } catch {
    const seal = getOfflineAuthSeal();
    if (seal?.username) {
      const snap = getCurrentSession();
      if (snap) return snap;
    }
    return getCurrentSession();
  }
}

export type MfaMethod = 'totp' | 'email' | 'sms';

export type AuthResult =
  | { success: true; user: AuthUser; offline?: boolean }
  | {
      success: false;
      mfaRequired: true;
      /** Opaque token for Express MFA, or 'supabase' marker */
      mfaToken: string;
      methods: MfaMethod[];
      emailHint?: string;
      phoneHint?: string;
      message?: string;
      /** Supabase TOTP challenge ids */
      factorId?: string;
      challengeId?: string;
    }
  | {
      success: false;
      mfaEnrollRequired: true;
      factorId: string;
      secret: string;
      uri: string;
      message?: string;
    }
  | { success: false; error: string; offline?: boolean };

export async function authenticateUser(
  username: string,
  password: string,
  turnstileToken?: string,
): Promise<AuthResult> {
  if (isCloudConfigured()) {
    try {
      const res = await cloudLogin(username, password);
      if (res.user) {
        setCurrentSession(res.user);
        return { success: true, user: res.user, offline: false };
      }
      if ('mfaRequired' in res && res.mfaRequired) {
        return {
          success: false,
          mfaRequired: true,
          mfaToken: 'supabase',
          methods: res.methods || ['totp'],
          factorId: res.factorId,
          challengeId: res.challengeId,
          message: res.message,
        };
      }
      if ('mfaEnrollRequired' in res && res.mfaEnrollRequired) {
        return {
          success: false,
          mfaEnrollRequired: true,
          factorId: res.factorId,
          secret: res.secret,
          uri: res.uri,
          message: res.message,
        };
      }
      return { success: false, error: ('error' in res && res.error) || 'Invalid username or password.' };
    } catch (err: any) {
      if (!isNetworkError(err)) {
        return { success: false, error: err?.message || 'Sign-in failed.' };
      }
      // Cloud unreachable: fall through to offline path
    }
  }
  try {
    const result = await request<{
      mfaRequired?: boolean;
      mfaToken?: string;
      methods?: MfaMethod[];
      emailHint?: string;
      phoneHint?: string;
      message?: string;
      token?: string;
      user?: AuthUser;
    }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        username,
        password,
        'cf-turnstile-response': turnstileToken || undefined,
        turnstileToken: turnstileToken || undefined,
      }),
    });

    if (result.mfaRequired && result.mfaToken) {
      return {
        success: false,
        mfaRequired: true,
        mfaToken: result.mfaToken,
        methods: result.methods || ['totp'],
        emailHint: result.emailHint,
        phoneHint: result.phoneHint,
        message: result.message,
      };
    }

    if (result.user && result.token) {
      setSessionToken(result.token);
      setCurrentSession(result.user);
      return { success: true, user: result.user, offline: false };
    }
    if (result.user) {
      setCurrentSession(result.user);
      return { success: true, user: result.user, offline: false };
    }
    return { success: false, error: 'Unexpected login response.' };
  } catch (loginError: any) {
    if (SERVER_REJECTED.has(Number(loginError?.status))) {
      return { success: false, error: loginError?.message || 'Invalid username or password.' };
    }
    const local = await validateLocalCredentials(username, password);
    if (local) {
      setCurrentSession(local);
      return { success: true, user: local, offline: true };
    }
    const fallback = localLogin(username, password);
    if (fallback) {
      setCurrentSession(fallback);
      return { success: true, user: fallback, offline: true };
    }
    return {
      success: false,
      error: loginError?.message || 'Invalid credentials for online or offline access.',
    };
  }
}

/** Resend email/SMS OTP during MFA step. */
export async function sendMfaCode(
  mfaToken: string,
  method: 'email' | 'sms',
): Promise<{ success: boolean; error?: string; hint?: string }> {
  try {
    const result = await request<{ sent: boolean; hint?: string }>('/api/auth/login/mfa/send', {
      method: 'POST',
      body: JSON.stringify({ mfaToken, method }),
    });
    return { success: true, hint: result.hint };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Could not send code.' };
  }
}

/** Finish first-time Google Authenticator enrollment after password login. */
export async function confirmMfaEnroll(
  factorId: string,
  code: string,
): Promise<{ success: boolean; user?: AuthUser; error?: string }> {
  try {
    const conf = await cloudConfirmTotpEnroll(factorId, code);
    if (!conf.success) return { success: false, error: conf.error || 'Invalid code.' };
    const user = await cloudRestore();
    if (user) {
      setCurrentSession(user);
      return { success: true, user };
    }
    return {
      success: false,
      error: 'Authenticator saved. Please sign in again and enter the new 6-digit code.',
    };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Could not confirm authenticator.' };
  }
}

/** Complete MFA with TOTP / email / SMS code (Supabase or Express backend). */
export async function verifyMfaCode(
  mfaToken: string,
  code: string,
  method?: MfaMethod,
  supabaseIds?: { factorId?: string; challengeId?: string },
): Promise<{ success: boolean; user?: AuthUser; error?: string }> {
  // Supabase TOTP path
  if (mfaToken === 'supabase' && supabaseIds?.factorId && supabaseIds?.challengeId) {
    try {
      const res = await cloudVerifyMfa(supabaseIds.factorId, supabaseIds.challengeId, code);
      if (res.user) {
        setCurrentSession(res.user);
        return { success: true, user: res.user };
      }
      return { success: false, error: res.error || 'Invalid verification code.' };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Invalid verification code.' };
    }
  }

  try {
    const result = await request<{ token: string; user: AuthUser }>('/api/auth/login/mfa/verify', {
      method: 'POST',
      body: JSON.stringify({ mfaToken, code, method }),
    });
    if (result.token) setSessionToken(result.token);
    if (result.user) {
      setCurrentSession(result.user);
      return { success: true, user: result.user };
    }
    return { success: false, error: 'MFA verification failed.' };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Invalid verification code.' };
  }
}

/**
 * Explicit offline-only sign-in (skips network). Used when UI is in local fallback mode.
 */
export async function authenticateOffline(
  username: string,
  password: string,
): Promise<{ success: boolean; user?: AuthUser; error?: string }> {
  const local = await validateLocalCredentials(username, password);
  if (local) {
    setCurrentSession(local);
    return { success: true, user: local };
  }
  const fallback = localLogin(username, password);
  if (fallback) {
    setCurrentSession(fallback);
    return { success: true, user: fallback };
  }
  return { success: false, error: 'Offline credentials rejected. Check username and password.' };
}

export async function logoutCurrentSession(): Promise<void> {
  try {
    if (isCloudConfigured()) {
      await cloudLogout();
      return;
    }
    await request('/api/auth/logout', { method: 'POST' });
  } catch {
    /* offline — still clear client session */
  } finally {
    setSessionToken(null);
    setCurrentSession(null);
  }
}

export async function requestSignup(data: {
  username: string;
  name: string;
  password: string;
}): Promise<{ success: boolean; message?: string; error?: string }> {
  if (isCloudConfigured()) {
    try {
      const res = await cloudSignup(data);
      return { success: true, message: res.message };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Could not submit account request.' };
    }
  }
  try {
    const result = await request<{ pending: boolean; message: string }>('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return { success: true, message: result.message };
  } catch (error: any) {
    try {
      enqueueLocalSignupRequest(data);
      return {
        success: true,
        message: 'Account request saved locally. An owner can approve it from User Management when online or offline.',
      };
    } catch (localErr: any) {
      return {
        success: false,
        error: localErr?.message || error.message || 'Could not submit account request.',
      };
    }
  }
}

export async function requestPasswordRecovery(
  username: string,
): Promise<{ success: boolean; message?: string; error?: string }> {
  if (isCloudConfigured()) {
    const sb = getSupabase();
    if (!sb) return { success: false, error: 'Cloud is not configured.' };
    if (!username.includes('@')) {
      return {
        success: false,
        error: 'Password reset by email only works for accounts that use an email address. Ask the owner to reset your password in Supabase.',
      };
    }
    const { error } = await sb.auth.resetPasswordForEmail(loginIdentifierToEmail(username));
    if (error) return { success: false, error: error.message };
    return { success: true, message: 'If that email has an account, a reset link has been sent.' };
  }
  try {
    const result = await request<{ message: string }>('/api/auth/recover', {
      method: 'POST',
      body: JSON.stringify({ username }),
    });
    return { success: true, message: result.message };
  } catch (error: any) {
    return {
      success: false,
      error: error.message || 'Recovery requires a live server connection.',
    };
  }
}

/**
 * React-friendly auth snapshot helper (usable as a lightweight hook body).
 */
export function getAuthSessionSnapshot(): {
  user: AuthUser | null;
  offlineSeal: OfflineCapabilityGrant | null;
  hasOfflineRbac: boolean;
} {
  const user = getCurrentSession();
  const offlineSeal = getOfflineAuthSeal();
  return {
    user,
    offlineSeal,
    hasOfflineRbac: Boolean(offlineSeal && offlineSeal.canViewAnalytics),
  };
}

/* -------------------------------------------------------------------------- */
/* Local managed-user store (owner approval / recovery when API is offline)  */
/* -------------------------------------------------------------------------- */

const MANAGED_USERS_KEY = 'diamatrix_managed_users_v1';

function readManagedUsers(): AuthUser[] {
  try {
    const raw = localStorage.getItem(MANAGED_USERS_KEY);
    if (!raw) return seedManagedUsers();
    const list = JSON.parse(raw) as AuthUser[];
    return Array.isArray(list) ? list : seedManagedUsers();
  } catch {
    return seedManagedUsers();
  }
}

function writeManagedUsers(users: AuthUser[]): void {
  try {
    localStorage.setItem(MANAGED_USERS_KEY, JSON.stringify(users));
  } catch {
    /* ignore */
  }
}

function seedManagedUsers(): AuthUser[] {
  const owner: AuthUser = {
    id: 'owner-admin-1',
    username: 'admin',
    name: 'MD Shahadat Hossen',
    designation: 'System Owner & Master Administrator',
    role: 'admin',
    status: 'approved',
    isOwner: true,
    canEdit: true,
    canUpload: true,
    canExport: true,
    createdAt: '2026-09-21',
  };
  writeManagedUsers([owner]);
  return [owner];
}

function findManaged(id: string): { users: AuthUser[]; index: number; user: AuthUser | null } {
  const users = readManagedUsers();
  const index = users.findIndex((u) => u.id === id);
  return { users, index, user: index >= 0 ? users[index] : null };
}

export async function getManagedUsers(): Promise<AuthUser[]> {
  if (isCloudConfigured()) {
    try {
      return await cloudListUsers();
    } catch {
      return [];
    }
  }
  try {
    const result = await request<{ users: AuthUser[] }>('/api/auth/users');
    if (Array.isArray(result.users)) {
      writeManagedUsers(result.users);
      return result.users;
    }
  } catch {
    /* offline — local store */
  }
  return readManagedUsers();
}

export async function approveUser(userId: string): Promise<AuthUser> {
  if (isCloudConfigured()) return cloudSetStatus(userId, 'approved');
  try {
    const result = await request<{ user: AuthUser }>(`/api/auth/users/${encodeURIComponent(userId)}/approve`, {
      method: 'POST',
    });
    if (result.user) {
      const { users, index } = findManaged(userId);
      if (index >= 0) {
        users[index] = { ...users[index], ...result.user, status: 'approved' };
        writeManagedUsers(users);
      }
      return result.user;
    }
  } catch {
    /* local path */
  }
  const { users, index, user } = findManaged(userId);
  if (!user) throw new Error('User not found.');
  if (user.isOwner) throw new Error('Owner account cannot be modified this way.');
  const updated: AuthUser = {
    ...user,
    status: 'approved',
    canEdit: true,
    canUpload: true,
    canExport: true,
  };
  users[index] = updated;
  writeManagedUsers(users);
  return updated;
}

export async function rejectUser(userId: string): Promise<AuthUser> {
  if (isCloudConfigured()) return cloudSetStatus(userId, 'rejected');
  try {
    const result = await request<{ user: AuthUser }>(`/api/auth/users/${encodeURIComponent(userId)}/reject`, {
      method: 'POST',
    });
    if (result.user) {
      const { users, index } = findManaged(userId);
      if (index >= 0) {
        users[index] = { ...users[index], ...result.user, status: 'rejected' };
        writeManagedUsers(users);
      }
      return result.user;
    }
  } catch {
    /* local path */
  }
  const { users, index, user } = findManaged(userId);
  if (!user) throw new Error('User not found.');
  if (user.isOwner) throw new Error('Owner account cannot be rejected.');
  const updated: AuthUser = { ...user, status: 'rejected' };
  users[index] = updated;
  writeManagedUsers(users);
  return updated;
}

export async function resetManagedUserPassword(
  userId: string,
  newPassword: string,
): Promise<void> {
  if (!newPassword || newPassword.trim().length < 8) {
    throw new Error('Password must be at least 8 characters.');
  }
  if (isCloudConfigured()) {
    throw new Error(
      'Passwords of cloud accounts are reset in the Supabase dashboard (Authentication > Users), or the user can use "Forgot password" if they signed up with an email.',
    );
  }
  try {
    await request(`/api/auth/users/${encodeURIComponent(userId)}/password`, {
      method: 'POST',
      body: JSON.stringify({ password: newPassword.trim() }),
    });
  } catch {
    /* persist locally so offline recovery still works */
  }
  const { users, index, user } = findManaged(userId);
  if (!user) throw new Error('User not found.');
  users[index] = {
    ...user,
    password: newPassword.trim(),
    resetRequestedAt: undefined,
  };
  writeManagedUsers(users);
}

export async function deleteManagedUser(userId: string): Promise<void> {
  if (isCloudConfigured()) return cloudDeleteUser(userId);
  try {
    await request(`/api/auth/users/${encodeURIComponent(userId)}`, { method: 'DELETE' });
  } catch {
    /* local path */
  }
  const { users, user } = findManaged(userId);
  if (!user) throw new Error('User not found.');
  if (user.isOwner) throw new Error('Owner account cannot be deleted.');
  writeManagedUsers(users.filter((u) => u.id !== userId));
}

export function updateUserProfile(
  userId: string,
  patch: { name?: string; designation?: string },
): { success: boolean; user?: AuthUser; error?: string } {
  const session = getCurrentSession();
  const { users, index, user } = findManaged(userId);
  const target = user || (session && session.id === userId ? session : null);
  if (!target) return { success: false, error: 'User not found.' };

  const updated: AuthUser = {
    ...target,
    name: patch.name != null ? String(patch.name).trim() || target.name : target.name,
    designation:
      patch.designation != null
        ? String(patch.designation).trim() || target.designation
        : target.designation,
  };

  if (index >= 0) {
    users[index] = updated;
    writeManagedUsers(users);
  } else {
    writeManagedUsers([...users.filter((u) => u.id !== updated.id), updated]);
  }

  if (session && session.id === userId) {
    setCurrentSession(updated);
  }
  return { success: true, user: updated };
}

export function changeUserPassword(
  userId: string,
  currentPassword: string,
  newPassword: string,
): { success: boolean; error?: string } {
  if (!newPassword || newPassword.trim().length < 8) {
    return { success: false, error: 'New password must be at least 8 characters.' };
  }
  const { users, index, user } = findManaged(userId);
  const session = getCurrentSession();
  const target = user || (session && session.id === userId ? session : null);
  if (!target) return { success: false, error: 'User not found.' };

  // Require stored password match only — no magic demo passwords accepted.
  const stored = target.password;
  if (!stored || stored !== currentPassword) {
    return { success: false, error: 'Current password is incorrect.' };
  }

  const updated = { ...target, password: newPassword.trim() };
  if (index >= 0) {
    users[index] = updated;
    writeManagedUsers(users);
  } else {
    writeManagedUsers([...users.filter((u) => u.id !== updated.id), updated]);
  }
  if (session && session.id === userId) {
    setCurrentSession({ ...session, password: undefined });
  }
  return { success: true };
}

/** Persist a pending signup into the local managed-user list (offline-friendly). */
export function enqueueLocalSignupRequest(data: {
  username: string;
  name: string;
  password: string;
}): AuthUser {
  const users = readManagedUsers();
  const username = data.username.trim().toLowerCase();
  if (users.some((u) => u.username.toLowerCase() === username)) {
    throw new Error('Username already exists.');
  }
  const pending: AuthUser = {
    id: `pending-${Date.now()}`,
    username,
    name: data.name.trim() || username,
    role: 'user',
    status: 'pending',
    password: data.password,
    canEdit: false,
    canUpload: false,
    canExport: false,
    isOwner: false,
    createdAt: new Date().toISOString().slice(0, 10),
  };
  writeManagedUsers([...users, pending]);
  return pending;
}

/** Profile update that also works against the cloud (the sync version above is used for local accounts). */
export async function updateUserProfileAsync(
  userId: string,
  patch: { name?: string; designation?: string },
): Promise<{ success: boolean; user?: AuthUser; error?: string }> {
  if (!isCloudConfigured()) return updateUserProfile(userId, patch);
  try {
    const session = getCurrentSession();
    const clean = {
      name: patch.name != null ? String(patch.name).trim() || undefined : undefined,
      designation: patch.designation != null ? String(patch.designation).trim() || undefined : undefined,
    };
    await cloudUpdateOwnProfile(userId, clean);
    if (session && session.id === userId) {
      const updated: AuthUser = { ...session, name: clean.name ?? session.name, designation: clean.designation ?? session.designation };
      setCurrentSession(updated);
      return { success: true, user: updated };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Could not update the profile.' };
  }
}

/** Password change that also works against the cloud: verifies the current password first. */
export async function changeUserPasswordAsync(
  userId: string,
  currentPassword: string,
  newPassword: string,
): Promise<{ success: boolean; error?: string }> {
  if (!isCloudConfigured()) return changeUserPassword(userId, currentPassword, newPassword);
  if (!newPassword || newPassword.trim().length < 8) {
    return { success: false, error: 'New password must be at least 8 characters.' };
  }
  try {
    const session = getCurrentSession();
    if (!session) return { success: false, error: 'Please sign in again.' };
    const check = await cloudLogin(session.username, currentPassword);
    if (!check.user) return { success: false, error: 'Current password is incorrect.' };
    await cloudChangeOwnPassword(newPassword.trim());
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Could not change the password.' };
  }
}
