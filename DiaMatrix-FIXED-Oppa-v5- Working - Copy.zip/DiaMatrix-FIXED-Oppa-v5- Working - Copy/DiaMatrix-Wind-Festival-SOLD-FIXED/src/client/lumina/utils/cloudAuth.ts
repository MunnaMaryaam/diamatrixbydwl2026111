/**
 * Supabase Auth + profiles, shaped like the app's existing AuthUser so the rest of the UI is unchanged.
 * Includes MFA (TOTP / Google Authenticator) when the user has enrolled a factor in Supabase.
 */
import type { AuthUser, UserRole } from '../types';
import { getSupabase, loginIdentifierToEmail } from './supabaseClient';

interface ProfileRow {
  id: string;
  username: string;
  name: string | null;
  designation: string | null;
  role: string;
  status: 'pending' | 'approved' | 'rejected';
  is_owner: boolean;
  can_edit: boolean;
  can_upload: boolean;
  can_export: boolean;
  created_at: string;
}

const PROFILE_COLUMNS =
  'id,username,name,designation,role,status,is_owner,can_edit,can_upload,can_export,created_at';

export function profileToAuthUser(p: ProfileRow): AuthUser {
  const role = (['admin', 'manager', 'analyst', 'user'].includes(p.role) ? p.role : 'user') as UserRole;
  return {
    id: p.id,
    username: p.username,
    name: p.name || p.username,
    designation: p.designation || undefined,
    role,
    status: p.status,
    isOwner: p.is_owner,
    canEdit: p.can_edit,
    canUpload: p.can_upload,
    canExport: p.can_export,
    createdAt: p.created_at?.slice(0, 10),
  };
}

function need() {
  const sb = getSupabase();
  if (!sb) throw new Error('Cloud is not configured.');
  return sb;
}

async function loadOwnProfile(userId: string): Promise<ProfileRow | null> {
  const { data, error } = await need().from('profiles').select(PROFILE_COLUMNS).eq('id', userId).maybeSingle();
  if (error) throw error;
  return (data as ProfileRow) ?? null;
}

async function assertApprovedProfile(userId: string): Promise<{ user?: AuthUser; error?: string }> {
  const profile = await loadOwnProfile(userId);
  if (!profile) {
    await need().auth.signOut();
    return { error: 'This account has no profile (it may have been removed). Contact the owner.' };
  }
  if (profile.status === 'pending') {
    await need().auth.signOut();
    return { error: 'Your account is waiting for approval by the owner.' };
  }
  if (profile.status === 'rejected') {
    await need().auth.signOut();
    return { error: 'Your account request was rejected. Contact the owner.' };
  }
  return { user: profileToAuthUser(profile) };
}

export type CloudLoginResult =
  | { user: AuthUser; error?: undefined; mfaRequired?: false }
  | { error: string; user?: undefined; mfaRequired?: false }
  | {
      mfaRequired: true;
      factorId: string;
      challengeId: string;
      methods: Array<'totp'>;
      message: string;
      user?: undefined;
      error?: undefined;
    }
  | {
      /** Owner/admin must enroll Google Authenticator before full access */
      mfaEnrollRequired: true;
      factorId: string;
      secret: string;
      uri: string;
      message: string;
      user?: undefined;
      error?: undefined;
    };

/** Owner / admin accounts always require MFA (enroll if missing, then challenge). */
function mustUseMfa(profile: ProfileRow): boolean {
  return Boolean(profile.is_owner) || profile.role === 'admin' || profile.role === 'owner';
}

/**
 * Password login.
 * - If a verified TOTP factor exists → always require 6-digit code (never skip).
 * - If owner/admin has no TOTP yet → force enrollment (QR / secret) before access.
 */
export async function cloudLogin(identifier: string, password: string): Promise<CloudLoginResult> {
  const sb = need();
  const { data, error } = await sb.auth.signInWithPassword({
    email: loginIdentifierToEmail(identifier),
    password,
  });
  if (error) {
    if (/invalid login credentials/i.test(error.message)) return { error: 'Invalid username or password.' };
    if (/email not confirmed/i.test(error.message)) {
      return {
        error:
          'This account needs email confirmation. Ask the owner to turn off "Confirm email" in Supabase Auth settings.',
      };
    }
    throw error;
  }

  if (!data.user) return { error: 'Invalid username or password.' };

  const profileCheck = await assertApprovedProfile(data.user.id);
  if (profileCheck.error) return { error: profileCheck.error };
  const profile = await loadOwnProfile(data.user.id);
  if (!profile) {
    await sb.auth.signOut();
    return { error: 'This account has no profile (it may have been removed). Contact the owner.' };
  }

  // --- MFA: always inspect factors (do not rely only on AAL) ---
  try {
    const factors = await sb.auth.mfa.listFactors();
    const verifiedTotp =
      factors.data?.totp?.find((f) => f.status === 'verified') ||
      factors.data?.all?.find((f: { factor_type?: string; status?: string }) => f.factor_type === 'totp' && f.status === 'verified');

    // 1) Verified authenticator exists → challenge every login (never direct access)
    if (verifiedTotp) {
      const factorId = (verifiedTotp as { id: string }).id;
      const challenge = await sb.auth.mfa.challenge({ factorId });
      if (challenge.error || !challenge.data) {
        await sb.auth.signOut();
        return { error: challenge.error?.message || 'Could not start MFA challenge. Try again.' };
      }
      return {
        mfaRequired: true,
        factorId,
        challengeId: challenge.data.id,
        methods: ['totp'],
        message:
          'Password accepted. Open Google Authenticator and enter the 6-digit code for DiaMatrix.',
      };
    }

    // 2) Owner/admin without TOTP → force enroll now (session stays for enroll only)
    if (mustUseMfa(profile)) {
      const enroll = await sb.auth.mfa.enroll({
        factorType: 'totp',
        friendlyName: 'DiaMatrix Authenticator',
      });
      if (enroll.error || !enroll.data) {
        await sb.auth.signOut();
        return {
          error:
            enroll.error?.message ||
            'Two-factor authentication is required. Enable MFA (TOTP) in Supabase Auth settings, then try again.',
        };
      }
      return {
        mfaEnrollRequired: true,
        factorId: enroll.data.id,
        secret: enroll.data.totp.secret,
        uri: enroll.data.totp.uri,
        message:
          'Set up Google Authenticator: scan the QR / enter the secret, then type the 6-digit code to finish.',
      };
    }
  } catch (mfaErr: any) {
    // MFA API disabled on project → owner must not get in without protection
    if (mustUseMfa(profile)) {
      await sb.auth.signOut();
      return {
        error:
          'Multi-factor auth is not enabled on this Supabase project. Go to Authentication → Multi-Factor → enable TOTP, then sign in again.',
      };
    }
    console.warn('[cloudAuth] MFA check failed, continuing without MFA for non-owner', mfaErr?.message || mfaErr);
  }

  // Regular (non-owner) users without MFA factors
  return { user: profileCheck.user! };
}

/** Complete Supabase TOTP MFA after cloudLogin returned mfaRequired. */
export async function cloudVerifyMfa(
  factorId: string,
  challengeId: string,
  code: string,
): Promise<{ user?: AuthUser; error?: string }> {
  const sb = need();
  const { error } = await sb.auth.mfa.verify({
    factorId,
    challengeId,
    code: code.replace(/\s/g, ''),
  });
  if (error) {
    return { error: /invalid/i.test(error.message) ? 'Invalid verification code.' : error.message };
  }
  const { data } = await sb.auth.getUser();
  const uid = data.user?.id;
  if (!uid) return { error: 'Session lost after MFA. Sign in again.' };
  return assertApprovedProfile(uid);
}

/**
 * Enroll Google Authenticator for the currently signed-in user.
 * Returns secret + QR uri; caller must confirm with cloudConfirmTotpEnroll after scanning.
 */
export async function cloudEnrollTotp(): Promise<{
  factorId: string;
  secret: string;
  uri: string;
  error?: string;
}> {
  const sb = need();
  const { data, error } = await sb.auth.mfa.enroll({
    factorType: 'totp',
    friendlyName: 'DiaMatrix Authenticator',
  });
  if (error || !data) {
    return { factorId: '', secret: '', uri: '', error: error?.message || 'Could not start TOTP enrollment.' };
  }
  return {
    factorId: data.id,
    secret: data.totp.secret,
    uri: data.totp.uri,
  };
}

export async function cloudConfirmTotpEnroll(
  factorId: string,
  code: string,
): Promise<{ success: boolean; error?: string }> {
  const sb = need();
  const challenge = await sb.auth.mfa.challenge({ factorId });
  if (challenge.error || !challenge.data) {
    return { success: false, error: challenge.error?.message || 'Could not challenge TOTP.' };
  }
  const { error } = await sb.auth.mfa.verify({
    factorId,
    challengeId: challenge.data.id,
    code: code.replace(/\s/g, ''),
  });
  if (error) return { success: false, error: error.message };
  return { success: true };
}

export async function cloudRestore(): Promise<AuthUser | null> {
  const sb = need();
  const { data } = await sb.auth.getSession();
  const uid = data.session?.user?.id;
  if (!uid) return null;

  // If MFA is required but not completed, do not restore a half-auth session
  try {
    const aal = await sb.auth.mfa.getAuthenticatorAssuranceLevel();
    if (aal.data?.nextLevel === 'aal2' && aal.data.currentLevel !== 'aal2') {
      await sb.auth.signOut();
      return null;
    }
  } catch {
    /* MFA not available */
  }

  const profile = await loadOwnProfile(uid);
  if (!profile || profile.status !== 'approved') return null;
  return profileToAuthUser(profile);
}

export async function cloudLogout(): Promise<void> {
  await need().auth.signOut();
}

export async function cloudSignup(data: {
  username: string;
  name: string;
  password: string;
}): Promise<{ message: string }> {
  const sb = need();
  const username = data.username.trim().toLowerCase();
  const { data: res, error } = await sb.auth.signUp({
    email: loginIdentifierToEmail(username),
    password: data.password,
    options: {
      data: {
        username: username.includes('@') ? username.split('@')[0] : username,
        name: data.name.trim(),
      },
    },
  });
  if (error) {
    if (/already registered|already been registered/i.test(error.message)) {
      throw new Error('That username is already taken.');
    }
    throw error;
  }
  let firstUser = false;
  if (res.session && res.user) {
    const profile = await loadOwnProfile(res.user.id).catch(() => null);
    firstUser = profile?.status === 'approved';
    if (!firstUser) await sb.auth.signOut();
  }
  return {
    message: firstUser
      ? 'Owner account created. You can sign in now.'
      : 'Account request sent. The owner must approve it before you can sign in.',
  };
}

export async function cloudListUsers(): Promise<AuthUser[]> {
  const { data, error } = await need()
    .from('profiles')
    .select(PROFILE_COLUMNS)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return ((data ?? []) as ProfileRow[]).map(profileToAuthUser);
}

export async function cloudSetStatus(userId: string, status: 'approved' | 'rejected'): Promise<AuthUser> {
  const patch =
    status === 'approved'
      ? { status, can_edit: true, can_upload: true, can_export: true }
      : { status };
  const { data, error } = await need()
    .from('profiles')
    .update(patch)
    .eq('id', userId)
    .select(PROFILE_COLUMNS)
    .single();
  if (error) throw error;
  return profileToAuthUser(data as ProfileRow);
}

export async function cloudDeleteUser(userId: string): Promise<void> {
  const { data, error } = await need().from('profiles').delete().eq('id', userId).select('id');
  if (error) throw error;
  if (!data || data.length === 0) throw new Error('Could not delete this user (the owner cannot be deleted).');
}

export async function cloudUpdateOwnProfile(
  userId: string,
  patch: { name?: string; designation?: string },
): Promise<void> {
  const { error } = await need().from('profiles').update(patch).eq('id', userId);
  if (error) throw error;
}

export async function cloudChangeOwnPassword(newPassword: string): Promise<void> {
  const { error } = await need().auth.updateUser({ password: newPassword });
  if (error) throw error;
}
