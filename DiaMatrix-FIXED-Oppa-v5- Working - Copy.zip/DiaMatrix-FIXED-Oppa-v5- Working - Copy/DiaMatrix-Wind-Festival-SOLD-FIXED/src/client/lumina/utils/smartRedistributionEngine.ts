import type { RawInventoryRecord } from '../types';

/** Jewelry metal families supported for filtered redistribution calculations. */
export type MetalCategory = 'Gold' | 'Diamond' | 'Platinum' | 'Mixed' | 'Unknown';

export interface SmartTransferRecommendation {
  sku: string;
  styleName: string;
  fromBranch: string;
  toBranch: string;
  quantity: number;
  sourceAgeDays: number;
  destinationTurnRate: number;
  capitalReleased: number;
  priority: 'MEDIUM' | 'HIGH' | 'CRITICAL';
  reason: string;
  alert: string;
  /** Detected metal family for this recommendation. */
  metalCategory: MetalCategory;
  /** Estimated unit value used for high-value aging prioritization. */
  unitValue: number;
}

export interface SmartRedistributionOptions {
  /** Minimum age (days) before stock is considered aging. Default 90. */
  agingThresholdDays?: number;
  /** Minimum destination turn rate to receive stock. Default 1. */
  minimumDestinationTurnRate?: number;
  /**
   * When set, only positions matching these metal families are considered.
   * Omit or pass an empty array to include all metals.
   */
  metalCategories?: MetalCategory[];
  /**
   * When true (default), recommendations are ranked by a composite of
   * priority, capital released, and unit value so high-value aging stock
   * is transferred first.
   */
  prioritizeHighValueAging?: boolean;
}

interface Position {
  branch: string;
  sku: string;
  styleName: string;
  currentStock: number;
  sales90Days: number;
  ageDays: number;
  inventoryValue: number;
  unitValue: number;
  metalCategory: MetalCategory;
}

const isUsable = (value: unknown): number => {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : 0;
};

const turnRate = (sales: number, stock: number): number =>
  stock > 0 ? sales / stock : sales > 0 ? Infinity : 0;

/**
 * Infer metal family from free-text category / item / variant fields.
 * Jewelry ERP sheets rarely ship a dedicated Metal column; heuristics keep
 * Gold, Diamond, and Platinum redistribution separable without schema changes.
 */
export function detectMetalCategory(record: Pick<RawInventoryRecord, 'category' | 'itemName' | 'variant' | 'itemCode' | 'weight'>): MetalCategory {
  const haystack = [
    record.category,
    record.itemName,
    record.variant,
    record.itemCode,
    record.weight,
  ]
    .map((v) => String(v || '').toLowerCase())
    .join(' ');

  const hasGold = /\b(gold|au|yellow\s*gold|white\s*gold|rose\s*gold|18k|22k|24k|karat)\b/.test(haystack);
  const hasDiamond = /\b(diamond|dia|brilliant|solitaire|cvd|lab[\s-]?grown)\b/.test(haystack);
  const hasPlatinum = /\b(platinum|pt|plat)\b/.test(haystack);

  const hits = [hasGold, hasDiamond, hasPlatinum].filter(Boolean).length;
  if (hits >= 2) return 'Mixed';
  if (hasDiamond) return 'Diamond';
  if (hasPlatinum) return 'Platinum';
  if (hasGold) return 'Gold';
  return 'Unknown';
}

function buildPositions(records: RawInventoryRecord[]): Position[] {
  return records
    .map((record) => {
      const currentStock = isUsable(record.currentStock);
      const unitValue = isUsable(record.unitValueEstimate);
      return {
        branch: String(record.branch || '').trim(),
        sku: String(record.itemCode || record.weight || record.itemName || '').trim(),
        styleName: String(
          record.itemName || record.variant || record.category || record.weight || 'Jewelry Item',
        ).trim(),
        currentStock,
        sales90Days: isUsable(record.sales3M),
        ageDays: isUsable(record.ageDays),
        inventoryValue: unitValue * currentStock,
        unitValue,
        metalCategory: detectMetalCategory(record),
      };
    })
    .filter((position) => position.branch && position.sku);
}

/**
 * Generate branch-to-branch transfer recommendations.
 *
 * Supports optional filtering by metal category (Gold / Diamond / Platinum)
 * and prioritizes high-value aging stock so dead capital is released first.
 */
export function generateSmartRedistributionRecommendations(
  records: RawInventoryRecord[],
  options: SmartRedistributionOptions = {},
): SmartTransferRecommendation[] {
  const agingThresholdDays = options.agingThresholdDays ?? 90;
  const minimumDestinationTurnRate = options.minimumDestinationTurnRate ?? 1;
  const prioritizeHighValueAging = options.prioritizeHighValueAging !== false;
  const metalFilter =
    options.metalCategories && options.metalCategories.length > 0
      ? new Set(options.metalCategories)
      : null;

  let positions = buildPositions(records);
  if (metalFilter) {
    positions = positions.filter((p) => metalFilter.has(p.metalCategory));
  }

  const groups = new Map<string, Position[]>();
  positions.forEach((position) => {
    const existing = groups.get(position.sku) || [];
    existing.push(position);
    groups.set(position.sku, existing);
  });

  const recommendations: SmartTransferRecommendation[] = [];

  groups.forEach((locations, sku) => {
    // Aging stock at source — prefer older and higher unit value when ranking sources
    const sources = locations
      .filter((location) => location.currentStock > 0 && location.ageDays > agingThresholdDays)
      .sort((a, b) => {
        if (prioritizeHighValueAging) {
          // High unit-value aging stock first, then older age
          const valueDelta = b.unitValue - a.unitValue;
          if (valueDelta !== 0) return valueDelta;
        }
        return b.ageDays - a.ageDays;
      });

    const destinations = locations
      .map((location) => ({
        location,
        turn: turnRate(location.sales90Days, location.currentStock),
      }))
      .filter(({ location, turn }) => location.currentStock >= 0 && turn >= minimumDestinationTurnRate)
      .sort((a, b) => b.turn - a.turn);

    sources.forEach((source) => {
      const destination = destinations.find(({ location }) => location.branch !== source.branch);
      if (!destination) return;

      const demandGap = Math.max(
        0,
        Math.ceil(destination.location.sales90Days) - destination.location.currentStock,
      );
      const quantity = Math.min(source.currentStock, demandGap || source.currentStock);
      if (quantity < 1) return;

      const unitCapital = source.currentStock > 0 ? source.inventoryValue / source.currentStock : source.unitValue;
      const capitalReleased = Math.round(quantity * unitCapital);
      const turnLabel = Number.isFinite(destination.turn)
        ? `${destination.turn.toFixed(2)}x`
        : 'a stock-out rate (sales with zero stock on hand)';

      // Priority: age bands first, then boost CRITICAL when high unit value is trapped
      let priority: SmartTransferRecommendation['priority'] =
        source.ageDays >= 180 ? 'CRITICAL' : source.ageDays >= 120 ? 'HIGH' : 'MEDIUM';
      if (prioritizeHighValueAging && source.unitValue >= 50000 && priority !== 'CRITICAL') {
        // High-value piece aging > threshold escalates one step
        priority = priority === 'HIGH' ? 'CRITICAL' : 'HIGH';
      }

      const metalLabel =
        source.metalCategory !== 'Unknown' ? ` [${source.metalCategory}]` : '';

      recommendations.push({
        sku,
        styleName: source.styleName,
        fromBranch: source.branch,
        toBranch: destination.location.branch,
        quantity,
        sourceAgeDays: source.ageDays,
        destinationTurnRate: Number(destination.turn.toFixed(2)),
        capitalReleased,
        priority,
        metalCategory: source.metalCategory,
        unitValue: source.unitValue,
        reason: `${source.branch} has ${Math.round(source.ageDays)}-day-old${metalLabel} stock while ${destination.location.branch} is turning the same SKU at ${turnLabel} over the recent 90-day period.`,
        alert: `Optimization Alert: Transfer ${quantity} units of Style ${sku}${metalLabel} from ${source.branch} to ${destination.location.branch} to free up dead capital.`,
      });
    });
  });

  const rank = { CRITICAL: 3, HIGH: 2, MEDIUM: 1 } as const;
  return recommendations.sort((a, b) => {
    const priorityDelta = rank[b.priority] - rank[a.priority];
    if (priorityDelta !== 0) return priorityDelta;
    if (prioritizeHighValueAging) {
      // Prefer higher capital release, then higher unit value
      const capitalDelta = b.capitalReleased - a.capitalReleased;
      if (capitalDelta !== 0) return capitalDelta;
      return b.unitValue - a.unitValue;
    }
    return b.capitalReleased - a.capitalReleased;
  });
}

/**
 * Convenience: run redistribution for a single metal family only.
 */
export function generateRedistributionByMetal(
  records: RawInventoryRecord[],
  metal: MetalCategory,
  options: Omit<SmartRedistributionOptions, 'metalCategories'> = {},
): SmartTransferRecommendation[] {
  return generateSmartRedistributionRecommendations(records, {
    ...options,
    metalCategories: [metal],
  });
}

/**
 * Convenience: separate recommendation sets per metal family (Gold, Diamond, Platinum).
 * Unknown / Mixed are grouped under their own keys when present.
 */
export function generateRedistributionByAllMetals(
  records: RawInventoryRecord[],
  options: Omit<SmartRedistributionOptions, 'metalCategories'> = {},
): Record<MetalCategory, SmartTransferRecommendation[]> {
  const metals: MetalCategory[] = ['Gold', 'Diamond', 'Platinum', 'Mixed', 'Unknown'];
  const result = {} as Record<MetalCategory, SmartTransferRecommendation[]>;
  for (const metal of metals) {
    result[metal] = generateRedistributionByMetal(records, metal, options);
  }
  return result;
}
