/**
 * Main-thread queue that delegates heavy stock/sold merges to a module worker.
 * Supports progress callbacks and 5,000-row batching for multi-month uploads.
 */
import type { ParsedDataResult, UploadFileBlob } from './universalParser';
import type { WorkerProgressMessage, WorkerResultMessage } from './fileProcessingWorker';

export const DEFAULT_BATCH_SIZE = 5000;

type ProgressHandler = (info: {
  phase: 'parse' | 'merge' | 'finalize';
  processed: number;
  total: number;
}) => void;

interface QueueJob {
  stockFiles: UploadFileBlob[];
  soldFiles: UploadFileBlob[];
  batchSize?: number;
  onProgress?: ProgressHandler;
}

let worker: Worker | null = null;
let seq = 1;
const pending = new Map<
  number,
  {
    resolve: (value: ParsedDataResult) => void;
    reject: (reason?: unknown) => void;
    onProgress?: ProgressHandler;
  }
>();

function getWorker(): Worker {
  if (worker) return worker;
  worker = new Worker(new URL('./fileProcessingWorker.ts', import.meta.url), { type: 'module' });
  worker.onmessage = (event: MessageEvent<WorkerProgressMessage | WorkerResultMessage>) => {
    const data = event.data;
    if (!data || typeof data !== 'object' || !('id' in data)) return;

    if ('type' in data && data.type === 'progress') {
      const entry = pending.get(data.id);
      entry?.onProgress?.({
        phase: data.phase,
        processed: data.processed,
        total: data.total,
      });
      return;
    }

    const resultMsg = data as WorkerResultMessage;
    const entry = pending.get(resultMsg.id);
    if (!entry) return;
    pending.delete(resultMsg.id);
    if (resultMsg.ok && resultMsg.result) entry.resolve(resultMsg.result);
    else entry.reject(new Error(resultMsg.error || 'Background merge failed'));
  };
  worker.onerror = (err) => {
    console.error('[fileProcessingQueue] worker error', err);
  };
  return worker;
}

/**
 * Deep-clone upload blobs for the worker.
 * IMPORTANT: never transfer (neuter) the original ArrayBuffers — that left the
 * main-thread stockFiles/soldFiles empty after the first auto-merge, so
 * "Apply & Distribution" saw 0 bytes and did nothing.
 */
function cloneForWorker(files: UploadFileBlob[]): UploadFileBlob[] {
  return (files || []).map((f) => {
    if (f.content instanceof ArrayBuffer) {
      // Structured copy — worker gets its own buffer; UI keeps the original
      return { name: f.name, content: f.content.slice(0) };
    }
    return { name: f.name, content: f.content };
  });
}

/**
 * Queue a dual/multi-file merge on the worker thread.
 * Large results are assembled in 5,000-row batches inside the worker.
 */
export function queueBackgroundMerge(job: QueueJob): Promise<ParsedDataResult> {
  const id = seq++;
  return new Promise<ParsedDataResult>((resolve, reject) => {
    pending.set(id, { resolve, reject, onProgress: job.onProgress });
    try {
      const payload = {
        id,
        stockFiles: cloneForWorker(job.stockFiles),
        soldFiles: cloneForWorker(job.soldFiles),
        batchSize: job.batchSize ?? DEFAULT_BATCH_SIZE,
      };
      // Do NOT pass transferables — keep main-thread file buffers intact for Apply
      getWorker().postMessage(payload);
    } catch (error) {
      pending.delete(id);
      reject(error);
    }
  });
}

/**
 * Yield to the browser between synchronous main-thread batches (fallback path).
 */
export async function processInBatches<T, R>(
  items: T[],
  batchSize: number,
  handler: (batch: T[], batchIndex: number) => R | Promise<R>,
  onProgress?: (processed: number, total: number) => void,
): Promise<R[]> {
  const size = Math.max(500, batchSize || DEFAULT_BATCH_SIZE);
  const results: R[] = [];
  const total = items.length;
  for (let i = 0, batchIndex = 0; i < total; i += size, batchIndex++) {
    const batch = items.slice(i, i + size);
    results.push(await handler(batch, batchIndex));
    onProgress?.(Math.min(i + size, total), total);
    await new Promise((r) => setTimeout(r, 0));
  }
  return results;
}
