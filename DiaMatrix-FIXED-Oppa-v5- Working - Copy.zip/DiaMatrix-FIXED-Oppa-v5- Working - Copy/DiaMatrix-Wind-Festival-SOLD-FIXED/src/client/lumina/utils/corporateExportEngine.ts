import * as ExcelJS from 'exceljs';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import type { WhiteLabelSettings } from './settingsEngine';
import { getStoredSettings } from './settingsEngine';

export type ExportCell = string | number | null | undefined;

export interface CorporateExportColumn {
  key: string;
  header: string;
  align?: 'left' | 'center' | 'right';
  width?: number;
  numberFormat?: string;
}

export interface CorporateExportOptions {
  title: string;
  filename?: string;
  period?: string;
  columns: CorporateExportColumn[];
  rows: Record<string, ExportCell>[];
  whiteLabel?: WhiteLabelSettings;
  chartElement?: HTMLElement | null;
}

const FALLBACK_LOGO = '/diamatrix-logo-full.png';

function activeBrand(override?: WhiteLabelSettings): WhiteLabelSettings {
  return override || getStoredSettings().whiteLabel;
}

function safeFilename(value: string): string {
  return value.replace(/[^a-z0-9_-]+/gi, '_').replace(/^_+|_+$/g, '') || 'Corporate_Report';
}

async function imageToDataUrl(url: string): Promise<string | null> {
  try {
    if (url.startsWith('data:image/')) return url;
    const response = await fetch(url, { mode: 'cors' });
    if (!response.ok) return null;
    const blob = await response.blob();
    return await new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || '') || null);
      reader.onerror = () => resolve(null);
      reader.readAsDataURL(blob);
    });
  } catch {
    return null;
  }
}

function imageFormat(dataUrl: string): 'PNG' | 'JPEG' {
  const match = dataUrl.match(/^data:image\/(png|jpeg|jpg)/i);
  const format = match?.[1]?.toLowerCase();
  return format === 'jpeg' || format === 'jpg' ? 'JPEG' : 'PNG';
}

async function officeSafeImage(dataUrl: string): Promise<{ dataUrl: string; format: 'PNG' | 'JPEG' }> {
  if (/^data:image\/(png|jpeg|jpg);/i.test(dataUrl)) {
    return { dataUrl, format: imageFormat(dataUrl) };
  }
  try {
    const image = new Image();
    image.src = dataUrl;
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error('Unable to decode logo image'));
    });
    const canvas = document.createElement('canvas');
    canvas.width = image.naturalWidth || 600;
    canvas.height = image.naturalHeight || 200;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Canvas unavailable');
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    return { dataUrl: canvas.toDataURL('image/png'), format: 'PNG' };
  } catch {
    return { dataUrl, format: 'PNG' };
  }
}

async function resolveLogo(whiteLabel: WhiteLabelSettings): Promise<string | null> {
  return imageToDataUrl(whiteLabel.logoUrl || FALLBACK_LOGO);
}

function nowLabel(): string {
  return new Intl.DateTimeFormat(undefined, {
    year: 'numeric', month: 'short', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  }).format(new Date());
}

export async function exportCorporateExcel(options: CorporateExportOptions): Promise<void> {
  const brand = activeBrand(options.whiteLabel);
  const workbook = new ExcelJS.Workbook();
  workbook.creator = brand.companyName;
  workbook.company = brand.companyName;
  workbook.title = options.title;

  const sheet = workbook.addWorksheet('Report', {
    views: [{ showGridLines: false, state: 'frozen', ySplit: 5 }],
  });

  const columns = options.columns;
  const totalColumns = Math.max(columns.length, 6);
  sheet.columns = Array.from({ length: totalColumns }, (_, index) => ({
    width: columns[index]?.width || (index === 0 ? 30 : 16),
  }));

  sheet.mergeCells(1, 1, 1, totalColumns);
  const titleCell = sheet.getCell(1, 1);
  titleCell.value = brand.companyName;
  titleCell.font = { name: 'Aptos Display', size: 17, bold: true, color: { argb: 'FFFFFFFF' } };
  titleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: brand.primary.replace('#', '') } };
  titleCell.alignment = { vertical: 'middle', horizontal: 'left' };
  sheet.getRow(1).height = 30;

  sheet.mergeCells(2, 1, 2, totalColumns);
  const reportTitle = sheet.getCell(2, 1);
  reportTitle.value = options.title;
  reportTitle.font = { name: 'Aptos', size: 14, bold: true, color: { argb: 'FF' + brand.primary.replace('#', '') } };
  reportTitle.alignment = { vertical: 'middle', horizontal: 'left' };
  sheet.getRow(2).height = 24;

  sheet.mergeCells(3, 1, 3, totalColumns);
  const meta = sheet.getCell(3, 1);
  meta.value = `Period: ${options.period || 'Current'}  •  Generated: ${nowLabel()}`;
  meta.font = { name: 'Aptos', size: 9, color: { argb: 'FF64748B' }, italic: true };
  meta.alignment = { vertical: 'middle', horizontal: 'left' };

  const logo = await resolveLogo(brand);
  if (logo) {
    try {
      const officeLogo = await officeSafeImage(logo);
      const imageId = workbook.addImage({ base64: officeLogo.dataUrl, extension: officeLogo.format.toLowerCase() as 'png' | 'jpeg' });
      sheet.addImage(imageId, { tl: { col: Math.max(0, totalColumns - 2.3), row: 0.2 }, ext: { width: 150, height: 45 } });
    } catch {
      // Export remains valid if a remote/CSP logo cannot be embedded.
    }
  }

  const headerRow = sheet.addRow(columns.map((column) => column.header));
  headerRow.height = 24;
  headerRow.eachCell((cell, index) => {
    cell.font = { name: 'Aptos', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: brand.secondary.replace('#', '') } };
    cell.alignment = { horizontal: columns[index - 1]?.align || 'left', vertical: 'middle', wrapText: true };
    cell.border = { bottom: { style: 'thin', color: { argb: brand.border.replace('#', '') } } };
  });

  options.rows.forEach((record) => {
    const row = sheet.addRow(columns.map((column) => record[column.key] ?? ''));
    row.eachCell((cell, index) => {
      const column = columns[index - 1];
      cell.font = { name: 'Aptos', size: 10, color: { argb: 'FF' + brand.text.replace('#', '') } };
      cell.alignment = { horizontal: column?.align || 'left', vertical: 'middle', wrapText: true };
      cell.border = {
        bottom: { style: 'hair', color: { argb: brand.border.replace('#', '') } },
      };
      if (column?.numberFormat) cell.numFmt = column.numberFormat;
    });
  });

  for (let i = 1; i <= totalColumns; i += 1) {
    if (i > columns.length) sheet.getColumn(i).width = 4;
  }

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${safeFilename(options.filename || options.title)}.xlsx`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

export async function exportCorporatePdf(options: CorporateExportOptions): Promise<void> {
  const brand = activeBrand(options.whiteLabel);
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const pageWidth = 297;
  const pageHeight = 210;
  const margin = 10;
  const logo = await resolveLogo(brand);
  const pdfLogo = logo ? await officeSafeImage(logo) : null;

  const primaryRgb = hexToRgb(brand.primary);
  const secondaryRgb = hexToRgb(brand.secondary);
  const borderRgb = hexToRgb(brand.border);
  const textRgb = hexToRgb(brand.text);

  doc.setFillColor(...primaryRgb);
  doc.rect(0, 0, pageWidth, 25, 'F');
  if (logo) {
    try {
      if (pdfLogo) doc.addImage(pdfLogo.dataUrl, pdfLogo.format, margin, 4, 42, 14);
    } catch {
      // Keep textual header if image embedding is unavailable.
    }
  }
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(brand.companyName, 56, 11);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(`Generated: ${nowLabel()}`, 56, 17);

  doc.setTextColor(...textRgb);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(options.title, margin, 36);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`Period: ${options.period || 'Current'}`, margin, 42);

  let y = 48;
  const availableWidth = pageWidth - margin * 2;
  const baseWidths = options.columns.map((column) => Math.max(18, Math.min(65, (column.width || 16) * 2.2)));
  const scale = availableWidth / baseWidths.reduce((sum, width) => sum + width, 0);
  const widths = baseWidths.map((width) => width * scale);
  const rowHeight = 8;

  const drawRow = (values: ExportCell[], header = false) => {
    let x = margin;
    values.forEach((value, index) => {
      const width = widths[index] || 20;
      if (header) {
        doc.setFillColor(...secondaryRgb);
        doc.setTextColor(255, 255, 255);
      } else {
        doc.setFillColor(255, 255, 255);
        doc.setTextColor(...textRgb);
      }
      doc.rect(x, y, width, rowHeight, 'F');
      doc.setDrawColor(...borderRgb);
      doc.rect(x, y, width, rowHeight);
      doc.setFont('helvetica', header ? 'bold' : 'normal');
      doc.setFontSize(header ? 7 : 6.7);
      const text = String(value ?? '');
      const align = options.columns[index]?.align || 'left';
      const textX = align === 'right' ? x + width - 2 : align === 'center' ? x + width / 2 : x + 2;
      doc.text(doc.splitTextToSize(text, Math.max(4, width - 4)).slice(0, 2), textX, y + 5, {
        align: align === 'right' ? 'right' : align === 'center' ? 'center' : 'left',
      });
      x += width;
    });
    y += rowHeight;
  };

  drawRow(options.columns.map((column) => column.header), true);
  for (const record of options.rows) {
    if (y > pageHeight - 16) {
      doc.addPage('a4', 'landscape');
      y = 18;
      drawRow(options.columns.map((column) => column.header), true);
    }
    drawRow(options.columns.map((column) => record[column.key] ?? ''));
  }

  if (options.chartElement) {
    try {
      const canvas = await html2canvas(options.chartElement, {
        backgroundColor: '#FFFFFF',
        scale: Math.min(2, window.devicePixelRatio || 1.5),
        useCORS: true,
        logging: false,
      });
      const image = canvas.toDataURL('image/png');
      const imageWidth = pageWidth - margin * 2;
      const imageHeight = Math.min(100, (canvas.height * imageWidth) / canvas.width);
      if (y + imageHeight + 12 > pageHeight) {
        doc.addPage('a4', 'landscape');
        y = 18;
      }
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(...primaryRgb);
      doc.text('Analytics Visualization', margin, y + 5);
      doc.addImage(image, 'PNG', margin, y + 8, imageWidth, imageHeight);
    } catch {
      // Table export remains available even if a chart cannot be rasterized.
    }
  }

  const pages = doc.getNumberOfPages();
  for (let page = 1; page <= pages; page += 1) {
    doc.setPage(page);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);
    doc.text(`${brand.companyName}  •  ${options.title}`, margin, pageHeight - 6);
    doc.text(`Page ${page} / ${pages}`, pageWidth - margin, pageHeight - 6, { align: 'right' });
  }

  doc.save(`${safeFilename(options.filename || options.title)}.pdf`);
}

export async function exportCorporateReport(options: CorporateExportOptions): Promise<void> {
  await exportCorporateExcel(options);
  await exportCorporatePdf(options);
}

export async function exportCorporateChartPdf(
  element: HTMLElement,
  title: string,
  whiteLabel?: WhiteLabelSettings,
  period?: string,
): Promise<void> {
  await exportCorporatePdf({
    title,
    period,
    columns: [{ key: 'summary', header: 'Summary', width: 30 }],
    rows: [{ summary: 'Chart export' }],
    whiteLabel,
    chartElement: element,
    filename: title,
  });
}

function hexToRgb(hex: string): [number, number, number] {
  const normalized = hex.replace('#', '');
  const value = normalized.length === 3
    ? normalized.split('').map((char) => char + char).join('')
    : normalized.padEnd(6, '0').slice(0, 6);
  return [
    parseInt(value.slice(0, 2), 16) || 0,
    parseInt(value.slice(2, 4), 16) || 0,
    parseInt(value.slice(4, 6), 16) || 0,
  ];
}
