/**
 * Dashboard hub: natural motion for the hanging modules + water ripples.
 * Pure maths + small DOM helpers (no React) so it is easy to tune.
 *
 * Model (per module):
 *  - the golden thread swings from its knot on the tree (angle `swing`), driven by a slow wind that sweeps left -> right
 *    plus a few overlapping rhythms (so it never repeats like a metronome);
 *  - the tag hangs from the thread's end and mostly stays upright, only following a little and a moment later (`tagAbs`);
 *  - tassels are light: they lag more and flick more (`tasselAbs`);
 *  - a module hanging from another one (Refill Demand under Item Allocation Matrix) follows its parent (`childAbs`).
 * Water: ripples start where a module touches the water (each time it turns around), plus tiny rain-drop rings everywhere.
 */
const TAU = Math.PI * 2;

export type Motion = { amp: number; seed: number; T: number };

/** wind strength 0..1, slowly varying, arriving at the right side a few seconds after the left side */
export const gust = (t: number, x: number): number => {
  const u = t - (x / 1184) * 3.5;
  return 0.5 + 0.5 * (0.6 * Math.sin((TAU * u) / 21 + 0.6) + 0.4 * Math.sin((TAU * u) / 12.7 + 2.2));
};
/** irregular rhythm in [-1, 1]: three overlapping swings of different length */
const rhythm = (t: number, m: Motion): number =>
  0.55 * Math.sin((TAU * t) / m.T + m.seed * 1.7) +
  0.3 * Math.sin((TAU * t) / (m.T * 0.61) + m.seed * 2.9) +
  0.15 * Math.sin((TAU * t) / (m.T * 0.37) + m.seed * 0.7);

/** thread angle in degrees (rotation about the knot on the tree) */
export const swing = (m: Motion, t: number, x: number): number => {
  const g = gust(t, x);
  return m.amp * ((0.55 + 0.45 * g) * rhythm(t, m) + 0.3 * (2 * g - 1));
};
/** absolute angle of the tag itself: stays nearly upright, follows the thread late and softly */
export const tagAbs = (m: Motion, t: number, x: number): number =>
  0.28 * swing(m, t - 0.45, x) + 0.22 * m.amp * Math.sin((TAU * t) / 3.3 + m.seed * 2.1) * (0.4 + 0.6 * gust(t, x));
/** absolute angle of a tassel (k = 0 / 1 so the two never move together) */
export const tasselAbs = (m: Motion, t: number, x: number, k: number): number =>
  0.95 * swing(m, t - 0.8 - 0.25 * k, x) + 0.7 * m.amp * Math.sin((TAU * t) / 2.6 + m.seed * 3.3 + k * 2) * (0.5 + 0.5 * gust(t, x));
/** absolute angle of a module that hangs from another module's tag */
export const childAbs = (parent: Motion, own: Motion, t: number, x: number): number =>
  0.85 * tagAbs(parent, t - 0.3, x) + 0.5 * own.amp * Math.sin((TAU * t) / 3.9 + own.seed * 1.3);

/* ───────────────────────────── water ripples ───────────────────────────── */
export const RIP_N = 26;
export const WATER_Y0 = 1425; // first water row (picture pixels)
export const WATER_Y1 = 1625; // where the diamond pile starts
export const WATER_X0 = 40;
export const WATER_X1 = 1144;

type Ring = { l: SVGElement; d: SVGElement; on: boolean; t0: number; life: number; cx: number; cy: number; R: number; flat: number; k: number; patch: number };

export class RippleSystem {
  private rings: Ring[];
  private nextRain = 0.6;
  private last: Record<string, { v: number; dir: number; ext: number; at: number }> = {};
  private wobble: ({ map: SVGElement; group: SVGElement } | null)[];

  constructor(lights: SVGElement[], darks: SVGElement[], wobble: ({ map: SVGElement; group: SVGElement } | null)[]) {
    this.rings = lights.map((l, i) => ({ l, d: darks[i], on: false, t0: 0, life: 1, cx: 0, cy: 0, R: 1, flat: 0.2, k: 0, patch: -1 }));
    this.wobble = wobble;
  }

  private free(): Ring | null {
    return this.rings.find((r) => !r.on) ?? null;
  }
  spawn(t: number, cx: number, cy: number, R: number, life: number, k: number, flat: number, patch = -1): void {
    const r = this.free();
    if (!r) return;
    Object.assign(r, { on: true, t0: t, life, cx, cy, R, flat, k, patch });
  }

  /** watches a swinging signal and sends a ring each time it turns around (strength follows how far it just swung) */
  track(id: string, t: number, v: number, amp: number, cx: number, cy: number, patch: number): void {
    const s = this.last[id] ?? (this.last[id] = { v, dir: 0, ext: v, at: -9 });
    const dv = v - s.v;
    const dir = Math.abs(dv) < 1e-5 ? s.dir : Math.sign(dv);
    if (s.dir !== 0 && dir !== s.dir) {
      const swingSize = Math.abs(v - s.ext);
      if (swingSize > 0.22 * amp && t - s.at > 1.1) {
        const k = Math.min(1, swingSize / (1.3 * amp));
        this.spawn(t, cx + (Math.random() - 0.5) * 18, cy, 95 + 45 * k, 3.3 + 1.2 * k, 0.35 + 0.65 * k, 0.17, patch);
        s.at = t;
      }
      s.ext = v;
    }
    if (s.dir === 0) s.ext = v;
    s.v = v;
    s.dir = dir;
  }

  update(t: number, rain = true): void {
    if (rain && t > this.nextRain) {
      this.nextRain = t + 0.25 + Math.random() * 0.75; // a raindrop every ~0.6 s
      const y = WATER_Y0 + 8 + Math.random() * (WATER_Y1 - WATER_Y0 - 10);
      const depth = (y - WATER_Y0) / (WATER_Y1 - WATER_Y0); // nearer to the viewer = bigger
      const x = WATER_X0 + Math.random() * (WATER_X1 - WATER_X0);
      this.spawn(t, x, y, (14 + Math.random() * 20) * (0.7 + 0.9 * depth), 1.0 + Math.random() * 0.8, 0.28 + Math.random() * 0.3, 0.16 + 0.1 * depth);
    }
    const energy: number[] = [0, 0, 0, 0];
    for (const r of this.rings) {
      if (!r.on) continue;
      const u = (t - r.t0) / r.life;
      if (u >= 1) {
        r.on = false;
        r.l.setAttribute('stroke-opacity', '0');
        r.d.setAttribute('stroke-opacity', '0');
        continue;
      }
      const e = 1 - (1 - u) * (1 - u); // spreads fast, then slows down
      const rx = 3 + (r.R - 3) * e;
      const ry = Math.max(0.6, rx * r.flat);
      const fade = Math.min(1, u * 9) * Math.pow(1 - u, 1.4); // quick fade-in, long soft fade-out
      const o = (0.5 * r.k * fade).toFixed(3);
      const w = (2.6 * (1 - 0.7 * u) * (0.6 + 0.4 * r.k)).toFixed(2);
      r.l.setAttribute('cx', r.cx.toFixed(1)); r.l.setAttribute('cy', r.cy.toFixed(1));
      r.l.setAttribute('rx', rx.toFixed(1)); r.l.setAttribute('ry', ry.toFixed(1));
      r.l.setAttribute('stroke-opacity', o); r.l.setAttribute('stroke-width', w);
      // darker "shadow side" of the crest, a little lower
      r.d.setAttribute('cx', r.cx.toFixed(1)); r.d.setAttribute('cy', (r.cy + 1.8).toFixed(1));
      r.d.setAttribute('rx', (rx * 0.97).toFixed(1)); r.d.setAttribute('ry', ry.toFixed(1));
      r.d.setAttribute('stroke-opacity', (0.45 * r.k * fade).toFixed(3)); r.d.setAttribute('stroke-width', w);
      if (r.patch >= 0) energy[r.patch] += r.k * Math.pow(1 - u, 2);
    }
    this.wobble.forEach((el, i) => {
      if (!el) return;
      const sc = Math.min(5, 4.5 * energy[i]);
      el.map.setAttribute('scale', sc.toFixed(2));
      (el.group as unknown as HTMLElement).style.display = sc > 0.05 ? '' : 'none'; // no filter work while the water is calm
    });
  }
}
