import { SalesTimeframe } from '../types';

export type AppTheme = 'cosmic' | 'obsidian' | 'light' | 'silver' | 'corporate-blue' | 'corporate-slate' | 'midnight' | 'emerald' | 'royal-gold' | 'platinum-gold' | 'metallic';
export type TableDensity = 'compact' | 'standard' | 'comfortable';
export type CurrencyFormat = 'BDT' | 'USD' | 'EUR' | 'INR';
export type NumberNotation = 'south_asian' | 'international';
export type RedistributionStrategy = 'proportional' | 'aggressive_velocity' | 'balanced_safety';

export interface WhiteLabelSettings {
  companyName: string;
  logoUrl: string | null;
  primary: string;
  secondary: string;
  accent: string;
  sidebarBackground: string;
  sidebarForeground: string;
  surface: string;
  surfaceMuted: string;
  text: string;
  border: string;
}

export const DEFAULT_WHITE_LABEL: WhiteLabelSettings = {
  companyName: 'DiaMatrix',
  logoUrl: '/diamatrix-logo-full.png',
  primary: '#0B2545',
  secondary: '#143A66',
  accent: '#0D9488',
  sidebarBackground: '#0B2545',
  sidebarForeground: '#F8FAFC',
  surface: '#FFFFFF',
  surfaceMuted: '#F1F5F9',
  text: '#1F2937',
  border: '#E2E8F0',
};

export interface AppSettings {
  theme: AppTheme;
  whiteLabel: WhiteLabelSettings;
  density: TableDensity;
  currency: CurrencyFormat;
  numberNotation: NumberNotation;
  defaultTimeframe: SalesTimeframe;
  strategy: RedistributionStrategy;
  minBranchSafetyBuffer: number;
  agingWarningDays: number;
  autoSaveSession: boolean;
  highlightDeficits: boolean;
}

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'light',
  whiteLabel: DEFAULT_WHITE_LABEL,
  density: 'standard',
  currency: 'BDT',
  numberNotation: 'south_asian',
  defaultTimeframe: '1Y',
  strategy: 'proportional',
  minBranchSafetyBuffer: 0,
  agingWarningDays: 180,
  autoSaveSession: true,
  highlightDeficits: true
};

const SETTINGS_KEY = 'dwl_analytics_app_settings';
const THEME_PALETTE_VERSION_KEY = 'dwl_theme_palette_version';
const THEME_PALETTE_VERSION = 'theme-selection-v3';

function normalizeTheme(theme: unknown): AppTheme {
  if (theme === 'obsidian' || theme === 'light' || theme === 'silver' || theme === 'corporate-blue' || theme === 'corporate-slate' || theme === 'midnight' || theme === 'emerald' || theme === 'cosmic' || theme === 'royal-gold' || theme === 'platinum-gold' || theme === 'metallic') {
    return theme;
  }
  return 'light';
}

export function getStoredSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(DEFAULT_SETTINGS));
      localStorage.setItem(THEME_PALETTE_VERSION_KEY, THEME_PALETTE_VERSION);
      return DEFAULT_SETTINGS;
    }
    const parsed = JSON.parse(raw);
    const settings: AppSettings = {
      ...DEFAULT_SETTINGS,
      ...parsed,
      theme: normalizeTheme(parsed.theme),
      whiteLabel: { ...DEFAULT_WHITE_LABEL, ...(parsed.whiteLabel || {}) },
    };
    const hasThemeMigration = localStorage.getItem(THEME_PALETTE_VERSION_KEY) === THEME_PALETTE_VERSION;
    if (!hasThemeMigration) {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
      localStorage.setItem(THEME_PALETTE_VERSION_KEY, THEME_PALETTE_VERSION);
    }
    if (typeof document !== 'undefined') {
      applyThemeToDocument(settings.theme);
      applyWhiteLabelToDocument(settings.whiteLabel);
    }
    return settings;
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
}

export function saveStoredSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    localStorage.setItem(THEME_PALETTE_VERSION_KEY, THEME_PALETTE_VERSION);
    applyThemeToDocument(settings.theme);
    applyWhiteLabelToDocument(settings.whiteLabel);
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
}

export function applyWhiteLabelToDocument(whiteLabel: WhiteLabelSettings): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const tokens: Record<string, string> = {
    '--brand-primary': whiteLabel.primary,
    '--brand-secondary': whiteLabel.secondary,
    '--brand-accent': whiteLabel.accent,
    '--brand-sidebar': whiteLabel.sidebarBackground,
    '--brand-sidebar-fg': whiteLabel.sidebarForeground,
    '--brand-surface': whiteLabel.surface,
    '--brand-surface-muted': whiteLabel.surfaceMuted,
    '--brand-text': whiteLabel.text,
    '--brand-border': whiteLabel.border,
    '--shell-sidebar': whiteLabel.sidebarBackground,
    '--shell-titlebar': whiteLabel.surface,
    '--shell-titlebar-fg': whiteLabel.primary,
    '--shell-titlebar-border': whiteLabel.border,
    '--shell-fg': whiteLabel.text,
    '--shell-bg': whiteLabel.surfaceMuted,
    '--shell-panel-border': whiteLabel.border,
    '--shell-btn-bg': whiteLabel.surface,
    '--shell-btn-fg': whiteLabel.text,
    '--shell-btn-border': whiteLabel.border,
    '--shell-btn-hover': whiteLabel.surfaceMuted,
    '--shell-nav-hover': `${whiteLabel.accent}22`,
    '--shell-nav-active': `${whiteLabel.accent}38`,
    '--shell-sidebar-fg': whiteLabel.sidebarForeground,
    '--shell-btn-primary-bg': whiteLabel.primary,
    '--shell-btn-accent-bg': whiteLabel.accent,
    '--shell-accent': whiteLabel.accent,
    '--shell-panel': whiteLabel.surface,
    '--shell-grid-bg': whiteLabel.surface,
    '--shell-grid-th': whiteLabel.surfaceMuted,
    '--shell-grid-border': whiteLabel.border,
    '--brand-navy': whiteLabel.primary,
    '--brand-navy-mid': whiteLabel.secondary,
    '--brand-teal': whiteLabel.accent,
  };
  Object.entries(tokens).forEach(([key, value]) => root.style.setProperty(key, value));
  root.setAttribute('data-company-name', whiteLabel.companyName);
}

export function applyThemeToDocument(theme: AppTheme): void {
  const root = document.documentElement;
  root.classList.remove('theme-obsidian', 'theme-light', 'theme-silver', 'theme-corporate-blue', 'theme-corporate-slate', 'theme-midnight', 'theme-emerald', 'theme-cosmic', 'theme-royal-gold', 'theme-platinum-gold', 'theme-metallic', 'dark');
  root.classList.add(`theme-${theme}`);
  if (theme === 'silver' || theme === 'corporate-blue' || theme === 'metallic') root.classList.add('theme-light');
  if (theme === 'corporate-slate') root.classList.add('theme-cosmic');
  const isLightTheme = theme === 'light' || theme === 'silver' || theme === 'corporate-blue' || theme === 'metallic';
  if (!isLightTheme) root.classList.add('dark');
  root.setAttribute('data-theme', theme);
  try {
    root.style.colorScheme = isLightTheme ? 'light' : 'dark';
  } catch {
    /* ignore */
  }
}


/** Cycle next theme (header / keyboard helper) */
export function cycleTheme(current: AppTheme): AppTheme {
  return current === 'light' ? 'cosmic' : 'light';
}

export function formatCurrencyValue(val: number, currency: CurrencyFormat = 'BDT'): string {
  const symbols: Record<CurrencyFormat, string> = {
    BDT: '৳',
    USD: '$',
    EUR: '€',
    INR: '₹'
  };
  const sym = symbols[currency] || '৳';
  return `${sym}${val.toLocaleString()}`;
}
