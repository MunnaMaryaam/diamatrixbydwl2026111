/**
 * Supabase connection for the browser.
 *
 * Uses ONLY the project URL and the PUBLISHABLE key (safe to ship in a browser). Everything the key
 * can reach is limited by Row Level Security + the signed-in user (see supabase/migrations).
 * Never put a secret / service-role key in this app.
 */
import { createClient, type SupabaseClient } from '@supabase/supabase-js';

// Static `import.meta.env.VITE_*` references so Vite can inline them in the build.
const URL_ = String(import.meta.env.VITE_SUPABASE_URL || '').trim();
const KEY_ = String(import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();
const EMAIL_DOMAIN = String(import.meta.env.VITE_LOGIN_EMAIL_DOMAIN || 'diamatrix.app').trim().toLowerCase();

/** A secret key must never be used in a browser. If someone pastes one here, refuse to start. */
const LOOKS_LIKE_SECRET = /^sb_secret_/i.test(KEY_);

let client: SupabaseClient | null = null;

export function isCloudConfigured(): boolean {
  return Boolean(URL_ && KEY_) && !LOOKS_LIKE_SECRET;
}

export function cloudConfigProblem(): string | null {
  if (LOOKS_LIKE_SECRET) return 'A secret key was found in VITE_SUPABASE_PUBLISHABLE_KEY. Use the publishable key only.';
  return null;
}

export function getSupabase(): SupabaseClient | null {
  if (!isCloudConfigured()) return null;
  if (!client) {
    client = createClient(URL_, KEY_, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
    });
  }
  return client;
}

export function supabaseUrl(): string {
  return URL_;
}

export function supabaseKey(): string {
  return KEY_;
}

/** People log in with a username; Supabase needs an email, so a username becomes username@<domain>. */
export function loginIdentifierToEmail(identifier: string): string {
  const v = identifier.trim().toLowerCase();
  return v.includes('@') ? v : `${v}@${EMAIL_DOMAIN}`;
}

/** True when the error means "could not reach Supabase" (as opposed to "Supabase said no"). */
export function isNetworkError(err: unknown): boolean {
  const msg = String((err as any)?.message ?? err ?? '').toLowerCase();
  const name = String((err as any)?.name ?? '');
  return (
    name === 'TypeError' ||
    name === 'AuthRetryableFetchError' ||
    msg.includes('failed to fetch') ||
    msg.includes('networkerror') ||
    msg.includes('network request failed') ||
    msg.includes('load failed') ||
    msg.includes('fetch failed')
  );
}
