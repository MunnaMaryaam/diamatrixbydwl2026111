/**
 * Cloud sync (Supabase) for DiaMatrix.
 *
 * The app keeps working from the browser's own storage (fast, works offline). This module mirrors that
 * data to Supabase so every signed-in user sees the same data:
 *   - small shared documents (settings, refill orders, festival scheme, ...) -> table app_documents
 *   - daily inventory snapshots (large) -> daily_snapshots + daily_snapshot_chunks
 * Conflict rule: last write wins per document. Nothing here ever throws into the UI.
 */
import { getSupabase, isCloudConfigured } from './supabaseClient';
import { getSnapshotsFromIdb, saveSnapshotToIdb } from './indexedDbEngine';
import type { DailyInventorySnapshot } from './dailyStorageEngine';

/** localStorage keys that are shared through the cloud. */
export const CLOUD_DOC_KEYS = [
  'dwl_analytics_app_settings',
  'dmx_refill_orders_v1',
  'dmx_refill_po_seq',
  'diamatrix.festivalScheme.v1',
  'dmx_refill_suppliers',
  'diamatrix_column_maps_v1',
] as const;

const META_KEY = 'dmx.cloud.meta.v1';
const PENDING_SNAPS_KEY = 'dmx.cloud.pendingSnapshots.v1';
const BACKUP_PREFIX = 'dmx.cloud.backup.';
const CHUNK_SIZE = 1000;

export type CloudState = 'off' | 'idle' | 'syncing' | 'ok' | 'error';
export interface CloudStatus { state: CloudState; lastSyncAt?: number; message?: string }

let status: CloudStatus = { state: isCloudConfigured() ? 'idle' : 'off' };
export function getCloudStatus(): CloudStatus { return status; }
function setStatus(next: CloudStatus) {
  status = next;
  try { window.dispatchEvent(new CustomEvent('dmx-cloud-status', { detail: next })); } catch { /* not in a browser */ }
}

/* ------------------------------- local meta -------------------------------- */
interface Meta { synced: Record<string, string>; dirty: string[] }
function readMeta(): Meta {
  try {
    const raw = window.localStorage.getItem(META_KEY);
    const p = raw ? JSON.parse(raw) : {};
    return { synced: p.synced && typeof p.synced === 'object' ? p.synced : {}, dirty: Array.isArray(p.dirty) ? p.dirty : [] };
  } catch { return { synced: {}, dirty: [] }; }
}
function writeMeta(m: Meta) {
  try { window.localStorage.setItem(META_KEY, JSON.stringify(m)); } catch { /* quota */ }
}
function readPending(): string[] {
  try { const v = JSON.parse(window.localStorage.getItem(PENDING_SNAPS_KEY) || '[]'); return Array.isArray(v) ? v : []; } catch { return []; }
}
function writePending(ids: string[]) {
  try { window.localStorage.setItem(PENDING_SNAPS_KEY, JSON.stringify([...new Set(ids)])); } catch { /* quota */ }
}

/* ------------------------------ shared documents ---------------------------- */
let applyingRemote = false;
let installed = false;
let flushTimer: number | undefined;

/** Watches writes to the shared localStorage keys so changes are uploaded automatically. */
export function installCloudSync(): void {
  if (installed || typeof window === 'undefined' || !isCloudConfigured()) return;
  installed = true;
  const original = Storage.prototype.setItem;
  Storage.prototype.setItem = function patched(this: Storage, key: string, value: string) {
    original.call(this, key, value);
    try {
      if (this === window.localStorage && !applyingRemote && (CLOUD_DOC_KEYS as readonly string[]).includes(key)) markDirty(key);
    } catch { /* never break the app's own save */ }
  };
}

function markDirty(key: string) {
  const m = readMeta();
  if (!m.dirty.includes(key)) { m.dirty.push(key); writeMeta(m); }
  if (flushTimer !== undefined) window.clearTimeout(flushTimer);
  flushTimer = window.setTimeout(() => { void flushDirtyDocs(); }, 2000);
}

async function currentUserId(): Promise<string | null> {
  const sb = getSupabase();
  if (!sb) return null;
  const { data } = await sb.auth.getSession();
  return data.session?.user?.id ?? null;
}

/** Uploads every locally-changed shared document. */
export async function flushDirtyDocs(): Promise<void> {
  const sb = getSupabase();
  if (!sb) return;
  const uid = await currentUserId();
  if (!uid) return; // not signed in: keep them marked dirty
  const m = readMeta();
  const remaining: string[] = [];
  for (const key of m.dirty) {
    const raw = window.localStorage.getItem(key);
    if (raw == null) continue;
    const updatedAt = new Date().toISOString();
    const { error } = await sb.from('app_documents').upsert({ key, value: { raw }, updated_at: updatedAt, updated_by: uid }, { onConflict: 'key' });
    if (error) { remaining.push(key); continue; }
    m.synced[key] = updatedAt;
  }
  m.dirty = remaining;
  writeMeta(m);
}

/** Downloads shared documents that are newer in the cloud. Returns the keys that changed locally. */
async function pullDocs(): Promise<string[]> {
  const sb = getSupabase();
  if (!sb) return [];
  const { data, error } = await sb.from('app_documents').select('key,value,updated_at');
  if (error) throw error;
  const m = readMeta();
  const changed: string[] = [];
  const remoteKeys = new Set<string>();
  for (const doc of data ?? []) {
    const key = String((doc as any).key);
    if (!(CLOUD_DOC_KEYS as readonly string[]).includes(key)) continue;
    remoteKeys.add(key);
    if (m.dirty.includes(key)) continue; // our unsent change wins; it will be uploaded
    const remoteAt = String((doc as any).updated_at);
    const known = m.synced[key];
    if (known && Date.parse(known) >= Date.parse(remoteAt)) continue;
    const raw = (doc as any).value?.raw;
    if (typeof raw !== 'string') continue;
    const local = window.localStorage.getItem(key);
    if (local !== raw) {
      if (local != null && !known) {
        try { window.localStorage.setItem(BACKUP_PREFIX + key, local); } catch { /* quota */ }
      }
      applyingRemote = true;
      try { window.localStorage.setItem(key, raw); } finally { applyingRemote = false; }
      changed.push(key);
    }
    m.synced[key] = remoteAt;
  }
  // Documents that only exist on this computer (first time using the cloud) are uploaded.
  for (const key of CLOUD_DOC_KEYS) {
    if (!remoteKeys.has(key) && window.localStorage.getItem(key) != null && !m.dirty.includes(key)) m.dirty.push(key);
  }
  writeMeta(m);
  return changed;
}

/* ---------------------------------- snapshots -------------------------------- */
function chunkArray<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

/** Uploads one snapshot (header first, then records in chunks, then the final chunk count). */
export async function pushSnapshotNow(snapshot: DailyInventorySnapshot): Promise<void> {
  const sb = getSupabase();
  if (!sb) return;
  const uid = await currentUserId();
  if (!uid) throw new Error('Not signed in');
  const records = Array.isArray(snapshot.records) ? snapshot.records : [];
  if (records.length === 0) return;
  const { records: _omit, ...meta } = snapshot as any;
  const chunks = chunkArray(records, CHUNK_SIZE);
  const now = new Date().toISOString();

  let r = await sb.from('daily_snapshots').upsert(
    { id: snapshot.id, snapshot_date: snapshot.date, label: snapshot.label ?? '', meta, chunk_count: 0, updated_at: now, created_by: uid },
    { onConflict: 'id' },
  );
  if (r.error) throw r.error;
  for (let i = 0; i < chunks.length; i++) {
    r = await sb.from('daily_snapshot_chunks').upsert({ snapshot_id: snapshot.id, idx: i, records: chunks[i] }, { onConflict: 'snapshot_id,idx' });
    if (r.error) throw r.error;
  }
  const del = await sb.from('daily_snapshot_chunks').delete().eq('snapshot_id', snapshot.id).gte('idx', chunks.length);
  if (del.error) throw del.error;
  r = await sb.from('daily_snapshots').update({ chunk_count: chunks.length, updated_at: new Date().toISOString() }).eq('id', snapshot.id);
  if (r.error) throw r.error;
}

/** Called after a snapshot is saved locally. Fire-and-forget; failures are retried at the next sign-in. */
export function queueSnapshotPush(snapshot: DailyInventorySnapshot): void {
  if (!isCloudConfigured()) return;
  void pushSnapshotNow(snapshot).catch(() => writePending([...readPending(), snapshot.id]));
}

export function queueSnapshotDelete(id: string): void {
  const sb = getSupabase();
  if (!sb) return;
  writePending(readPending().filter((x) => x !== id));
  void sb.from('daily_snapshots').delete().eq('id', id).then(() => undefined, () => undefined);
}

async function pullSnapshots(): Promise<number> {
  const sb = getSupabase();
  if (!sb) return 0;
  const { data: remote, error } = await sb.from('daily_snapshots').select('id,chunk_count,meta');
  if (error) throw error;
  const local = await getSnapshotsFromIdb();
  const localIds = new Set(local.map((s) => s.id));
  let added = 0;
  for (const row of remote ?? []) {
    const id = String((row as any).id);
    const count = Number((row as any).chunk_count || 0);
    if (localIds.has(id) || count === 0) continue;
    const { data: chunks, error: cErr } = await sb.from('daily_snapshot_chunks').select('idx,records').eq('snapshot_id', id).order('idx', { ascending: true });
    if (cErr) throw cErr;
    if (!chunks || chunks.length !== count) continue; // incomplete upload in progress; try next time
    const records = chunks.flatMap((c: any) => (Array.isArray(c.records) ? c.records : []));
    await saveSnapshotToIdb({ ...(row as any).meta, id, records } as DailyInventorySnapshot);
    added++;
  }
  // First computer to use the cloud: upload what it already has. After that, only snapshots whose upload failed earlier.
  const remoteIds = new Set((remote ?? []).map((r: any) => String(r.id)));
  const toPush = remoteIds.size === 0 ? local : local.filter((s) => readPending().includes(s.id));
  const stillPending: string[] = [];
  for (const s of toPush) {
    try { await pushSnapshotNow(s); } catch { stillPending.push(s.id); }
  }
  writePending(remoteIds.size === 0 ? stillPending : readPending().filter((id) => stillPending.includes(id)));
  return added;
}

/* ------------------------------------ orchestrator --------------------------- */
let running: Promise<{ changed: boolean }> | null = null;

/** Run after sign-in / app start. Resolves with changed=true when local data was updated from the cloud. */
export function syncWithCloud(): Promise<{ changed: boolean }> {
  if (!isCloudConfigured() || typeof window === 'undefined') return Promise.resolve({ changed: false });
  if (running) return running;
  installCloudSync();
  running = (async () => {
    setStatus({ ...status, state: 'syncing' });
    try {
      if (!(await currentUserId())) { setStatus({ state: 'idle' }); return { changed: false }; }
      const docs = await pullDocs();
      const snaps = await pullSnapshots();
      await flushDirtyDocs();
      setStatus({ state: 'ok', lastSyncAt: Date.now() });
      return { changed: docs.length > 0 || snaps > 0 };
    } catch (err: any) {
      setStatus({ state: 'error', message: String(err?.message || err) });
      return { changed: false };
    } finally {
      running = null;
    }
  })();
  return running;
}
