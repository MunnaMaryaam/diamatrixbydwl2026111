import {
  exportCorporateExcel,
  exportCorporatePdf,
  exportCorporateReport,
  type CorporateExportOptions,
} from './corporateExportEngine';

export const DUMMY_CORPORATE_TABLE: CorporateExportOptions = {
  title: 'Inventory Valuation & Branch Performance',
  filename: 'Inventory_Valuation_Branch_Performance',
  period: '01-Oct-2026 to 03-Oct-2026',
  columns: [
    { key: 'branch', header: 'Branch', width: 28, align: 'left' },
    { key: 'sku', header: 'SKU / Style', width: 22, align: 'left' },
    { key: 'category', header: 'Category', width: 18, align: 'left' },
    { key: 'stock', header: 'Stock', width: 12, align: 'right', numberFormat: '#,##0' },
    { key: 'sold', header: 'Sold', width: 12, align: 'right', numberFormat: '#,##0' },
    { key: 'inventoryValue', header: 'Inventory Value', width: 18, align: 'right', numberFormat: '৳#,##0' },
    { key: 'turnRate', header: 'Turn Rate', width: 14, align: 'right', numberFormat: '0.00x' },
  ],
  rows: [
    { branch: 'Dhaka', sku: 'DN-2026-001', category: 'Diamond Necklace', stock: 1, sold: 8, inventoryValue: 300000, turnRate: 8 },
    { branch: 'Chittagong', sku: 'DN-2026-001', category: 'Diamond Necklace', stock: 4, sold: 0, inventoryValue: 1200000, turnRate: 0 },
    { branch: 'Dhaka', sku: 'RG-2026-014', category: 'Gold Ring', stock: 18, sold: 31, inventoryValue: 620000, turnRate: 1.72 },
    { branch: 'Sylhet', sku: 'NP-2026-008', category: 'Nosepin', stock: 42, sold: 57, inventoryValue: 315000, turnRate: 1.36 },
  ],
};

export async function exportDummyCorporateExcel(): Promise<void> {
  await exportCorporateExcel(DUMMY_CORPORATE_TABLE);
}

export async function exportDummyCorporatePdf(): Promise<void> {
  await exportCorporatePdf(DUMMY_CORPORATE_TABLE);
}

export async function exportDummyCorporateReport(): Promise<void> {
  await exportCorporateReport(DUMMY_CORPORATE_TABLE);
}
