/**
 * Software-format exports: coloured Excel + reliable PDF (no popup required).
 *
 * PRODUCTION RULE — Premium corporate layout preservation:
 * Every Excel and PDF export path must mirror the on-screen DiaMatrix UI:
 *  - Brand typography: Calibri / Arial stack, bold headers, tabular nums
 *  - Luxury Silver / Gold accents on title bars and KPI ribbons
 *  - Clean slate borders with light bevel (white top/left)
 *  - Company branding block kept intact on every export document
 *  - Header fill #D9E2EC / navy text; zebra body rows; semantic move-in/out fills
 */
import type { RedistributionReport } from '../types';
import { getReportDimension } from './reportDimension';
import {
  getBranchDisplayName,
  isOnlineBranch,
  isExcludedOutlet,
  isWarehouseBranchCode,
  isLockedRetailOutletCode,
  toLockedOutletShortcut,
  getLockedRetailOutletsOrdered,
} from './dataIdentityEngine';
import { getReportCategoryLabel } from './redistributionEngine';
import { getStoredSettings } from './settingsEngine';
import { exportCorporatePdf } from './corporateExportEngine';
import { BRAND as APP_BRAND } from '../brand';
import * as ExcelJS from 'exceljs';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

/**
 * DWL / Diamond World LTD / WHL = warehouse reserve only.
 * Never an outlet column (no Sold / Move IN/OUT). Front column = DWL Stock.
 */
function isRetailOutletBranch(b: string): boolean {
  if (!b || b === 'WHL' || b === 'DWL') return false;
  if (isWarehouseBranchCode(b) || isOnlineBranch(b) || isExcludedOutlet(b)) return false;
  // Strict lock: only GUL, BCT, KBH, … from user master list
  return isLockedRetailOutletCode(b);
}

/**
 * Full locked outlet list in user order (GUL…SYL).
 * Merges matrix branch keys so cell lookup works; missing outlets still appear (zeros).
 */
function resolveLockedOutletColumns(matrixBranches: string[] | undefined): string[] {
  const byShortcut = new Map<string, string>();
  (matrixBranches || []).forEach((b) => {
    if (!isRetailOutletBranch(b)) return;
    const sc = toLockedOutletShortcut(b);
    if (!byShortcut.has(sc)) byShortcut.set(sc, b);
    const up = String(b).toUpperCase().trim();
    if (up === sc) byShortcut.set(sc, b);
  });
  return getLockedRetailOutletsOrdered().map((code) => byShortcut.get(code) || code);
}

/** Sum warehouse stock for one item key (handles DWL, WHL, "Diamond World LTD", …). */
function sumWarehouseStock(
  report: RedistributionReport,
  weightKey: string,
): number {
  const cells = report.matrix?.cells || {};
  // Warehouse keys can be present in cells without appearing in matrix.branches.
  const branches = Array.from(new Set([
    ...(report.matrix?.branches || []),
    ...Object.keys(cells),
  ]));
  let total = 0;
  const seen = new Set<string>();
  for (const b of branches) {
    if (!isWarehouseBranchCode(b) && b !== 'DWL' && b !== 'WHL') continue;
    if (seen.has(b)) continue;
    seen.add(b);
    total += Number(cells[b]?.[weightKey]?.stock ?? 0);
  }
  // Legacy keys if not already in branches list
  for (const k of ['DWL', 'WHL'] as const) {
    if (seen.has(k)) continue;
    total += Number(cells[k]?.[weightKey]?.stock ?? 0);
  }
  return total;
}

const DEFAULT_DATE_RANGE = '01-03-2026 to 19-09-2026';
const BRAND = {
  short: 'DiaMatrix',
  full: 'DiaMatrix',
};

/** Luxury silver / gold palette used on export title bars and accent rules */
const LUXURY = {
  silver: 'C0C7D1',
  silverLight: 'E8ECF1',
  gold: 'C9A227',
  goldSoft: 'F5E6B8',
  navy: '0B2545',
  border: '94A3B8',
} as const;

export function esc(v: unknown): string {
  return String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function downloadBlob(blob: Blob, filename: string) {
  if (!blob || blob.size === 0) throw new Error('The report file is empty.');
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.rel = 'noopener';
  a.style.position = 'fixed';
  a.style.left = '-9999px';
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 10000);
}

/** Cell styles matching on-screen matrix */
export const CELL = {
  th: 'background:#D9E2EC;color:#0B2545;font-weight:700;border:1px solid #94A3B8;padding:6px 8px;text-align:center;white-space:normal;vertical-align:middle;font-family:Calibri,Arial,sans-serif;font-size:11px;',
  thSub:
    'background:#E8EEF4;color:#0B2545;font-weight:600;border:1px solid #94A3B8;padding:4px 6px;text-align:center;font-size:10px;font-family:Calibri,Arial,sans-serif;',
  td: 'border:1px solid #94a3b8;padding:4px 6px;text-align:center;vertical-align:middle;white-space:normal;font-family:Calibri,Arial,sans-serif;font-size:11px;',
  tdLeft:
    'border:1px solid #94a3b8;padding:4px 8px;text-align:left;font-weight:700;background:#f1f5f9;vertical-align:middle;font-family:Calibri,Arial,sans-serif;font-size:11px;',
  // Keep calculations/formulas/KPIs neutral. Movement uses text-only semantic emphasis.
  moveIn: 'color:#000000;font-weight:800;',
  moveOut: 'color:#000000;font-weight:800;',
  moveInBg: 'background:#c6efce;color:#000000;font-weight:800;',
  moveOutBg: 'background:#ffc7ce;color:#000000;font-weight:800;',
  zero: 'color:#000000;font-weight:800;',
  title: 'font-size:16px;font-weight:800;color:#0f172a;padding:8px 0;font-family:Calibri,Arial,sans-serif;',
  meta: 'font-size:11px;color:#475569;padding:2px 0;font-family:Calibri,Arial,sans-serif;',
};

export function netMoveCell(n: number): string {
  const v = Math.round(Number(n) || 0);
  if (v > 0) return `<td style="${CELL.td}${CELL.moveIn}">+${v}</td>`;
  if (v < 0) return `<td style="${CELL.td}${CELL.moveOut}">${v}</td>`;
  return `<td style="${CELL.td}${CELL.zero}">0</td>`;
}

export type StyledSheet = {
  name: string;
  /** Full HTML fragment (tables with inline styles) */
  html: string;
};

/** Multi-table coloured .xls — Excel / Sheets open with borders & colours */
export function downloadStyledExcel(sheets: StyledSheet[], filenameBase: string) {
  void (async () => {
    const wb = new ExcelJS.Workbook();
    wb.creator = 'DiaMatrix';
    wb.company = 'DiaMatrix';
    for (const sheet of sheets) {
      const ws = createSheet(wb, sheet.name.slice(0, 31) || 'Report');
      setupExcelSheet(ws);
      const doc = new DOMParser().parseFromString(`<div>${sheet.html}</div>`, 'text/html');
      const tables = Array.from(doc.querySelectorAll('table'));
      if (!tables.length) {
        const row = ws.addRow([doc.body.textContent?.trim() || 'No data']);
        styleExcelBody(row);
      } else {
        for (const table of tables) {
          for (const tr of Array.from(table.querySelectorAll('tr'))) {
            const values = Array.from(tr.querySelectorAll('th,td')).map((cell) => cell.textContent?.trim() || '');
            const row = ws.addRow(values);
            const hasHeader = tr.querySelector('th') != null;
            if (hasHeader) styleExcelHeader(row, EXECUTION_COLORS.deepBlue);
            else styleExcelBody(row);
          }
          ws.addRow([]);
        }
      }
      for (let i = 1; i <= ws.columnCount; i++) ws.getColumn(i).width = Math.min(42, Math.max(14, i === 1 ? 28 : 16));
      applyGlobalSheetFill(ws);
    }
    const buffer = await wb.xlsx.writeBuffer();
    const name = `${filenameBase.replace(/\.xls[x]?$/i, '')}.xlsx`;
    downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), name);
  })().catch((error) => {
    console.error('ExcelJS export failed:', error);
    window.alert('Excel export failed. Please try again.');
  });
}

/**
 * Reliable PDF path:
 * 1) Hidden iframe + print (no popup blocker)
 * 2) Fallback: download printable HTML (user opens → Ctrl+P → Save as PDF)
 */

/**
 * Print an on-screen report root while preserving layout.
 * Marks body + root, invokes window.print, then cleans up.
 * Requires print.css (imported via index.css) and data-dmx-report-print-root on the root node.
 */
export function printDomReportRoot(root?: HTMLElement | null): void {
  const el =
    root ||
    (document.querySelector('[data-dmx-report-print-root="true"]') as HTMLElement | null);
  if (!el) {
    window.print();
    return;
  }
  el.setAttribute('data-dmx-report-print-root', 'true');
  document.body.classList.add('dmx-printing-report');
  const cleanup = () => {
    document.body.classList.remove('dmx-printing-report');
    window.removeEventListener('afterprint', cleanup);
  };
  window.addEventListener('afterprint', cleanup, { once: true });
  // Fallback cleanup if afterprint does not fire
  setTimeout(cleanup, 60_000);
  try {
    window.focus();
    window.print();
  } catch {
    cleanup();
  }
}

/**
 * Wrap arbitrary table/section HTML as one outlet page for multi-page PDF/print.
 */
export function asOutletPrintPage(title: string, innerHtml: string, meta?: string): string {
  return `<section class="dmx-outlet-page" data-dmx-outlet-page="true">
  <h2>${esc(title)}</h2>
  ${meta ? `<div class="dmx-meta">${esc(meta)}</div>` : ''}
  ${innerHtml}
</section>`;
}

/** Shared print CSS injected into printable HTML / iframe documents. */
export const PRINT_DOCUMENT_CSS = `
  @page { size: A4 portrait; margin: 10mm 8mm 12mm 8mm; }
  * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; box-sizing: border-box; }
  html, body {
    font-family: Calibri, Arial, Helvetica, sans-serif;
    font-size: 10pt;
    color: #0f172a;
    background: #ffffff;
    margin: 0;
    padding: 0;
  }
  body { padding: 2mm 3mm; }
  h1 { font-size: 14pt; font-weight: 800; margin: 0 0 2mm; color: #0f172a; }
  h2 { font-size: 12pt; font-weight: 700; margin: 0 0 2mm; color: #0f172a; page-break-after: avoid; }
  .dmx-meta, .meta {
    color: #334155;
    font-weight: 600;
    font-size: 9pt;
    margin: 0 0 3mm;
  }
  table {
    width: 100%;
    max-width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    font-size: 8.5pt;
    margin: 0 0 3mm;
  }
  th, td {
    border: 1px solid #334155;
    padding: 2.5pt 3.5pt;
    vertical-align: top;
    word-break: break-word;
    overflow-wrap: anywhere;
    color: #0f172a;
    background: #ffffff;
  }
  th {
    background: #e2e8f0;
    font-weight: 700;
    font-size: 8pt;
  }
  td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
  tr { page-break-inside: avoid; break-inside: avoid; }
  thead { display: table-header-group; }
  .move-in { font-weight: 700; background: #f1f5f9; }
  .move-out { font-weight: 700; background: #e2e8f0; }
  .dmx-outlet-page, .section, [data-dmx-outlet-page="true"] {
    display: block;
    width: 100%;
    break-before: page;
    page-break-before: always;
    break-inside: avoid-page;
    page-break-inside: avoid;
    margin: 0;
    padding: 0 0 3mm;
  }
  .dmx-outlet-page:first-child, .section:first-child, [data-dmx-outlet-page="true"]:first-child {
    break-before: auto;
    page-break-before: auto;
  }
`;

/**
 * Build a complete printable HTML document (A4, outlet page-breaks, readable tables).
 */
export function buildPrintableDocumentHtml(title: string, bodyHtml: string): string {
  const whiteLabel = getStoredSettings().whiteLabel;
  const logo = whiteLabel.logoUrl || '/diamatrix-logo-full.png';
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${esc(title)}</title>
<style>${PRINT_DOCUMENT_CSS}</style>
</head>
<body class="dmx-print-document">
<header style="display:flex;align-items:center;gap:14px;border-bottom:3px solid #C9A227;padding:10px 4px 10px;margin-bottom:12px;background:linear-gradient(90deg,#F8FAFC 0%,#E8ECF1 55%,#F5E6B8 100%);border-radius:4px 4px 0 0;">
  <img src="${esc(logo)}" alt="${esc(whiteLabel.companyName)}" style="height:40px;max-width:180px;object-fit:contain;"/>
  <div style="flex:1;min-width:0;">
    <h1 style="margin:0;color:#0B2545;font-size:15pt;letter-spacing:0.01em;">${esc(title)}</h1>
    <div class="dmx-meta" style="color:#475569;font-weight:600;">${esc(whiteLabel.companyName)} · ${esc(BRAND.full)} · ${esc(new Date().toLocaleString())}</div>
  </div>
  <div style="width:4px;align-self:stretch;background:linear-gradient(180deg,#C9A227,#C0C7D1);border-radius:2px;"></div>
</header>
${bodyHtml}
</body>
</html>`;
}

/**
 * Reliable PDF path:
 * 1) Hidden iframe + print (no popup blocker)
 * 2) Fallback: download printable HTML (user opens → Ctrl+P → Save as PDF)
 */
export function downloadPrintablePdf(title: string, bodyHtml: string, filenameBase: string) {
  const fullHtml = buildPrintableDocumentHtml(title, bodyHtml);

  // 1) Hidden iframe print
  try {
    const iframe = document.createElement('iframe');
    iframe.setAttribute('title', 'pdf-print');
    iframe.style.cssText =
      'position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0;pointer-events:none;';
    document.body.appendChild(iframe);
    const doc = iframe.contentDocument || iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(fullHtml);
      doc.close();
      const win = iframe.contentWindow;
      const cleanup = () => {
        setTimeout(() => {
          try {
            document.body.removeChild(iframe);
          } catch {
            /* ignore */
          }
        }, 1000);
      };
      if (win) {
        setTimeout(() => {
          try {
            win.focus();
            win.print();
          } catch {
            /* fallback below */
          }
          cleanup();
        }, 450);
        // Also offer file download so user always gets something
        setTimeout(() => {
          downloadBlob(
            new Blob([fullHtml], { type: 'text/html;charset=utf-8' }),
            `${filenameBase}_PrintToPDF.html`
          );
        }, 600);
        return;
      }
    }
  } catch {
    /* fall through */
  }

  // 2) Direct HTML download
  downloadBlob(
    new Blob([fullHtml], { type: 'text/html;charset=utf-8' }),
    `${filenameBase}_PrintToPDF.html`
  );
  alert(
    'PDF file downloaded as HTML.\nOpen the file → Ctrl+P (or Cmd+P) → Save as PDF.\n(Print dialog may also open automatically.)'
  );
}

function buildMatrixHtml(report: RedistributionReport, period: string, mode: string): string {
  const branches = resolveLockedOutletColumns(report.matrix?.branches);
  const weights = report.matrix?.weights || [];
  const hasDesignBreakdown = weights.some((w) => String(w).includes(' · '));
  const dimension = getReportDimension(report);
  const dimensionLabel = dimension.label;

  const splitItemKey = (key: string): { dimension: string; design: string } => {
    const parts = String(key || '').split(' · ');
    if (parts.length >= 2) {
      return { dimension: parts[0].trim(), design: parts.slice(1).join(' · ').trim() };
    }
    return { dimension: String(key || '').trim(), design: '' };
  };

  const th = (text: string, cls = CELL.th) => `<th style="${cls}">${esc(text)}</th>`;
  const groupTh = (text: string) => `<th colspan="5" style="${CELL.th}">${esc(getBranchDisplayName(text))}</th>`;

  let thead = '<tr>';
  if (hasDesignBreakdown) {
    thead += th('Design Name') + th(dimensionLabel) + th('DWL\nStock');
  } else {
    thead += th(dimensionLabel === 'Amount' ? 'Amount' : 'Particulars Name') + th('DWL\nStock');
  }
  branches.filter((b) => b !== 'DWL').forEach((b) => { thead += groupTh(b); });
  thead += th('Total\nStock') + th('Total\nSold') + th('Refill\nDemand');
  thead += '</tr><tr>';
  if (hasDesignBreakdown) thead += '<th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '">Stock</th>';
  else thead += '<th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '">Stock</th>';
  branches.filter((b) => b !== 'DWL').forEach(() => {
    ['SOLD QTY', 'Current Stock', 'Average', 'Contribution %', 'Move IN/OUT'].forEach((h) => {
      thead += th(h, CELL.thSub);
    });
  });
  thead += '<th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '"></th></tr>';

  let body = '';
  weights.forEach((w) => {
    const { dimension: dimensionValue, design } = splitItemKey(w);
    const dwlStock = sumWarehouseStock(report, w);
    let totalStock = dwlStock;
    let totalSold = 0;
    const branchRows = branches.map((b) => {
      const cell = report.matrix.cells[b]?.[w];
      const sold = Number(cell?.sold ?? 0);
      const stock = Number(cell?.stock ?? 0);
      const avg = cell?.sales3M ? Math.round(cell.sales3M / 3) : Math.round(sold / 3);
      const net = Number(cell?.netMove ?? 0);
      totalStock += stock;
      totalSold += sold;
      return { sold, stock, avg, net };
    });
    const totalSoldForItem = branchRows.reduce((sum, x) => sum + x.sold, 0);
    const refill = report.weightSummaries.find((x) => x.weight === w)?.unmetShortage || Math.max(0, totalSold - totalStock);

    body += '<tr>';
    if (hasDesignBreakdown) {
      body += `<td style="${CELL.tdLeft}">${esc(design || '—')}</td>`;
      body += `<td style="${CELL.td}">${esc(dimensionValue)}</td>`;
    } else {
      body += `<td style="${CELL.tdLeft}">${esc(dimensionValue)}</td>`;
    }
    body += `<td style="${CELL.td}">${Math.round(dwlStock)}</td>`;
    branchRows.forEach(({ sold, stock, avg, net }) => {
      const contrib = totalSoldForItem > 0 ? Math.round((sold / totalSoldForItem) * 100) : 0;
      body += `<td style="${CELL.td}">${Math.round(sold)}</td>`;
      body += `<td style="${CELL.td}">${Math.round(stock)}</td>`;
      body += `<td style="${CELL.td}">${avg}</td>`;
      body += `<td style="${CELL.td}">${contrib}%</td>`;
      if (net > 0) body += `<td style="${CELL.td}${CELL.moveInBg}">+${Math.round(net)}</td>`;
      else if (net < 0) body += `<td style="${CELL.td}${CELL.moveOutBg}">${Math.round(net)}</td>`;
      else body += `<td style="${CELL.td}">0</td>`;
    });
    body += `<td style="${CELL.td}">${Math.round(totalStock)}</td>`;
    body += `<td style="${CELL.td}">${Math.round(totalSold)}</td>`;
    body += `<td style="${CELL.td}">${Math.round(refill)}</td>`;
    body += '</tr>';
  });

  return `<div style="${CELL.meta}">Period: ${esc(period)} · Mode: ${esc(mode)} · Dimension: ${esc(dimensionLabel)}</div>
  <table style="width:100%;border-collapse:collapse;table-layout:fixed;">
    <thead>${thead}</thead>
    <tbody>${body}</tbody>
  </table>`;
}

function buildBranchSummaryHtml(report: RedistributionReport, period: string): string {
  let rows = `<tr>
    <th style="${CELL.th}">Branch</th>
    <th style="${CELL.th}">Total Sold</th>
    <th style="${CELL.th}">Current Stock</th>
    <th style="${CELL.th}">Move IN</th>
    <th style="${CELL.th}">Move OUT</th>
    <th style="${CELL.th}">Net Change</th>
    <th style="${CELL.th}">Status</th>
  </tr>`;
  (report.branchSummaries || []).forEach((b) => {
    rows += `<tr>
      <td style="${CELL.tdLeft}">${esc(getBranchDisplayName(b.branch))}</td>
      <td style="${CELL.td}">${b.totalSold}</td>
      <td style="${CELL.td}">${b.totalCurrentStock}</td>
      <td style="${CELL.td}${CELL.moveIn}">${b.totalMoveIn}</td>
      <td style="${CELL.td}${CELL.moveOut}">${b.totalMoveOut}</td>
      <td style="${CELL.td}">${b.netChange}</td>
      <td style="${CELL.td}">${esc(b.status)}</td>
    </tr>`;
  });
  return `<div style="${CELL.meta}">Period: ${esc(period)}</div>
  <table><tbody>${rows}</tbody></table>`;
}

function buildTransfersHtml(report: RedistributionReport): string {
  let rows = `<tr>
    <th style="${CELL.th}">Order ID</th>
    <th style="${CELL.th}">Item</th>
    <th style="${CELL.th}">From</th>
    <th style="${CELL.th}">To</th>
    <th style="${CELL.th}">Qty</th>
    <th style="${CELL.th}">Priority</th>
    <th style="${CELL.th}">Reason</th>
  </tr>`;
  (report.transferOrders || []).forEach((t) => {
    rows += `<tr>
      <td style="${CELL.td}">${esc(t.id)}</td>
      <td style="${CELL.td}">${esc(t.weight)}</td>
      <td style="${CELL.td}">${esc(getBranchDisplayName(t.fromBranch))}</td>
      <td style="${CELL.td}">${esc(getBranchDisplayName(t.toBranch))}</td>
      <td style="${CELL.td}">${t.qty}</td>
      <td style="${CELL.td}">${esc(t.priority)}</td>
      <td style="${CELL.tdLeft}">${esc(t.reason)}</td>
    </tr>`;
  });
  return `<table><tbody>${rows}</tbody></table>`;
}

function buildRefillHtml(report: RedistributionReport): string {
  let rows = `<tr>
    <th style="${CELL.th}">Item</th>
    <th style="${CELL.th}">Qty to Buy</th>
    <th style="${CELL.th}">Sold Demand</th>
    <th style="${CELL.th}">Available Stock</th>
    <th style="${CELL.th}">Urgency</th>
    <th style="${CELL.th}">Rationale</th>
  </tr>`;
  (report.procurementOrders || []).forEach((p) => {
    rows += `<tr>
      <td style="${CELL.tdLeft}">${esc(p.weight)}</td>
      <td style="${CELL.td}">${p.qtyToBuy}</td>
      <td style="${CELL.td}">${p.soldDemand}</td>
      <td style="${CELL.td}">${p.availableStock}</td>
      <td style="${CELL.td}">${esc(p.urgency)}</td>
      <td style="${CELL.tdLeft}">${esc(p.rationale)}</td>
    </tr>`;
  });
  return `<table><tbody>${rows}</tbody></table>`;
}

/** Full software-style Excel (matrix + branch + moves + refill) */
export function exportStyledExcelReport(
  report: RedistributionReport,
  period: string,
  allocationMode: string,
  _whiteLabel?: import('./settingsEngine').WhiteLabelSettings
): void {
  const mode = (['contribution', 'baseline', 'hybrid', 'liquidity', 'demand_backup', 'coverage'].includes(allocationMode)
    ? allocationMode
    : 'contribution') as ExecutionMode;
  void exportExecutionExcelReport(report, mode);
}

/** PDF: print dialog + HTML fallback download */
export function exportReportPdf(
  report: RedistributionReport,
  period: string,
  allocationMode: string,
  _whiteLabel?: import('./settingsEngine').WhiteLabelSettings
): void {
  const mode = (['contribution', 'baseline', 'hybrid', 'liquidity', 'demand_backup', 'coverage'].includes(allocationMode)
    ? allocationMode
    : 'contribution') as ExecutionMode;
  void exportExecutionPdfReport(report, mode);
}

/**
 * Generic AOA (array of arrays) → software-format styled Excel table.
 * First row = header. Soft light-gray headers + soft green/pink movement cells.
 * netMoveColIndex / movementColIndexes (0-based) get print-friendly Move colours.
 */
export function exportAoaStyledExcel(
  sheets: {
    name: string;
    rows: (string | number | null | undefined)[][];
    netMoveColIndex?: number;
    /** Extra 0-based column indexes to colour as movement (Withdraw / Receive / Move IN…) */
    movementColIndexes?: number[];
  }[],
  filenameBase: string
) {
  void (async () => {
    const wb = new ExcelJS.Workbook();
    wb.creator = 'DiaMatrix';
    wb.company = 'DiaMatrix';
    for (const sheet of sheets) {
      const ws = createSheet(wb, sheet.name.slice(0, 31) || 'Report');
      setupExcelSheet(ws);
      if (!sheet.rows.length) {
        ws.addRow(['No data']);
        continue;
      }
      const [header, ...body] = sheet.rows;
      styleExcelHeader(ws.addRow(header.map((v) => v ?? '')), 'D9E2EC');
      const moveIdx = new Set<number>();
      if (sheet.netMoveColIndex != null) moveIdx.add(sheet.netMoveColIndex);
      (sheet.movementColIndexes || []).forEach((i) => moveIdx.add(i));
      body.forEach((values) => {
        const row = ws.addRow(values.map((v) => v ?? ''));
        styleExcelBody(row);
        moveIdx.forEach((zeroBased) => {
          const index = zeroBased + 1;
          const raw = Number(values[zeroBased]);
          if (Number.isFinite(raw) && values[zeroBased] !== '' && values[zeroBased] != null) {
            styleMovementCell(row.getCell(index), raw);
          }
        });
      });
      for (let i = 1; i <= ws.columnCount; i++) ws.getColumn(i).width = i === 1 ? 28 : 14;
      applyGlobalSheetFill(ws);
      ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: Math.max(1, ws.rowCount), column: ws.columnCount } };
      ws.views = [{ showGridLines: true, state: 'frozen', ySplit: 1 }];
    }
    const buffer = await wb.xlsx.writeBuffer();
    downloadBlob(
      new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
      `${filenameBase.replace(/\.xlsx?$/i, '')}.xlsx`
    );
  })();
}

/* --------------------------------------------------------------------------
 * ExcelJS + jsPDF execution export engine
 * -------------------------------------------------------------------------- */
const EXECUTION_COLORS = {
  navy: '0A0F1D', white: 'FFFFFF', slate: 'F4F6F9', deepBlue: '0B3D5C',
  blue: '0F4C81', ice: 'E6F0FA',
  silver: LUXURY.silverLight, silverDeep: LUXURY.silver,
  red: '9B1C1C', gold: LUXURY.gold, goldSoft: LUXURY.goldSoft, green: '14532D',
  border: LUXURY.border, text: '0F172A',
  headerBg: 'D9E2EC', headerText: LUXURY.navy,
  bodyBg: 'FFFFFF', bodyText: '0F172A',
  accentBar: LUXURY.gold,
};
type ExecutionMode = 'contribution' | 'baseline' | 'hybrid' | 'liquidity' | 'demand_backup' | 'coverage';
const executionModeLabel = (mode: ExecutionMode) =>
  mode === 'contribution' ? 'Contribution'
  : mode === 'baseline' ? '3-Month Baseline'
  : mode === 'hybrid' ? 'Hybrid'
  : mode === 'liquidity' ? 'Capital Liquidity'
  : mode === 'demand_backup' ? 'Demand-Backup & Safety'
  : 'Universal Coverage';

function excelFill(color: string): any { return { type: 'pattern', pattern: 'solid', fgColor: { argb: `FF${color}` } }; }
/** Default: bold Calibri 13pt — larger, high-contrast Excel report typography */
/** Move IN / OUT cells: BLACK, BOLD, large (readable at a glance when printed). */
const MOVE_FONT_SIZE = 16;
function excelFont(color: string, bold = true, size = 13): any { return { name: 'Calibri', size, bold, color: { argb: `FF${color}` } }; }
function excelBorder(color = EXECUTION_COLORS.border): any {
  const side: any = { style: 'thin', color: { argb: `FF${color}` } };
  return { top: side, bottom: side, left: side, right: side };
}
function shade(hex: string, amt: number): string {
  // mix with white (amt>0) or black (amt<0)
  const n = parseInt(hex, 16); const t = amt < 0 ? 0 : 255; const p = Math.abs(amt);
  const ch = (v: number) => Math.round((t - v) * p + v).toString(16).padStart(2, '0');
  return (ch((n >> 16) & 255) + ch((n >> 8) & 255) + ch(n & 255)).toUpperCase();
}
function gradientFill(top: string, bottom: string): any {
  return { type: 'gradient', gradient: 'angle', degree: 90, stops: [{ position: 0, color: { argb: `FF${top}` } }, { position: 1, color: { argb: `FF${bottom}` } }] };
}
/** Raised "3D" edge: light top/left, dark bottom/right. */
function bevelBorder(light: string, dark: string, style: 'thin' | 'medium' = 'thin'): any {
  const l: any = { style, color: { argb: `FF${light}` } };
  const d: any = { style, color: { argb: `FF${dark}` } };
  return { top: l, left: l, bottom: d, right: d };
}
/** True when fill is light → BLACK text required. */
function isLightFill(hex: string): boolean {
  const h = String(hex || '').replace(/^#/, '').toUpperCase();
  if (!/^[0-9A-F]{6}$/.test(h)) return true;
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 >= 0.55;
}

function paintHeaderCell(c: any, fill: string) {
  // Light header fills + BOLD BLACK text (never same colour as background)
  let bg = String(fill || EXECUTION_COLORS.headerBg).replace(/^#/, '').toUpperCase();
  if (!isLightFill(bg)) bg = 'D9E2EC';
  c.fill = excelFill(bg);
  c.font = excelFont('000000', true, 13);
  c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
  c.border = bevelBorder('FFFFFF', '64748B', 'thin');
}
function styleExcelHeader(row: any, fill = EXECUTION_COLORS.headerBg) {
  row.height = 38;
  row.eachCell((c: any) => paintHeaderCell(c, fill));
}
function styleExcelBody(row: any) {
  row.height = 26;
  row.eachCell((c: any, col: number) => {
    // Light bg + BOLD BLACK text — maximum contrast
    const bg = col === 1 ? 'E8EEF4' : row.number % 2 === 0 ? 'F8FAFC' : 'FFFFFF';
    c.fill = excelFill(bg);
    c.font = excelFont('000000', true, 12);
    c.alignment = { vertical: 'middle', horizontal: col === 1 ? 'left' : 'center', wrapText: true };
    c.border = bevelBorder('FFFFFF', '64748B');
  });
}
function styleMovementCell(c: any, value: number) {
  // Light green/pink fills + dark opposite bold text
  const v = Math.round(Number(value) || 0);
  c.alignment = { horizontal: 'center', vertical: 'middle' };
  c.border = excelBorder('64748B');
  if (v > 0) {
    c.value = `+${v}`;
    c.fill = excelFill('C6EFCE');
    c.font = excelFont('000000', true, MOVE_FONT_SIZE);
  } else if (v < 0) {
    c.value = `${v}`;
    c.fill = excelFill('FFC7CE');
    c.font = excelFont('000000', true, MOVE_FONT_SIZE);
  } else {
    c.value = '0';
    c.fill = excelFill('FFFFFF');
    c.font = excelFont('000000', true, MOVE_FONT_SIZE);
  }
}
/** Excel sheet names: max 31 chars, no \ / ? * [ ] :, unique per workbook (case-insensitive). */
function safeSheetName(wb: any, raw: string): string {
  const base = (String(raw || 'Report').replace(/[\\/?*\[\]:]/g, ' ').replace(/\s+/g, ' ').trim() || 'Report').slice(0, 31);
  const taken = new Set<string>((wb.worksheets || []).map((w: any) => String(w.name).toLowerCase()));
  if (!taken.has(base.toLowerCase())) return base;
  for (let i = 2; i < 1000; i++) {
    const suffix = ` (${i})`;
    const candidate = base.slice(0, 31 - suffix.length) + suffix;
    if (!taken.has(candidate.toLowerCase())) return candidate;
  }
  return base.slice(0, 27) + Date.now().toString().slice(-4);
}
/** Create a worksheet and immediately enable gridlines. */
function createSheet(wb: any, name: string): any {
  const worksheet = wb.addWorksheet(safeSheetName(wb, name));
  worksheet.views = [{ showGridLines: true }];
  return worksheet;
}
function setupExcelSheet(ws: any) {
  // Frozen header + first column mirrors the on-screen matrix cockpit layout
  ws.views = [{ showGridLines: true, state: 'frozen', xSplit: 1, ySplit: 4 }];
  ws.properties.defaultRowHeight = 12;
  // Landscape A4: all branch rows fit one page height; columns may span pages
  ws.pageSetup = {
    orientation: 'landscape',
    fitToPage: true,
    fitToHeight: 1,
    fitToWidth: 0,
    paperSize: 9, // A4
    horizontalDpi: 300,
    verticalDpi: 300,
    blackAndWhite: false,
    draft: false,
    printTitlesRow: '1:6',
    printTitlesColumn: 'A:A', // Branch name on every printed page
  };
  ws.pageMargins = { left: 0.2, right: 0.2, top: 0.25, bottom: 0.25, header: 0.15, footer: 0.15 };
  ws.properties.defaultColWidth = 8;
}
const MOVE_IN_FILL = 'C6EFCE';
const OVERSTOCK_FILL = 'FFC7CE';
function semanticFillFor(value: unknown): string | null {
  const t = String(value ?? '').trim().toLowerCase();
  if (t === 'move in') return MOVE_IN_FILL;
  if (t === 'overstock') return OVERSTOCK_FILL;
  return null;
}
/** Solid green for "Move IN", solid light red/orange for "Overstock" (cell, or whole row if it is the row label). */
function applySemanticFills(ws: any) {
  ws.eachRow((row: any) => {
    const first = semanticFillFor(row.getCell(1).value);
    row.eachCell({ includeEmpty: false }, (cell: any, col: number) => {
      const color = semanticFillFor(cell.value);
      if (color) { cell.fill = excelFill(color); return; }
      if (first && col > 1) cell.fill = excelFill(first);
    });
    if (first) row.getCell(1).fill = excelFill(first);
  });
}
function applyGlobalSheetFill(ws: any) {
  applySemanticFills(ws);
  // Ensure every cell has fill + border; then force readable bold text.
  const MOVE_ARGB = new Set(['FFC6EFCE', 'FFFFC7CE']);
  ws.eachRow((row: any) => {
    row.eachCell({ includeEmpty: true }, (cell: any) => {
      if (!cell.fill) cell.fill = excelFill(EXECUTION_COLORS.white);
      if (!cell.border) cell.border = excelBorder();
    });
  });
  // Contrast pass: light cells → bold BLACK; movement greens/pinks keep dark green/red
  ws.eachRow((row: any, rowNumber: number) => {
    row.eachCell({ includeEmpty: false }, (cell: any) => {
      const argb = String(cell.fill?.fgColor?.argb || 'FFFFFFFF').toUpperCase();
      const hex = argb.startsWith('FF') && argb.length === 8 ? argb.slice(2) : 'FFFFFF';
      // Keep the larger Move IN/OUT size set by styleMovementCell (never shrink it back).
      if (argb === 'FFC6EFCE') {
        cell.font = excelFont('000000', true, Math.max(13, Number(cell.font?.size) || 13));
        return;
      }
      if (argb === 'FFFFC7CE') {
        cell.font = excelFont('000000', true, Math.max(13, Number(cell.font?.size) || 13));
        return;
      }
      if (argb === 'FFFFF4CC') {
        cell.font = excelFont('000000', true, 12);
        return;
      }
      // Default: bold black on light surfaces
      if (isLightFill(hex)) {
        const size = cell.font?.size || 12;
        cell.font = excelFont('000000', true, size);
      } else {
        cell.font = excelFont('FFFFFF', true, cell.font?.size || 12);
      }
    });
  });
  // Fix leftover solid dark movement fills
  ws.eachRow((row: any, rowNumber: number) => {
    if (rowNumber <= 4) return;
    row.eachCell({ includeEmpty: false }, (cell: any) => {
      const raw = cell.value;
      const s = String(raw ?? '').trim();
      const m = s.match(/^([+-]?)(\d+)$/);
      if (!m) return;
      const argb = String(cell.fill?.fgColor?.argb || '').toUpperCase();
      if (argb === 'FFC6EFCE' || argb === 'FFFFC7CE') return;
      if (argb === 'FF166534' || argb === 'FF991B1B' || argb === 'FF14532D' || argb === 'FF9B1C1C') {
        styleMovementCell(cell, parseInt(m[1] + m[2], 10));
      }
    });
  });
  ws.views = [{ ...(ws.views?.[0] || {}), showGridLines: true }];
}
async function addExcelMeta(ws: any, report: RedistributionReport, mode: ExecutionMode, workbook: any, lastCol = 8) {
  lastCol = Math.max(8, lastCol);
  // Exact software header: logo at top-left, selected date range at top-right.
  ws.getRow(1).height = 42;
  ws.mergeCells(1, 1, 1, 3); // logo (top-left)
  ws.mergeCells(1, 4, 1, lastCol - 3); // title
  ws.mergeCells(1, lastCol - 2, 1, lastCol); // date range (top-right)
  const title = ws.getCell(1, 4);
  const titleCat = getReportCategoryLabel(report);
  title.value = titleCat
    ? `${executionModeLabel(mode)} — ${titleCat}`
    : `${executionModeLabel(mode)} — Execution Report`;
  title.fill = excelFill(EXECUTION_COLORS.silver);
  title.font = excelFont(EXECUTION_COLORS.text, true, 15);
  title.alignment = { horizontal: 'left', vertical: 'middle' };
  const dateCell = ws.getCell(1, lastCol);
  dateCell.value = report.period || DEFAULT_DATE_RANGE;
  dateCell.fill = excelFill(EXECUTION_COLORS.silver);
  dateCell.font = excelFont(EXECUTION_COLORS.text, true, 10);
  dateCell.alignment = { horizontal: 'right', vertical: 'middle' };
  ws.getRow(1).eachCell((c: any) => { c.border = excelBorder('B8C0CC'); });

  const imageId = await getWorkbookLogoId(workbook);
  if (imageId != null) placeLogo(ws, imageId);

  const whiteLabel = getStoredSettings().whiteLabel;
  const catName = titleCat;
  if (catName) {
    ws.mergeCells(2, 1, 2, lastCol);
    const catCell = ws.getCell(2, 1);
    catCell.value = `CATEGORY: ${catName}`;
    catCell.font = excelFont(EXECUTION_COLORS.navy, true, 20);
    catCell.fill = excelFill(LUXURY.goldSoft);
    catCell.alignment = { horizontal: 'left', vertical: 'middle' };
    catCell.border = excelBorder(LUXURY.gold);
    ws.getRow(2).height = 32;
  }
  const metaRow = catName ? 3 : 2;
  ws.mergeCells(metaRow, 1, metaRow, lastCol);
  const meta = ws.getCell(metaRow, 1);
  meta.value = `${whiteLabel.companyName} · Period: ${report.period || 'Current'} · Mode: ${executionModeLabel(mode)} · Generated: ${new Date().toLocaleString()}`;
  meta.font = excelFont(EXECUTION_COLORS.deepBlue, true);
  meta.fill = excelFill(EXECUTION_COLORS.ice);
  meta.alignment = { horizontal: 'left', vertical: 'middle' };
  const legendRow = metaRow + 1;
  ws.mergeCells(legendRow, 1, legendRow, lastCol);
  ws.getCell(legendRow, 1).value = 'Green = Move-In · Red = Move-Out · Gold = Refill / shortage';
  ws.getCell(legendRow, 1).font = excelFont(EXECUTION_COLORS.text, false, 9);
}

export async function buildExecutionExcelWorkbook(report: RedistributionReport, mode: ExecutionMode): Promise<ArrayBuffer> {
  const wb = new ExcelJS.Workbook();
  const whiteLabel = getStoredSettings().whiteLabel;
  const catName = getReportCategoryLabel(report);
  const catSuffix = catName ? ` · ${catName}` : '';
  wb.creator = whiteLabel.companyName; wb.company = whiteLabel.companyName; wb.title = `${whiteLabel.companyName} — ${executionModeLabel(mode)} Execution Report${catSuffix}`;
  const branches = resolveLockedOutletColumns(report.matrix?.branches);
  const weights = report.matrix?.weights || [];
  const designBreakdown = weights.some((w) => String(w).includes(' · '));
  const lead = designBreakdown ? 3 : 2;
  const row1: string[] = designBreakdown ? ['Design Name', 'Carat', 'DWL Stock'] : [report.categoryConfig?.itemLabel || 'Item / Particular', 'DWL Stock'];
  branches.forEach((b) => row1.push(getBranchDisplayName(b), '', '', '', ''));
  row1.push('Total Stock', 'Total Sold', 'Refill Demand');
  const row2: string[] = designBreakdown ? ['', '', ''] : ['', ''];
  branches.forEach(() => row2.push('Sold Qty', 'Current Stock', 'Average', 'Contribution %', 'Move IN/OUT'));
  row2.push('', '', '');
  const headerMerges: [number, number, number, number][] = [];
  const branchGroups: { startCol: number; span: number }[] = [];
  let gc = lead + 1;
  branches.forEach(() => { headerMerges.push([1, gc, 1, gc + 4]); branchGroups.push({ startCol: gc, span: 5 }); gc += 5; });
  [0, 1, 2].forEach((i) => headerMerges.push([1, gc + i, 2, gc + i]));
  for (let c = 1; c <= lead - 1; c++) headerMerges.push([1, c, 2, c]);
  const matrixRows = weights.map((w) => {
    const parts = String(w).split(' · '); const dimension = parts[0] || ''; const design = parts.length > 1 ? parts.slice(1).join(' · ') : '';
    const dwl = sumWarehouseStock(report, w);
    let totalStock = dwl; let totalSold = 0;
    const branchRows = branches.map((b) => { const c = report.matrix.cells[b]?.[w]; const sold = Number(c?.sold ?? 0); const stock = Number(c?.stock ?? 0); const avg = c?.sales3M ? Math.round(Number(c.sales3M) / 3) : Math.round(sold / 3); const net = Number(c?.netMove ?? 0); totalStock += stock; totalSold += sold; return { sold, stock, avg, net }; });
    const itemSold = branchRows.reduce((sum, x) => sum + x.sold, 0);
    const refillQty = Number(report.weightSummaries.find((x) => x.weight === w)?.unmetShortage ?? Math.max(0, itemSold - totalStock));
    const values: (string | number)[] = designBreakdown ? [design || '—', dimension, Math.round(dwl)] : [dimension, Math.round(dwl)];
    branchRows.forEach(({ sold, stock, avg, net }) => values.push(Math.round(sold), Math.round(stock), avg, `${itemSold > 0 ? Math.round((sold / itemSold) * 100) : 0}%`, net));
    values.push(Math.round(totalStock), Math.round(totalSold), Math.round(refillQty));
    return values;
  });
  const logoId = await getWorkbookLogoId(wb);
  writeStyledRowsSheet(wb, logoId, {
    name: 'Execution Matrix',
    title: catName
      ? `${executionModeLabel(mode)} — ${catName}`
      : `${executionModeLabel(mode)} — Execution Report`,
    period: report.period,
    categoryName: catName || undefined,
    headerRows: [row1, row2],
    headerMerges,
    rows: matrixRows,
    movementCols: branches.map((_, bi) => lead + bi * 5 + 5),
    refillCols: [lead + branches.length * 5 + 3],
    branchGroups,
    freezeCols: lead,
    columnWidths: [22, 12, 12],
  });

  const summary = createSheet(wb, 'Branch Summary'); setupExcelSheet(summary); await addExcelMeta(summary, report, mode, wb); styleExcelHeader(summary.addRow(['Branch', 'Total Sold', 'Current Stock', 'Move IN', 'Move OUT', 'Net Change', 'Status']), 'D9E2EC');
  (report.branchSummaries || []).forEach((b) => {
    const isWh = isWarehouseBranchCode(b.branch) || b.isWarehouse;
    // DWL / Diamond World LTD = warehouse reserve only — stock only, no sold/move columns
    const sold = isWh ? 0 : b.totalSold;
    const moveIn = isWh ? 0 : b.totalMoveIn;
    const moveOut = isWh ? 0 : Math.abs(Number(b.totalMoveOut || 0));
    const net = isWh ? 0 : b.netChange;
    const status = isWh ? 'WAREHOUSE RESERVE' : b.status;
    const label = isWh ? `${getBranchDisplayName(b.branch)} (DWL Stock)` : getBranchDisplayName(b.branch);
    const r = summary.addRow([label, sold, b.totalCurrentStock, moveIn, moveOut, net, status]);
    styleExcelBody(r);
    if (!isWh) {
      styleMovementCell(r.getCell(4), Number(moveIn || 0));
      styleMovementCell(r.getCell(5), -Math.abs(Number(moveOut || 0)));
      styleMovementCell(r.getCell(6), Number(net || 0));
    }
  });
  [26, 16, 18, 14, 14, 15, 18].forEach((w, i) => summary.getColumn(i + 1).width = w);
  applyGlobalSheetFill(summary);

  const moves = createSheet(wb, 'Movement Orders'); setupExcelSheet(moves); await addExcelMeta(moves, report, mode, wb); styleExcelHeader(moves.addRow(['Order ID', 'Item', 'From', 'To', 'Qty', 'Priority', 'Reason']), 'D9E2EC');
  (report.transferOrders || []).forEach((t) => { const r = moves.addRow([t.id, t.weight, getBranchDisplayName(t.fromBranch), getBranchDisplayName(t.toBranch), t.qty, t.priority, t.reason]); styleExcelBody(r); if (Number(t.qty) > 0) { r.getCell(5).font = excelFont(EXECUTION_COLORS.green, true); r.getCell(5).fill = excelFill('E8F5E9'); } });
  [22, 18, 20, 20, 12, 14, 44].forEach((w, i) => moves.getColumn(i + 1).width = w);
  applyGlobalSheetFill(moves);

  const refill = createSheet(wb, 'Refill Demand'); setupExcelSheet(refill); await addExcelMeta(refill, report, mode, wb); styleExcelHeader(refill.addRow(['Item', 'Qty to Buy', 'Sold Demand', 'Available Stock', 'Urgency', 'Rationale']), 'D9E2EC');
  (report.procurementOrders || []).forEach((p) => { const r = refill.addRow([p.weight, p.qtyToBuy, p.soldDemand, p.availableStock, p.urgency, p.rationale]); styleExcelBody(r); if (Number(p.qtyToBuy) > 0) { r.getCell(2).font = excelFont(EXECUTION_COLORS.gold, true); r.getCell(2).fill = excelFill('FFF4CC'); } });
  [24, 14, 16, 18, 14, 52].forEach((w, i) => refill.getColumn(i + 1).width = w);
  applyGlobalSheetFill(refill);

  // Use an awaited loop here. `addExcelMeta()` loads the logo asynchronously, so a
  // `forEach(async ...)` callback would leave `await` outside the callback's async
  // boundary and could also write the workbook before the logo is attached.
  for (const branch of branches) {
    const ws = createSheet(wb, `Outlet - ${getBranchDisplayName(branch)}`);
    setupExcelSheet(ws);
    await addExcelMeta(ws, { ...report, period: report.period } as RedistributionReport, mode, wb);
    ws.getCell(4, 1).value = `Outlet: ${getBranchDisplayName(branch)}`;
    ws.getCell(4, 1).font = excelFont(EXECUTION_COLORS.deepBlue, true, 11);
    ws.getCell(1, 1).fill = excelFill(EXECUTION_COLORS.silver);
    ws.getCell(1, 1).font = excelFont(EXECUTION_COLORS.text, true, 14);
    ws.getRow(1).height = 28;
    styleExcelHeader(ws.addRow(['Item', 'Sold Qty', 'Current Stock', 'Average', 'Contribution %', 'Move IN/OUT', 'Refill', 'Status']), 'D9E2EC');
    ws.views = [{ showGridLines: true, state: 'frozen', xSplit: 1, ySplit: 5 }];
    weights.forEach((w) => {
      const c = report.matrix.cells[branch]?.[w];
      const sold = Number(c?.sold ?? 0);
      const stock = Number(c?.stock ?? 0);
      const avg = c?.sales3M ? Math.round(Number(c.sales3M) / 3) : Math.round(sold / 3);
      const net = Number(c?.netMove ?? 0);
      const refillQty = Math.max(0, avg - stock);
      const r = ws.addRow([w, sold, stock, avg, `${sold > 0 ? Math.round((sold / Math.max(1, sold + stock)) * 100) : 0}%`, net, refillQty, net > 0 ? 'Move In' : net < 0 ? 'Move Out' : refillQty > 0 ? 'Refill' : 'Balanced']);
      styleExcelBody(r);
      styleMovementCell(r.getCell(6), net);
      if (refillQty > 0) {
        r.getCell(7).font = excelFont(EXECUTION_COLORS.gold, true);
        r.getCell(7).fill = excelFill('FFF4CC');
      }
    });
    [28, 14, 18, 14, 16, 16, 12, 18].forEach((w, i) => ws.getColumn(i + 1).width = w);
    applyGlobalSheetFill(ws);
  }
  return (await wb.xlsx.writeBuffer()) as ArrayBuffer;
}

export async function exportExecutionExcelReport(report: RedistributionReport, mode: ExecutionMode): Promise<void> {
  const filename = `DiaMatrix_${executionModeLabel(mode).replace(/\s+/g, '_')}_Execution_Report.xlsx`;
  try {
    const buffer = await buildExecutionExcelWorkbook(report, mode);
    downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), filename);
  } catch (error) {
    console.error('ExcelJS execution export failed:', error);
    window.alert(`Excel export failed: ${error instanceof Error ? error.message : 'Please try again.'}`);
  }
}

function pdfPageHeader(doc: jsPDF, title: string, period: string, pageNo: number, totalPages: number) {
  doc.setFillColor(10, 15, 29); doc.rect(0, 0, 297, 18, 'F'); doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text(title, 10, 11); doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.text(`${period || 'Current period'} · Page ${pageNo} / ${totalPages}`, 287, 11, { align: 'right' });
}
function pdfCell(doc: jsPDF, text: string, x: number, y: number, w: number, h: number, opts: { fill?: [number, number, number]; text?: [number, number, number]; bold?: boolean } = {}) {
  if (opts.fill) { doc.setFillColor(...opts.fill); doc.rect(x, y, w, h, 'F'); } doc.setDrawColor(190, 205, 218); doc.rect(x, y, w, h); doc.setTextColor(...(opts.text || [20, 33, 61])); doc.setFont('helvetica', opts.bold ? 'bold' : 'normal'); doc.setFontSize(7); const lines = doc.splitTextToSize(String(text ?? ''), Math.max(5, w - 4)); doc.text(lines.slice(0, 2), x + 2, y + 5);
}

export async function exportExecutionPdfReport(report: RedistributionReport, mode: ExecutionMode): Promise<void> {
  const filename = `DiaMatrix_${executionModeLabel(mode).replace(/\s+/g, '_')}_Execution_Report.pdf`;
  const source = document.querySelector<HTMLElement>('[data-dmx-report-print-root=\"true\"]');
  if (!source) {
    const branches = (report.matrix?.branches || []).filter(
      (b) => b && !isOnlineBranch(b) && !isExcludedOutlet(b),
    );
    const rows = (report.matrix?.weights || []).map((weight) => {
      const totalSold = branches.reduce((sum, branch) => sum + Number(report.matrix.cells[branch]?.[weight]?.sold ?? 0), 0);
      const totalStock = branches.reduce((sum, branch) => sum + Number(report.matrix.cells[branch]?.[weight]?.stock ?? 0), 0);
      return {
        item: weight,
        sold: totalSold,
        stock: totalStock,
        refill: Math.max(0, Math.round(totalSold / 3) - totalStock),
      };
    });
    await exportCorporatePdf({
      title: `${executionModeLabel(mode)} — Execution Report`,
      filename: `DiaMatrix_${executionModeLabel(mode).replace(/\s+/g, '_')}_Execution_Report`,
      period: report.period,
      whiteLabel: getStoredSettings().whiteLabel,
      columns: [
        { key: 'item', header: report.categoryConfig?.itemLabel || 'Item / Particular', width: 34 },
        { key: 'sold', header: 'Sold Qty', width: 14, align: 'right', numberFormat: '#,##0' },
        { key: 'stock', header: 'Current Stock', width: 16, align: 'right', numberFormat: '#,##0' },
        { key: 'refill', header: 'Refill Demand', width: 16, align: 'right', numberFormat: '#,##0' },
      ],
      rows,
    });
    return;
  }

  const clone = source.cloneNode(true) as HTMLElement;
  clone.querySelectorAll<HTMLElement>('.dmx-print-hide, button, [role=\"button\"]').forEach((el) => el.remove());
  clone.querySelectorAll<HTMLElement>('.overflow-auto, .overflow-x-auto, .overflow-y-auto').forEach((el) => {
    el.style.overflow = 'visible';
    el.style.maxHeight = 'none';
    el.style.height = 'auto';
  });
  clone.querySelectorAll<HTMLElement>('[style*=\"position: sticky\"], .sticky').forEach((el) => { el.style.position = 'static'; });
  const whiteLabel = getStoredSettings().whiteLabel;
  const exportHeader = document.createElement('div');
  exportHeader.style.cssText = `display:flex;align-items:center;gap:14px;padding:14px 16px;margin:0 0 14px;border-bottom:3px solid ${whiteLabel.accent};background:#fff;font-family:Arial,sans-serif;`;
  const exportLogo = document.createElement('img');
  exportLogo.src = whiteLabel.logoUrl || '/diamatrix-logo-full.png';
  exportLogo.alt = whiteLabel.companyName;
  exportLogo.style.cssText = 'height:44px;max-width:180px;object-fit:contain;';
  const exportMeta = document.createElement('div');
  exportMeta.innerHTML = `<div style=\"font-size:18px;font-weight:800;color:${whiteLabel.primary}\">${esc(whiteLabel.companyName)}</div><div style=\"font-size:14px;font-weight:700;color:#334155;margin-top:2px\">${esc(executionModeLabel(mode))} — Execution Report</div><div style=\"font-size:10px;color:#64748b;margin-top:3px\">Period: ${esc(report.period || 'Current')} · Generated: ${esc(new Date().toLocaleString())}</div>`;
  exportHeader.append(exportLogo, exportMeta);
  clone.prepend(exportHeader);
  clone.style.cssText = 'position:fixed;left:-100000px;top:0;width:794px;max-width:none;background:#fff;color:#14213D;padding:0;margin:0;';

  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;left:-100000px;top:0;width:794px;background:#fff;z-index:-1;';
  host.appendChild(clone);
  document.body.appendChild(host);

  try {
    await new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
    const canvas = await html2canvas(clone, {
      scale: Math.min(2, window.devicePixelRatio || 1.5),
      backgroundColor: '#ffffff',
      useCORS: true,
      logging: false,
      windowWidth: 794,
      scrollX: 0,
      scrollY: 0,
    });
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 8;
    const usableWidth = pageWidth - margin * 2;
    const imgWidth = usableWidth;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    const image = canvas.toDataURL('image/png');
    if (imgHeight <= pageHeight - margin * 2) {
      doc.addImage(image, 'PNG', margin, margin, imgWidth, imgHeight);
    } else {
      // Slice the actual UI image into A4-height pages, preserving the same on-screen design.
      const pagePxHeight = Math.floor(canvas.width * ((pageHeight - margin * 2) / usableWidth));
      let offset = 0;
      let page = 0;
      while (offset < canvas.height) {
        const slice = document.createElement('canvas');
        slice.width = canvas.width;
        slice.height = Math.min(pagePxHeight, canvas.height - offset);
        const ctx = slice.getContext('2d');
        if (!ctx) throw new Error('Unable to create PDF canvas.');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, slice.width, slice.height);
        ctx.drawImage(canvas, 0, offset, canvas.width, slice.height, 0, 0, canvas.width, slice.height);
        if (page > 0) doc.addPage('a4', 'portrait');
        const sliceHeight = (slice.height * imgWidth) / slice.width;
        doc.addImage(slice.toDataURL('image/png'), 'PNG', margin, margin, imgWidth, sliceHeight);
        offset += slice.height;
        page += 1;
      }
    }
    doc.save(filename);
  } finally {
    host.remove();
  }
}

export function printExecutionReport(_report: RedistributionReport, _mode: ExecutionMode): void {
  // Print the actual on-screen report root — layout preserved via print.css
  printDomReportRoot(
    document.querySelector('[data-dmx-report-print-root="true"]') as HTMLElement | null,
  );
}

export function printExecutionReportHtml(report: RedistributionReport, mode: ExecutionMode): void {
  const branches = (report.matrix?.branches || []).filter((b) => b && !isOnlineBranch(b) && !isExcludedOutlet(b));
  const pages = branches
    .map((branch) => {
      const rows = (report.matrix?.weights || [])
        .map((w) => {
          const c = report.matrix.cells[branch]?.[w];
          const net = Number(c?.netMove ?? 0);
          const avg = c?.sales3M
            ? Math.round(Number(c.sales3M) / 3)
            : Math.round(Number(c?.sold ?? 0) / 3);
          const moveClass = net > 0 ? 'move-in' : net < 0 ? 'move-out' : '';
          return `<tr>
            <td>${esc(w)}</td>
            <td class="num">${Number(c?.sold ?? 0)}</td>
            <td class="num">${Number(c?.stock ?? 0)}</td>
            <td class="num">${avg}</td>
            <td class="num ${moveClass}">${net > 0 ? '+' : ''}${net}</td>
            <td class="num">${Math.max(0, avg - Number(c?.stock ?? 0))}</td>
          </tr>`;
        })
        .join('');
      return `<section class="dmx-outlet-page" data-dmx-outlet-page="true">
        <h2>${esc(executionModeLabel(mode))} — ${esc(getBranchDisplayName(branch))}</h2>
        <div class="dmx-meta">${esc(report.period || '')}</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th class="num">Sold</th>
              <th class="num">Stock</th>
              <th class="num">Average</th>
              <th class="num">Move IN/OUT</th>
              <th class="num">Refill</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </section>`;
    })
    .join('');
  const html = buildPrintableDocumentHtml(executionModeLabel(mode), pages);
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 350);
}

/* --------------------------------------------------------------------------
 * Shared styled-rows engine: UI handlers pass rows here; all styling,
 * gridlines, Move IN / Overstock fills, logo + date-range header,
 * 3D bevel look and freeze panes live here.
 * -------------------------------------------------------------------------- */
export type StyledRowsSheet = {
  name: string;
  title: string;
  /** Date range shown top-right, e.g. "01-03-2026 to 19-09-2026" */
  period?: string;
  /** Product / category name shown in the meta row (e.g. "Nosepin 7 stone", "Universal Jewelry Inventory") */
  categoryName?: string;
  /** Header rows (1+), rendered with header styling */
  headerRows: (string | number | null | undefined)[][];
  /** Body rows */
  rows: (string | number | null | undefined)[][];
  /** Merge ranges [r1,c1,r2,c2]; r is relative to first header row (1-based) */
  headerMerges?: [number, number, number, number][];
  /** 1-based column indexes holding numeric net-move values (green/orange) */
  movementCols?: number[];
  /** 1-based column indexes holding refill demand (gold when > 0) */
  refillCols?: number[];
  /** Branch column groups (1-based start column + span) — coloured differently so branches are easy to tell apart */
  branchGroups?: { startCol: number; span: number }[];
  /** Distribution mode shown in the header, e.g. 'Sales Contribution' */
  modeLabel?: string;
  /** 'emerald' = emerald-green headers (distribution / design-wise files). Default alternates blue/teal per branch. */
  theme?: 'default' | 'emerald';
  /** Number of left columns kept frozen (item / design / DWL). Default 1 */
  freezeCols?: number;
  /**
   * 1-based column indexes AFTER which a vertical print page-break is inserted.
   * Only at complete Stock|Sold|Move boundaries — page never ends mid-group on Stock.
   */
  colPageBreaks?: number[];
  columnWidths?: number[];
};

const GROUP_HEADER = ['D0E4F5', 'C8E8E4'];
const GROUP_TINT = ['F5FAFF', 'F2FAF8'];
const EMERALD_HEADER = ['C6EFCE', 'B8E6C8'];
const EMERALD_TINT = ['F0FBF4', 'F5FCF8'];

/** Logo is 900x194 (4.64:1) — keep aspect ratio inside the 42pt header row. */
function placeLogo(ws: any, imageId: number) {
  ws.addImage(imageId, { tl: { col: 0.1, row: 0.12 }, ext: { width: 226, height: 49 } });
}
const LOGO_CACHE = new WeakMap<object, number | null>();
/** Embed the logo once per workbook and reuse the id on every sheet (keeps file size small). */
async function getWorkbookLogoId(wb: any): Promise<number | null> {
  if (LOGO_CACHE.has(wb)) return LOGO_CACHE.get(wb) ?? null;
  const id = await loadLogoId(wb);
  LOGO_CACHE.set(wb, id);
  return id;
}

async function loadLogoId(wb: any): Promise<number | null> {
  try {
    const configuredLogo = getStoredSettings().whiteLabel.logoUrl || '/diamatrix-logo-full.png';
    const res = await fetch(configuredLogo, { mode: 'cors' });
    if (!res.ok) return null;
    const contentType = res.headers.get('content-type') || '';
    const extension = contentType.includes('jpeg') || contentType.includes('jpg') ? 'jpeg' : 'png';
    return wb.addImage({ buffer: await res.arrayBuffer(), extension });
  } catch {
    return null;
  }
}

function writeStyledRowsSheet(wb: any, logoId: number | null, sheet: StyledRowsSheet): any {
  const ws = createSheet(wb, sheet.name.slice(0, 31) || 'Report');
  setupExcelSheet(ws);
  const colCount = Math.max(8, ...sheet.headerRows.map((r) => r.length), ...sheet.rows.map((r) => r.length));
  const period = sheet.period || DEFAULT_DATE_RANGE;
  const emerald = sheet.theme === 'emerald';
  const hdrColors = emerald ? EMERALD_HEADER : GROUP_HEADER;
  const tints = emerald ? EMERALD_TINT : GROUP_TINT;
  const baseHeader = emerald ? 'C6EFCE' : 'D9E2EC';

  // Row 1: logo (top-left) · title · date range (top-right)
  ws.getRow(1).height = 42;
  const dateSpan = colCount <= 10 ? 2 : 3; // narrow sheets: give the title more room
  ws.mergeCells(1, 1, 1, 3);
  ws.mergeCells(1, 4, 1, colCount - dateSpan);
  ws.mergeCells(1, colCount - dateSpan + 1, 1, colCount);
  const title = ws.getCell(1, 4);
  title.value = sheet.title;
  title.font = excelFont(EXECUTION_COLORS.text, true, 16);
  title.alignment = { horizontal: 'left', vertical: 'middle' };
  const date = ws.getCell(1, colCount - dateSpan + 1);
  date.value = period;
  date.font = excelFont(EXECUTION_COLORS.text, true, 12);
  date.alignment = { horizontal: 'right', vertical: 'middle' };
  ws.getRow(1).eachCell((c: any) => { c.fill = excelFill(EXECUTION_COLORS.silver); c.border = bevelBorder('FFFFFF', '8A94A3', 'medium'); });
  if (logoId != null) placeLogo(ws, logoId);

  const whiteLabel = getStoredSettings().whiteLabel;
  const catLabel = (sheet.categoryName || '').trim();
  // Big category banner — which product/category this report is for
  if (catLabel) {
    ws.mergeCells(2, 1, 2, colCount);
    const catCell = ws.getCell(2, 1);
    catCell.value = `CATEGORY: ${catLabel}`;
    catCell.font = excelFont(EXECUTION_COLORS.navy, true, 20);
    catCell.fill = excelFill(LUXURY.goldSoft);
    catCell.alignment = { horizontal: 'left', vertical: 'middle' };
    catCell.border = bevelBorder('FFFFFF', LUXURY.gold);
    ws.getRow(2).height = 32;
  }

  const metaRow = catLabel ? 3 : 2;
  ws.mergeCells(metaRow, 1, metaRow, colCount);
  ws.getCell(metaRow, 1).value = `${whiteLabel.companyName} · Period: ${period} · Generated: ${new Date().toLocaleString()}`;
  ws.getCell(metaRow, 1).font = excelFont(EXECUTION_COLORS.deepBlue, true, 11);
  ws.getCell(metaRow, 1).fill = excelFill(EXECUTION_COLORS.ice);
  ws.getRow(metaRow).height = 20;

  let nextRow = metaRow + 1;
  if (sheet.modeLabel) {
    ws.mergeCells(nextRow, 1, nextRow, colCount);
    ws.getCell(nextRow, 1).value = `DISTRIBUTION MODE: ${sheet.modeLabel}`;
    ws.getCell(nextRow, 1).font = excelFont(EXECUTION_COLORS.deepBlue, true, 12);
    ws.getCell(nextRow, 1).fill = excelFill('FEF3C7');
    ws.getRow(nextRow).height = 22;
    nextRow += 1;
  }
  ws.mergeCells(nextRow, 1, nextRow, colCount);
  ws.getCell(nextRow, 1).value = 'Soft green = Move IN · Soft pink = Move OUT / Overstock · Gold = Refill / shortage · Print-friendly colours';
  ws.getCell(nextRow, 1).font = excelFont(EXECUTION_COLORS.text, true, 10);
  ws.getCell(nextRow, 1).fill = excelFill('FFFFFF');
  ws.getRow(nextRow).height = 18;

  // Header rows (branch names row + metric row)
  const headerStart = ws.rowCount + 1;
  const groups = sheet.branchGroups || [];
  sheet.headerRows.forEach((h) => {
    const r = ws.addRow(h.map((v) => v ?? ''));
    styleExcelHeader(r, baseHeader);
    groups.forEach((g, gi) => {
      for (let c = g.startCol; c < g.startCol + g.span; c++) paintHeaderCell(r.getCell(c), hdrColors[gi % 2]);
    });
  });
  (sheet.headerMerges || []).forEach(([r1, c1, r2, c2]) => ws.mergeCells(headerStart + r1 - 1, c1, headerStart + r2 - 1, c2));
  const headerEnd = headerStart + sheet.headerRows.length - 1;

  sheet.rows.forEach((values) => {
    const row = ws.addRow(values.map((v) => v ?? ''));
    styleExcelBody(row);
    groups.forEach((g, gi) => {
      for (let c = g.startCol; c < g.startCol + g.span; c++) {
        const cell = row.getCell(c);
        // Light group tint + ALWAYS bold black text (never same as background)
        const tint = tints[gi % 2];
        cell.fill = excelFill(tint);
        cell.font = excelFont('000000', true, 12);
        if (c === g.startCol) {
          cell.border = {
            ...bevelBorder('FFFFFF', '8FA1B8'),
            left: { style: 'medium', color: { argb: emerald ? 'FF047857' : 'FF0F4C81' } },
          };
        }
      }
    });
    (sheet.movementCols || []).forEach((col) => {
      const raw = Number(values[col - 1]);
      if (values[col - 1] !== '' && Number.isFinite(raw)) styleMovementCell(row.getCell(col), raw);
    });
    (sheet.refillCols || []).forEach((col) => {
      if (Number(values[col - 1]) > 0) {
        const c = row.getCell(col);
        c.fill = excelFill('FFF4CC'); // light gold
        c.font = excelFont('000000', true, 12); // black bold on gold
      }
    });
  });

  for (let i = 1; i <= colCount; i++) {
    ws.getColumn(i).width = sheet.columnWidths?.[i - 1] ?? (i === 1 ? 16 : i <= 4 ? 9 : 7);
  }
  // Compact body rows so all outlets fit on one landscape page height
  const bodyRowCount = Math.max(1, ws.rowCount - headerEnd);
  const compactBodyH = bodyRowCount > 24 ? 11 : bodyRowCount > 18 ? 12 : 14;
  for (let r = headerEnd + 1; r <= ws.rowCount; r++) {
    ws.getRow(r).height = compactBodyH;
  }
  // Freeze header + lead columns (Branch / totals) so every printed page keeps them
  const freezeX = sheet.freezeCols ?? 1;
  ws.views = [{ showGridLines: true, state: 'frozen', xSplit: freezeX, ySplit: headerEnd }];
  // Landscape A4: fit ALL branch rows on one page height (no vertical page waste).
  // Width may span pages for many carats; breaks only after Stock|Sold|Move groups.
  const leadLetters = freezeX > 1 ? `A:${colLetter(freezeX)}` : 'A:A';
  ws.pageSetup = {
    ...(ws.pageSetup || {}),
    orientation: 'landscape',
    fitToPage: true,
    fitToHeight: 1, // all outlets on one page height
    fitToWidth: 0, // horizontal pages OK for many carat columns
    paperSize: 9, // A4
    horizontalDpi: 300,
    verticalDpi: 300,
    printTitlesRow: `1:${headerEnd}`,
    printTitlesColumn: leadLetters,
  };
  ws.pageMargins = {
    left: 0.2,
    right: 0.2,
    top: 0.25,
    bottom: 0.25,
    header: 0.15,
    footer: 0.15,
  };
  const lastCol = colLetter(colCount);
  const lastRow = Math.max(headerEnd, ws.rowCount);
  try {
    ws.pageSetup.printArea = `A1:${lastCol}${lastRow}`;
  } catch {
    /* older exceljs may ignore printArea */
  }
  // Column page breaks: ExcelJS model (brk id = last column on previous page)
  const breaks = (sheet.colPageBreaks || []).filter((n) => n >= freezeX && n < colCount);
  if (breaks.length) {
    try {
      const model = (ws as any).model || ws;
      if (model) {
        model.pageBreaks = model.pageBreaks || {};
        model.pageBreaks.colBreaks = breaks.map((id) => ({
          id,
          max: 1048575,
          man: 1,
        }));
      }
      // Also try per-column API when present
      breaks.forEach((colIdx) => {
        const col = ws.getColumn(colIdx);
        if (col && typeof (col as any).addPageBreak === 'function') {
          (col as any).addPageBreak();
        }
      });
    } catch {
      /* ignore if runtime exceljs lacks pageBreak model */
    }
  }
  ws.autoFilter = { from: { row: headerEnd, column: 1 }, to: { row: lastRow, column: colCount } };
  applyGlobalSheetFill(ws);
  // TOTAL row — light slate bar (readable on screen + print; not dark navy)
  for (let r = headerEnd + 1; r <= ws.rowCount; r++) {
    const cell1 = String(ws.getRow(r).getCell(1).value ?? '').toUpperCase();
    if (cell1.startsWith('TOTAL')) {
      const row = ws.getRow(r);
      row.eachCell({ includeEmpty: true }, (cell: any) => {
        cell.fill = excelFill('E8EEF5');
        cell.font = excelFont('0F2744', true, 10);
        cell.border = {
          top: { style: 'medium', color: { argb: 'FF0B6FB8' } },
          bottom: { style: 'thin', color: { argb: 'FFC5D0DC' } },
          left: { style: 'thin', color: { argb: 'FFC5D0DC' } },
          right: { style: 'thin', color: { argb: 'FFC5D0DC' } },
        };
      });
    }
  }
  return ws;
}

function colLetter(n: number): string {
  let s = '';
  let x = n;
  while (x > 0) {
    const m = (x - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    x = Math.floor((x - 1) / 26);
  }
  return s || 'A';
}

export async function exportStyledRowsExcel(sheets: StyledRowsSheet[], filename: string): Promise<void> {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DiaMatrix';
  wb.company = 'DiaMatrix';
  const logoId = await getWorkbookLogoId(wb);
  for (const sheet of sheets) writeStyledRowsSheet(wb, logoId, sheet);
  const buffer = await wb.xlsx.writeBuffer();
  downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), filename);
}

/* --------------------------------------------------------------------------
 * File 1: distribution_now.xlsx — one customised sheet per outlet
 * -------------------------------------------------------------------------- */
export type DistributionModeKey = 'contribution' | 'baseline' | 'hybrid' | 'liquidity' | 'demand_backup' | 'coverage';
export function distributionModeLabel(mode: string): string {
  return mode === 'baseline' ? '② 3-Month Baseline'
    : mode === 'hybrid' ? '③ Hybrid'
    : mode === 'liquidity' ? '④ Capital Liquidity'
    : mode === 'demand_backup' ? '⑤ Demand-Backup'
    : mode === 'coverage' ? '⑥ Universal Coverage'
    : '① Sales Contribution';
}

/** One-line explanation for Design Analysis UI / Excel header */
export function distributionModeExplanation(mode: string): string {
  return mode === 'baseline'
    ? 'Target = average monthly sales × 3, then scaled to live stock.'
    : mode === 'hybrid'
    ? 'Takes the higher of contribution vs baseline, then compresses to available stock.'
    : mode === 'liquidity'
    ? 'Prioritises capital release; aging stock above 90 days is scaled down.'
    : mode === 'demand_backup'
    ? '3M baseline + 20% high-performer boost + stock-out safety buffer.'
    : mode === 'coverage'
    ? 'Every outlet ≥1 pc; remaining by sales share. Hard cap 30 pcs/outlet (e.g. 22 on hand → max +8).'
    : 'Full company pool (DWL + branches) distributed by each outlet’s sales share.';
}
export async function exportDistributionNowExcel(report: RedistributionReport, mode: DistributionModeKey | string = 'contribution'): Promise<void> {
  const modeLabel = distributionModeLabel(mode);
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DiaMatrix';
  wb.company = 'DiaMatrix';
  const logoId = await getWorkbookLogoId(wb);
  const branches = resolveLockedOutletColumns(report.matrix?.branches);
  const weights = report.matrix?.weights || [];
  if (!branches.length) throw new Error('No outlet data found to export.');

  // Loop: one worksheet (addWorksheet via createSheet) per outlet, e.g. Bashundhara City
  for (const branch of branches) {
    const name = getBranchDisplayName(branch);
    const rows = weights.map((w) => {
      const c = report.matrix.cells[branch]?.[w];
      const sold = Number(c?.sold ?? 0);
      const stock = Number(c?.stock ?? 0);
      const avg = c?.sales3M ? Math.round(Number(c.sales3M) / 3) : Math.round(sold / 3);
      const net = Number(c?.netMove ?? 0);
      const refill = Math.max(0, avg - stock);
      const status = net > 0 ? 'Move IN' : net < 0 ? 'Overstock' : refill > 0 ? 'Refill' : 'Balanced';
      const contrib = sold + stock > 0 ? `${Math.round((sold / Math.max(1, sold + stock)) * 100)}%` : '0%';
      return [w, sold, stock, avg, contrib, net, refill, status] as (string | number)[];
    });
    writeStyledRowsSheet(wb, logoId, {
      name,
      title: `Distribution — ${name} · ${modeLabel.split(' (')[0]}`,
      period: report.period,
      categoryName: getReportCategoryLabel(report),
      modeLabel,
      theme: 'emerald',
      headerRows: [['Item', 'Sold Qty', 'Current Stock', 'Average', 'Contribution %', 'Move IN/OUT', 'Refill', 'Status']],
      rows,
      movementCols: [6],
      refillCols: [7],
      freezeCols: 1,
      columnWidths: [26, 14, 16, 14, 16, 16, 12, 16],
    });
  }
  const buffer = await wb.xlsx.writeBuffer();
  downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), 'distribution_now.xlsx');
}

/* --------------------------------------------------------------------------
 * File 2: design_wise_stock_analysis.xlsx — grouped by design / Item_Code, matrix layout
 * -------------------------------------------------------------------------- */
export type DesignWiseExportRow = {
  carat: string;
  stock: number;
  sold: number;
  refill: number;
  /** Warehouse / DWL stock — front column only (no sold/move) */
  dwlStock?: number;
  byOutlet: Record<string, { stock: number; sold: number; moveIn: number; moveOut: number; netMove: number }>;
};
export type DesignWiseExportGroup = { design: string; rows: DesignWiseExportRow[] };

export async function exportDesignWiseStockExcel(
  groups: DesignWiseExportGroup[],
  outlets: string[],
  period: string | undefined,
  dimensionLabel = 'Carat',
  /** Optional main-category layer (no style codes) — written as first sheet */
  categoryGroups?: DesignWiseExportGroup[],
  /** Active distribution mode key (contribution / baseline / …) */
  allocationMode?: string,
  /** Product / category name shown on every sheet meta row */
  categoryName?: string
): Promise<void> {
  if (!groups.length && !(categoryGroups && categoryGroups.length)) {
    throw new Error('No design data found to export.');
  }
  // Warehouse never an outlet row/column — always full locked master list (GUL…SYL)
  const retailOutlets = resolveLockedOutletColumns(outlets);
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DiaMatrix';
  wb.company = 'DiaMatrix';
  const logoId = await getWorkbookLogoId(wb);
  const modeKey = allocationMode || 'contribution';
  const modeLabel = distributionModeLabel(modeKey);
  const modeHint = distributionModeExplanation(modeKey);

  /**
   * Print layout (sample-style, transposed):
   *   LEFT  = Branch / Outlet (rows down) — DWL warehouse row first when stock > 0
   *   TOP   = Design · Carat / Cent (columns across) each with Stock | Sold | Move
   *   Lead  = Branch | Total Stock | DWL | Total Sold | Refill
   *   DWL column: value on DWL row + TOTAL; blank on retail outlets.
   * Condensed cells + landscape + header repeats every printed page.
   */
  type ItemCol = {
    key: string;
    label: string;
    design: string;
    carat: string;
    byOutlet: Record<string, { stock: number; sold: number; net: number }>;
    dwlStock: number;
    stock: number;
    sold: number;
    refill: number;
  };

  const collectItems = (gs: DesignWiseExportGroup[], withDesignLabel: boolean): ItemCol[] => {
    const items: ItemCol[] = [];
    gs.forEach((g) => {
      g.rows.forEach((r) => {
        const byOutlet: ItemCol['byOutlet'] = {};
        retailOutlets.forEach((o) => {
          const c = r.byOutlet[o] || { stock: 0, sold: 0, moveIn: 0, moveOut: 0, netMove: 0 };
          const net = c.netMove !== 0 ? c.netMove : c.moveIn - c.moveOut;
          byOutlet[o] = { stock: c.stock, sold: c.sold, net };
        });
        const label = withDesignLabel
          ? g.design === '(Category / No Style)'
            ? String(r.carat)
            : `${g.design} · ${r.carat}`
          : String(r.carat);
        items.push({
          key: `${g.design}||${r.carat}`,
          label,
          design: g.design,
          carat: r.carat,
          byOutlet,
          dwlStock: Number(r.dwlStock || 0),
          stock: r.stock,
          sold: r.sold,
          refill: r.refill,
        });
      });
    });
    // Skip zero-activity carats so export stays printable
    const active = items.filter(
      (it) =>
        it.stock > 0 ||
        it.sold > 0 ||
        it.dwlStock > 0 ||
        it.refill > 0 ||
        Object.values(it.byOutlet).some((c) => c.stock > 0 || c.sold > 0 || c.net !== 0),
    );
    active.sort((a, b) => {
      const na = parseFloat(a.carat);
      const nb = parseFloat(b.carat);
      if (!isNaN(na) && !isNaN(nb) && na !== nb) return na - nb;
      return a.label.localeCompare(b.label, undefined, { numeric: true });
    });
    return active;
  };

  const buildTransposedSheet = (
    name: string,
    title: string,
    gs: DesignWiseExportGroup[],
    withDesignLabel: boolean,
  ) => {
    const items = collectItems(gs, withDesignLabel);
    if (!items.length || !retailOutlets.length) return;

    const lead = 5; // Branch · Total Stock · DWL · Total Sold · Refill
    const totalDwlStock = Math.round(items.reduce((sum, it) => sum + Number(it.dwlStock || 0), 0));
    const row1: (string | number)[] = ['Branch / Outlet', 'Total Stock', 'DWL', 'Total Sold', 'Refill'];
    items.forEach((it) => {
      row1.push(it.label, '', '');
    });
    const row2: (string | number)[] = ['', '', '', '', ''];
    items.forEach(() => {
      row2.push('Stock', 'Sold', 'Move');
    });

    const headerMerges: [number, number, number, number][] = [];
    for (let c = 1; c <= lead; c++) headerMerges.push([1, c, 2, c]);
    const itemGroups: { startCol: number; span: number }[] = [];
    items.forEach((_, i) => {
      const start = lead + i * 3 + 1;
      headerMerges.push([1, start, 1, start + 2]);
      itemGroups.push({ startCol: start, span: 3 });
    });
    const movementCols = items.map((_, i) => lead + i * 3 + 3);
    const refillCols = [5];

    // DWL warehouse row first — per-carat stock under each group (matches UI + upload sheet)
    const dwlRow: (string | number)[] = [
      'DWL',
      totalDwlStock > 0 ? totalDwlStock : '',
      totalDwlStock > 0 ? totalDwlStock : '',
      '',
      '',
    ];
    items.forEach((it) => {
      const d = Math.round(Number(it.dwlStock || 0));
      dwlRow.push(d > 0 ? d : '', '', ''); // Stock only; no Sold/Move for warehouse
    });

    const body: (string | number)[][] = retailOutlets.map((o) => {
      let tStock = 0;
      let tSold = 0;
      let tRefill = 0;
      const vals: (string | number)[] = [toLockedOutletShortcut(o)];
      // DWL once at front — blank on outlet rows (warehouse is not per-outlet)
      vals.push(0, '', 0, 0);
      items.forEach((it) => {
        const c = it.byOutlet[o] || { stock: 0, sold: 0, net: 0 };
        tStock += c.stock;
        tSold += c.sold;
        vals.push(Math.round(c.stock) || '', Math.round(c.sold) || '', c.net !== 0 ? Math.round(c.net) : '');
      });
      const need = items.reduce((s, it) => {
        const n = it.byOutlet[o]?.net || 0;
        return s + (n > 0 ? n : 0);
      }, 0);
      tRefill = need;
      vals[1] = Math.round(tStock);
      vals[2] = ''; // DWL blank on outlet rows
      vals[3] = Math.round(tSold);
      vals[4] = Math.round(tRefill) || '';
      return vals;
    });

    // TOTAL row — Total Stock / Sold = pure retail; DWL once at front
    let retailGrandStock = 0;
    let retailGrandSold = 0;
    body.forEach((r) => {
      retailGrandStock += Number(r[1]) || 0;
      retailGrandSold += Number(r[3]) || 0;
    });
    const total: (string | number)[] = [
      'TOTAL',
      Math.round(retailGrandStock),
      totalDwlStock > 0 ? totalDwlStock : '',
      Math.round(retailGrandSold),
      Math.round(items.reduce((s, it) => s + it.refill, 0)) || '',
    ];
    items.forEach((it) => {
      let st = 0;
      let so = 0;
      let nt = 0;
      retailOutlets.forEach((o) => {
        const c = it.byOutlet[o] || { stock: 0, sold: 0, net: 0 };
        st += c.stock;
        so += c.sold;
        nt += c.net;
      });
      total.push(
        Math.round(st) || '',
        Math.round(so) || '',
        nt !== 0 ? Math.round(nt) : '',
      );
    });
    // Order: DWL row → outlets → TOTAL
    if (totalDwlStock > 0) {
      body.unshift(dwlRow);
    }
    body.push(total);

    const colWidths = [14, 8, 8, 8, 7, ...items.flatMap(() => [7, 6, 6])];

    writeStyledRowsSheet(wb, logoId, {
      name: name.slice(0, 31),
      title,
      period,
      categoryName: categoryName || undefined,
      modeLabel: `${modeLabel} — ${modeHint}`,
      theme: 'emerald',
      headerRows: [row1, row2],
      headerMerges,
      movementCols,
      refillCols,
      branchGroups: itemGroups,
      freezeCols: 1,
      columnWidths: colWidths,
      rows: body,
    });
  };

  // Sheet 1 — Main Category
  const catGs =
    categoryGroups && categoryGroups.length
      ? categoryGroups
      : groups.filter((g) => g.design === '(Category / No Style)');
  if (catGs.length) {
    const catTitle = categoryName
      ? `Main Category Stock Analysis — ${categoryName}`
      : 'Main Category Stock Analysis';
    buildTransposedSheet('01 Main Category', catTitle, catGs, false);
  }

  // Design groups only
  const designOnly = groups
    .filter((g) => g.design !== '(Category / No Style)')
    .slice()
    .sort((a, b) => a.design.localeCompare(b.design, undefined, { numeric: true, sensitivity: 'base' }));

  // Sheet 2 — All designs
  if (designOnly.length) {
    buildTransposedSheet(
      '02 All Designs',
      'Design-wise Stock Analysis — All Designs',
      designOnly,
      true,
    );
  } else if (groups.length && !catGs.length) {
    buildTransposedSheet('02 All Designs', 'Design-wise Stock Analysis — All Designs', groups, true);
  }

  // Sheets 3+ — one per design (carats on top, branches left)
  for (const g of designOnly) {
    buildTransposedSheet(g.design, `Design: ${g.design}`, [g], false);
  }

  const buffer = await wb.xlsx.writeBuffer();
  downloadBlob(
    new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
    'design_wise_stock_analysis.xlsx',
  );
}


/* --------------------------------------------------------------------------
 * Refill Demand Invoice / Purchase Order PDF (logo + professional bordered grid)
 * -------------------------------------------------------------------------- */
export interface RefillInvoiceLine {
  designCode: string;
  qty: number;
  price: number;
  /** Optional category / product family shown on the invoice grid. */
  category?: string;
}
export interface RefillInvoiceData {
  poNumber: string;
  /** Display date, e.g. 04-10-2026 */
  date: string;
  outletName: string;
  supplierName: string;
  /** Currency code shown in PDF (jsPDF core fonts cannot draw ৳), e.g. 'BDT' */
  currency: string;
  lines: RefillInvoiceLine[];
  notes?: string;
}

async function loadInvoiceLogo(): Promise<{ dataUrl: string; ratio: number } | null> {
  try {
    const url = getStoredSettings().whiteLabel.logoUrl || '/diamatrix-logo-full.png';
    let dataUrl = url;
    if (!url.startsWith('data:image/')) {
      const res = await fetch(url, { mode: 'cors' });
      if (!res.ok) return null;
      const blob = await res.blob();
      dataUrl = await new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(String(r.result || ''));
        r.onerror = () => reject(new Error('logo read failed'));
        r.readAsDataURL(blob);
      });
    }
    // Re-draw through a canvas: guarantees PNG (jsPDF-safe, e.g. for SVG logos) and gives us the aspect ratio.
    const img = new Image();
    img.src = dataUrl;
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error('logo decode failed'));
    });
    const w = img.naturalWidth || 900;
    const h = img.naturalHeight || 194;
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(img, 0, 0, w, h);
    return { dataUrl: canvas.toDataURL('image/png'), ratio: w / h };
  } catch {
    return null;
  }
}

const fmtMoney = (n: number) =>
  (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Standard A4 invoice PDF: logo header, outlet/supplier boxes, bordered item grid, grand total, signatures. */
export async function exportRefillInvoicePdf(data: RefillInvoiceData): Promise<void> {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const W = 210;
  const H = 297;
  const M = 12;
  const innerW = W - M * 2;
  const NAVY: [number, number, number] = [11, 37, 69];
  const GRID: [number, number, number] = [51, 65, 85];
  const HEAD_BG: [number, number, number] = [217, 226, 236];
  const logo = await loadInvoiceLogo();
  const lines = data.lines.filter((l) => l.designCode.trim() && l.qty > 0);
  const grand = lines.reduce((sum, l) => sum + l.qty * l.price, 0);
  const totalQty = lines.reduce((sum, l) => sum + l.qty, 0);

  const drawHeader = (): number => {
    doc.setDrawColor(...GRID);
    doc.setLineWidth(0.4);
    doc.rect(M, M, innerW, 24);
    if (logo) {
      const lh = 16;
      const lw = Math.min(70, lh * logo.ratio);
      try { doc.addImage(logo.dataUrl, 'PNG', M + 3, M + 4, lw, lw / logo.ratio); } catch { /* text header fallback below */ }
    } else {
      doc.setFont('helvetica', 'bold'); doc.setFontSize(14); doc.setTextColor(...NAVY);
      doc.text(APP_BRAND.company, M + 3, M + 13);
    }
    doc.setTextColor(...NAVY);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(15);
    doc.text('PURCHASE ORDER / INVOICE', W - M - 3, M + 10, { align: 'right' });
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(71, 85, 105);
    doc.text('Refill Demand Requisition', W - M - 3, M + 16, { align: 'right' });
    doc.text(APP_BRAND.company, W - M - 3, M + 21, { align: 'right' });
    return M + 24;
  };

  let y = drawHeader();

  // Meta + party boxes (2 columns x 2 rows grid)
  const boxH = 12;
  const half = innerW / 2;
  const cell = (label: string, value: string, x: number, yy: number, w: number) => {
    doc.setDrawColor(...GRID); doc.setLineWidth(0.3); doc.rect(x, yy, w, boxH);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(7); doc.setTextColor(100, 116, 139);
    doc.text(label.toUpperCase(), x + 2, yy + 4);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.setTextColor(15, 23, 42);
    doc.text(doc.splitTextToSize(value || '-', w - 4).slice(0, 1), x + 2, yy + 9.5);
  };
  cell('PO / Invoice No', data.poNumber, M, y, half);
  cell('Date', data.date, M + half, y, half);
  cell('Bill To / Outlet', data.outletName, M, y + boxH, half);
  cell('Bill From / Supplier', data.supplierName, M + half, y + boxH, half);
  y += boxH * 2 + 6;

  // Item grid — SL, SKU, Category, Qty, Price, Total Amount (premium blue/silver borders)
  const cols = [
    { h: 'SL', w: 10, a: 'center' as const },
    { h: 'SKU', w: 52, a: 'left' as const },
    { h: 'Category', w: 28, a: 'left' as const },
    { h: 'Qty', w: 18, a: 'right' as const },
    { h: `Price (${data.currency})`, w: 30, a: 'right' as const },
    { h: `Total Amount (${data.currency})`, w: innerW - 10 - 52 - 28 - 18 - 30, a: 'right' as const },
  ];
  const rowH = 8;
  const drawRow = (vals: string[], opts: { head?: boolean; bold?: boolean; fill?: [number, number, number] } = {}) => {
    let x = M;
    cols.forEach((c, i) => {
      if (opts.head || opts.fill) {
        doc.setFillColor(...(opts.head ? HEAD_BG : opts.fill!));
        doc.rect(x, y, c.w, rowH, 'F');
      }
      doc.setDrawColor(...GRID); doc.setLineWidth(0.3); doc.rect(x, y, c.w, rowH);
      doc.setFont('helvetica', opts.head || opts.bold ? 'bold' : 'normal');
      doc.setFontSize(opts.head ? 8.5 : 9);
      doc.setTextColor(opts.head ? 11 : 15, opts.head ? 37 : 23, opts.head ? 69 : 42);
      const txt = doc.splitTextToSize(vals[i] ?? '', c.w - 4)[0] || '';
      const tx = c.a === 'right' ? x + c.w - 2 : c.a === 'center' ? x + c.w / 2 : x + 2;
      doc.text(txt, tx, y + 5.4, { align: c.a });
      x += c.w;
    });
    y += rowH;
  };
  const footerReserve = 70;
  const newPage = () => { doc.addPage('a4', 'portrait'); y = drawHeader() + 6; drawRow(cols.map((c) => c.h), { head: true }); };

  drawRow(cols.map((c) => c.h), { head: true });
  lines.forEach((l, i) => {
    if (y + rowH > H - M - 12) newPage();
    drawRow([
      String(i + 1),
      l.designCode,
      l.category || '-',
      String(l.qty),
      fmtMoney(l.price),
      fmtMoney(l.qty * l.price),
    ]);
  });
  if (y + rowH * 2 + footerReserve > H - M) newPage();
  // Totals rows (merged label cells) — same bordered grid
  const totalRow = (label: string, qty: string, amount: string, fill: [number, number, number]) => {
    const labelW = cols[0].w + cols[1].w + cols[2].w;
    doc.setFillColor(...fill); doc.rect(M, y, innerW, rowH, 'F');
    doc.setDrawColor(...GRID); doc.setLineWidth(0.3);
    doc.rect(M, y, labelW, rowH);
    doc.rect(M + labelW, y, cols[3].w, rowH);
    doc.rect(M + labelW + cols[3].w, y, cols[4].w, rowH);
    doc.rect(M + labelW + cols[3].w + cols[4].w, y, cols[5].w, rowH);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(9.5); doc.setTextColor(15, 23, 42);
    doc.text(label, M + labelW - 2, y + 5.4, { align: 'right' });
    doc.text(qty, M + labelW + cols[3].w - 2, y + 5.4, { align: 'right' });
    doc.text(amount, W - M - 2, y + 5.4, { align: 'right' });
    y += rowH;
  };
  totalRow('Total', String(totalQty), fmtMoney(grand), [241, 245, 249]);
  totalRow(`GRAND TOTAL (${data.currency})`, '', fmtMoney(grand), [198, 239, 206]);

  if (data.notes?.trim()) {
    y += 5;
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.setTextColor(71, 85, 105);
    doc.text('NOTES', M, y);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(15, 23, 42);
    const noteLines = doc.splitTextToSize(data.notes.trim(), innerW).slice(0, 4);
    doc.text(noteLines, M, y + 5);
    y += 5 + noteLines.length * 4;
  }

  // Signature boxes
  const sigY = Math.max(y + 18, H - M - 38);
  const sigW = innerW / 3;
  ['Prepared By', 'Approved By', 'Supplier Receipt'].forEach((label, i) => {
    const x = M + sigW * i;
    doc.setDrawColor(...GRID); doc.setLineWidth(0.3); doc.rect(x, sigY, sigW, 24);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.setTextColor(71, 85, 105);
    doc.text(label, x + sigW / 2, sigY + 21, { align: 'center' });
  });

  // Page footer
  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(100, 116, 139);
    doc.text(`${APP_BRAND.company} · ${data.poNumber} · Generated ${new Date().toLocaleString()}`, M, H - 6);
    doc.text(`Page ${p} / ${pages}`, W - M, H - 6, { align: 'right' });
  }
  doc.save(`${data.poNumber.replace(/[^a-z0-9_-]+/gi, '_')}.pdf`);
}
