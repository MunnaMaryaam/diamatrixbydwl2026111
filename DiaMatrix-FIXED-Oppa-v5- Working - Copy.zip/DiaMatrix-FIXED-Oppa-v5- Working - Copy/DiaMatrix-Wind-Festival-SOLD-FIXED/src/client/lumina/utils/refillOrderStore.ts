/**
 * Refill purchase-order store (browser localStorage, tiny pub/sub).
 * "Requisition" in Refill Demand creates an order here; the New Order page lists / edits / exports them.
 */
import { useSyncExternalStore } from 'react';

export interface RefillOrderLine {
  id: number;
  designCode: string;
  qty: number;
  price: number;
  /** Optional product family / category for invoice lines (SKU grouping). */
  category?: string;
}

export interface RefillOrder {
  id: string; // PO number
  createdAt: string; // ISO
  source: 'requisition' | 'manual';
  /** Outlet code, or '' for an all-outlet / central requisition */
  outlet: string;
  supplier: string;
  notes: string;
  lines: RefillOrderLine[];
}

const ORDERS_KEY = 'dmx_refill_orders_v1';
const SEQ_KEY = 'dmx_refill_po_seq';
export const DEFAULT_SUPPLIER = 'Central Hub (DWL)';

let orders: RefillOrder[] = read();
let selectedId: string | null = orders[0]?.id ?? null;
const listeners = new Set<() => void>();

function read(): RefillOrder[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]');
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function commit(next: RefillOrder[], nextSelected: string | null = selectedId) {
  orders = next;
  selectedId = nextSelected;
  try { localStorage.setItem(ORDERS_KEY, JSON.stringify(orders)); } catch { /* storage unavailable */ }
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => { listeners.delete(l); };
}

// useSyncExternalStore needs a stable snapshot per state: bundle both in one cached object.
let snapshot: { orders: RefillOrder[]; selectedId: string | null } = { orders, selectedId };
function getSnapshot() {
  if (snapshot.orders !== orders || snapshot.selectedId !== selectedId) snapshot = { orders, selectedId };
  return snapshot;
}

export function useRefillOrders() {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
}

export function nextPoNumber(): string {
  let seq = 0;
  try { seq = parseInt(localStorage.getItem(SEQ_KEY) || '0', 10) || 0; } catch { /* ignore */ }
  seq += 1;
  try { localStorage.setItem(SEQ_KEY, String(seq)); } catch { /* ignore */ }
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  return `PO-${ymd}-${String(seq).padStart(3, '0')}`;
}

export function createOrder(input: Partial<Omit<RefillOrder, 'id' | 'createdAt'>> & { lines?: RefillOrderLine[] }): RefillOrder {
  const order: RefillOrder = {
    id: nextPoNumber(),
    createdAt: new Date().toISOString(),
    source: input.source ?? 'manual',
    outlet: input.outlet ?? '',
    supplier: input.supplier ?? DEFAULT_SUPPLIER,
    notes: input.notes ?? '',
    lines: input.lines ?? [],
  };
  commit([order, ...orders], order.id);
  return order;
}

export function updateOrder(id: string, patch: Partial<Omit<RefillOrder, 'id' | 'createdAt'>>) {
  commit(orders.map((o) => (o.id === id ? { ...o, ...patch } : o)));
}

export function deleteOrder(id: string) {
  const next = orders.filter((o) => o.id !== id);
  commit(next, selectedId === id ? next[0]?.id ?? null : selectedId);
}

export function selectOrder(id: string | null) {
  commit(orders, id);
}

/** Fired by the Requisition button; App switches to the New Order page. */
export const OPEN_NEW_ORDER_EVENT = 'dmx:open-new-order';
