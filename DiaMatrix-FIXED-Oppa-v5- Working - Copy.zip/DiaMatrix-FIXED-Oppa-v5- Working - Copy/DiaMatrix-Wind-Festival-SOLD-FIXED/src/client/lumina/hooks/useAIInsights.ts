import { useDeferredValue, useMemo } from 'react';
import type { RawInventoryRecord, SpecialMonth } from '../types';
import {
  forecastTopCategories,
  type DemandForecastResult,
} from '../utils/demandForecastEngine';
import {
  generateSmartRedistributionRecommendations,
  type SmartTransferRecommendation,
} from '../utils/smartRedistributionEngine';

export interface AIInsights {
  forecasts: DemandForecastResult[];
  transfers: SmartTransferRecommendation[];
  /** true while a newly uploaded dataset is still being processed */
  isRefreshing: boolean;
}

const NO_SPECIAL_MONTHS: SpecialMonth[] = [];

/**
 * Single entry point that feeds the working dataset (whatever the upload
 * pipeline last produced) into the demand-forecast and smart-redistribution
 * engines. Every consumer should use this hook so that:
 *  - results recompute automatically when `records` or `specialMonths` change
 *  - computation is memoized (no re-run on unrelated re-renders)
 *  - large uploads don't block the UI thread (useDeferredValue)
 */
export function useAIInsights(
  records: RawInventoryRecord[],
  specialMonths: SpecialMonth[] = NO_SPECIAL_MONTHS,
): AIInsights {
  const deferredRecords = useDeferredValue(records);
  const isRefreshing = deferredRecords !== records;

  const forecasts = useMemo(
    () => forecastTopCategories(deferredRecords, specialMonths),
    [deferredRecords, specialMonths],
  );

  const transfers = useMemo(
    () => generateSmartRedistributionRecommendations(deferredRecords),
    [deferredRecords],
  );

  return { forecasts, transfers, isRefreshing };
}

export default useAIInsights;
