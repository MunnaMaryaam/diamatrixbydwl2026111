/**
 * AI Insights store (Zustand)
 *
 * Single source of truth for the output of the two analytical engines:
 *  - demandForecastEngine      -> category demand forecasts with natural-language alerts
 *  - smartRedistributionEngine -> branch-to-branch transfer recommendations
 *
 * `runInsights` is called as soon as an upload has been parsed and normalized, so the
 * results are already in state by the time the dashboard re-renders. It is also called
 * from an effect in App for any other path that replaces the working dataset
 * (initial load, restore from upload history, and so on).
 */
import { create } from 'zustand';
import { useShallow } from 'zustand/react/shallow';
import type { RawInventoryRecord, SpecialMonth } from '../types';
import {
  forecastTopCategories,
  type DemandForecastResult,
} from '../utils/demandForecastEngine';
import {
  generateSmartRedistributionRecommendations,
  type SmartTransferRecommendation,
} from '../utils/smartRedistributionEngine';

export type InsightsSource = 'initial' | 'upload' | 'history' | 'sync';
export type InsightsStatus = 'idle' | 'ready' | 'error';

interface AIInsightsState {
  forecasts: DemandForecastResult[];
  transfers: SmartTransferRecommendation[];
  status: InsightsStatus;
  source: InsightsSource;
  rowCount: number;
  computedAt: number | null;
  errorMessage: string | null;
  runInsights: (
    records: RawInventoryRecord[],
    specialMonths?: SpecialMonth[],
    source?: InsightsSource,
  ) => void;
}

// Reference cache: skips recomputation when the same dataset is pushed twice
// (for example from the import handler and then from the sync effect).
let lastRecords: RawInventoryRecord[] | null = null;
let lastMonths: SpecialMonth[] | undefined;

export const useAIInsightsStore = create<AIInsightsState>((set) => ({
  forecasts: [],
  transfers: [],
  status: 'idle',
  source: 'initial',
  rowCount: 0,
  computedAt: null,
  errorMessage: null,

  runInsights: (records, specialMonths, source = 'sync') => {
    if (records === lastRecords && specialMonths === lastMonths) return;
    lastRecords = records;
    lastMonths = specialMonths;

    try {
      const forecasts = forecastTopCategories(records, specialMonths ?? []);
      const transfers = generateSmartRedistributionRecommendations(records);
      set({
        forecasts,
        transfers,
        status: 'ready',
        source,
        rowCount: records.length,
        computedAt: Date.now(),
        errorMessage: null,
      });
    } catch (error) {
      set({
        forecasts: [],
        transfers: [],
        status: 'error',
        source,
        rowCount: records.length,
        computedAt: Date.now(),
        errorMessage: error instanceof Error ? error.message : 'Insight calculation failed.',
      });
    }
  },
}));

/**
 * Props for <AIIntelligencePanel />, selected from the store in one shallow-compared call.
 * Usage: <AIIntelligencePanel {...useAIInsightsPanelProps()} />
 */
export function useAIInsightsPanelProps() {
  return useAIInsightsStore(
    useShallow((state) => ({
      forecasts: state.forecasts,
      transfers: state.transfers,
      status: state.status,
      rowCount: state.rowCount,
      computedAt: state.computedAt,
      errorMessage: state.errorMessage,
    })),
  );
}
