/**
 * Beautiful official Returnable Pull-back / Replenishment Order Excel
 * Multi-sheet: All Branches | each branch | Summary
 */

import ExcelJS from 'exceljs';
import type { BranchGroup, PdfLabelReport, TransferKind } from './pdfLabelTypes';

const C = {
  navy: 'FF0B1F33',
  head: 'FF0F3A5F',
  headAlt: 'FF1A4A6F',
  accent: 'FF0EA5E9',
  branchBg: 'FFEFF6FF',
  branchBorder: 'FF38BDF8',
  totalBg: 'FFF1F5F9',
  grandBg: 'FF0F172A',
  white: 'FFFFFFFF',
  muted: 'FF64748B',
  text: 'FF0F172A',
  line: 'FFCBD5E1',
  soft: 'FFF8FAFC',
  teal: 'FF0D9488',
  amber: 'FFD97706',
};

function solid(cell: ExcelJS.Cell, argb: string) {
  cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb } };
}

function border(
  cell: ExcelJS.Cell,
  style: 'thin' | 'medium' | 'hair' = 'thin',
  color = C.line,
) {
  const b = { style, color: { argb: color } };
  cell.border = { top: b, left: b, bottom: b, right: b };
}

function box(
  ws: ExcelJS.Worksheet,
  r1: number,
  c1: number,
  r2: number,
  c2: number,
  style: 'thin' | 'medium' = 'medium',
  color = C.navy,
) {
  for (let r = r1; r <= r2; r++) {
    for (let c = c1; c <= c2; c++) {
      const cell = ws.getCell(r, c);
      const p = cell.border || {};
      cell.border = {
        top: r === r1 ? { style, color: { argb: color } } : p.top || { style: 'thin', color: { argb: C.line } },
        bottom: r === r2 ? { style, color: { argb: color } } : p.bottom || { style: 'thin', color: { argb: C.line } },
        left: c === c1 ? { style, color: { argb: color } } : p.left || { style: 'thin', color: { argb: C.line } },
        right: c === c2 ? { style, color: { argb: color } } : p.right || { style: 'thin', color: { argb: C.line } },
      };
    }
  }
}

function dataUrlToBuffer(dataUrl: string): { buffer: ArrayBuffer; ext: 'png' | 'jpeg' } | null {
  try {
    const m = dataUrl.match(/^data:image\/(png|jpeg|jpg|webp);base64,(.+)$/i);
    if (!m) return null;
    const ext = m[1].toLowerCase() === 'png' ? 'png' : 'jpeg';
    const bin = atob(m[2]);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return { buffer: bytes.buffer, ext };
  } catch {
    return null;
  }
}

async function tryLoadLogo(): Promise<{ buffer: ArrayBuffer; ext: 'png' | 'jpeg' } | null> {
  for (const url of ['/diamatrix-mark.png', '/diamatrix-logo-icon.png', '/diamatrix-logo-full.png']) {
    try {
      const res = await fetch(url);
      if (!res.ok) continue;
      const buf = await res.arrayBuffer();
      if (buf.byteLength > 100) return { buffer: buf, ext: 'png' };
    } catch {
      /* */
    }
  }
  return null;
}

function kindTitle(kind?: TransferKind) {
  if (kind === 'returnable') return 'RETURNABLE PULL-BACK ORDER';
  if (kind === 'dropable') return 'REPLENISHMENT ORDER';
  return 'BRANCH LABEL REPORT';
}

function kindShort(kind?: TransferKind) {
  if (kind === 'returnable') return 'Returnable Pull-back';
  if (kind === 'dropable') return 'Replenishment';
  return 'Report';
}

function kindColor(kind?: TransferKind) {
  if (kind === 'returnable') return C.teal;
  if (kind === 'dropable') return C.amber;
  return C.head;
}

function orderNo(kind?: TransferKind) {
  const prefix = kind === 'dropable' ? 'DO' : kind === 'returnable' ? 'RO' : 'LR';
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const t = `${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}`;
  return `${prefix}-${ymd}-${t}`;
}

function sheetName(name: string) {
  return (name.replace(/[\\/*?:\[\]]/g, '_').trim() || 'Branch').slice(0, 31);
}

function setupSheet(ws: ExcelJS.Worksheet) {
  ws.columns = [
    { width: 5 },
    { width: 9 },   // image — matches ~46px photo
    { width: 15 },
    { width: 7 },
    { width: 9 },
    { width: 12 },
    { width: 11 },
    { width: 11 },
  ];
  ws.properties.defaultRowHeight = 18;
  ws.pageSetup = {
    paperSize: 9,
    orientation: 'portrait',
    fitToPage: true,
    fitToWidth: 1,
    fitToHeight: 0,
    horizontalCentered: true,
    margins: { left: 0.55, right: 0.55, top: 0.5, bottom: 0.5, header: 0.2, footer: 0.2 },
  };
}

type HeaderOpts = {
  ws: ExcelJS.Worksheet;
  wb: ExcelJS.Workbook;
  report: PdfLabelReport;
  title: string;
  short: string;
  ono: string;
  logo: { buffer: ArrayBuffer; ext: 'png' | 'jpeg' } | null;
  subtitleExtra?: string;
};

async function writeHeader(opts: HeaderOpts): Promise<{ nextRow: number; headerRow: number }> {
  const { ws, wb, report, title, short, ono, logo, subtitleExtra } = opts;
  const accent = kindColor(report.transferKind);

  // Top accent bar
  for (let c = 1; c <= 8; c++) {
    solid(ws.getCell(1, c), accent);
    ws.getCell(1, c).border = undefined as any;
  }
  ws.getRow(1).height = 6;

  // Logo + title block
  ws.mergeCells(2, 1, 3, 1);
  ws.getRow(2).height = 26;
  ws.getRow(3).height = 22;
  if (logo) {
    const id = wb.addImage({ buffer: logo.buffer as any, extension: logo.ext });
    ws.addImage(id, { tl: { col: 0.2, row: 1.2 }, ext: { width: 48, height: 48 } });
  }

  ws.mergeCells(2, 2, 2, 8);
  const tCell = ws.getCell(2, 2);
  tCell.value = title;
  tCell.font = { name: 'Calibri', bold: true, size: 18, color: { argb: C.navy } };
  tCell.alignment = { vertical: 'middle', horizontal: 'left' };

  ws.mergeCells(3, 2, 3, 8);
  const sCell = ws.getCell(3, 2);
  sCell.value = subtitleExtra
    ? `${report.product || 'D.NOSEPIN'}   ·   ${subtitleExtra}`
    : `${report.product || 'D.NOSEPIN'}   ·   Branch Wise Transfer Document`;
  sCell.font = { name: 'Calibri', size: 11, color: { argb: C.muted } };
  sCell.alignment = { vertical: 'middle' };

  for (let c = 1; c <= 8; c++) {
    solid(ws.getCell(2, c), C.white);
    solid(ws.getCell(3, c), C.white);
  }
  box(ws, 2, 1, 3, 8, 'medium', C.navy);

  // Meta strip
  let r = 4;
  const meta: [string, string][] = [
    ['Order No.', ono],
    ['Document Date', report.reportRunOn || new Date().toLocaleString()],
    ['Transfer Type', short.toUpperCase()],
    ['Generated', new Date().toLocaleString()],
  ];
  const metaStart = r;
  for (const [lab, val] of meta) {
    ws.mergeCells(r, 1, r, 2);
    ws.getCell(r, 1).value = lab;
    ws.getCell(r, 1).font = { name: 'Calibri', bold: true, size: 9, color: { argb: C.muted } };
    solid(ws.getCell(r, 1), C.soft);
    ws.mergeCells(r, 3, r, 8);
    ws.getCell(r, 3).value = val;
    ws.getCell(r, 3).font = { name: 'Calibri', bold: true, size: 10, color: { argb: C.text } };
    solid(ws.getCell(r, 3), C.white);
    for (let c = 1; c <= 8; c++) {
      border(ws.getCell(r, c), 'thin', C.line);
      ws.getCell(r, c).alignment = { vertical: 'middle' };
    }
    ws.getRow(r).height = 18;
    r++;
  }
  box(ws, metaStart, 1, r - 1, 8, 'medium', C.navy);

  r += 1;

  // Column headers
  const headerRow = r;
  const headers = ['Sl', 'Image', 'Barcode', 'Qty', 'Carat', 'Gross Wt (gm)', 'Net Wt (gm)', 'Price (৳)'];
  headers.forEach((h, i) => {
    const cell = ws.getCell(r, i + 1);
    cell.value = h;
    cell.font = { name: 'Calibri', bold: true, size: 10, color: { argb: C.white } };
    solid(cell, C.head);
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    border(cell, 'thin', C.navy);
  });
  ws.getRow(r).height = 24;
  r++;

  return { nextRow: r, headerRow };
}

function writeItem(
  ws: ExcelJS.Worksheet,
  r: number,
  it: { sl: number; barcode: string; carat: number; grossWt: number; netWt: number; price: number; qty?: number; imageDataUrl?: string },
  imgs: { row: number; dataUrl: string }[],
  design?: string,
) {
  ws.getRow(r).height = 52;
  const qty = (it as any).qty ?? 1;
  const specs: { col: number; value: string | number | null; align: 'center' | 'left' | 'right'; mono?: boolean }[] = [
    { col: 1, value: it.sl, align: 'center' },
    { col: 2, value: null, align: 'center' },
    { col: 3, value: it.barcode, align: 'left', mono: true },
    { col: 4, value: qty, align: 'center' },
    { col: 5, value: it.carat, align: 'center' },
    { col: 6, value: it.grossWt, align: 'center' },
    { col: 7, value: it.netWt, align: 'center' },
    { col: 8, value: it.price, align: 'right' },
  ];
  for (const s of specs) {
    const cell = ws.getCell(r, s.col);
    cell.value = s.value;
    cell.font = {
      name: s.mono ? 'Consolas' : 'Calibri',
      size: 10,
      bold: s.col === 8,
      color: { argb: C.text },
    };
    cell.alignment = { horizontal: s.align, vertical: 'middle' };
    border(cell, 'thin', C.line);
    if (s.col === 5) cell.numFmt = '0.00';
    if (s.col === 6) cell.numFmt = '0.0000';
    if (s.col === 7) cell.numFmt = '0.00';
    if (s.col === 8) cell.numFmt = '#,##0';
    if (r % 2 === 0 && s.col !== 2) solid(cell, C.soft);
  }
  const src = design || it.imageDataUrl;
  if (src) imgs.push({ row: r, dataUrl: src });
}

function writeBranchBanner(ws: ExcelJS.Worksheet, r: number, br: BranchGroup) {
  ws.mergeCells(r, 1, r, 8);
  for (let c = 1; c <= 8; c++) {
    solid(ws.getCell(r, c), C.branchBg);
    border(ws.getCell(r, c), 'thin', C.branchBorder);
  }
  ws.getCell(r, 1).value =
    `  ${br.branch}     ${br.totalPcs} pcs  ·  Carat ${br.totalCarat}  ·  Net ${br.totalNetWt} g  ·  ৳ ${br.totalPrice.toLocaleString()}`;
  ws.getCell(r, 1).font = { name: 'Calibri', bold: true, size: 11, color: { argb: C.navy } };
  ws.getCell(r, 1).alignment = { vertical: 'middle' };
  ws.getRow(r).height = 22;
}

function writeBranchTotal(ws: ExcelJS.Worksheet, r: number, br: BranchGroup) {
  ws.mergeCells(r, 1, r, 2);
  for (let c = 1; c <= 8; c++) {
    solid(ws.getCell(r, c), C.totalBg);
    border(ws.getCell(r, c), 'thin', C.muted);
    ws.getCell(r, c).font = { name: 'Calibri', bold: true, size: 10, color: { argb: C.text } };
    ws.getCell(r, c).alignment = { vertical: 'middle', horizontal: c >= 4 ? 'center' : 'left' };
  }
  ws.getCell(r, 1).value = `${br.branch} Total`;
  ws.getCell(r, 3).value = `${br.totalPcs} pcs`;
  ws.getCell(r, 4).value = br.totalQty ?? br.totalPcs;
  ws.getCell(r, 5).value = br.totalCarat;
  ws.getCell(r, 5).numFmt = '0.00';
  ws.getCell(r, 6).value = br.totalGrossWt;
  ws.getCell(r, 6).numFmt = '0.0000';
  ws.getCell(r, 7).value = br.totalNetWt;
  ws.getCell(r, 7).numFmt = '0.00';
  ws.getCell(r, 8).value = br.totalPrice;
  ws.getCell(r, 8).numFmt = '#,##0';
  ws.getCell(r, 8).alignment = { horizontal: 'right', vertical: 'middle' };
  ws.getRow(r).height = 22;
}

function writeGrand(ws: ExcelJS.Worksheet, r: number, label: string, pcs: number, qty: number, carat: number, gross: number, net: number, price: number) {
  ws.mergeCells(r, 1, r, 2);
  for (let c = 1; c <= 8; c++) {
    solid(ws.getCell(r, c), C.grandBg);
    border(ws.getCell(r, c), 'medium', C.navy);
    ws.getCell(r, c).font = { name: 'Calibri', bold: true, size: 11, color: { argb: C.white } };
    ws.getCell(r, c).alignment = { vertical: 'middle', horizontal: c >= 4 ? 'center' : 'left' };
  }
  ws.getCell(r, 1).value = label;
  ws.getCell(r, 3).value = `${pcs} pcs`;
  ws.getCell(r, 4).value = qty;
  ws.getCell(r, 5).value = carat;
  ws.getCell(r, 6).value = gross;
  ws.getCell(r, 7).value = net;
  ws.getCell(r, 8).value = price;
  ws.getCell(r, 8).numFmt = '#,##0';
  ws.getCell(r, 8).alignment = { horizontal: 'right', vertical: 'middle' };
  ws.getRow(r).height = 26;
}

function writeSign(ws: ExcelJS.Worksheet, start: number): number {
  let r = start;
  const sig0 = r;
  ws.mergeCells(r, 1, r, 3);
  ws.getCell(r, 1).value = 'Prepared by';
  ws.getCell(r, 1).font = { name: 'Calibri', bold: true, size: 9, color: { argb: C.muted } };
  ws.mergeCells(r, 5, r, 8);
  ws.getCell(r, 5).value = 'Authorized / Received by';
  ws.getCell(r, 5).font = { name: 'Calibri', bold: true, size: 9, color: { argb: C.muted } };
  r++;
  for (let i = 0; i < 3; i++) {
    ws.getRow(r).height = 14;
    for (let c = 1; c <= 8; c++) {
      solid(ws.getCell(r, c), C.white);
      border(ws.getCell(r, c), 'hair', C.line);
    }
    r++;
  }
  ws.mergeCells(r, 1, r, 3);
  ws.getCell(r, 1).value = 'Name & Signature          Date ________';
  ws.getCell(r, 1).font = { name: 'Calibri', size: 8, color: { argb: C.muted } };
  ws.mergeCells(r, 5, r, 8);
  ws.getCell(r, 5).value = 'Name & Signature          Date ________';
  ws.getCell(r, 5).font = { name: 'Calibri', size: 8, color: { argb: C.muted } };
  box(ws, sig0, 1, r, 8, 'medium', C.navy);
  r += 2;
  ws.mergeCells(r, 1, r, 8);
  ws.getCell(r, 1).value =
    'System-generated document. Gross Wt = lower value on label · Net Wt = upper value · Carat as printed on tag.';
  ws.getCell(r, 1).font = { name: 'Calibri', size: 8, italic: true, color: { argb: 'FF94A3B8' } };
  return r;
}

function embedImgs(wb: ExcelJS.Workbook, ws: ExcelJS.Worksheet, list: { row: number; dataUrl: string }[]) {
  for (const p of list) {
    const parsed = dataUrlToBuffer(p.dataUrl);
    if (!parsed) continue;
    try {
      const id = wb.addImage({ buffer: parsed.buffer as any, extension: parsed.ext });
      // Image sized to fit Image cell (col B), small padding
      ws.addImage(id, {
        tl: { col: 1.08, row: p.row - 1 + 0.12 },
        ext: { width: 46, height: 46 },
      });
    } catch {
      /* */
    }
  }
}

export async function exportPdfLabelExcel(report: PdfLabelReport, filename?: string): Promise<void> {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DiaMatrix';
  wb.created = new Date();

  const title = kindTitle(report.transferKind);
  const short = kindShort(report.transferKind);
  const ono = orderNo(report.transferKind);
  const logo = await tryLoadLogo();
  const design = report.designImageDataUrl;

  // ---- All Branches ----
  const wsAll = wb.addWorksheet('All Branches', { views: [{ showGridLines: false }] });
  setupSheet(wsAll);
  const { nextRow: a0, headerRow: aH } = await writeHeader({
    ws: wsAll, wb, report, title, short, ono, logo,
  });
  let r = a0;
  const imgsAll: { row: number; dataUrl: string }[] = [];
  const tStart = aH;

  for (const br of report.branches) {
    writeBranchBanner(wsAll, r, br);
    r++;
    for (const it of br.items) {
      writeItem(wsAll, r, it, imgsAll, design);
      r++;
    }
    writeBranchTotal(wsAll, r, br);
    r++;
  }
  const tEnd = r - 1;
  writeGrand(wsAll, r, 'GRAND TOTAL', report.grandTotalPcs, report.grandTotalQty ?? report.grandTotalPcs, report.grandTotalCarat, report.grandTotalGrossWt, report.grandTotalNetWt, report.grandTotalPrice);
  r += 2;
  r = writeSign(wsAll, r);
  box(wsAll, tStart, 1, tEnd, 8, 'medium', C.navy);
  embedImgs(wb, wsAll, imgsAll);
  wsAll.views = [{ state: 'frozen', ySplit: aH, showGridLines: false }];

  // ---- Per branch ----
  for (const br of report.branches) {
    const ws = wb.addWorksheet(sheetName(br.branch), { views: [{ showGridLines: false }] });
    setupSheet(ws);
    const { nextRow: b0, headerRow: bH } = await writeHeader({
      ws, wb, report, title, short, ono, logo,
      subtitleExtra: `Branch: ${br.branch}`,
    });
    let brR = b0;
    const imgs: { row: number; dataUrl: string }[] = [];
    const ts = bH;
    writeBranchBanner(ws, brR, br);
    brR++;
    for (const it of br.items) {
      writeItem(ws, brR, it, imgs, design);
      brR++;
    }
    writeBranchTotal(ws, brR, br);
    const te = brR;
    brR += 2;
    writeGrand(ws, brR, `${br.branch} TOTAL`, br.totalPcs, br.totalQty ?? br.totalPcs, br.totalCarat, br.totalGrossWt, br.totalNetWt, br.totalPrice);
    brR += 2;
    brR = writeSign(ws, brR);
    box(ws, ts, 1, te, 8, 'medium', C.navy);
    embedImgs(wb, ws, imgs);
    ws.views = [{ state: 'frozen', ySplit: bH, showGridLines: false }];
  }

  // ---- Summary ----
  const wsSum = wb.addWorksheet('Summary', { views: [{ showGridLines: false }] });
  setupSheet(wsSum);
  const { nextRow: s0, headerRow: sH } = await writeHeader({
    ws: wsSum, wb, report, title: `${title} — SUMMARY`, short, ono, logo,
    subtitleExtra: 'Branch totals overview',
  });
  // Override header labels for summary
  ['#', 'Branch', 'Pcs', 'Qty', 'Carat', 'Gross Wt', 'Net Wt', 'Price (৳)'].forEach((h, i) => {
    const cell = wsSum.getCell(sH, i + 1);
    cell.value = h;
    cell.font = { name: 'Calibri', bold: true, size: 10, color: { argb: C.white } };
    solid(cell, C.head);
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    border(cell, 'thin', C.navy);
  });
  let sr = s0;
  report.branches.forEach((br, i) => {
    const vals: (string | number)[] = [i + 1, br.branch, br.totalPcs, br.totalQty ?? br.totalPcs, br.totalCarat, br.totalGrossWt, br.totalNetWt, br.totalPrice];
    vals.forEach((v, ci) => {
      const cell = wsSum.getCell(sr, ci + 1);
      cell.value = v;
      cell.font = { name: 'Calibri', size: 10, bold: ci === 1, color: { argb: C.text } };
      cell.alignment = { horizontal: ci === 1 ? 'left' : 'center', vertical: 'middle' };
      border(cell, 'thin', C.line);
      if (i % 2 === 1) solid(cell, C.soft);
      if (ci === 4) cell.numFmt = '0.00';
      if (ci === 5) cell.numFmt = '0.0000';
      if (ci === 6) cell.numFmt = '0.00';
      if (ci === 7) cell.numFmt = '#,##0';
    });
    sr++;
  });
  for (let c = 1; c <= 8; c++) {
    solid(wsSum.getCell(sr, c), C.grandBg);
    border(wsSum.getCell(sr, c), 'medium', C.navy);
    wsSum.getCell(sr, c).font = { name: 'Calibri', bold: true, size: 10, color: { argb: C.white } };
  }
  wsSum.getCell(sr, 2).value = 'GRAND TOTAL';
  wsSum.getCell(sr, 3).value = report.grandTotalPcs;
  wsSum.getCell(sr, 4).value = report.grandTotalQty ?? report.grandTotalPcs;
  wsSum.getCell(sr, 5).value = report.grandTotalCarat;
  wsSum.getCell(sr, 6).value = report.grandTotalGrossWt;
  wsSum.getCell(sr, 7).value = report.grandTotalNetWt;
  wsSum.getCell(sr, 8).value = report.grandTotalPrice;
  wsSum.getCell(sr, 8).numFmt = '#,##0';
  wsSum.views = [{ state: 'frozen', ySplit: sH, showGridLines: false }];

  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename || `${short}_${report.product.replace(/\W+/g, '_')}_${ono}.xlsx`;
  a.click();
  URL.revokeObjectURL(url);
}

export function exportPdfLabelCsv(report: PdfLabelReport, filename?: string): void {
  const short = kindShort(report.transferKind);
  const lines = [
    `"${kindTitle(report.transferKind)}"`,
    `"Product: ${report.product}"`,
    `"Report run on: ${report.reportRunOn}"`,
    `"Type: ${short}"`,
    '',
    'Sl,Branch,Barcode,Qty,Carat,Gross Wt (gm),Net Wt (gm),Price',
  ];
  for (const br of report.branches) {
    for (const it of br.items) {
      lines.push([it.sl, br.branch, it.barcode, it.qty ?? 1, it.carat, it.grossWt, it.netWt, it.price].join(','));
    }
  }
  lines.push(
    `,"GRAND TOTAL",${report.grandTotalPcs} pcs,${report.grandTotalQty ?? report.grandTotalPcs},${report.grandTotalCarat},${report.grandTotalGrossWt},${report.grandTotalNetWt},${report.grandTotalPrice}`,
  );
  const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download =
    filename ||
    `${short}_${report.product.replace(/\W+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
