/**
 * Design-wise Stock vs Sold matching from image label PDFs.
 *
 * Rules:
 * - Match key = normalized design number (vendor prefixes stripped)
 * - Each barcode/tag = 1 pc
 * - Same design may have different weight / carat
 * - Amount taken from Stock only (Sold PDFs usually have no price)
 */

import type { LabelItem, PdfLabelReport } from './pdfLabelTypes';

const VENDOR_PREFIX_RE =
  /^(?:PGJ|PJX|DWL|NICE|HRKJ|PKGJ|PKRJ|PRML|FAB|PIND|PKMJ|PASJ|REJW|GSTR|TJIM|ARNA|AKST|ADYA|AADA|ANUJ|DANT|KOSA|GHIR|SKV|KANT|PUJ|KGK|FEB|MAR|MAY|APR|TARA|UMA|UDAY|SPRS|SNVI|BALA|BNMJ|BIRA|PREN|PPJ|PVJ|PCJ|PKOJ|HRAJ|MIDA|ELEG|SKV|GHR|ANUJ)-/i;

const DATE_PAREN_RE = /\s*\(\s*\d{1,2}[-/][A-Z]{3}[^)]*\)?/gi;

/**
 * Full design token (optional vendor prefix + core).
 * Covers WLR/ILR/TLR, R####, FR####, IME/LME, IJRCX, JRG/JRC/JRY...,
 * DWR, SBLR, FAB-xxx-RN, RG/xxx, RGG..., etc. as seen in Stock/Sold image PDFs.
 */
const DESIGN_TOKEN_RE = new RegExp(
  String.raw`\b((?:[A-Z]{2,6}-){0,3}(?:` +
    String.raw`WLR\d{2}-\d{4,5}(?:-[A-Z0-9]+)?|NP[A-Z0-9\-]{2,20}` +
    String.raw`|ILR\d{2}-\d{4,5}(?:-[A-Z0-9]+)?` +
    String.raw`|TLR\d{2}-\d{3,5}(?:-[A-Z0-9]+)?` +
    String.raw`|TLR\d{2}-[A-Z]{2,5}-\d+` +
    String.raw`|R\d{3,5}` +
    String.raw`|FR\d{4}[A-Z]?` +
    String.raw`|HR\d{4}[A-Z]?` +
    String.raw`|IME\s?\d{3,5}[A-Z]?` +
    String.raw`|LME\d{3,5}[A-Z]?` +
    String.raw`|INV\d{3,5}[A-Z]?` +
    String.raw`|RG[GNF/][A-Z0-9/]{2,14}` +
    String.raw`|RG\/[A-Z0-9]{2,12}` +
    String.raw`|IJRCX\d+[A-Z]*` +
    String.raw`|JR[CGYHFSRA]\d+[A-Z0-9]*` +
    String.raw`|DWR-[\w\-]{3,20}` +
    String.raw`|FAB-\d+-RN` +
    String.raw`|SBLR-?\d+` +
    String.raw`|CR\d{4,6}` +
    String.raw`|LDRG\d+[A-Z0-9]*` +
    String.raw`|UIRG\d+` +
    String.raw`|KR\d{5,7}[A-Z]?` +
    String.raw`|KLR\d+` +
    String.raw`|MR\d{3,5}` +
    String.raw`|RR\d{4,6}[A-Z]?` +
    String.raw`|SRN\d+` +
    String.raw`|CLR\d+` +
    String.raw`|LR[-]?\d{3,6}` +
    String.raw`|IR\d{4,6}[A-Z]?` +
    String.raw`|DR\d{4,6}` +
    String.raw`|RNG\d{4,6}` +
    String.raw`|BJLR\d+` +
    String.raw`|SLR\d+` +
    String.raw`|VJR[A0-9][A-Z0-9]*` +
    String.raw`|NJR-?\d+` +
    String.raw`|DEI\d+` +
    String.raw`|ECR-?\d+` +
    String.raw`|R-\d{3,5}` +
    String.raw`|DJLR\d+\w*` +
    String.raw`|RGF\d+\w*` +
    String.raw`|RGG\d+\w*` +
    String.raw`|RGN\d+\w*` +
    String.raw`|AJR\d+` +
    String.raw`|JYPS\d+[A-Z]?` +
    String.raw`))\b`,
  'gi',
);

export function normalizeDesignCode(raw: string): string {
  let s = String(raw || '')
    .toUpperCase()
    .replace(DATE_PAREN_RE, '')
    .replace(/\s+/g, '')
    .trim();
  for (let i = 0; i < 4; i++) {
    const next = s.replace(VENDOR_PREFIX_RE, '');
    if (next === s) break;
    s = next;
  }
  return s.replace(/^[-/.]+|[-/.]+$/g, '');
}

/** Pull design codes from raw PDF text (layout / pdf.js text). */
export function extractDesignTokensFromText(rawText: string): string[] {
  if (!rawText) return [];
  const cleaned = rawText.replace(DATE_PAREN_RE, ' ');
  const out: string[] = [];
  let m: RegExpExecArray | null;
  const re = new RegExp(DESIGN_TOKEN_RE.source, 'gi');
  while ((m = re.exec(cleaned)) !== null) {
    const n = normalizeDesignCode(m[1]);
    if (n.length >= 3) out.push(n);
  }
  return out;
}

export interface DesignAgg {
  design: string;
  soldQty: number;
  stockQty: number;
  totalQty: number;
  /** Sum of stock tag prices */
  stockAmount: number;
  status: 'BOTH' | 'STOCK_ONLY' | 'SOLD_ONLY';
}

export interface StockVsSoldReport {
  stockFileName: string;
  soldFileName: string;
  generatedAt: string;
  rows: DesignAgg[];
  totalUnique: number;
  bothCount: number;
  stockOnlyCount: number;
  soldOnlyCount: number;
  totalStockPcs: number;
  totalSoldPcs: number;
  totalStockAmount: number;
}


/** Map design → invoice date from patterns like PJX-LME1784 (14-SEP-26) or broken (14-APR-\n26) */
/** Map design → invoice date; handles broken "(14-APR-\n23)" line wraps */
export function extractDesignDateMap(rawText: string): Map<string, string> {
  const map = new Map<string, string>();
  if (!rawText) return map;
  let m: RegExpExecArray | null;

  const put = (rawDesign: string, code: string) => {
    const d = normalizeDesignCode(rawDesign);
    const c = code.toUpperCase().replace(/\s+/g, '');
    if (d.length < 3) return;
    if (!/^\d{1,2}-[A-Z]{3}-\d{2,4}$/.test(c)) return;
    // prefer first date seen for design (or keep existing)
    if (!map.has(d)) map.set(d, c);
  };

  // Complete: DESIGN (14-SEP-26)
  const re =
    /\b([A-Z0-9][A-Z0-9\/\-]{3,30})\s*\(\s*(\d{1,2}-[A-Z]{3}-\d{2,4})\s*\)/gi;
  while ((m = re.exec(rawText)) !== null) put(m[1], m[2]);

  // Broken newline: DESIGN (14-APR- \n 23)
  const re2 =
    /\b([A-Z0-9][A-Z0-9\/\-]{3,30})\s*\(\s*(\d{1,2}-[A-Z]{3}-)\s*[\r\n]+\s*(\d{2,4})\s*\)/gi;
  while ((m = re2.exec(rawText)) !== null) put(m[1], m[2] + m[3]);

  // Loose: DESIGN (14-APR- then within 50 chars year + )
  const re3 =
    /\b([A-Z0-9][A-Z0-9\/\-]{3,30})\s*\(\s*(\d{1,2}-[A-Z]{3}-)/gi;
  while ((m = re3.exec(rawText)) !== null) {
    const tail = rawText.slice(m.index, m.index + 55);
    // must end year with ) to avoid eating next design codes
    const year = tail.match(
      /\((\d{1,2}-[A-Z]{3}-)[^0-9\)]{0,30}(\d{2,4})\s*\)/i,
    );
    if (year) put(m[1], year[1] + year[2]);
  }

  return map;
}


function aggregateFromReport(report: PdfLabelReport | null, rawText: string): Map<string, { qty: number; amount: number }> {
  const map = new Map<string, { qty: number; amount: number }>();
  const bump = (design: string, qty: number, amount: number) => {
    const d = normalizeDesignCode(design);
    if (!d || d.length < 3) return;
    const prev = map.get(d) || { qty: 0, amount: 0 };
    prev.qty += qty;
    prev.amount += amount;
    map.set(d, prev);
  };

  // Primary: structured items — each item/image/barcode = 1 qty
  let structuredPcs = 0;
  if (report) {
    for (const br of report.branches) {
      for (const it of br.items) {
        const d = normalizeDesignCode(it.designCode || '');
        if (d.length < 3) continue;
        bump(d, 1, it.price || 0);
        structuredPcs += 1;
      }
    }
  }
  const barcodeCount = (rawText.match(/\b\d{10,14}\b/g) || []).length;
  const declared = report?.grandTotalPcs || report?.grandTotalQty || 0;
  const totalPcs = Math.max(declared, barcodeCount);
  if (structuredPcs > 0 && totalPcs > 0 && structuredPcs >= totalPcs * 0.5) {
    return map;
  }

  // Fallback: text design tokens
  const tokens = extractDesignTokensFromText(rawText);
  const textCounts = new Map<string, number>();
  for (const t of tokens) {
    const d = normalizeDesignCode(t);
    if (d.length >= 3) textCounts.set(d, (textCounts.get(d) || 0) + 1);
  }
  const textTotal = [...textCounts.values()].reduce((s, v) => s + v, 0);
  const scale = totalPcs > 0 && textTotal > totalPcs * 1.35 ? totalPcs / textTotal : 1;
  if (textTotal > 0 && structuredPcs < totalPcs * 0.5) {
    map.clear();
    const totalPrice = report?.grandTotalPrice || 0;
    const scaledTotal = Math.max(1, Math.round(textTotal * scale));
    for (const [d, c] of textCounts) {
      const qty = Math.max(1, Math.round(c * scale));
      const amt = totalPrice > 0 ? (totalPrice * qty) / scaledTotal : 0;
      bump(d, qty, amt);
    }
  }

  if (map.size === 0 && report) {
    const productFallback = (report.product || 'ITEM').replace(/\s+/g, '').toUpperCase() || 'ITEM';
    for (const br of report.branches) {
      for (const it of br.items) {
        const caratKey = it.carat && it.carat > 0 ? it.carat.toFixed(2) : '0.00';
        bump(`${productFallback}-${caratKey}`, 1, it.price || 0);
      }
    }
  }
  return map;
}

/**
 * Build design-wise Stock vs Sold quantity report.
 * Pass parsed reports when available; always pass raw text for design fallback.
 */
export function buildStockVsSoldReport(opts: {
  stockReport: PdfLabelReport | null;
  soldReport: PdfLabelReport | null;
  stockText: string;
  soldText: string;
  stockFileName?: string;
  soldFileName?: string;
}): StockVsSoldReport {
  const stockMap = aggregateFromReport(opts.stockReport, opts.stockText);
  const soldMap = aggregateFromReport(opts.soldReport, opts.soldText);

  // Sold should not carry amount — zero it
  for (const v of soldMap.values()) v.amount = 0;

  const all = new Set([...stockMap.keys(), ...soldMap.keys()]);
  const rows: DesignAgg[] = [];

  for (const design of all) {
    const st = stockMap.get(design);
    const so = soldMap.get(design);
    const stockQty = st?.qty || 0;
    const soldQty = so?.qty || 0;
    const stockAmount = st?.amount || 0;
    let status: DesignAgg['status'] = 'SOLD_ONLY';
    if (stockQty && soldQty) status = 'BOTH';
    else if (stockQty) status = 'STOCK_ONLY';
    rows.push({
      design,
      soldQty,
      stockQty,
      totalQty: soldQty + stockQty,
      stockAmount: Math.round(stockAmount),
      status,
    });
  }

  rows.sort((a, b) => b.totalQty - a.totalQty || b.stockAmount - a.stockAmount || a.design.localeCompare(b.design));

  // Prefer declared grand totals from parsed reports (barcode/branch counts)
  // so KPI cards stay accurate even when some design codes are missed in text.
  const stockPcsFromRows = rows.reduce((s, r) => s + r.stockQty, 0);
  const soldPcsFromRows = rows.reduce((s, r) => s + r.soldQty, 0);
  const stockPcsDeclared = opts.stockReport?.grandTotalPcs || opts.stockReport?.grandTotalQty || 0;
  const soldPcsDeclared = opts.soldReport?.grandTotalPcs || opts.soldReport?.grandTotalQty || 0;

  return {
    stockFileName: opts.stockFileName || 'Stock.pdf',
    soldFileName: opts.soldFileName || 'Sold.pdf',
    generatedAt: new Date().toLocaleString(),
    rows,
    totalUnique: rows.length,
    bothCount: rows.filter((r) => r.status === 'BOTH').length,
    stockOnlyCount: rows.filter((r) => r.status === 'STOCK_ONLY').length,
    soldOnlyCount: rows.filter((r) => r.status === 'SOLD_ONLY').length,
    totalStockPcs: Math.max(stockPcsFromRows, stockPcsDeclared),
    totalSoldPcs: Math.max(soldPcsFromRows, soldPcsDeclared),
    totalStockAmount: rows.reduce((s, r) => s + r.stockAmount, 0),
  };
}

/** Attach design codes onto LabelItems from nearby text when missing. */
export function enrichItemsWithDesignFromText(report: PdfLabelReport, rawText: string): PdfLabelReport {
  const tokens = extractDesignTokensFromText(rawText);
  if (!tokens.length) return report;

  // Walk items in order; assign next design token when designCode missing
  let ti = 0;
  const branches = report.branches.map((br) => ({
    ...br,
    items: br.items.map((it) => {
      if (it.designCode && normalizeDesignCode(it.designCode).length >= 3) return it;
      const design = tokens[ti];
      if (design) ti += 1;
      return design ? { ...it, designCode: design } : it;
    }),
  }));
  return { ...report, branches };
}

/* ─── Card-level detail for full design report ─────────────────────────── */

export interface DesignCardDetail {
  source: 'stock' | 'sold';
  branch: string;
  barcode: string;
  design: string;
  carat: number;
  grossWt: number;
  netWt: number;
  amount: number; // stock price; 0 for sold
  /** Invoice / tag date from stock image e.g. 27-JUL-22 */
  invoiceDate?: string;
  imageDataUrl?: string;
}

export interface DesignDetailGroup {
  design: string;
  stockQty: number;
  soldQty: number;
  stockAmount: number;
  cards: DesignCardDetail[];
  /** branch → { stock, sold } */
  byOutlet: Record<string, { stock: number; sold: number }>;
}

export interface StockVsSoldDetailReport extends StockVsSoldReport {
  groups: DesignDetailGroup[];
  /** All outlets seen */
  outlets: string[];
}

/**
 * Build detail report with per-tag cards + outlet summary, grouped by design.
 * Uses structured LabelItems when present; falls back to text designs + barcode count.
 */
export function buildStockVsSoldDetailReport(opts: {
  stockReport: PdfLabelReport | null;
  soldReport: PdfLabelReport | null;
  stockText: string;
  soldText: string;
  stockFileName?: string;
  soldFileName?: string;
}): StockVsSoldDetailReport {
  const base = buildStockVsSoldReport(opts);
  const cards: DesignCardDetail[] = [];

  const stockDateMap = extractDesignDateMap(opts.stockText || '');
  const soldDateMap = extractDesignDateMap(opts.soldText || '');

  const pushFromReport = (report: PdfLabelReport | null, source: 'stock' | 'sold') => {
    if (!report) return;
    const dateMap = source === 'stock' ? stockDateMap : soldDateMap;
    const productFallback =
      (report.product || 'ITEM').replace(/\s+/g, '').toUpperCase() || 'ITEM';
    for (const br of report.branches) {
      for (const it of br.items) {
        let design = normalizeDesignCode(it.designCode || '');
        // Fallback: when design code is missing (common in image stock/sold reports)
        // group by product + carat so the matrix still builds fully
        if (!design || design.length < 3) {
          const caratKey = it.carat && it.carat > 0 ? it.carat.toFixed(2) : '0.00';
          design = `${productFallback}-${caratKey}`;
        }
        const invoiceDate =
          it.dateCode ||
          dateMap.get(design) ||
          // try without aggressive normalize
          (it.designCode ? dateMap.get(normalizeDesignCode(it.designCode)) : undefined);
        cards.push({
          source,
          branch: br.branch || 'UNKNOWN',
          barcode: it.barcode,
          design,
          carat: it.carat || 0,
          grossWt: it.grossWt || 0,
          netWt: it.netWt || 0,
          amount: source === 'stock' ? it.price || 0 : 0,
          invoiceDate: invoiceDate || undefined,
          imageDataUrl: it.imageDataUrl,
        });
      }
    }
  };

  pushFromReport(opts.stockReport, 'stock');
  pushFromReport(opts.soldReport, 'sold');

  // Fill any stock cards still missing dates: match by design from map
  for (const c of cards) {
    if (c.source !== 'stock') continue;
    if (c.invoiceDate) continue;
    const d = normalizeDesignCode(c.design);
    const hit = stockDateMap.get(d);
    if (hit) c.invoiceDate = hit;
  }

  // If almost no structured design cards, synthesize minimal cards from aggregate rows
  if (cards.length < 3) {
    for (const row of base.rows) {
      for (let i = 0; i < row.stockQty; i++) {
        cards.push({
          source: 'stock',
          branch: 'STOCK',
          barcode: '',
          design: row.design,
          carat: 0,
          grossWt: 0,
          netWt: 0,
          amount: row.stockQty ? Math.round(row.stockAmount / row.stockQty) : 0,
        });
      }
      for (let i = 0; i < row.soldQty; i++) {
        cards.push({
          source: 'sold',
          branch: 'SOLD',
          barcode: '',
          design: row.design,
          carat: 0,
          grossWt: 0,
          netWt: 0,
          amount: 0,
        });
      }
    }
  }

  const byDesign = new Map<string, DesignCardDetail[]>();
  for (const c of cards) {
    const list = byDesign.get(c.design) || [];
    list.push(c);
    byDesign.set(c.design, list);
  }

  const outletSet = new Set<string>();
  const groups: DesignDetailGroup[] = [];

  for (const [design, list] of byDesign) {
    const byOutlet: Record<string, { stock: number; sold: number }> = {};
    let stockQty = 0;
    let soldQty = 0;
    let stockAmount = 0;
    for (const c of list) {
      outletSet.add(c.branch);
      if (!byOutlet[c.branch]) byOutlet[c.branch] = { stock: 0, sold: 0 };
      if (c.source === 'stock') {
        byOutlet[c.branch].stock += 1;
        stockQty += 1;
        stockAmount += c.amount;
      } else {
        byOutlet[c.branch].sold += 1;
        soldQty += 1;
      }
    }
    groups.push({
      design,
      stockQty,
      soldQty,
      stockAmount: Math.round(stockAmount),
      cards: list,
      byOutlet,
    });
  }

  groups.sort(
    (a, b) =>
      b.stockQty + b.soldQty - (a.stockQty + a.soldQty) ||
      b.stockAmount - a.stockAmount ||
      a.design.localeCompare(b.design),
  );

  return {
    ...base,
    groups,
    outlets: [...outletSet].sort(),
  };
}
