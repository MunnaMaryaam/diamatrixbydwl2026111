/**
 * Parser for Diamond World style label / stock / sold PDFs.
 *
 * Supports two main layouts:
 * 1. Classic tag sheets (D.NOSEPIN style) — sequential barcodes + carat
 * 2. Stock Report (Image) / Sold Report — branch headers + D.PRODUCT +
 *    multi-column product cards with design code, barcode, carat
 *
 * Extracts: branch groups, barcodes, carat, design codes, gross/net weight, price.
 */

import type { BranchGroup, LabelItem, ParseResult, PdfLabelReport } from './pdfLabelTypes';

const KNOWN_BRANCHES = new Set([
  'BSL','DMD','KBH','PCT','RAJ','RUP','SAV','DWL','JES','CTG','SYL','KHL',
  'BAR','COM','MYM','RAN','NAR','GAZ','TAN','FAR','BOG','DIN','BCT','BLY',
  'BMK','CHU','CUM','DNM','GUL','JAS','KHU','MIR','MOH','NAK','NOR','ONL',
  'UTT','FAIR','RAJSHAHI','NARG','NRG','RANG','PAB','KUS','BAC',
]);

const BRANCH_RE = /^(BSL|DMD|KBH|PCT|RAJ|RUP|SAV|DWL|JES|CTG|SYL|KHL|BAR|COM|MYM|RAN|NAR|GAZ|TAN|FAR|BOG|DIN|BCT|BLY|BMK|CHU|CUM|DNM|GUL|JAS|KHU|MIR|MOH|NAK|NOR|ONL|UTT|FAIR|NARG|NRG|[A-Z]{2,5})$/i;

/** 10–14 digit barcode */
const BARCODE_RE = /\b(\d{10,14})\b/g;

/** Carat values commonly 0.10 – 0.90 */
const CARAT_PAIR_RE = /\b(\d{10,14})\s+(0\.\d{2})\b/g;

/** Design-like tokens */
const DESIGN_TOKEN_RE =
  /\b((?:[A-Z]{2,6}-){0,3}(?:WLR\d{2}-\d{4,5}(?:-[A-Z0-9]+)?|NP[A-Z0-9\-]{2,20}|ILR\d{2}-\d{4,5}(?:-[A-Z0-9]+)?|TLR\d{2}-\d{3,5}(?:-[A-Z0-9]+)?|R\d{3,5}|FR\d{4}|IME\s?\d{3,5}[A-Z]?|LME\d{3,5}[A-Z]?|INV\d{3,5}[A-Z]?|RG[GNF/][A-Z0-9/]{2,12}|IJRCX\d+[A-Z]*|JR[CGYHFSRA]\d+[A-Z0-9]*|DWR-[\w\-]{3,20}|SBLR-?\d+|CR\d{5}|LDRG\d+[A-Z0-9]*|UIRG\d+|KR\d{5,7}[A-Z]?|KLR\d+|MR\d{3,5}|RR\d{4,6}[A-Z]?|SRN\d+|CLR\d+|LR\d{5,}|IR\d{4,6}[A-Z]?|DR\d{4,6}|RNG\d{4,6}|BJLR\d+|SLR\d+|VJR[A0-9][A-Z0-9]*|NJR-?\d+|DEI\d+|ECR-?\d+|R-\d{3,5}|DJLR\d+\w*|RGF\d+\w*|RGG\d+\w*|RGN\d+\w*|R\d{4,6}|[A-Z]{2,5}\d{4,8}[A-Z0-9]*))\b/gi;

function toNum(s: string): number {
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : 0;
}

/**
 * Detect whether the PDF looks like the multi-column Stock/Sold Image report.
 */
function isImageStockSoldReport(rawText: string): boolean {
  // Any jewellery product line: D.RING, D.NOSEPIN, D.EARRING, D.BANGLE, D.CHAIN …
  const hasProductLine = /\bD\.?\s*[A-Z]{3,24}\b/i.test(rawText);
  const hasBranchCount =
    /\bD\.?\s*[A-Z]{3,24}\s+\d{1,3}\s+\d{1,4}/i.test(rawText);
  const hasManyBarcodes = (rawText.match(/\b\d{11,14}\b/g) || []).length > 30;
  return hasProductLine && (hasBranchCount || hasManyBarcodes);
}

/**
 * Parse the Stock Report (Image) / Sold Report layout.
 *
 * Improved strategy (position-based):
 *  1. Find branch sections via "BRANCH\nD.PRODUCT N N" anchors (any category)
 *  2. Within each section window collect barcode+carat pairs and design tokens
 *  3. Zip designs onto pairs in document order
 *  4. Fallback: standalone barcodes when pairs are sparse (Stock layout)
 */
function parseImageStockSoldReport(rawText: string): ParseResult {
  let reportRunOn = '';
  const runMatch = rawText.match(/Report run on:\s*([^\n]+)/i);
  if (runMatch) reportRunOn = runMatch[1].trim();

  // Any product category (jewellery): first D.XXXXX found in report
  let product = 'D.ITEM';
  {
    const pm = rawText.match(/\bD\.?\s*([A-Z]{3,24})\b/i);
    if (pm) product = 'D.' + pm[1].toUpperCase();
  }

  // --- Branch section anchors ---
  // Layout (verified from real Stock/Sold PDFs):
  //   BCT
  //   D.RING                    51              52
  //   <product images / barcodes — each = 1 qty for BCT>
  //   BLY
  //   D.RING                    27              79
  // Rule: BRANCH + D.PRODUCT header → window until next BRANCH header.
  //       Every barcode in window = 1 image = 1 pcs for that outlet.
  type Section = { start: number; branch: string; declared: number };
  const sections: Section[] = [];

  const headerRe =
    /\b([A-Z]{2,5})\b(?:\s|\n|\r){0,20}D\.?\s*[A-Z]{3,20}\b/gi;
  let hm: RegExpExecArray | null;
  while ((hm = headerRe.exec(rawText)) !== null) {
    const br = hm[1].toUpperCase();
    if (!KNOWN_BRANCHES.has(br)) continue;
    const prev = hm.index > 0 ? rawText[hm.index - 1] : ' ';
    if (/[A-Za-z0-9]/.test(prev)) continue;
    if (sections.length && sections[sections.length - 1].branch === br) continue;
    sections.push({ start: hm.index, branch: br, declared: 0 });
  }

  // Declared qty from header numbers right after D.PRODUCT (e.g. 37 37 → 37)
  for (let i = 0; i < sections.length; i++) {
    const sec = sections[i];
    const endPos =
      i + 1 < sections.length
        ? sections[i + 1].start
        : Math.min(sec.start + 500, rawText.length);
    const slice = rawText.slice(sec.start, endPos);
    const afterRing = slice.split(/D\.?\s*[A-Z]{3,20}/i)[1] || slice;
    const m = afterRing.match(/\b(\d{1,3})\s+(\d{1,4})\b/);
    if (m) {
      const n1 = parseInt(m[1], 10);
      if (n1 >= 1 && n1 <= 500) sec.declared = n1;
    }
  }

  // --- barcode + carat pairs ---
  type Pair = { pos: number; barcode: string; carat: number };
  const pairs: Pair[] = [];
  let pm: RegExpExecArray | null;
  const pairRe = /\b(\d{10,14})\s+(0\.\d{2})\b/g;
  while ((pm = pairRe.exec(rawText)) !== null) {
    const carat = toNum(pm[2]);
    if (carat > 0 && carat < 5) {
      pairs.push({ pos: pm.index, barcode: pm[1], carat });
    }
  }

  // --- all barcodes (each barcode = 1 image = 1 qty) ---
  type BcPos = { pos: number; barcode: string };
  const allBc: BcPos[] = [];
  const seenBc = new Set<string>();
  let bm: RegExpExecArray | null;
  const bcRe = /\b(\d{10,14})\b/g;
  while ((bm = bcRe.exec(rawText)) !== null) {
    if (!seenBc.has(bm[1])) {
      seenBc.add(bm[1]);
      allBc.push({ pos: bm.index, barcode: bm[1] });
    }
  }

  // --- design tokens with positions ---
  type DesPos = { pos: number; design: string };
  const designs: DesPos[] = [];
  let dm: RegExpExecArray | null;
  const dRe = new RegExp(DESIGN_TOKEN_RE.source, 'gi');
  while ((dm = dRe.exec(rawText)) !== null) {
    const raw = dm[1].toUpperCase().replace(/\s+/g, '');
    const cleaned = raw.replace(/\(.*$/, '').replace(/[-/.]+$/, '');
    if (cleaned.length >= 3) {
      designs.push({ pos: dm.index, design: cleaned });
    }
  }

  // --- price amounts (Stock: 5–7 digit taka) ---
  type PricePos = { pos: number; price: number };
  const prices: PricePos[] = [];
  let prm: RegExpExecArray | null;
  const priceRe = /\b([1-9]\d{4,6})\b/g;
  while ((prm = priceRe.exec(rawText)) !== null) {
    const n = parseInt(prm[1], 10);
    if (n >= 10000 && n <= 9999999 && prm[1].length <= 7) {
      prices.push({ pos: prm.index, price: n });
    }
  }

  // --- invoice / tag dates (handles line-broken "(14-APR-\n26)") ---
  type DatePos = { pos: number; dateCode: string };
  const dateHits: DatePos[] = [];
  const pushDate = (pos: number, code: string) => {
    const c = code.toUpperCase().replace(/\s+/g, '');
    if (!/^\d{1,2}-[A-Z]{3}-\d{2,4}$/.test(c)) return;
    if (dateHits.some((d) => d.pos === pos && d.dateCode === c)) return;
    dateHits.push({ pos, dateCode: c });
  };
  let dtm: RegExpExecArray | null;
  // Complete: (27-JUL-22)
  const dateRe = /\((\d{1,2}-[A-Z]{3}-\d{2,4})\)/gi;
  while ((dtm = dateRe.exec(rawText)) !== null) {
    pushDate(dtm.index, dtm[1]);
  }
  // Broken across lines/spaces: (14-APR-   \n  26)
  const dateBrokenRe = /\((\d{1,2}-[A-Z]{3}-)\s*[\r\n]+\s*(\d{2,4})\)/gi;
  while ((dtm = dateBrokenRe.exec(rawText)) !== null) {
    pushDate(dtm.index, dtm[1] + dtm[2]);
  }
  // Even looser: (14-APR- then within 40 chars a 2-digit year and )
  const dateLooseBrokenRe = /\((\d{1,2}-[A-Z]{3}-)\s*/gi;
  while ((dtm = dateLooseBrokenRe.exec(rawText)) !== null) {
    const tail = rawText.slice(dtm.index, dtm.index + 40);
    const ym = tail.match(/^[^\d]*(\d{1,2}-[A-Z]{3}-)\s*(\d{2,4})/);
    // already handled if complete in first 15 chars
    const complete = tail.match(/^\((\d{1,2}-[A-Z]{3}-\d{2,4})\)/);
    if (complete) continue;
    const yearOnly = tail.match(/\((\d{1,2}-[A-Z]{3}-)[^0-9]{0,25}(\d{2,4})/);
    if (yearOnly) pushDate(dtm.index, yearOnly[1] + yearOnly[2]);
  }
  // Loose without requiring closing paren nearby
  const dateTokenRe = /\b(\d{1,2}-[A-Z]{3}-\d{2})\b/gi;
  while ((dtm = dateTokenRe.exec(rawText)) !== null) {
    pushDate(dtm.index, dtm[1]);
  }

  const nearestDate = (pos: number, window: DatePos[]): string | undefined => {
    if (!window.length) return undefined;
    let best = window[0];
    let bestDist = Math.abs(best.pos - pos);
    for (const d of window) {
      const dist = Math.abs(d.pos - pos);
      if (dist < bestDist) {
        best = d;
        bestDist = dist;
      }
    }
    return bestDist < 600 ? best.dateCode : undefined;
  };

  // --- build items per branch: every barcode in window = 1 pcs ---
  const branchMap = new Map<
    string,
    { barcode: string; carat: number; design?: string; price?: number; dateCode?: string }[]
  >();
  const branchOrder: string[] = [];

  for (let i = 0; i < sections.length; i++) {
    const sec = sections[i];
    const endPos = i + 1 < sections.length ? sections[i + 1].start : rawText.length;
    const secPairs = pairs.filter((p) => p.pos >= sec.start && p.pos < endPos);
    const secDesigns = designs.filter((d) => d.pos >= sec.start && d.pos < endPos);
    const secBc = allBc.filter((b) => b.pos >= sec.start && b.pos < endPos);
    const secPrices = prices.filter((p) => p.pos >= sec.start && p.pos < endPos);
    const secDates = dateHits.filter((d) => d.pos >= sec.start && d.pos < endPos);

    if (!branchMap.has(sec.branch)) {
      branchMap.set(sec.branch, []);
      branchOrder.push(sec.branch);
    }
    const list = branchMap.get(sec.branch)!;
    const used = new Set(list.map((x) => x.barcode));

    // Prefer full barcode list (1 barcode = 1 image = 1 qty)
    for (let k = 0; k < secBc.length; k++) {
      const b = secBc[k];
      if (used.has(b.barcode)) continue;
      used.add(b.barcode);
      const matchPair = pairs.find((p) => p.barcode === b.barcode);
      // nearest design by position
      let design = secDesigns[k]?.design;
      if (!design && secDesigns.length) {
        let best = secDesigns[0];
        let bestDist = Math.abs(best.pos - b.pos);
        for (const d of secDesigns) {
          const dist = Math.abs(d.pos - b.pos);
          if (dist < bestDist) {
            best = d;
            bestDist = dist;
          }
        }
        if (bestDist < 200) design = best.design;
      }
      list.push({
        barcode: b.barcode,
        carat: matchPair?.carat || 0,
        design,
        price: secPrices[k]?.price || 0,
        dateCode: nearestDate(b.pos, secDates) || secDates[k]?.dateCode,
      });
    }

    // Pad to declared header count if barcodes under-counted
    if (sec.declared > 0 && list.length < sec.declared) {
      const need = sec.declared - list.length;
      for (let k = 0; k < need; k++) {
        const di = list.length + k;
        list.push({
          barcode: `SYN-${sec.branch}-${di + 1}`,
          carat: 0,
          design: secDesigns[di]?.design,
          price: secPrices[di]?.price || 0,
          dateCode: secDates[di]?.dateCode,
        });
      }
    }

    // Fill missing dates from section date pool (order-based)
    const usedDates = new Set(
      list.map((x) => x.dateCode).filter(Boolean) as string[],
    );
    let di = 0;
    for (const it of list) {
      if (it.dateCode) continue;
      while (di < secDates.length && usedDates.has(secDates[di].dateCode)) di++;
      if (di >= secDates.length) break;
      it.dateCode = secDates[di].dateCode;
      usedDates.add(secDates[di].dateCode);
      di++;
    }
  }


  // --- FALLBACK: if position windows missed barcodes (scrambled pdf.js text) ---
  // Assign remaining barcodes to branches in header order up to each declared qty.
  // Rule still: 1 barcode = 1 image = 1 pcs.
  {
    const assigned = new Set<string>();
    for (const br of branchOrder) {
      for (const it of branchMap.get(br) || []) assigned.add(it.barcode);
    }
    const leftover = allBc.filter((b) => !assigned.has(b.barcode));
    let li = 0;
    for (const sec of sections) {
      if (!branchMap.has(sec.branch)) {
        branchMap.set(sec.branch, []);
        if (!branchOrder.includes(sec.branch)) branchOrder.push(sec.branch);
      }
      const list = branchMap.get(sec.branch)!;
      const need = Math.max(0, (sec.declared || 0) - list.length);
      for (let k = 0; k < need && li < leftover.length; k++, li++) {
        const b = leftover[li];
        list.push({
          barcode: b.barcode,
          carat: 0,
          design: undefined,
          price: 0,
          dateCode: undefined,
        });
      }
      // Still short? pad synthetic so outlet total = declared
      if (sec.declared > 0 && list.length < sec.declared) {
        const pad = sec.declared - list.length;
        for (let k = 0; k < pad; k++) {
          list.push({
            barcode: `SYN-${sec.branch}-F${list.length + 1}`,
            carat: 0,
            design: undefined,
            price: 0,
            dateCode: undefined,
          });
        }
      }
    }
  }

  // Build BranchGroup[]
  const branches: BranchGroup[] = [];
  for (const br of branchOrder) {
    const rawItems = branchMap.get(br) || [];
    if (rawItems.length === 0) continue;

    const items: LabelItem[] = rawItems.map((it, k) => ({
      sl: k + 1,
      barcode: it.barcode,
      carat: it.carat || 0,
      grossWt: 0,
      netWt: 0,
      price: it.price || 0,
      qty: 1,
      designCode: it.design || undefined,
      dateCode: it.dateCode || undefined,
    }));

    const totalPcs = items.length;
    const totalCarat = items.reduce((s, it) => s + it.carat, 0);
    const totalPrice = items.reduce((s, it) => s + (it.price || 0), 0);

    branches.push({
      branch: br,
      items,
      totalPcs,
      totalCarat: Math.round(totalCarat * 100) / 100,
      totalGrossWt: 0,
      totalNetWt: 0,
      totalPrice,
      totalQty: totalPcs,
    });
  }

  if (branches.length === 0) {
    return {
      ok: false,
      error:
        'No branch/item data found in image stock/sold report. Check PDF text layer.',
      rawTextPreview: rawText.slice(0, 800),
    };
  }

  const report: PdfLabelReport = {
    reportTitle: `${product} - Branch Wise Report`,
    reportRunOn: reportRunOn || new Date().toLocaleString(),
    product,
    branches,
    grandTotalPcs: branches.reduce((s, b) => s + b.totalPcs, 0),
    grandTotalCarat:
      Math.round(branches.reduce((s, b) => s + b.totalCarat, 0) * 100) / 100,
    grandTotalGrossWt: 0,
    grandTotalNetWt: 0,
    grandTotalPrice: branches.reduce((s, b) => s + b.totalPrice, 0),
    grandTotalQty: branches.reduce((s, b) => s + b.totalQty, 0),
  };

  return { ok: true, report, rawTextPreview: rawText.slice(0, 500) };
}

/**
 * Classic sequential parser (original D.NOSEPIN / tag-sheet logic).
 */
function parseClassicLabelReport(rawText: string): ParseResult {
  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  let reportRunOn = '';
  const runMatch = rawText.match(/Report run on:\s*([^\n]+)/i);
  if (runMatch) reportRunOn = runMatch[1].trim();

  // Any jewellery product category from D.XXXXX header
  let product = 'D.ITEM';
  {
    const pm = rawText.match(/\bD\.?\s*([A-Z]{3,24})\b/i);
    if (pm) product = 'D.' + pm[1].toUpperCase();
  }

  const barcodes: string[] = [];
  const seen = new Set<string>();
  let m: RegExpExecArray | null;
  const bcRe = /\b(\d{11,14})\b/g;
  while ((m = bcRe.exec(rawText)) !== null) {
    const bc = m[1];
    if (!seen.has(bc)) {
      seen.add(bc);
      barcodes.push(bc);
    }
  }

  if (barcodes.length === 0) {
    return {
      ok: false,
      error: 'No barcodes found in PDF text. This parser needs a text-layer PDF (not pure image scan).',
      rawTextPreview: rawText.slice(0, 800),
    };
  }

  const branchOrder: string[] = [];
  const branchSeen = new Set<string>();
  for (const line of lines) {
    const up = line.toUpperCase().replace(/\s+/g, '');
    if (BRANCH_RE.test(up) && up.length <= 6 && !branchSeen.has(up)) {
      if (KNOWN_BRANCHES.has(up) || up.length <= 4) {
        branchSeen.add(up);
        branchOrder.push(up);
      }
    }
  }
  if (branchOrder.length === 0) {
    branchOrder.push('BSL', 'DMD', 'KBH', 'PCT', 'RAJ');
  }

  const countHints: Record<string, number> = {};
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const up = line.toUpperCase().replace(/\s+/g, '');
    if (branchOrder.includes(up)) {
      for (let j = i + 1; j < Math.min(i + 6, lines.length); j++) {
        const nums = lines[j].match(/\b(\d{1,3})\b/g);
        if (nums && nums.length >= 1) {
          const n = parseInt(nums[0], 10);
          if (n > 0 && n < 200) {
            countHints[up] = n;
            break;
          }
        }
      }
    }
  }

  const branchCounts: number[] = [];
  const hintSum = branchOrder.reduce((s, b) => s + (countHints[b] || 0), 0);
  if (hintSum === barcodes.length && hintSum > 0) {
    branchOrder.forEach((b) => branchCounts.push(countHints[b] || 0));
  } else {
    const per = Math.ceil(barcodes.length / Math.max(branchOrder.length, 1));
    let remaining = barcodes.length;
    for (let i = 0; i < branchOrder.length; i++) {
      const c = i === branchOrder.length - 1 ? remaining : Math.min(per, remaining);
      branchCounts.push(c);
      remaining -= c;
    }
  }

  const prices: number[] = [];
  const priceRe = /\b(1[0-9]{4}|2[0-9]{4})\b/g;
  while ((m = priceRe.exec(rawText)) !== null) {
    prices.push(parseInt(m[1], 10));
  }

  const carats: number[] = [];
  // Prefer explicit barcode+carat pairs
  const pairRe = /\b\d{10,14}\s+(0\.\d{2})\b/g;
  while ((m = pairRe.exec(rawText)) !== null) {
    carats.push(parseFloat(m[1]));
  }
  if (carats.length < barcodes.length * 0.5) {
    // fallback
    const caratRe = /\b(0\.0[2-9]|0\.[1-9]\d)\b/g;
    while ((m = caratRe.exec(rawText)) !== null) {
      carats.push(parseFloat(m[1]));
    }
  }

  const grossWts: number[] = [];
  const grossRe = /(?:^|\s)(\.\d{3,4})\b/g;
  while ((m = grossRe.exec(rawText)) !== null) {
    grossWts.push(parseFloat('0' + m[1]));
  }

  const netWts: number[] = [];
  const netRe = /\b(0\.(?:2[0-9]|3[0-5]))\b/g;
  while ((m = netRe.exec(rawText)) !== null) {
    netWts.push(parseFloat(m[1]));
  }

  const n = barcodes.length;
  const getAt = <T>(arr: T[], i: number, fallback: T): T => (i < arr.length ? arr[i] : fallback);

  const branches: BranchGroup[] = [];
  let idx = 0;
  for (let bi = 0; bi < branchOrder.length; bi++) {
    const branch = branchOrder[bi];
    const count = branchCounts[bi] || 0;
    if (count <= 0) continue;

    const items: LabelItem[] = [];
    for (let k = 0; k < count && idx < n; k++, idx++) {
      const barcode = barcodes[idx];
      const carat = getAt(carats, idx, 0);
      let gross = getAt(grossWts, idx, 0);
      let net = getAt(netWts, idx, 0);
      const price = getAt(prices, idx, 0);

      if (gross === 0 && net > 0) gross = Math.round((net + 0.0034) * 10000) / 10000;
      if (net === 0 && gross > 0) net = Math.round(gross * 100) / 100;

      items.push({
        sl: k + 1,
        barcode,
        carat,
        grossWt: gross,
        netWt: net,
        price,
        qty: 1,
      });
    }

    const totalPcs = items.length;
    const totalCarat = items.reduce((s, it) => s + it.carat, 0);
    const totalGrossWt = items.reduce((s, it) => s + it.grossWt, 0);
    const totalNetWt = items.reduce((s, it) => s + it.netWt, 0);
    const totalPrice = items.reduce((s, it) => s + it.price, 0);
    const totalQty = items.reduce((s, it) => s + (it.qty || 1), 0);

    branches.push({
      branch,
      items,
      totalPcs,
      totalCarat: Math.round(totalCarat * 100) / 100,
      totalGrossWt: Math.round(totalGrossWt * 10000) / 10000,
      totalNetWt: Math.round(totalNetWt * 100) / 100,
      totalPrice,
      totalQty,
    });
  }

  if (idx < n) {
    const leftover = barcodes.slice(idx);
    const last = branches[branches.length - 1];
    if (last) {
      leftover.forEach((bc, i) => {
        last.items.push({
          sl: last.items.length + 1,
          barcode: bc,
          carat: getAt(carats, idx + i, 0),
          grossWt: getAt(grossWts, idx + i, 0),
          netWt: getAt(netWts, idx + i, 0),
          price: getAt(prices, idx + i, 0),
          qty: 1,
        });
      });
      last.totalPcs = last.items.length;
      last.totalCarat = Math.round(last.items.reduce((s, it) => s + it.carat, 0) * 100) / 100;
      last.totalGrossWt = Math.round(last.items.reduce((s, it) => s + it.grossWt, 0) * 10000) / 10000;
      last.totalNetWt = Math.round(last.items.reduce((s, it) => s + it.netWt, 0) * 100) / 100;
      last.totalPrice = last.items.reduce((s, it) => s + it.price, 0);
      last.totalQty = last.items.reduce((s, it) => s + (it.qty || 1), 0);
    }
  }

  const report: PdfLabelReport = {
    reportTitle: `${product} - Branch Wise Report`,
    reportRunOn: reportRunOn || new Date().toLocaleString(),
    product,
    branches,
    grandTotalPcs: branches.reduce((s, b) => s + b.totalPcs, 0),
    grandTotalCarat: Math.round(branches.reduce((s, b) => s + b.totalCarat, 0) * 100) / 100,
    grandTotalGrossWt: Math.round(branches.reduce((s, b) => s + b.totalGrossWt, 0) * 10000) / 10000,
    grandTotalNetWt: Math.round(branches.reduce((s, b) => s + b.totalNetWt, 0) * 100) / 100,
    grandTotalPrice: branches.reduce((s, b) => s + b.totalPrice, 0),
    grandTotalQty: branches.reduce((s, b) => s + (b.totalQty || b.totalPcs), 0),
  };

  return { ok: true, report, rawTextPreview: rawText.slice(0, 500) };
}

/**
 * Main entry: parse plain text extracted from the label / stock / sold PDF.
 */
export function parseLabelPdfText(rawText: string): ParseResult {
  if (!rawText || rawText.trim().length < 50) {
    return {
      ok: false,
      error: 'PDF text too short or empty. Try a different PDF or ensure text layer exists.',
    };
  }

  // Prefer the specialised image-report parser when the layout matches
  if (isImageStockSoldReport(rawText)) {
    const result = parseImageStockSoldReport(rawText);
    if (result.ok && result.report && result.report.grandTotalPcs > 0) {
      return result;
    }
    // fall through to classic if image parser yielded nothing useful
  }

  return parseClassicLabelReport(rawText);
}

/**
 * Build a report from manually confirmed rows (used when user corrects parse).
 */
export function buildReportFromItems(
  product: string,
  reportRunOn: string,
  groups: { branch: string; items: LabelItem[] }[],
): PdfLabelReport {
  const branches: BranchGroup[] = groups.map((g) => {
    const items = g.items.map((it, i) => ({ ...it, sl: i + 1 }));
    return {
      branch: g.branch,
      items,
      totalPcs: items.length,
      totalCarat: Math.round(items.reduce((s, it) => s + it.carat, 0) * 100) / 100,
      totalGrossWt: Math.round(items.reduce((s, it) => s + it.grossWt, 0) * 10000) / 10000,
      totalNetWt: Math.round(items.reduce((s, it) => s + it.netWt, 0) * 100) / 100,
      totalPrice: items.reduce((s, it) => s + it.price, 0),
      totalQty: items.reduce((s, it) => s + (it.qty || 1), 0),
    };
  });

  return {
    reportTitle: `${product} - Branch Wise Report`,
    reportRunOn,
    product,
    branches,
    grandTotalPcs: branches.reduce((s, b) => s + b.totalPcs, 0),
    grandTotalCarat: Math.round(branches.reduce((s, b) => s + b.totalCarat, 0) * 100) / 100,
    grandTotalGrossWt: Math.round(branches.reduce((s, b) => s + b.totalGrossWt, 0) * 10000) / 10000,
    grandTotalNetWt: Math.round(branches.reduce((s, b) => s + b.totalNetWt, 0) * 100) / 100,
    grandTotalPrice: branches.reduce((s, b) => s + b.totalPrice, 0),
    grandTotalQty: branches.reduce((s, b) => s + (b.totalQty || b.totalPcs), 0),
  };
}
