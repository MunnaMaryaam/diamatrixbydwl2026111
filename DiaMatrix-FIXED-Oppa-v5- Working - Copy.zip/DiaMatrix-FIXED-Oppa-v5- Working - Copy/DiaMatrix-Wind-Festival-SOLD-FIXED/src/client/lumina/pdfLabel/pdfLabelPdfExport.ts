/**
 * Beautiful A4 Portrait PDF — matches Excel report structure
 */

import type { PdfLabelReport, TransferKind } from './pdfLabelTypes';

function kindTitle(kind?: TransferKind) {
  if (kind === 'returnable') return 'RETURNABLE PULL-BACK ORDER';
  if (kind === 'dropable') return 'REPLENISHMENT ORDER';
  return 'BRANCH LABEL REPORT';
}

function kindShort(kind?: TransferKind) {
  if (kind === 'returnable') return 'Returnable Pull-back';
  if (kind === 'dropable') return 'Replenishment';
  return 'Report';
}

function orderNo(kind?: TransferKind) {
  const prefix = kind === 'dropable' ? 'DO' : kind === 'returnable' ? 'RO' : 'LR';
  const d = new Date();
  const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const t = `${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}`;
  return `${prefix}-${ymd}-${t}`;
}

function kindRgb(kind?: TransferKind): [number, number, number] {
  if (kind === 'returnable') return [13, 148, 136];
  if (kind === 'dropable') return [217, 119, 6];
  return [15, 58, 95];
}

async function loadJsPdf(): Promise<any> {
  // @ts-expect-error
  if (typeof window !== 'undefined' && window.jspdf?.jsPDF) return window.jspdf.jsPDF;
  // @ts-expect-error
  if (typeof window !== 'undefined' && window.jsPDF) return window.jsPDF;
  await new Promise<void>((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('Failed to load jsPDF'));
    document.head.appendChild(s);
  });
  // @ts-expect-error
  const mod = window.jspdf || window;
  return mod.jsPDF || mod;
}

function loadImage(dataUrl: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = dataUrl;
  });
}

export async function exportPdfLabelPdf(report: PdfLabelReport): Promise<void> {
  const JsPDF = await loadJsPdf();
  const doc = new JsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  const pageW = 210;
  const pageH = 297;
  const m = 14;
  const contentW = pageW - m * 2;
  let y = m;

  const title = kindTitle(report.transferKind);
  const short = kindShort(report.transferKind);
  const ono = orderNo(report.transferKind);
  const accent = kindRgb(report.transferKind);

  const sharedImg =
    report.designImageDataUrl ||
    report.branches.flatMap((b) => b.items.map((i) => i.imageDataUrl).filter(Boolean))[0] ||
    null;

  let imgEl: HTMLImageElement | null = null;
  if (sharedImg) imgEl = await loadImage(sharedImg as string);

  const ensure = (need: number) => {
    if (y + need > pageH - m - 4) {
      // footer line on old page
      doc.setDrawColor(203, 213, 225);
      doc.setLineWidth(0.3);
      doc.line(m, pageH - 8, pageW - m, pageH - 8);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7);
      doc.setTextColor(148, 163, 184);
      doc.text(`${title}  ·  ${ono}`, m, pageH - 5);
      doc.addPage();
      y = m;
      // small accent on new page
      doc.setFillColor(accent[0], accent[1], accent[2]);
      doc.rect(0, 0, pageW, 3, 'F');
      y = m + 2;
    }
  };

  // Top accent bar
  doc.setFillColor(accent[0], accent[1], accent[2]);
  doc.rect(0, 0, pageW, 4, 'F');
  y = m + 2;

  // Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(11, 31, 51);
  doc.text(title, m, y + 2);
  y += 8;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(100, 116, 139);
  doc.text(`${report.product || 'D.NOSEPIN'}  ·  Branch Wise Transfer Document`, m, y);
  y += 7;

  // Meta card
  const metaH = 24;
  doc.setDrawColor(11, 31, 51);
  doc.setLineWidth(0.5);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(m, y, contentW, metaH, 1.5, 1.5, 'FD');

  doc.setFontSize(8);
  const meta = [
    [`Order No.`, ono],
    [`Document Date`, report.reportRunOn || new Date().toLocaleString()],
    [`Transfer Type`, short.toUpperCase()],
    [`Generated`, new Date().toLocaleString()],
  ];
  let my = y + 5.5;
  meta.forEach(([lab, val]) => {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(100, 116, 139);
    doc.text(lab, m + 4, my);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(String(val), m + 38, my);
    my += 5;
  });
  y += metaH + 6;

  // Column layout
  // Sl Image Barcode Qty Carat Gross Net Price
  const cols = [8, 18, 36, 12, 16, 24, 22, contentW - 8 - 18 - 36 - 12 - 16 - 24 - 22];
  const colX = (i: number) => {
    let x = m;
    for (let k = 0; k < i; k++) x += cols[k];
    return x;
  };

  const drawHeader = () => {
    ensure(10);
    doc.setFillColor(15, 58, 95);
    doc.rect(m, y, contentW, 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    ['Sl', 'Image', 'Barcode', 'Qty', 'Carat', 'Gross', 'Net', 'Price'].forEach((h, i) => {
      doc.text(h, colX(i) + 1.5, y + 5.5);
    });
    y += 8;
  };

  drawHeader();

  const rowH = 15;

  for (const br of report.branches) {
    ensure(rowH + 14);
    // Branch bar
    doc.setFillColor(239, 246, 255);
    doc.setDrawColor(56, 189, 248);
    doc.setLineWidth(0.3);
    doc.rect(m, y, contentW, 7, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(11, 31, 51);
    doc.text(
      `${br.branch}    ${br.totalPcs} pcs  ·  Ct ${br.totalCarat}  ·  Net ${br.totalNetWt} g  ·  Tk ${br.totalPrice.toLocaleString()}`,
      m + 2.5,
      y + 4.8,
    );
    y += 7;

    for (const it of br.items) {
      ensure(rowH + 2);
      // zebra
      const odd = it.sl % 2 === 0;
      if (odd) {
        doc.setFillColor(248, 250, 252);
        doc.rect(m, y, contentW, rowH, 'F');
      }
      doc.setDrawColor(203, 213, 225);
      doc.setLineWidth(0.2);
      doc.rect(m, y, contentW, rowH);

      // vertical guides (subtle)
      let gx = m;
      for (let i = 0; i < cols.length - 1; i++) {
        gx += cols[i];
        doc.line(gx, y, gx, y + rowH);
      }

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(15, 23, 42);
      doc.text(String(it.sl), colX(0) + 2, y + 9.5);

      if (imgEl) {
        try {
          const size = 12;
          doc.addImage(imgEl, 'JPEG', colX(1) + 2.5, y + 1.5, size, size);
        } catch {
          /* */
        }
      }

      doc.setFont('courier', 'normal');
      doc.setFontSize(7.5);
      doc.text(it.barcode, colX(2) + 1, y + 9.5);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.text(String(it.qty ?? 1), colX(3) + 3, y + 9.5);
      doc.text(String(it.carat), colX(4) + 2, y + 9.5);
      doc.text(String(it.grossWt), colX(5) + 1.5, y + 9.5);
      doc.text(String(it.netWt), colX(6) + 1.5, y + 9.5);
      doc.setFont('helvetica', 'bold');
      doc.text(it.price.toLocaleString(), colX(7) + 1.5, y + 9.5);

      y += rowH;
    }

    // Branch total
    ensure(9);
    doc.setFillColor(241, 245, 249);
    doc.setDrawColor(100, 116, 139);
    doc.setLineWidth(0.3);
    doc.rect(m, y, contentW, 7, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(15, 23, 42);
    doc.text(
      `${br.branch} Total:  ${br.totalPcs} pcs  ·  Qty ${br.totalQty ?? br.totalPcs}  ·  Ct ${br.totalCarat}  ·  Net ${br.totalNetWt}  ·  Tk ${br.totalPrice.toLocaleString()}`,
      m + 2.5,
      y + 4.8,
    );
    y += 9;
  }

  // Grand total
  ensure(14);
  doc.setFillColor(15, 23, 42);
  doc.rect(m, y, contentW, 10, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(255, 255, 255);
  doc.text(
    `GRAND TOTAL    ${report.grandTotalPcs} pcs    ·    Qty ${report.grandTotalQty ?? report.grandTotalPcs}    ·    Ct ${report.grandTotalCarat}    ·    Net ${report.grandTotalNetWt} g    ·    Tk ${report.grandTotalPrice.toLocaleString()}`,
    m + 3,
    y + 6.5,
  );
  y += 16;

  // Signature box
  ensure(32);
  doc.setDrawColor(11, 31, 51);
  doc.setLineWidth(0.5);
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(m, y, contentW, 30, 1.5, 1.5, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('Prepared by', m + 4, y + 6);
  doc.text('Authorized / Received by', m + contentW / 2 + 4, y + 6);
  // line for signature
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.3);
  doc.line(m + 4, y + 20, m + contentW / 2 - 6, y + 20);
  doc.line(m + contentW / 2 + 4, y + 20, pageW - m - 4, y + 20);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text('Name & Signature          Date ________', m + 4, y + 26);
  doc.text('Name & Signature          Date ________', m + contentW / 2 + 4, y + 26);

  // Footer on last page
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.3);
  doc.line(m, pageH - 8, pageW - m, pageH - 8);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text(`${title}  ·  ${ono}  ·  System generated`, m, pageH - 5);
  doc.text('Page ' + doc.getNumberOfPages(), pageW - m - 15, pageH - 5);

  doc.save(`${short}_${(report.product || 'Report').replace(/\W+/g, '_')}_${ono}.pdf`);
}
