/**
 * Excel export matching software UI:
 * Summary breakdown · Full report (Design columns) · Aging analysis
 * Each image/barcode = 1 qty
 */

import ExcelJS from 'exceljs';
import type { StockVsSoldDetailReport, DesignCardDetail } from './designMatch';

const C = {
  navy: 'FF0B2545',
  blue: 'FF0284C7',
  head: 'FF0F3A5F',
  both: 'FFC8E6C9',
  stock: 'FFBBDEFB',
  sold: 'FFFFE0B2',
  dead: 'FFFFCDD2',
  moveIn: 'FFDCFCE7',
  moveOut: 'FFFFE4E6',
  white: 'FFFFFFFF',
  line: 'FFCBD5E1',
  text: 'FF0F172A',
  muted: 'FFF1F5F9',
};

function solid(cell: ExcelJS.Cell, argb: string) {
  cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb } };
}

function border(cell: ExcelJS.Cell) {
  const b = { style: 'thin' as const, color: { argb: C.line } };
  cell.border = { top: b, left: b, bottom: b, right: b };
}

function headCell(cell: ExcelJS.Cell, value: string | number, fill = C.navy) {
  cell.value = value;
  cell.font = { bold: true, color: { argb: C.white }, size: 10 };
  solid(cell, fill);
  border(cell);
  cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
}

function bodyCell(cell: ExcelJS.Cell, value: string | number | null | undefined, bg?: string) {
  cell.value = value === null || value === undefined || value === '' ? '–' : value;
  border(cell);
  cell.alignment = { horizontal: 'center', vertical: 'middle' };
  if (bg) solid(cell, bg);
  cell.font = { size: 10, color: { argb: C.text } };
}

function parseInvoiceDate(code?: string): Date | null {
  if (!code) return null;
  const m = code.trim().toUpperCase().match(/^(\d{1,2})-([A-Z]{3})-(\d{2,4})$/);
  if (!m) return null;
  const months: Record<string, number> = {
    JAN: 0, FEB: 1, MAR: 2, APR: 3, MAY: 4, JUN: 5,
    JUL: 6, AUG: 7, SEP: 8, OCT: 9, NOV: 10, DEC: 11,
  };
  const mon = months[m[2]];
  if (mon === undefined) return null;
  let year = parseInt(m[3], 10);
  if (year < 100) year += year >= 70 ? 1900 : 2000;
  const d = new Date(year, mon, parseInt(m[1], 10));
  return Number.isNaN(d.getTime()) ? null : d;
}

function daysBetween(from: Date, to: Date): number {
  return Math.max(0, Math.floor((to.getTime() - from.getTime()) / 86400000));
}

export async function exportStockVsSoldExcel(
  report: StockVsSoldDetailReport,
): Promise<void> {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DiaMatrix Lumina';
  wb.created = new Date();

  const cards: DesignCardDetail[] = (report.groups || []).flatMap((g) => g.cards || []);
  const stockCards = cards.filter((c) => c.source === 'stock');
  const soldCards = cards.filter((c) => c.source === 'sold');

  // ── designs & outlets ──
  const designSet = new Set<string>();
  const outletSet = new Set<string>();
  for (const c of cards) {
    designSet.add((c.design || 'UNKNOWN').toUpperCase());
    outletSet.add((c.branch || 'UNK').toUpperCase());
  }
  const designs = [...designSet].sort((a, b) => a.localeCompare(b));
  const outlets = [...outletSet].sort((a, b) => {
    if (a === 'DWL') return -1;
    if (b === 'DWL') return 1;
    return a.localeCompare(b);
  });

  // cell map branch__design → { stk, sold }
  const cells = new Map<string, { stk: number; sold: number; amount: number }>();
  for (const c of cards) {
    const d = (c.design || 'UNKNOWN').toUpperCase();
    const br = (c.branch || 'UNK').toUpperCase();
    const key = `${br}__${d}`;
    const prev = cells.get(key) || { stk: 0, sold: 0, amount: 0 };
    if (c.source === 'stock') {
      prev.stk += 1;
      prev.amount += c.amount || 0;
    } else {
      prev.sold += 1;
    }
    cells.set(key, prev);
  }

  // design totals
  const designTotals = designs.map((d) => {
    let stk = 0;
    let sold = 0;
    let amount = 0;
    for (const br of outlets) {
      const cell = cells.get(`${br}__${d}`) || { stk: 0, sold: 0, amount: 0 };
      stk += cell.stk;
      sold += cell.sold;
      amount += cell.amount;
    }
    return {
      design: d,
      stockQty: stk,
      soldQty: sold,
      move: sold - stk,
      amount,
      status: stk > 0 && sold > 0 ? 'BOTH' : stk > 0 ? 'STOCK_ONLY' : 'SOLD_ONLY',
    };
  });

  // ═══════════════════════════════════════════
  // Sheet 1: Summary (like Summary breakdown)
  // ═══════════════════════════════════════════
  const sum = wb.addWorksheet('Summary');
  sum.getCell('A1').value = 'Stock vs Sold — Summary Breakdown';
  sum.getCell('A1').font = { bold: true, size: 14, color: { argb: C.navy } };
  sum.mergeCells('A1:F1');
  sum.getCell('A2').value =
    `Stock: ${report.stockFileName || '—'}  ·  Sold: ${report.soldFileName || '—'}`;
  sum.getCell('A3').value = `Generated: ${report.generatedAt || new Date().toLocaleString()}`;
  sum.getCell('A4').value =
    'Each image/barcode = 1 pcs · Columns = Design · Sub = Sold | Stock | Move';

  const metrics: [string, number][] = [
    ['Total Unique Designs', report.totalUnique || designs.length],
    ['Total Stock Pcs', report.totalStockPcs || stockCards.length],
    ['Total Sold Pcs', report.totalSoldPcs || soldCards.length],
    ['Designs in Both', report.bothCount || designTotals.filter((d) => d.status === 'BOTH').length],
    ['Stock only designs', report.stockOnlyCount || designTotals.filter((d) => d.status === 'STOCK_ONLY').length],
    ['Sold only designs', report.soldOnlyCount || designTotals.filter((d) => d.status === 'SOLD_ONLY').length],
    ['Total Stock Amount ৳', report.totalStockAmount || designTotals.reduce((s, d) => s + d.amount, 0)],
  ];
  headCell(sum.getCell(6, 1), 'Metric');
  headCell(sum.getCell(6, 2), 'Value');
  metrics.forEach(([k, v], i) => {
    bodyCell(sum.getCell(7 + i, 1), k);
    bodyCell(sum.getCell(7 + i, 2), v);
    if (k.includes('Amount')) sum.getCell(7 + i, 2).numFmt = '#,##0';
    sum.getCell(7 + i, 1).alignment = { horizontal: 'left' };
  });

  // Design-wise summary table
  const ds = 16;
  sum.getCell(ds, 1).value = 'Design-wise Summary (same as software)';
  sum.getCell(ds, 1).font = { bold: true, size: 12, color: { argb: C.navy } };
  const dHeaders = ['Design', 'Sold', 'Stock', 'Move', 'Amount ৳', 'Status'];
  dHeaders.forEach((h, i) => headCell(sum.getCell(ds + 1, i + 1), h));
  designTotals
    .sort((a, b) => b.soldQty - a.soldQty || b.stockQty - a.stockQty)
    .forEach((r, idx) => {
      const row = ds + 2 + idx;
      const bg =
        r.status === 'BOTH' ? C.both : r.status === 'STOCK_ONLY' ? C.stock : C.sold;
      bodyCell(sum.getCell(row, 1), r.design, bg);
      sum.getCell(row, 1).alignment = { horizontal: 'left' };
      bodyCell(sum.getCell(row, 2), r.soldQty || '–', bg);
      bodyCell(sum.getCell(row, 3), r.stockQty || '–', bg);
      const moveBg = r.move > 0 ? C.moveIn : r.move < 0 ? C.moveOut : bg;
      bodyCell(sum.getCell(row, 4), r.move === 0 ? '–' : r.move > 0 ? `+${r.move}` : r.move, moveBg);
      bodyCell(sum.getCell(row, 5), r.amount || '–', bg);
      if (r.amount) sum.getCell(row, 5).numFmt = '#,##0';
      bodyCell(
        sum.getCell(row, 6),
        r.status === 'BOTH' ? 'BOTH' : r.status === 'STOCK_ONLY' ? 'STOCK ONLY' : 'SOLD ONLY',
        bg,
      );
    });
  sum.getColumn(1).width = 28;
  sum.getColumn(2).width = 10;
  sum.getColumn(3).width = 10;
  sum.getColumn(4).width = 10;
  sum.getColumn(5).width = 14;
  sum.getColumn(6).width = 14;

  // ═══════════════════════════════════════════
  // Sheet 2: Full Report matrix (Outlet × Design)
  // ═══════════════════════════════════════════
  const full = wb.addWorksheet('Full_Report');
  full.getCell('A1').value = 'Full Report — Outlet × Design (Sold | Stock | Move)';
  full.getCell('A1').font = { bold: true, size: 13, color: { argb: C.navy } };
  full.mergeCells(1, 1, 1, 8);

  // Header row 3: Outlet totals labels + design names (merged 3 cols each)
  const labelCols = ['Outlet', 'T.Stock', 'T.Sold', 'Contrib%', 'IN', 'OUT'];
  labelCols.forEach((h, i) => headCell(full.getCell(3, i + 1), h));

  // Design headers starting at col 7
  const designStartCol = 7;
  designs.forEach((d, di) => {
    const c0 = designStartCol + di * 3;
    headCell(full.getCell(3, c0), d, C.blue);
    full.mergeCells(3, c0, 3, c0 + 2);
    headCell(full.getCell(4, c0), 'Sold', C.head);
    headCell(full.getCell(4, c0 + 1), 'Stock', C.head);
    headCell(full.getCell(4, c0 + 2), 'Move', C.head);
  });
  // blank row-4 under labels
  for (let i = 1; i <= 6; i++) {
    headCell(full.getCell(4, i), '', C.head);
  }

  const totalSoldAll = soldCards.length || report.totalSoldPcs || 1;

  outlets.forEach((br, ri) => {
    const row = 5 + ri;
    let rowStk = 0;
    let rowSold = 0;
    let rowIn = 0;
    let rowOut = 0;

    designs.forEach((d, di) => {
      const cell = cells.get(`${br}__${d}`) || { stk: 0, sold: 0, amount: 0 };
      const move = cell.sold - cell.stk;
      rowStk += cell.stk;
      rowSold += cell.sold;
      if (move > 0) rowIn += move;
      else if (move < 0) rowOut += -move;

      const c0 = designStartCol + di * 3;
      bodyCell(full.getCell(row, c0), cell.sold || '–');
      bodyCell(full.getCell(row, c0 + 1), cell.stk || '–');
      const moveBg = move > 0 ? C.moveIn : move < 0 ? C.moveOut : undefined;
      bodyCell(full.getCell(row, c0 + 2), move === 0 ? '–' : move > 0 ? `+${move}` : move, moveBg);
    });

    const contrib = totalSoldAll > 0 ? Math.round((rowSold / totalSoldAll) * 1000) / 10 : 0;
    const bg = br === 'DWL' ? 'FFE0F2FE' : undefined;
    bodyCell(full.getCell(row, 1), br, bg);
    full.getCell(row, 1).font = { bold: true, size: 10, color: { argb: C.blue } };
    bodyCell(full.getCell(row, 2), rowStk || '–', bg);
    bodyCell(full.getCell(row, 3), rowSold || '–', bg);
    bodyCell(full.getCell(row, 4), contrib > 0 ? `${contrib}%` : '–', bg);
    bodyCell(full.getCell(row, 5), rowIn > 0 ? `+${rowIn}` : '–', rowIn > 0 ? C.moveIn : bg);
    bodyCell(full.getCell(row, 6), rowOut > 0 ? `−${rowOut}` : '–', rowOut > 0 ? C.moveOut : bg);
  });

  full.getColumn(1).width = 10;
  for (let i = 2; i <= 6; i++) full.getColumn(i).width = 9;
  for (let i = 0; i < designs.length * 3; i++) {
    full.getColumn(designStartCol + i).width = 7;
  }
  full.views = [{ state: 'frozen', xSplit: 6, ySplit: 4 }];

  // ═══════════════════════════════════════════
  // Sheet 3: Outlet Totals
  // ═══════════════════════════════════════════
  const ot = wb.addWorksheet('Outlet_Totals');
  ot.getCell('A1').value = 'Outlet Totals';
  ot.getCell('A1').font = { bold: true, size: 13, color: { argb: C.navy } };
  ['Outlet', 'T.Stock', 'T.Sold', 'Contrib%', 'Move IN', 'Move OUT'].forEach((h, i) =>
    headCell(ot.getCell(3, i + 1), h),
  );
  outlets.forEach((br, ri) => {
    let rowStk = 0;
    let rowSold = 0;
    let rowIn = 0;
    let rowOut = 0;
    for (const d of designs) {
      const cell = cells.get(`${br}__${d}`) || { stk: 0, sold: 0, amount: 0 };
      const move = cell.sold - cell.stk;
      rowStk += cell.stk;
      rowSold += cell.sold;
      if (move > 0) rowIn += move;
      else if (move < 0) rowOut += -move;
    }
    const contrib = totalSoldAll > 0 ? Math.round((rowSold / totalSoldAll) * 1000) / 10 : 0;
    const row = 4 + ri;
    bodyCell(ot.getCell(row, 1), br);
    ot.getCell(row, 1).font = { bold: true, size: 10 };
    bodyCell(ot.getCell(row, 2), rowStk || '–');
    bodyCell(ot.getCell(row, 3), rowSold || '–');
    bodyCell(ot.getCell(row, 4), contrib > 0 ? `${contrib}%` : '–');
    bodyCell(ot.getCell(row, 5), rowIn > 0 ? rowIn : '–', rowIn > 0 ? C.moveIn : undefined);
    bodyCell(ot.getCell(row, 6), rowOut > 0 ? rowOut : '–', rowOut > 0 ? C.moveOut : undefined);
  });
  for (let i = 1; i <= 6; i++) ot.getColumn(i).width = 12;

  // ═══════════════════════════════════════════
  // Sheet 4: Aging Analysis
  // ═══════════════════════════════════════════
  const aging = wb.addWorksheet('Aging_Analysis');
  aging.getCell('A1').value = 'Aging Analysis — Invoice date → days in stock';
  aging.getCell('A1').font = { bold: true, size: 13, color: { argb: C.navy } };
  aging.getCell('A2').value =
    '90+ days (3 months+) = DEAD / STUCK stock · As of: ' + new Date().toLocaleDateString();

  const asOf = new Date();
  type AgeRow = {
    design: string;
    branch: string;
    barcode: string;
    invoiceDate: string;
    days: number;
    amount: number;
    dead: boolean;
  };
  const ageRows: AgeRow[] = [];
  for (const c of stockCards) {
    const inv = c.invoiceDate || '';
    const d = parseInvoiceDate(inv);
    const days = d ? daysBetween(d, asOf) : -1;
    ageRows.push({
      design: c.design,
      branch: c.branch,
      barcode: c.barcode,
      invoiceDate: inv || '—',
      days,
      amount: c.amount || 0,
      dead: days > 90,
    });
  }

  // Design-level aging
  const byDes = new Map<
    string,
    { pcs: number; deadPcs: number; maxDays: number; sumDays: number; dated: number; amount: number; branches: Set<string> }
  >();
  for (const r of ageRows) {
    const prev = byDes.get(r.design) || {
      pcs: 0,
      deadPcs: 0,
      maxDays: 0,
      sumDays: 0,
      dated: 0,
      amount: 0,
      branches: new Set<string>(),
    };
    prev.pcs += 1;
    if (r.dead) prev.deadPcs += 1;
    if (r.days >= 0) {
      prev.maxDays = Math.max(prev.maxDays, r.days);
      prev.sumDays += r.days;
      prev.dated += 1;
    }
    prev.amount += r.amount;
    prev.branches.add(r.branch);
    byDes.set(r.design, prev);
  }

  const deadPcs = ageRows.filter((r) => r.dead).length;
  const b0 = ageRows.filter((r) => r.days >= 0 && r.days <= 30).length;
  const b1 = ageRows.filter((r) => r.days >= 31 && r.days <= 60).length;
  const b2 = ageRows.filter((r) => r.days >= 61 && r.days <= 90).length;
  const b3 = ageRows.filter((r) => r.days > 90).length;

  headCell(aging.getCell(4, 1), 'Metric');
  headCell(aging.getCell(4, 2), 'Value');
  const ageMetrics: [string, number][] = [
    ['Stock pcs', stockCards.length],
    ['With invoice date', ageRows.filter((r) => r.days >= 0).length],
    ['0–30 days', b0],
    ['31–60 days', b1],
    ['61–90 days', b2],
    ['90+ DEAD/STUCK', b3],
    ['Dead pcs', deadPcs],
  ];
  ageMetrics.forEach(([k, v], i) => {
    bodyCell(aging.getCell(5 + i, 1), k);
    bodyCell(aging.getCell(5 + i, 2), v, k.includes('DEAD') || k.includes('Dead') ? C.dead : undefined);
    aging.getCell(5 + i, 1).alignment = { horizontal: 'left' };
  });

  const ad = 14;
  aging.getCell(ad, 1).value = 'Design-wise Aging';
  aging.getCell(ad, 1).font = { bold: true, size: 12, color: { argb: C.navy } };
  ['Design', 'Pcs', 'Dead (90+)', 'Max days', 'Avg days', 'Amount ৳', 'Outlet(s)', 'Status'].forEach(
    (h, i) => headCell(aging.getCell(ad + 1, i + 1), h),
  );

  const designAgeRows = [...byDes.entries()]
    .map(([design, v]) => ({
      design,
      ...v,
      avgDays: v.dated ? Math.round(v.sumDays / v.dated) : 0,
      branchList: [...v.branches].sort().join(', '),
    }))
    .sort((a, b) => b.maxDays - a.maxDays || b.deadPcs - a.deadPcs);

  designAgeRows.forEach((r, idx) => {
    const row = ad + 2 + idx;
    const bg = r.deadPcs > 0 ? C.dead : undefined;
    bodyCell(aging.getCell(row, 1), r.design, bg);
    aging.getCell(row, 1).alignment = { horizontal: 'left' };
    bodyCell(aging.getCell(row, 2), r.pcs, bg);
    bodyCell(aging.getCell(row, 3), r.deadPcs || '–', bg);
    bodyCell(aging.getCell(row, 4), r.maxDays || '–', bg);
    bodyCell(aging.getCell(row, 5), r.avgDays || '–', bg);
    bodyCell(aging.getCell(row, 6), r.amount || '–', bg);
    if (r.amount) aging.getCell(row, 6).numFmt = '#,##0';
    bodyCell(aging.getCell(row, 7), r.branchList, bg);
    aging.getCell(row, 7).alignment = { horizontal: 'left' };
    bodyCell(
      aging.getCell(row, 8),
      r.deadPcs > 0 ? 'DEAD / STUCK' : r.maxDays > 60 ? 'AGING' : 'OK',
      bg,
    );
  });

  [28, 8, 12, 10, 10, 12, 24, 14].forEach((w, i) => {
    aging.getColumn(i + 1).width = w;
  });

  // ═══════════════════════════════════════════
  // Sheet 5: Piece detail (barcode)
  // ═══════════════════════════════════════════
  const piece = wb.addWorksheet('Piece_Detail');
  piece.getCell('A1').value = 'Piece-level Stock detail (oldest first)';
  piece.getCell('A1').font = { bold: true, size: 12, color: { argb: C.navy } };
  ['Design', 'Outlet', 'Barcode', 'Invoice date', 'Days', 'Bucket', 'Amount ৳'].forEach((h, i) =>
    headCell(piece.getCell(3, i + 1), h),
  );
  [...ageRows]
    .sort((a, b) => b.days - a.days)
    .forEach((r, idx) => {
      const row = 4 + idx;
      const bg = r.dead ? C.dead : undefined;
      const bucket =
        r.days < 0 ? 'N/A' : r.days <= 30 ? '0-30' : r.days <= 60 ? '31-60' : r.days <= 90 ? '61-90' : '90+';
      bodyCell(piece.getCell(row, 1), r.design, bg);
      piece.getCell(row, 1).alignment = { horizontal: 'left' };
      bodyCell(piece.getCell(row, 2), r.branch, bg);
      bodyCell(piece.getCell(row, 3), r.barcode || '–', bg);
      bodyCell(piece.getCell(row, 4), r.invoiceDate, bg);
      bodyCell(piece.getCell(row, 5), r.days >= 0 ? r.days : '–', bg);
      bodyCell(piece.getCell(row, 6), bucket, bg);
      bodyCell(piece.getCell(row, 7), r.amount || '–', bg);
      if (r.amount) piece.getCell(row, 7).numFmt = '#,##0';
    });
  [28, 10, 16, 14, 8, 10, 12].forEach((w, i) => {
    piece.getColumn(i + 1).width = w;
  });

  // download
  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Stock_vs_Sold_Report_${new Date().toISOString().slice(0, 10)}.xlsx`;
  a.click();
  URL.revokeObjectURL(url);
}
