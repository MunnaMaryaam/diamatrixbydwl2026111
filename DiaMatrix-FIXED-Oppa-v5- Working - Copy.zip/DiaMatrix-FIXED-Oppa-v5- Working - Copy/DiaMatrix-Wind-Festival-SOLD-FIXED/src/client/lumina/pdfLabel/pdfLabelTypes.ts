/** Types for PDF Label Report */

export type TransferKind = 'returnable' | 'dropable';

export interface LabelItem {
  sl: number;
  barcode: string;
  carat: number;
  grossWt: number;
  netWt: number;
  price: number;
  /** Quantity (default 1 per tag/barcode) */
  qty: number;
  designCode?: string;
  dateCode?: string;
  imageDataUrl?: string;
}

export interface BranchGroup {
  branch: string;
  items: LabelItem[];
  totalPcs: number;
  totalCarat: number;
  totalGrossWt: number;
  totalNetWt: number;
  totalPrice: number;
  totalQty: number;
}

export interface PdfLabelReport {
  reportTitle: string;
  reportRunOn: string;
  product: string;
  branches: BranchGroup[];
  grandTotalPcs: number;
  grandTotalCarat: number;
  grandTotalGrossWt: number;
  grandTotalNetWt: number;
  grandTotalPrice: number;
  grandTotalQty: number;
  designImageDataUrl?: string;
  transferKind?: TransferKind;
}

export interface ParseResult {
  ok: boolean;
  report?: PdfLabelReport;
  error?: string;
  rawTextPreview?: string;
}
