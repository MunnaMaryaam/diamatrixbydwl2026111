/**
 * PDF Label Report
 * - PDF upload → text + images from PDF
 * - Optional design image override (when set, ONLY that image is used everywhere)
 * - Returnable Pull-back / Replenishment choice → Excel title & filename
 * - On-screen report matches Excel layout (logo spirit, date, tables)
 */

import React, { useCallback, useRef, useState } from 'react';
import {
  Upload,
  FileText,
  Download,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Image as ImageIcon,
  Table2,
  ImagePlus,
  Package,
  PackageOpen,
} from 'lucide-react';
import { parseLabelPdfText } from './pdfLabelParser';
import { exportPdfLabelExcel, exportPdfLabelCsv } from './pdfLabelExport';
import { exportPdfLabelPdf } from './pdfLabelPdfExport';
import type { PdfLabelReport, ParseResult, LabelItem, TransferKind } from './pdfLabelTypes';

async function loadPdfJs(): Promise<any> {
  // @ts-expect-error optional global
  let pdfjsLib = typeof window !== 'undefined' ? window.pdfjsLib : null;
  if (pdfjsLib) return pdfjsLib;
  await new Promise<void>((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load pdf.js'));
    document.head.appendChild(script);
  });
  // @ts-expect-error set by script
  pdfjsLib = window.pdfjsLib;
  if (!pdfjsLib) throw new Error('pdf.js not available');
  pdfjsLib.GlobalWorkerOptions.workerSrc =
    'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  return pdfjsLib;
}

async function extractTextFromPdf(pdf: any): Promise<string> {
  const parts: string[] = [];
  for (let p = 1; p <= pdf.numPages; p++) {
    const page = await pdf.getPage(p);
    const content = await page.getTextContent();
    const items = (content.items as any[])
      .filter((it) => it.str)
      .map((it) => ({
        str: it.str as string,
        x: it.transform?.[4] ?? 0,
        y: it.transform?.[5] ?? 0,
      }));
    items.sort((a, b) => b.y - a.y || a.x - b.x);
    let lastY = items[0]?.y ?? 0;
    let line = '';
    for (const it of items) {
      if (Math.abs(it.y - lastY) > 8) {
        if (line.trim()) parts.push(line.trim());
        line = it.str;
        lastY = it.y;
      } else {
        line += (line ? ' ' : '') + it.str;
      }
    }
    if (line.trim()) parts.push(line.trim());
    parts.push('');
  }
  return parts.join('\n');
}

function imageDataToDataUrl(imgData: any): string | null {
  try {
    const w = imgData.width || imgData.w;
    const h = imgData.height || imgData.h;
    if (!w || !h) return null;
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    const kind = imgData.kind;
    const src = imgData.data;
    if (!src) return null;
    const imageData = ctx.createImageData(w, h);
    const dst = imageData.data;
    if (kind === 3 || src.length === w * h * 4) {
      for (let i = 0; i < src.length; i++) dst[i] = src[i];
    } else if (kind === 2 || src.length === w * h * 3) {
      let s = 0;
      for (let i = 0; i < dst.length; i += 4) {
        dst[i] = src[s++];
        dst[i + 1] = src[s++];
        dst[i + 2] = src[s++];
        dst[i + 3] = 255;
      }
    } else {
      let s = 0;
      for (let i = 0; i < dst.length; i += 4) {
        const g = src[s++] ?? 128;
        dst[i] = g;
        dst[i + 1] = g;
        dst[i + 2] = g;
        dst[i + 3] = 255;
      }
    }
    ctx.putImageData(imageData, 0, 0);
    return canvas.toDataURL('image/png');
  } catch {
    return null;
  }
}

async function extractImagesFromPdf(pdf: any, pdfjsLib: any): Promise<string[]> {
  const results: string[] = [];
  const seen = new Set<string>();
  for (let p = 1; p <= pdf.numPages; p++) {
    const page = await pdf.getPage(p);
    const ops = await page.getOperatorList();
    const fnArray = ops.fnArray as number[];
    const argsArray = ops.argsArray as any[];
    for (let i = 0; i < fnArray.length; i++) {
      const fn = fnArray[i];
      const isPaint =
        fn === pdfjsLib.OPS?.paintImageXObject ||
        fn === pdfjsLib.OPS?.paintImageMaskXObject ||
        fn === 85 ||
        fn === 86;
      if (!isPaint) continue;
      const imgName = argsArray[i]?.[0];
      if (!imgName || typeof imgName !== 'string' || seen.has(imgName)) continue;
      try {
        const imgData: any = await new Promise((resolve) => {
          let resolved = false;
          const tryGet = (store: any) => {
            if (!store) return;
            try {
              store.get(imgName, (data: any) => {
                if (!resolved && data) {
                  resolved = true;
                  resolve(data);
                }
              });
            } catch {
              /* */
            }
          };
          tryGet(page.objs);
          tryGet((pdf as any).commonObjs ?? (page as any).commonObjs);
          setTimeout(() => {
            if (!resolved) resolve(null);
          }, 1500);
        });
        if (!imgData) continue;
        const w = imgData.width || imgData.w || 0;
        const h = imgData.height || imgData.h || 0;
        if (w < 40 || h < 40 || w > 1200 || h > 1200) continue;
        const dataUrl = imageDataToDataUrl(imgData);
        if (dataUrl) {
          seen.add(imgName);
          results.push(dataUrl);
        }
      } catch {
        /* */
      }
    }
  }
  return results;
}

/**
 * Page-render + grid crop tuned for Diamond World label sheets.
 * Each tag looks like the sample: design code top, product photo center,
 * price bottom, barcode + carat bottom strip.
 * We crop the center product-photo zone of each estimated cell.
 */
async function extractImagesByPageRender(pdf: any, expectedCount: number): Promise<string[]> {
  if (expectedCount <= 0) return [];
  const out: string[] = [];
  for (let p = 1; p <= pdf.numPages && out.length < expectedCount; p++) {
    const page = await pdf.getPage(p);
    const scale = 3; // sharper crop
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext('2d');
    if (!ctx) continue;
    await page.render({ canvasContext: ctx, viewport }).promise;

    // Label sheets: typically 4–5 across; estimate from count
    const cols = expectedCount <= 5 ? expectedCount : expectedCount <= 10 ? 5 : Math.min(6, Math.max(4, Math.ceil(Math.sqrt(expectedCount))));
    const rows = Math.ceil(expectedCount / cols);
    const cellW = Math.floor(canvas.width / cols);
    const cellH = Math.floor(canvas.height / Math.max(rows, 1));

    // Photo sits roughly mid-upper of tag (below design text, above price)
    const cropW = cellW * 0.55;
    const cropH = cellH * 0.42;
    const ox = (cellW - cropW) / 2;
    const oy = cellH * 0.22;

    for (let r = 0; r < rows && out.length < expectedCount; r++) {
      for (let c = 0; c < cols && out.length < expectedCount; c++) {
        const sx = Math.max(0, c * cellW + ox);
        const sy = Math.max(0, r * cellH + oy);
        const tw = Math.max(72, Math.floor(cropW));
        const th = Math.max(72, Math.floor(cropH));
        const thumb = document.createElement('canvas');
        thumb.width = tw;
        thumb.height = th;
        const tctx = thumb.getContext('2d');
        if (!tctx) continue;
        tctx.fillStyle = '#fff';
        tctx.fillRect(0, 0, tw, th);
        tctx.drawImage(canvas, sx, sy, cropW, cropH, 0, 0, tw, th);

        // Skip blank / near-white cells
        const sample = tctx.getImageData(0, 0, Math.min(12, tw), Math.min(12, th)).data;
        let sum = 0;
        let dark = 0;
        for (let i = 0; i < sample.length; i += 4) {
          const v = sample[i] + sample[i + 1] + sample[i + 2];
          sum += v;
          if (v < 600) dark++;
        }
        const avg = sum / (sample.length / 4);
        if (avg > 745 && dark < 3) continue;
        out.push(thumb.toDataURL('image/jpeg', 0.92));
      }
    }
  }
  return out;
}

function attachImagesToReport(
  report: PdfLabelReport,
  images: string[],
  designOverride?: string | null,
): PdfLabelReport {
  let idx = 0;
  const branches = report.branches.map((br) => {
    const items: LabelItem[] = br.items.map((it) => {
      const imageDataUrl = designOverride || images[idx] || images[0] || undefined;
      idx++;
      return { ...it, imageDataUrl };
    });
    return { ...br, items };
  });
  return {
    ...report,
    branches,
    designImageDataUrl: designOverride || undefined,
  };
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Failed to read image'));
    reader.readAsDataURL(file);
  });
}

export const PdfLabelReportView: React.FC = () => {
  const pdfInputRef = useRef<HTMLInputElement>(null);
  const imgInputRef = useRef<HTMLInputElement>(null);

  const [pdfName, setPdfName] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);
  const [report, setReport] = useState<PdfLabelReport | null>(null);
  const [pdfImages, setPdfImages] = useState<string[]>([]);
  const [designOverride, setDesignOverride] = useState<string | null>(null);
  const [transferKind, setTransferKind] = useState<TransferKind>('returnable');
  const [error, setError] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);
  const [pdfDragOver, setPdfDragOver] = useState(false);
  const [imgDragOver, setImgDragOver] = useState(false);
  const pdfDragDepth = useRef(0);
  const imgDragDepth = useRef(0);

  const reset = useCallback(() => {
    setPdfName('');
    setParseResult(null);
    setReport(null);
    setPdfImages([]);
    setDesignOverride(null);
    setError(null);
    setLoadingMsg('');
    if (pdfInputRef.current) pdfInputRef.current.value = '';
    if (imgInputRef.current) imgInputRef.current.value = '';
  }, []);

  const rebuildReport = useCallback(
    (
      base: PdfLabelReport,
      images: string[],
      override: string | null,
      kind: TransferKind,
    ) => {
      const withImg = attachImagesToReport(base, images, override);
      setReport({ ...withImg, transferKind: kind });
    },
    [],
  );

  const handlePdf = useCallback(
    async (file: File) => {
      if (!file) return;
      if (!/\.pdf$/i.test(file.name)) {
        setError('Only PDF files are accepted.');
        return;
      }
      setLoading(true);
      setError(null);
      setParseResult(null);
      setReport(null);
      setPdfImages([]);
      setPdfName(file.name);

      try {
        setLoadingMsg('Loading PDF…');
        const pdfjsLib = await loadPdfJs();
        const buf = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: buf }).promise;

        setLoadingMsg('Reading text…');
        const text = await extractTextFromPdf(pdf);
        const result = parseLabelPdfText(text);
        setParseResult(result);

        if (!result.ok || !result.report) {
          setError(result.error || 'Could not parse PDF text.');
          return;
        }

        const totalPcs = result.report.grandTotalPcs;
        setLoadingMsg('Extracting images from PDF…');
        let images = await extractImagesFromPdf(pdf, pdfjsLib);

        if (images.length < Math.min(totalPcs, 3)) {
          setLoadingMsg('Cropping label photos from page…');
          const cropped = await extractImagesByPageRender(pdf, totalPcs);
          if (cropped.length > images.length) images = cropped;
        }

        // Pick ONE best/clear product photo and use it everywhere (design-wise)
        let best: string | null = null;
        if (images.length > 0) {
          // Prefer mid-size images (product photos); skip tiny icons if mixed
          best = images.reduce((a, b) => (b.length > a.length ? b : a), images[0]);
        }
        if (best) {
          images = Array(totalPcs).fill(best);
          // Also set as design image so Excel/PDF use same clear photo
          if (!designOverride) {
            // keep in pdfImages as single source
          }
        }

        setPdfImages(images);
        // If we found a clear photo and user has no override, treat as shared design image
        const shared = designOverride || best || null;
        rebuildReport(result.report, images, shared, transferKind);
        if (best && !designOverride) {
          // store so UI shows one clear image
          setDesignOverride(null); // keep optional upload path; shared applied via rebuild
        }

        if (images.length === 0 && !designOverride) {
          setError(
            'Data parsed, but no images found in PDF. Upload a design image to fill the Image column.',
          );
        }
      } catch (e: any) {
        setError(e?.message || 'Failed to read PDF.');
      } finally {
        setLoading(false);
        setLoadingMsg('');
      }
    },
    [designOverride, transferKind, rebuildReport],
  );

  const handleDesignImage = useCallback(
    async (file: File) => {
      if (!file || !/^image\//i.test(file.type)) {
        setError('Please select an image (PNG / JPG / WEBP).');
        return;
      }
      try {
        const dataUrl = await readFileAsDataUrl(file);
        setDesignOverride(dataUrl);
        if (report) {
          // Keep structure; force every row to use only this image
          const base = { ...report, designImageDataUrl: undefined };
          // strip per-item so attach uses override only
          const clean: PdfLabelReport = {
            ...base,
            branches: base.branches.map((br) => ({
              ...br,
              items: br.items.map(({ imageDataUrl: _i, ...rest }) => rest),
            })),
          };
          rebuildReport(clean, [], dataUrl, transferKind);
        }
      } catch {
        setError('Could not read design image.');
      }
    },
    [report, transferKind, rebuildReport],
  );

  const clearDesignOverride = useCallback(() => {
    setDesignOverride(null);
    if (imgInputRef.current) imgInputRef.current.value = '';
    if (report) {
      const base = parseResult?.report || report;
      rebuildReport(base, pdfImages, null, transferKind);
    }
  }, [report, parseResult, pdfImages, transferKind, rebuildReport]);

  const onKindChange = (kind: TransferKind) => {
    setTransferKind(kind);
    if (report) setReport({ ...report, transferKind: kind });
  };

  const onPdfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) void handlePdf(f);
  };

  const onImgChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) void handleDesignImage(f);
  };

  const onPdfDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    pdfDragDepth.current += 1;
    setPdfDragOver(true);
  };
  const onPdfDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    pdfDragDepth.current = Math.max(0, pdfDragDepth.current - 1);
    if (pdfDragDepth.current === 0) setPdfDragOver(false);
  };
  const onPdfDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
  };
  const onPdfDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    pdfDragDepth.current = 0;
    setPdfDragOver(false);
    if (loading) return;
    const list = e.dataTransfer?.files;
    if (!list || list.length === 0) return;
    // Prefer first PDF in the drop
    let f: File | null = null;
    for (let i = 0; i < list.length; i++) {
      const cand = list[i];
      if (cand && (/\.pdf$/i.test(cand.name) || cand.type === 'application/pdf')) {
        f = cand;
        break;
      }
    }
    if (!f) f = list[0] || null;
    if (f) void handlePdf(f);
  };

  const onImgDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    imgDragDepth.current += 1;
    setImgDragOver(true);
  };
  const onImgDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    imgDragDepth.current = Math.max(0, imgDragDepth.current - 1);
    if (imgDragDepth.current === 0) setImgDragOver(false);
  };
  const onImgDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
  };
  const onImgDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    imgDragDepth.current = 0;
    setImgDragOver(false);
    const list = e.dataTransfer?.files;
    if (!list || list.length === 0) return;
    let f: File | null = null;
    for (let i = 0; i < list.length; i++) {
      const cand = list[i];
      if (cand && /^image\//.test(cand.type)) {
        f = cand;
        break;
      }
    }
    if (!f) f = list[0] || null;
    if (f) void handleDesignImage(f);
  };

  const downloadExcel = async () => {
    if (!report) return;
    setExporting(true);
    try {
      // Ensure one shared clear image on all rows for Excel
      const shared =
        designOverride ||
        report.designImageDataUrl ||
        report.branches.flatMap((b) => b.items.map((i) => i.imageDataUrl)).find(Boolean);
      const forExport = {
        ...report,
        transferKind,
        designImageDataUrl: shared || report.designImageDataUrl,
        branches: report.branches.map((br) => ({
          ...br,
          items: br.items.map((it) => ({
            ...it,
            imageDataUrl: shared || it.imageDataUrl,
          })),
        })),
      };
      await exportPdfLabelExcel(forExport);
    } catch (e: any) {
      setError(e?.message || 'Excel export failed.');
    } finally {
      setExporting(false);
    }
  };

  const downloadPdf = async () => {
    if (!report) return;
    setExporting(true);
    try {
      const shared =
        designOverride ||
        report.designImageDataUrl ||
        report.branches.flatMap((b) => b.items.map((i) => i.imageDataUrl)).find(Boolean);
      await exportPdfLabelPdf({
        ...report,
        transferKind,
        designImageDataUrl: shared || report.designImageDataUrl,
      });
    } catch (e: any) {
      setError(e?.message || 'PDF export failed.');
    } finally {
      setExporting(false);
    }
  };

  const downloadCsv = () => {
    if (report) exportPdfLabelCsv({ ...report, transferKind });
  };

  /** Image shown in a row: override wins, else per-item from PDF */
  const rowImage = (it: LabelItem) => designOverride || it.imageDataUrl || null;

  return (
    <div className="p-3 sm:p-5 max-w-6xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-extrabold text-slate-800 tracking-wide flex items-center gap-2">
            <FileText className="w-5 h-5 text-sky-600" />
            PDF Label Report
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            PDF থেকে data + image · চাইলে clear design image · Returnable Pull-back / Replenishment · Excel অন্যান্য রিপোর্টের মতো
          </p>
        </div>
        {report && (
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => void downloadExcel()}
              disabled={exporting}
              className="relative inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-white text-[13px] font-bold disabled:opacity-55 transition-all duration-200 active:scale-[0.97] active:translate-y-[1px] hover:brightness-105"
              style={{
                background: 'linear-gradient(165deg, #34D399 0%, #059669 45%, #047857 100%)',
                boxShadow:
                  '0 1px 0 rgba(255,255,255,0.35) inset, 0 -1px 0 rgba(0,0,0,0.12) inset, 0 6px 16px rgba(5,150,105,0.4), 0 2px 4px rgba(15,23,42,0.1)',
                border: '1px solid #047857',
              }}
            >
              <span className="pointer-events-none absolute inset-x-2 top-0 h-[42%] rounded-t-xl bg-gradient-to-b from-white/40 to-transparent" />
              {exporting ? <Loader2 className="w-4 h-4 animate-spin relative z-[1]" /> : <Download className="w-4 h-4 relative z-[1]" />}
              <span className="relative z-[1]">Excel</span>
            </button>
            <button
              type="button"
              onClick={() => void downloadPdf()}
              disabled={exporting}
              className="relative inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-white text-[13px] font-bold disabled:opacity-55 transition-all duration-200 active:scale-[0.97] active:translate-y-[1px] hover:brightness-105"
              style={{
                background: 'linear-gradient(165deg, #FB7185 0%, #E11D48 45%, #BE123C 100%)',
                boxShadow:
                  '0 1px 0 rgba(255,255,255,0.3) inset, 0 -1px 0 rgba(0,0,0,0.12) inset, 0 6px 16px rgba(225,29,72,0.4), 0 2px 4px rgba(15,23,42,0.1)',
                border: '1px solid #BE123C',
              }}
            >
              <span className="pointer-events-none absolute inset-x-2 top-0 h-[42%] rounded-t-xl bg-gradient-to-b from-white/35 to-transparent" />
              {exporting ? <Loader2 className="w-4 h-4 animate-spin relative z-[1]" /> : <FileText className="w-4 h-4 relative z-[1]" />}
              <span className="relative z-[1]">PDF (A4)</span>
            </button>
            <button
              type="button"
              onClick={downloadCsv}
              className="relative inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-slate-800 text-[13px] font-bold transition-all duration-200 active:scale-[0.97] active:translate-y-[1px] hover:brightness-105"
              style={{
                background: 'linear-gradient(180deg, #FFFFFF 0%, #E2E8F0 100%)',
                boxShadow:
                  '0 1px 0 rgba(255,255,255,1) inset, 0 -1px 0 rgba(15,23,42,0.06) inset, 0 4px 12px rgba(15,23,42,0.1)',
                border: '1px solid #CBD5E1',
              }}
            >
              <span className="pointer-events-none absolute inset-x-2 top-0 h-[42%] rounded-t-xl bg-gradient-to-b from-white/90 to-transparent" />
              <span className="relative z-[1]">CSV</span>
            </button>
            <button
              type="button"
              onClick={reset}
              className="relative inline-flex items-center gap-1.5 px-2.5 py-2 rounded-xl text-rose-600 transition-all duration-200 active:scale-[0.97] hover:text-rose-700"
              style={{
                background: 'linear-gradient(180deg, #FFFFFF 0%, #FFF1F2 100%)',
                boxShadow: '0 1px 0 rgba(255,255,255,1) inset, 0 3px 10px rgba(225,29,72,0.12)',
                border: '1px solid #FECDD3',
              }}
              title="Clear"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Returnable Pull-back / Replenishment — premium 3D */}
      <div
        className="flex flex-wrap items-center gap-3 rounded-2xl border border-slate-200/80 px-4 py-3.5"
        style={{
          background: 'linear-gradient(180deg, #FFFFFF 0%, #F1F5F9 100%)',
          boxShadow:
            '0 1px 0 rgba(255,255,255,0.9) inset, 0 8px 24px rgba(15,23,42,0.06), 0 2px 4px rgba(15,23,42,0.04)',
        }}
      >
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mr-0.5">
          Type
        </span>
        <button
          type="button"
          onClick={() => onKindChange('returnable')}
          className="group relative inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-[13px] font-bold tracking-tight transition-all duration-200 active:scale-[0.97] active:translate-y-[1px]"
          style={
            transferKind === 'returnable'
              ? {
                  color: '#fff',
                  background: 'linear-gradient(165deg, #2DD4BF 0%, #0D9488 42%, #0F766E 100%)',
                  boxShadow:
                    '0 1px 0 rgba(255,255,255,0.35) inset, 0 -1px 0 rgba(0,0,0,0.15) inset, 0 8px 20px rgba(13,148,136,0.45), 0 2px 4px rgba(15,23,42,0.12)',
                  border: '1px solid rgba(15,118,110,0.9)',
                }
              : {
                  color: '#0F766E',
                  background: 'linear-gradient(180deg, #FFFFFF 0%, #F0FDFA 100%)',
                  boxShadow:
                    '0 1px 0 rgba(255,255,255,1) inset, 0 4px 12px rgba(15,23,42,0.08), 0 1px 2px rgba(15,23,42,0.06)',
                  border: '1px solid #99F6E4',
                }
          }
        >
          <span
            className="pointer-events-none absolute inset-x-2 top-0 h-[45%] rounded-t-xl opacity-40"
            style={{
              background:
                transferKind === 'returnable'
                  ? 'linear-gradient(180deg, rgba(255,255,255,0.55), transparent)'
                  : 'linear-gradient(180deg, rgba(255,255,255,0.9), transparent)',
            }}
          />
          <Package className="w-4 h-4 relative z-[1]" />
          <span className="relative z-[1]">Returnable Pull-back</span>
        </button>
        <button
          type="button"
          onClick={() => onKindChange('dropable')}
          className="group relative inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-[13px] font-bold tracking-tight transition-all duration-200 active:scale-[0.97] active:translate-y-[1px]"
          style={
            transferKind === 'dropable'
              ? {
                  color: '#fff',
                  background: 'linear-gradient(165deg, #FBBF24 0%, #D97706 42%, #B45309 100%)',
                  boxShadow:
                    '0 1px 0 rgba(255,255,255,0.35) inset, 0 -1px 0 rgba(0,0,0,0.15) inset, 0 8px 20px rgba(217,119,6,0.45), 0 2px 4px rgba(15,23,42,0.12)',
                  border: '1px solid rgba(180,83,9,0.9)',
                }
              : {
                  color: '#B45309',
                  background: 'linear-gradient(180deg, #FFFFFF 0%, #FFFBEB 100%)',
                  boxShadow:
                    '0 1px 0 rgba(255,255,255,1) inset, 0 4px 12px rgba(15,23,42,0.08), 0 1px 2px rgba(15,23,42,0.06)',
                  border: '1px solid #FDE68A',
                }
          }
        >
          <span
            className="pointer-events-none absolute inset-x-2 top-0 h-[45%] rounded-t-xl opacity-40"
            style={{
              background:
                transferKind === 'dropable'
                  ? 'linear-gradient(180deg, rgba(255,255,255,0.55), transparent)'
                  : 'linear-gradient(180deg, rgba(255,255,255,0.9), transparent)',
            }}
          />
          <PackageOpen className="w-4 h-4 relative z-[1]" />
          <span className="relative z-[1]">Replenishment</span>
        </button>
        <span className="text-[11px] text-slate-500 ml-1 font-medium">
          Excel title & filename এ Type দেখাবে
        </span>
      </div>

      {/* Uploads */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div
          onDragEnter={onPdfDragEnter}
          onDragLeave={onPdfDragLeave}
          onDragOver={onPdfDragOver}
          onDrop={onPdfDrop}
          onClick={() => !loading && pdfInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-colors ${
            pdfDragOver
              ? 'border-sky-500 bg-sky-100 ring-2 ring-sky-300 ring-offset-1'
              : 'border-sky-300 bg-sky-50/70 hover:bg-sky-50'
          }`}
        >
          <input
            ref={pdfInputRef}
            type="file"
            accept=".pdf,application/pdf"
            className="hidden"
            onChange={onPdfChange}
            disabled={loading}
          />
          {loading ? (
            <div className="flex flex-col items-center gap-2 text-sky-700">
              <Loader2 className="w-7 h-7 animate-spin" />
              <span className="text-sm font-medium">{loadingMsg || 'Processing…'}</span>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-1.5 text-sky-800">
              <Upload className="w-7 h-7 text-sky-500" />
              <span className="text-sm font-semibold">Label PDF আপলোড</span>
              <span className="text-[11px] text-slate-500">Click বা drag &amp; drop PDF এখানে</span>
              {pdfName && (
                <span className="text-[11px] mt-1 font-mono text-slate-600 bg-white px-2 py-0.5 rounded border truncate max-w-full">
                  {pdfName}
                  {pdfImages.length > 0 ? ` · ${pdfImages.length} img` : ''}
                </span>
              )}
            </div>
          )}
        </div>

        <div
          onDragEnter={onImgDragEnter}
          onDragLeave={onImgDragLeave}
          onDragOver={onImgDragOver}
          onDrop={onImgDrop}
          className={`border-2 border-dashed rounded-xl p-5 text-center relative transition-colors ${
            imgDragOver
              ? 'border-violet-500 bg-violet-100 ring-2 ring-violet-300 ring-offset-1'
              : 'border-violet-300 bg-violet-50/70'
          }`}
        >
          <input
            ref={imgInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            className="hidden"
            onChange={onImgChange}
          />
          <div
            onClick={() => imgInputRef.current?.click()}
            className="flex flex-col items-center gap-1.5 text-violet-900 cursor-pointer"
          >
            {designOverride ? (
              <img
                src={designOverride}
                alt="Design override"
                className="w-14 h-14 object-contain rounded-lg border border-violet-200 bg-white shadow-sm"
              />
            ) : (
              <ImagePlus className="w-7 h-7 text-violet-500" />
            )}
            <span className="text-sm font-semibold">
              {designOverride ? 'Design image (active)' : 'Optional: clear design image'}
            </span>
            <span className="text-[11px] text-slate-500">
              দিলে শুধু এই ছবিই সব row-এ · না দিলে PDF-এর ছবি
            </span>
          </div>
          {designOverride && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                clearDesignOverride();
              }}
              className="absolute top-2 right-2 text-[11px] text-rose-600 hover:underline font-medium"
            >
              Clear override
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2.5 text-sm text-amber-900">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <div className="text-xs">{error}</div>
        </div>
      )}

      {/* ===== ON-SCREEN REPORT (same structure as Excel) ===== */}
      {report && (
        <div className="rounded-xl border-2 border-slate-400 bg-white shadow-md overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-start gap-3">
                <img
                  src="/diamatrix-mark.png"
                  alt=""
                  className="w-10 h-10 object-contain hidden sm:block"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 tracking-wide">
                    {transferKind === 'returnable' ? 'RETURNABLE PULL-BACK ORDER' : 'REPLENISHMENT ORDER'}
                    {' · '}
                    {report.product}
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Report run on: {report.reportRunOn}
                    {designOverride
                      ? ' · Design image override'
                      : pdfImages.length > 0
                        ? ` · ${pdfImages.length} images from PDF`
                        : ''}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-emerald-700 text-xs font-semibold">
                <CheckCircle2 className="w-4 h-4" />
                {report.grandTotalPcs} pcs · {report.branches.length} branches
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-px bg-slate-200 border-b border-slate-200">
            {[
              { label: 'Total Pcs', value: report.grandTotalPcs },
              { label: 'Total Carat', value: report.grandTotalCarat },
              { label: 'Net Wt (gm)', value: report.grandTotalNetWt },
              { label: 'Total Price', value: `৳${report.grandTotalPrice.toLocaleString()}` },
            ].map((k) => (
              <div key={k.label} className="bg-white px-3 py-2.5">
                <div className="text-[10px] uppercase tracking-wide text-slate-500 font-semibold">
                  {k.label}
                </div>
                <div className="text-base font-bold text-slate-800 tabular-nums">{k.value}</div>
              </div>
            ))}
          </div>

          <div className="divide-y divide-slate-200">
            {report.branches.map((br) => (
              <div key={br.branch}>
                <div className="flex items-center justify-between px-4 py-2 bg-slate-100 border-b border-slate-200">
                  <span className="font-extrabold text-slate-800 tracking-wider text-sm">
                    {br.branch}
                  </span>
                  <span className="text-[11px] text-slate-600 tabular-nums">
                    {br.totalPcs} pcs · Carat {br.totalCarat} · Net {br.totalNetWt} g · ৳
                    {br.totalPrice.toLocaleString()}
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border-collapse border border-slate-300">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 text-left">
                        <th className="px-3 py-2 font-semibold w-10 border border-slate-400 bg-slate-700 text-white">Sl</th>
                        <th className="px-3 py-2 font-semibold w-16 border border-slate-400 bg-slate-700 text-white">
                          <span className="inline-flex items-center gap-1">
                            <ImageIcon className="w-3 h-3" /> Image
                          </span>
                        </th>
                        <th className="px-3 py-2 font-semibold border border-slate-400 bg-slate-700 text-white">Barcode</th>
                        <th className="px-3 py-2 font-semibold border border-slate-400 bg-slate-700 text-white">Qty</th>
                        <th className="px-3 py-2 font-semibold border border-slate-400 bg-slate-700 text-white">Carat</th>
                        <th className="px-3 py-2 font-semibold border border-slate-400 bg-slate-700 text-white">
                          Gross Wt (gm)
                        </th>
                        <th className="px-3 py-2 font-semibold border border-slate-400 bg-slate-700 text-white">
                          Net Wt (gm)
                        </th>
                        <th className="px-3 py-2 font-semibold border border-slate-400 bg-slate-700 text-white">Price</th>
                      </tr>
                    </thead>
                    <tbody>
                      {br.items.map((it) => {
                        const src = rowImage(it);
                        return (
                          <tr
                            key={it.barcode}
                            className="border border-slate-200 hover:bg-sky-50/50"
                          >
                            <td className="px-3 py-1.5 tabular-nums text-slate-600">{it.sl}</td>
                            <td className="px-3 py-1.5">
                              {src ? (
                                <img
                                  src={src}
                                  alt=""
                                  className="w-14 h-14 object-contain rounded border border-slate-200 bg-white"
                                />
                              ) : (
                                <span className="inline-flex items-center justify-center w-14 h-14 rounded border border-dashed border-slate-200 text-slate-300">
                                  <ImageIcon className="w-3.5 h-3.5" />
                                </span>
                              )}
                            </td>
                            <td className="px-3 py-1.5 font-mono text-slate-800">{it.barcode}</td>
                            <td className="px-3 py-1.5 tabular-nums text-center">{it.qty ?? 1}</td>
                            <td className="px-3 py-1.5 tabular-nums">{it.carat}</td>
                            <td className="px-3 py-1.5 tabular-nums">{it.grossWt}</td>
                            <td className="px-3 py-1.5 tabular-nums">{it.netWt}</td>
                            <td className="px-3 py-1.5 tabular-nums font-semibold text-slate-800">
                              {it.price.toLocaleString()}
                            </td>
                          </tr>
                        );
                      })}
                      <tr className="bg-slate-100 font-semibold border border-slate-300">
                        <td className="px-3 py-2" colSpan={2}>
                          {br.branch} Total
                        </td>
                        <td className="px-3 py-2">{br.totalPcs} pcs</td>
                        <td className="px-3 py-2 tabular-nums text-center">{br.totalQty ?? br.totalPcs}</td>
                        <td className="px-3 py-2 tabular-nums">{br.totalCarat}</td>
                        <td className="px-3 py-2 tabular-nums">{br.totalGrossWt}</td>
                        <td className="px-3 py-2 tabular-nums">{br.totalNetWt}</td>
                        <td className="px-3 py-2 tabular-nums">
                          {br.totalPrice.toLocaleString()}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>

          <div className="px-4 py-3 bg-slate-800 text-white flex flex-wrap items-center justify-between gap-2 text-sm">
            <span className="font-bold flex items-center gap-2">
              <Table2 className="w-4 h-4" />
              GRAND TOTAL
            </span>
            <span className="tabular-nums font-medium">
              {report.grandTotalPcs} pcs · Carat {report.grandTotalCarat} · Net{' '}
              {report.grandTotalNetWt} g · ৳{report.grandTotalPrice.toLocaleString()}
            </span>
          </div>

          <div className="px-4 py-2 bg-slate-50 text-[11px] text-slate-500 border-t border-slate-200">
            Type: <strong>{transferKind === 'returnable' ? 'Returnable Pull-back' : 'Replenishment'}</strong>
            {' · '}
            Gross Wt = lower on label; Net Wt = upper; Carat as printed.
            {designOverride
              ? ' Design image override active (all rows).'
              : ' Images from uploaded PDF.'}
          </div>
        </div>
      )}

      {!report && !loading && !error && (
        <div className="rounded-lg border border-slate-200 bg-white p-4 text-xs text-slate-600 space-y-2">
          <div className="font-semibold text-slate-800">কীভাবে ব্যবহার করবেন</div>
          <ol className="list-decimal list-inside space-y-1.5">
            <li>
              <strong>Returnable Pull-back</strong> বা <strong>Replenishment</strong> সিলেক্ট করুন
            </li>
            <li>Label PDF আপলোড — data + image PDF থেকে আসবে</li>
            <li>
              (ঐচ্ছিক) Clear design image দিন → তখন <em>শুধু</em> সেই ছবিই সব row-এ
            </li>
            <li>সফটওয়্যারে Excel-এর মতো রিপোর্ট (logo, date, type, tables)</li>
            <li>Excel Download → same layout + embedded images + Returnable Pull-back/Replenishment title</li>
          </ol>
        </div>
      )}
    </div>
  );
};

export default PdfLabelReportView;
