import React, { useEffect, useRef } from 'react';
import { PARTICLE_LOGO as D } from './diamatrixParticleLogoData';

/**
 * Gateway particle animation.
 * Thousands of glowing particles form the DW monogram with a diamond.
 * Moving the cursor fast scatters them; they then drift back into the logo.
 */
type Particle = {
  hx: number;
  hy: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  w: number;
  s: number;
  a: number;
  ph: number;
  dia: boolean;
  star: boolean;
};

export const DiaMatrixParticleCanvas: React.FC<{ className?: string }> = ({
  className,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;

    const LW = D.w;
    const LH = D.h;

    function unpack(b: string, n: number): Uint8Array {
      const s = atob(b);
      const o = new Uint8Array(n);
      for (let i = 0; i < n; i++) {
        o[i] = (s.charCodeAt(i >> 3) >> (7 - (i & 7))) & 1;
      }
      return o;
    }

    const SM = unpack(D.sm, LW * LH);
    const DM = unpack(D.dm, LW * LH);
    const SPT: number[] = [];
    const DPT: number[] = [];
    for (let i = 0; i < LW * LH; i++) {
      if (DM[i]) DPT.push(i);
      else if (SM[i]) SPT.push(i);
    }
    const ALL = SPT.length + DPT.length;

    function sprite(core: string, mid: string, edge: string) {
      const s = 64;
      const c = document.createElement('canvas');
      c.width = c.height = s;
      const g = c.getContext('2d')!;
      const r = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      r.addColorStop(0, core);
      r.addColorStop(0.14, mid);
      r.addColorStop(0.38, edge);
      r.addColorStop(1, 'rgba(20,80,255,0)');
      g.fillStyle = r;
      g.fillRect(0, 0, s, s);
      return c;
    }
    const SP_BLUE = sprite(
      'rgba(235,248,255,1)',
      'rgba(140,210,255,.95)',
      'rgba(40,130,255,.32)',
    );
    const SP_DIA = sprite(
      'rgba(255,255,255,1)',
      'rgba(210,240,255,1)',
      'rgba(120,200,255,.38)',
    );

    let W = 0;
    let H = 0;
    let dpr = 1;
    let P: Particle[] = [];
    let scale = 1;
    let OX = 0;
    let OY = 0;
    let last = 0;
    let raf = 0;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

    // Mouse position and speed (px/s). The push strength depends on speed.
    const mouse = {
      x: -9999,
      y: -9999,
      px: -9999,
      py: -9999,
      on: false,
      speed: 0,
      dx: 0,
      dy: 0,
    };

    function layout() {
      const r = cv!.getBoundingClientRect();
      if (!r.width || !r.height) return;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = r.width;
      H = r.height;
      cv!.width = W * dpr;
      cv!.height = H * dpr;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      scale = Math.min(W / LW, H / LH) * 0.84;
      OX = (W - LW * scale) / 2;
      OY = (H - LH * scale) / 2;
      // Density follows the on-screen area of the logo so every part is filled.
      const area = ALL * scale * scale;
      const N = Math.round(
        Math.max(3500, Math.min(W < 640 ? 7000 : 16000, area / 3.8)),
      );
      const old = P;
      P = [];
      const diaShare = (DPT.length * 2.2) / (SPT.length + DPT.length * 2.2);
      for (let i = 0; i < N; i++) {
        // Diamond pixels get extra weight so the facets stay bright.
        const dia = Math.random() < diaShare;
        const idx = dia
          ? DPT[(Math.random() * DPT.length) | 0]
          : SPT[(Math.random() * SPT.length) | 0];
        const o = old[i];
        P.push({
          hx: OX + ((idx % LW) + Math.random()) * scale,
          hy: OY + (((idx / LW) | 0) + Math.random()) * scale,
          x: o ? o.x : Math.random() * W,
          y: o ? o.y : Math.random() * H,
          vx: 0,
          vy: 0,
          w: 1.3 + Math.random() * 0.9,
          s: 0.6 + Math.random() * 0.7,
          a: 0.6 + Math.random() * 0.4,
          ph: Math.random() * 6.28,
          dia,
          star: Math.random() < 0.035,
        });
      }
    }

    function frame(t: number) {
      const dt = Math.min(0.033, (t - (last || t)) / 1000) || 0.016;
      last = t;

      if (mouse.on && mouse.px > -9000) {
        const mx = mouse.x - mouse.px;
        const my = mouse.y - mouse.py;
        const len = Math.hypot(mx, my);
        const inst = len / dt;
        mouse.speed += (inst - mouse.speed) * 0.35;
        if (inst > 1) {
          mouse.dx += (mx / len - mouse.dx) * 0.4;
          mouse.dy += (my / len - mouse.dy) * 0.4;
        }
      } else {
        mouse.speed *= 0.8;
      }
      mouse.px = mouse.x;
      mouse.py = mouse.y;

      // Below ~60px/s nothing happens; a fast swipe (>1200px/s) scatters hard.
      const strength = mouse.on
        ? Math.min(1.7, Math.pow(Math.max(0, mouse.speed - 60) / 1100, 1.15))
        : 0;
      const R = Math.max(110, Math.min(W, H) * 0.26);
      const R2 = R * R;

      ctx!.globalCompositeOperation = 'source-over';
      ctx!.clearRect(0, 0, W, H);
      ctx!.globalCompositeOperation = 'lighter';
      const sz = Math.max(2.1, scale * 0.028);
      const zeta = 0.82;

      for (let i = 0; i < P.length; i++) {
        const p = P[i];
        if (strength > 0.001) {
          const dx = p.x - mouse.x;
          const dy = p.y - mouse.y;
          const d2 = dx * dx + dy * dy;
          if (d2 < R2) {
            const d = Math.sqrt(d2) + 0.001;
            const f = 1 - d / R;
            const rnd = 0.35 + Math.random() * 0.9;
            const kick = strength * f * f * 8000 * dt * rnd;
            p.vx +=
              ((dx / d) * 0.7 +
                mouse.dx * 0.35 +
                (Math.random() - 0.5) * 0.7) *
              kick;
            p.vy +=
              ((dy / d) * 0.7 +
                mouse.dy * 0.35 +
                (Math.random() - 0.5) * 0.7) *
              kick;
          }
        }
        // Slow spring back to the exact logo position.
        const hx =
          p.hx +
          (reduce ? 0 : Math.cos(t * 0.0011 + p.ph) * 0.2 * scale * 0.5);
        const hy =
          p.hy +
          (reduce ? 0 : Math.sin(t * 0.0009 + p.ph) * 0.2 * scale * 0.5);
        const w = p.w;
        p.vx += (-w * w * (p.x - hx) - 2 * zeta * w * p.vx) * dt;
        p.vy += (-w * w * (p.y - hy) - 2 * zeta * w * p.vy) * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;

        const off = Math.hypot(p.x - p.hx, p.y - p.hy);
        const sp = Math.hypot(p.vx, p.vy);
        const glow = Math.min(1, off / 60 + sp / 700);
        const fl = p.star
          ? Math.pow(Math.max(0, Math.sin(t * 0.0014 + p.ph * 3)), 14)
          : 0;
        const s = sz * p.s * (p.dia ? 1.15 : 1) * (1 + glow * 0.8 + fl * 2.2);
        ctx!.globalAlpha = Math.min(
          1,
          p.a *
            (0.78 + glow * 0.5 + fl) *
            (0.88 + 0.12 * Math.sin(t * 0.004 * p.s + p.ph)),
        );
        ctx!.drawImage(p.dia ? SP_DIA : SP_BLUE, p.x - s, p.y - s, s * 2, s * 2);
      }
      ctx!.globalAlpha = 1;
      raf = requestAnimationFrame(frame);
    }

    function pos(e: PointerEvent) {
      const r = cv!.getBoundingClientRect();
      mouse.x = e.clientX - r.left;
      mouse.y = e.clientY - r.top;
    }
    const onEnter = (e: PointerEvent) => {
      pos(e);
      mouse.px = mouse.x;
      mouse.py = mouse.y;
      mouse.on = true;
    };
    const onMove = (e: PointerEvent) => {
      pos(e);
      mouse.on = true;
    };
    const onOff = () => {
      mouse.on = false;
      mouse.px = -9999;
    };

    cv.addEventListener('pointerenter', onEnter);
    cv.addEventListener('pointermove', onMove);
    cv.addEventListener('pointerdown', onEnter);
    cv.addEventListener('pointerleave', onOff);
    cv.addEventListener('pointercancel', onOff);
    cv.addEventListener('pointerup', onOff);

    const ro = new ResizeObserver(layout);
    ro.observe(cv);
    layout();
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      cv.removeEventListener('pointerenter', onEnter);
      cv.removeEventListener('pointermove', onMove);
      cv.removeEventListener('pointerdown', onEnter);
      cv.removeEventListener('pointerleave', onOff);
      cv.removeEventListener('pointercancel', onOff);
      cv.removeEventListener('pointerup', onOff);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      role="img"
      aria-label="Particles forming the DW monogram with a diamond"
      style={{
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        display: 'block',
        cursor: 'crosshair',
        touchAction: 'none',
      }}
    />
  );
};
