/**
 * Demand Opportunity Analysis — Odoo / Tally hierarchical accordion grid.
 * Metal family → Product type → Style leaf rows with actionable procurement badges.
 * Fed by useAIInsights (demandForecastEngine + smartRedistributionEngine).
 */
import React, { useCallback, useMemo, useState } from 'react';
import type { RedistributionReport, RawInventoryRecord, WeightSummary } from '../types';
import {
  TrendingUp,
  ShoppingBag,
  Flame,
  ChevronRight,
  ChevronDown,
  Download,
  ArrowRight,
  Store,
  Sparkles,
  Layers,
  Search,
} from 'lucide-react';
import { exportCorporateExcel } from '../utils/corporateExportEngine';
import { useAIInsights } from '../hooks/useAIInsights';
import {
  detectMetalCategory,
  type MetalCategory,
} from '../utils/smartRedistributionEngine';

/* -------------------------------------------------------------------------- */
/* Props                                                                       */
/* -------------------------------------------------------------------------- */

interface DemandOpportunityAnalysisProps {
  report: RedistributionReport;
  onSelectBranch?: (branch: string) => void;
  onSelectWeight?: (weight: string) => void;
  rawRecords?: RawInventoryRecord[];
}

/* -------------------------------------------------------------------------- */
/* Hierarchy                                                                   */
/* -------------------------------------------------------------------------- */

const METAL_ORDER: MetalCategory[] = ['Diamond', 'Gold', 'Platinum', 'Mixed', 'Unknown'];

const METAL_TITLE: Record<MetalCategory, string> = {
  Diamond: 'DIAMOND INVENTORY',
  Gold: 'GOLD INVENTORY',
  Platinum: 'PLATINUM INVENTORY',
  Mixed: 'MIXED METAL INVENTORY',
  Unknown: 'GENERAL / UNCLASSIFIED',
};

const METAL_ACCENT: Record<MetalCategory, string> = {
  Diamond: 'from-sky-800 to-slate-800 border-sky-700',
  Gold: 'from-amber-700 to-yellow-900 border-amber-600',
  Platinum: 'from-slate-600 to-slate-800 border-slate-500',
  Mixed: 'from-violet-800 to-slate-800 border-violet-600',
  Unknown: 'from-slate-600 to-slate-700 border-slate-500',
};

type ProcurementAction = 'ORDER' | 'ADEQUATE' | 'ZERO_STOCK';

interface OpportunityLeaf {
  id: string;
  sku: string;
  sold: number;
  stock: number;
  unmetShortage: number;
  velocity: WeightSummary['velocityCategory'];
  action: ProcurementAction;
  orderQty: number;
}

interface ProductTypeGroup {
  key: string;
  label: string;
  variants: OpportunityLeaf[];
  totalSold: number;
  totalStock: number;
  orderUnits: number;
  shortageCount: number;
}

interface MetalSection {
  metal: MetalCategory;
  title: string;
  productTypes: ProductTypeGroup[];
  totalSold: number;
  totalStock: number;
  styleCount: number;
  orderUnits: number;
  shortageCount: number;
}

function detectProductType(text: string): string {
  const t = text.toLowerCase();
  if (/\b(nosepin|nose\s*pin|nath|nathni)\b/.test(t)) return 'Nosepins';
  if (/\b(earring|ear\s*ring|jhumka|bali|stud)\b/.test(t)) return 'Earrings';
  if (/\b(ring|band|solitaire)\b/.test(t)) return 'Rings';
  if (/\b(necklace|haar|mangalsutra)\b/.test(t)) return 'Necklaces';
  if (/\b(pendant|locket)\b/.test(t)) return 'Pendants';
  if (/\b(bangle|kada|bracelet)\b/.test(t)) return 'Bangles & Bracelets';
  if (/\b(chain)\b/.test(t)) return 'Chains';
  if (/\b(set|parure)\b/.test(t)) return 'Sets';
  return 'Other Styles';
}

function metalFromText(text: string): MetalCategory {
  return detectMetalCategory({
    category: '',
    itemName: text,
    variant: text,
    itemCode: text,
    weight: text,
  });
}

function leafFromWeight(w: WeightSummary): OpportunityLeaf {
  const sold = Number(w.soldQty) || 0;
  const stock = Number(w.currentStock) || 0;
  const unmet = Math.max(0, Number(w.unmetShortage) || Math.max(0, sold - stock));
  let action: ProcurementAction = 'ADEQUATE';
  if (stock === 0 && sold > 0) action = 'ZERO_STOCK';
  else if (unmet > 0) action = 'ORDER';
  return {
    id: w.weight,
    sku: w.weight,
    sold,
    stock,
    unmetShortage: unmet,
    velocity: w.velocityCategory,
    action,
    orderQty: unmet > 0 ? unmet : stock === 0 && sold > 0 ? sold : 0,
  };
}

function buildOpportunityHierarchy(weights: WeightSummary[]): MetalSection[] {
  const byMetal = new Map<MetalCategory, Map<string, OpportunityLeaf[]>>();

  weights.forEach((w) => {
    const metal = metalFromText(w.weight);
    const productType = detectProductType(w.weight);
    if (!byMetal.has(metal)) byMetal.set(metal, new Map());
    const types = byMetal.get(metal)!;
    if (!types.has(productType)) types.set(productType, []);
    types.get(productType)!.push(leafFromWeight(w));
  });

  return METAL_ORDER.filter((m) => byMetal.has(m)).map((metal) => {
    const types = byMetal.get(metal)!;
    const productTypes: ProductTypeGroup[] = Array.from(types.entries())
      .map(([key, variants]) => {
        const sorted = [...variants].sort(
          (a, b) => b.orderQty - a.orderQty || b.sold - a.sold,
        );
        return {
          key,
          label: key,
          variants: sorted,
          totalSold: sorted.reduce((s, v) => s + v.sold, 0),
          totalStock: sorted.reduce((s, v) => s + v.stock, 0),
          orderUnits: sorted.reduce((s, v) => s + v.orderQty, 0),
          shortageCount: sorted.filter((v) => v.action !== 'ADEQUATE').length,
        };
      })
      .sort((a, b) => b.orderUnits - a.orderUnits || b.totalSold - a.totalSold);

    return {
      metal,
      title: METAL_TITLE[metal],
      productTypes,
      totalSold: productTypes.reduce((s, p) => s + p.totalSold, 0),
      totalStock: productTypes.reduce((s, p) => s + p.totalStock, 0),
      styleCount: productTypes.reduce((s, p) => s + p.variants.length, 0),
      orderUnits: productTypes.reduce((s, p) => s + p.orderUnits, 0),
      shortageCount: productTypes.reduce((s, p) => s + p.shortageCount, 0),
    };
  });
}

/* -------------------------------------------------------------------------- */
/* Badges                                                                      */
/* -------------------------------------------------------------------------- */

function ProcurementBadge({
  action,
  orderQty,
  unit,
}: {
  action: ProcurementAction;
  orderQty: number;
  unit: string;
}) {
  if (action === 'ORDER' || action === 'ZERO_STOCK') {
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-amber-500 text-white px-2.5 py-0.5 text-[10px] font-extrabold shadow-sm ring-1 ring-amber-600/40">
        <ShoppingBag className="w-3 h-3" />
        Order {orderQty.toLocaleString()} {unit}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300 px-2.5 py-0.5 text-[10px] font-bold ring-1 ring-emerald-300/60">
      Stock Adequate
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/* Component                                                                   */
/* -------------------------------------------------------------------------- */

export const DemandOpportunityAnalysis: React.FC<DemandOpportunityAnalysisProps> = ({
  report,
  onSelectBranch,
  onSelectWeight,
  rawRecords = [],
}) => {
  // Reactive AI engines — recomputes when upload pipeline replaces rawRecords
  const { forecasts: forecastResults, transfers: transferRecommendations, isRefreshing } =
    useAIInsights(rawRecords, report.specialMonths);

  const [activeSubTab, setActiveSubTab] = useState<'opportunity' | 'branch_demand' | 'ai_forecast'>(
    'opportunity',
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedTypes, setExpandedTypes] = useState<Set<string>>(new Set());
  const [collapsedMetals, setCollapsedMetals] = useState<Set<MetalCategory>>(new Set());
  const [showOnlyGaps, setShowOnlyGaps] = useState(true);

  const itemLabel = report.categoryConfig?.itemLabel || 'Item / Particular';
  const itemUnit = report.categoryConfig?.itemUnit || 'Pcs';
  const estimatedUnitPrice = report.categoryConfig?.estimatedAvgUnitPrice || 250;

  const zeroStockHighDemandWeights = useMemo(
    () =>
      (report.weightSummaries || [])
        .filter((w) => w.soldQty > 0 && w.currentStock === 0)
        .sort((a, b) => b.soldQty - a.soldQty),
    [report.weightSummaries],
  );

  const unmetShortageWeights = useMemo(
    () =>
      (report.weightSummaries || [])
        .filter((w) => w.unmetShortage > 0)
        .sort((a, b) => b.unmetShortage - a.unmetShortage),
    [report.weightSummaries],
  );

  const branchShortages = useMemo(
    () =>
      (report.branchSummaries || [])
        .filter((b) => b.totalSold > 0 && b.totalCurrentStock === 0)
        .sort((a, b) => b.totalSold - a.totalSold),
    [report.branchSummaries],
  );

  const estimatedLostUnits = report.totalNewStockToBuy;
  const estimatedOpportunityValue = estimatedLostUnits * estimatedUnitPrice;

  const hierarchySource = useMemo(() => {
    const all = report.weightSummaries || [];
    if (!showOnlyGaps) return all;
    return all.filter(
      (w) => w.unmetShortage > 0 || (w.soldQty > 0 && w.currentStock === 0),
    );
  }, [report.weightSummaries, showOnlyGaps]);

  const metalSections = useMemo(() => {
    const built = buildOpportunityHierarchy(hierarchySource);
    const q = searchTerm.trim().toLowerCase();
    if (!q) return built;
    return built
      .map((section) => {
        const productTypes = section.productTypes
          .map((pt) => {
            const variants = pt.variants.filter(
              (v) =>
                v.sku.toLowerCase().includes(q) ||
                pt.label.toLowerCase().includes(q) ||
                section.title.toLowerCase().includes(q),
            );
            if (!variants.length) return null;
            return {
              ...pt,
              variants,
              totalSold: variants.reduce((s, v) => s + v.sold, 0),
              totalStock: variants.reduce((s, v) => s + v.stock, 0),
              orderUnits: variants.reduce((s, v) => s + v.orderQty, 0),
              shortageCount: variants.filter((v) => v.action !== 'ADEQUATE').length,
            };
          })
          .filter((pt): pt is ProductTypeGroup => pt !== null);
        if (!productTypes.length) return null;
        return {
          ...section,
          productTypes,
          totalSold: productTypes.reduce((s, p) => s + p.totalSold, 0),
          totalStock: productTypes.reduce((s, p) => s + p.totalStock, 0),
          styleCount: productTypes.reduce((s, p) => s + p.variants.length, 0),
          orderUnits: productTypes.reduce((s, p) => s + p.orderUnits, 0),
          shortageCount: productTypes.reduce((s, p) => s + p.shortageCount, 0),
        };
      })
      .filter((s): s is MetalSection => s !== null);
  }, [hierarchySource, searchTerm]);

  const toggleMetal = useCallback((metal: MetalCategory) => {
    setCollapsedMetals((prev) => {
      const next = new Set(prev);
      if (next.has(metal)) next.delete(metal);
      else next.add(metal);
      return next;
    });
  }, []);

  const toggleType = useCallback((key: string) => {
    setExpandedTypes((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  const handleExportDemandReport = async () => {
    const rows = unmetShortageWeights.map((w) => ({
      item: itemUnit === 'ct' ? `${w.weight} ct` : w.weight,
      soldDemand: w.soldQty,
      currentInventory: w.currentStock,
      unmetShortage: w.unmetShortage,
      velocity: w.velocityCategory,
      action: `Order ${w.unmetShortage} ${itemUnit} to satisfy verified customer demand`,
    }));

    await exportCorporateExcel({
      title: 'Unmet Demand & Lost Sales Opportunity',
      filename: 'Lost_Sales_Demand_Opportunity_Report',
      period: report.period,
      columns: [
        { key: 'item', header: itemLabel, align: 'left', width: 28 },
        {
          key: 'soldDemand',
          header: `Sold Demand (${itemUnit})`,
          align: 'right',
          width: 18,
          numberFormat: '#,##0',
        },
        {
          key: 'currentInventory',
          header: `Current Inventory (${itemUnit})`,
          align: 'right',
          width: 20,
          numberFormat: '#,##0',
        },
        {
          key: 'unmetShortage',
          header: `Unmet Shortage (${itemUnit})`,
          align: 'right',
          width: 20,
          numberFormat: '#,##0',
        },
        { key: 'velocity', header: 'Turnover Velocity', align: 'center', width: 18 },
        { key: 'action', header: 'Recommended Action', align: 'left', width: 48 },
      ],
      rows,
    });
  };

  return (
    <div className="space-y-4">
      {/* Opportunity banner */}
      <div className="bg-gradient-to-r from-amber-500/10 via-red-500/10 to-blue-500/10 border border-amber-300/40 dark:border-amber-700/30 rounded-xl p-4 sm:p-5 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="p-1 rounded-md bg-amber-500 text-white">
                <Flame className="w-4 h-4" />
              </span>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                Unmet Demand & Lost Sales Potential
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-bold">
                Direct Sales Booster
              </span>
              {isRefreshing && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold">
                  Refreshing AI…
                </span>
              )}
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 max-w-2xl">
              Hierarchical view of proven customer demand versus on-hand inventory. Expand a product
              type to review style-level order recommendations from the AI engines.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white dark:bg-slate-900 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="text-right">
              <div className="text-[10px] uppercase tracking-wide text-slate-500 font-semibold">
                Estimated Opportunity
              </div>
              <div className="text-lg font-extrabold text-amber-600 tabular-nums">
                {estimatedOpportunityValue.toLocaleString(undefined, {
                  maximumFractionDigits: 0,
                })}
              </div>
              <div className="text-[10px] text-slate-500">
                {estimatedLostUnits.toLocaleString()} {itemUnit} gap
              </div>
            </div>
            <button
              type="button"
              onClick={handleExportDemandReport}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Export
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
          {[
            {
              label: 'Zero-Stock Styles',
              value: zeroStockHighDemandWeights.length,
              icon: Flame,
              color: 'text-rose-600',
            },
            {
              label: 'Unmet Shortage Lines',
              value: unmetShortageWeights.length,
              icon: ShoppingBag,
              color: 'text-amber-600',
            },
            {
              label: 'AI Forecast Alerts',
              value: forecastResults.length,
              icon: Sparkles,
              color: 'text-indigo-600',
            },
            {
              label: 'Transfer Opportunities',
              value: transferRecommendations.length,
              icon: TrendingUp,
              color: 'text-emerald-600',
            },
          ].map((k) => (
            <div
              key={k.label}
              className="rounded-lg border border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/60 px-3 py-2"
            >
              <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-slate-500 font-semibold">
                <k.icon className={`w-3 h-3 ${k.color}`} />
                {k.label}
              </div>
              <div className={`text-lg font-bold mt-0.5 ${k.color}`}>{k.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Sub-tabs */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="inline-flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 text-xs">
          {(
            [
              { id: 'opportunity' as const, label: 'Style Opportunity Matrix', icon: Layers },
              { id: 'branch_demand' as const, label: 'Outlet Shortages', icon: Store },
              { id: 'ai_forecast' as const, label: 'AI Forecasts', icon: Sparkles },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSubTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg font-bold transition-all cursor-pointer ${
                activeSubTab === tab.id
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Hierarchical opportunity matrix */}
      {activeSubTab === 'opportunity' && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search style, product type, metal…"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
            </div>
            <button
              type="button"
              onClick={() => setShowOnlyGaps((v) => !v)}
              className={`px-3 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer border ${
                showOnlyGaps
                  ? 'bg-amber-500 text-white border-amber-600'
                  : 'bg-white dark:bg-slate-900 text-slate-600 border-slate-300 dark:border-slate-600'
              }`}
            >
              {showOnlyGaps ? 'Showing gaps only' : 'Showing all styles'}
            </button>
          </div>

          {metalSections.length === 0 ? (
            <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-10 text-center text-sm text-slate-500">
              {showOnlyGaps
                ? 'No unmet shortage or zero-stock styles in the current dataset.'
                : 'No style inventory available.'}
            </div>
          ) : (
            <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-950">
              {metalSections.map((section) => {
                const metalOpen = !collapsedMetals.has(section.metal);
                return (
                  <div key={section.metal}>
                    <button
                      type="button"
                      onClick={() => toggleMetal(section.metal)}
                      className={`w-full flex items-center justify-between gap-3 px-4 py-3 text-left bg-gradient-to-r ${METAL_ACCENT[section.metal]} text-white cursor-pointer`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        {metalOpen ? (
                          <ChevronDown className="w-4 h-4 shrink-0" />
                        ) : (
                          <ChevronRight className="w-4 h-4 shrink-0" />
                        )}
                        <span className="text-sm font-extrabold tracking-wide truncate">
                          {section.title}
                        </span>
                        <span className="text-[10px] font-semibold bg-white/15 rounded-full px-2 py-0.5">
                          {section.styleCount} styles · {section.productTypes.length} types
                        </span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0 text-[11px] font-semibold">
                        <span className="bg-white/20 rounded-full px-2 py-0.5 tabular-nums">
                          Stock {section.totalStock.toLocaleString()}
                        </span>
                        {section.orderUnits > 0 && (
                          <span className="bg-amber-400 text-slate-900 rounded-full px-2 py-0.5 font-extrabold tabular-nums">
                            Order {section.orderUnits.toLocaleString()} {itemUnit}
                          </span>
                        )}
                      </div>
                    </button>

                    {metalOpen &&
                      section.productTypes.map((pt) => {
                        const typeKey = `${section.metal}::${pt.key}`;
                        const typeOpen = expandedTypes.has(typeKey);
                        return (
                          <div
                            key={typeKey}
                            className="border-t border-slate-100 dark:border-slate-800"
                          >
                            <button
                              type="button"
                              onClick={() => toggleType(typeKey)}
                              className="w-full flex items-center justify-between gap-3 px-4 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-900/60 cursor-pointer"
                            >
                              <div className="flex items-center gap-2 min-w-0 flex-wrap">
                                {typeOpen ? (
                                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                                ) : (
                                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                                )}
                                <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                                  {pt.label}
                                </span>
                                <span className="text-[10px] text-slate-500">
                                  {pt.variants.length} variant
                                  {pt.variants.length === 1 ? '' : 's'}
                                </span>
                                <span className="inline-flex rounded-full bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-[10px] font-bold tabular-nums">
                                  Stock {pt.totalStock.toLocaleString()}
                                </span>
                                {pt.orderUnits > 0 && (
                                  <ProcurementBadge
                                    action="ORDER"
                                    orderQty={pt.orderUnits}
                                    unit={itemUnit}
                                  />
                                )}
                              </div>
                              <span className="text-[11px] text-slate-500 tabular-nums shrink-0">
                                Demand {pt.totalSold.toLocaleString()}
                              </span>
                            </button>

                            {typeOpen && (
                              <div className="overflow-x-auto bg-slate-50/70 dark:bg-slate-950/50 border-t border-slate-100 dark:border-slate-800">
                                <table className="w-full text-xs">
                                  <thead>
                                    <tr className="bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-300">
                                      <th className="py-2 px-3 text-left font-semibold">#</th>
                                      <th className="py-2 px-3 text-left font-semibold">
                                        SKU / Style
                                      </th>
                                      <th className="py-2 px-3 text-right font-semibold">
                                        Have
                                      </th>
                                      <th className="py-2 px-3 text-right font-semibold">
                                        Demand
                                      </th>
                                      <th className="py-2 px-3 text-center font-semibold">
                                        Procurement Advice
                                      </th>
                                      <th className="py-2 px-3 text-left font-semibold">
                                        Velocity
                                      </th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {pt.variants.map((v, idx) => (
                                      <tr
                                        key={v.id}
                                        onClick={() => onSelectWeight?.(v.sku)}
                                        className={`border-t border-slate-100 dark:border-slate-800/60 cursor-pointer hover:bg-amber-50/40 dark:hover:bg-amber-950/20 ${
                                          v.action !== 'ADEQUATE'
                                            ? 'bg-amber-50/50 dark:bg-amber-950/20'
                                            : idx % 2 === 0
                                              ? 'bg-white dark:bg-slate-950'
                                              : 'bg-slate-50/80 dark:bg-slate-900/40'
                                        }`}
                                      >
                                        <td className="py-2 px-3 text-slate-400">{idx + 1}</td>
                                        <td className="py-2 px-3 font-mono text-[11px] font-semibold text-slate-800 dark:text-slate-100">
                                          {v.sku}
                                        </td>
                                        <td className="py-2 px-3 text-right tabular-nums font-medium">
                                          {v.stock.toLocaleString()}
                                        </td>
                                        <td className="py-2 px-3 text-right tabular-nums">
                                          {v.sold.toLocaleString()}
                                        </td>
                                        <td className="py-2 px-3 text-center">
                                          <ProcurementBadge
                                            action={v.action}
                                            orderQty={v.orderQty}
                                            unit={itemUnit}
                                          />
                                        </td>
                                        <td className="py-2 px-3 text-[10px] text-slate-500">
                                          {v.velocity}
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        );
                      })}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Outlet shortages */}
      {activeSubTab === 'branch_demand' && (
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
          <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 text-xs font-bold flex items-center gap-2">
            <Store className="w-3.5 h-3.5 text-rose-500" />
            Outlets with demand but zero on-hand stock
          </div>
          {branchShortages.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              No fully stocked-out outlets with sales demand.
            </div>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-100 dark:bg-slate-900 text-slate-600">
                  <th className="py-2 px-3 text-left font-semibold">Outlet</th>
                  <th className="py-2 px-3 text-right font-semibold">Sold Demand</th>
                  <th className="py-2 px-3 text-right font-semibold">Stock</th>
                  <th className="py-2 px-3 text-center font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {branchShortages.map((b) => (
                  <tr
                    key={b.branch}
                    className="border-t border-slate-100 dark:border-slate-800 hover:bg-rose-50/40 cursor-pointer"
                    onClick={() => onSelectBranch?.(b.branch)}
                  >
                    <td className="py-2 px-3 font-semibold">{b.branch}</td>
                    <td className="py-2 px-3 text-right tabular-nums">
                      {b.totalSold.toLocaleString()}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-rose-600 font-bold">
                      0
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-700">
                        Replenish outlet <ArrowRight className="w-3 h-3" />
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* AI forecast strip */}
      {activeSubTab === 'ai_forecast' && (
        <div className="space-y-3">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
            Category demand forecasts from demandForecastEngine · {forecastResults.length} alert
            {forecastResults.length === 1 ? '' : 's'}
          </div>
          {forecastResults.length === 0 ? (
            <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500">
              No forecast alerts yet. Upload a stock sheet to activate AI demand forecasting.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {forecastResults.map((f, i) => (
                <div
                  key={`${f.category}-${i}`}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-sm"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-sm font-bold text-slate-900 dark:text-white">
                        {f.category}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-3">
                        {f.alert || 'Demand outlook available.'}
                      </div>
                    </div>
                    <span
                      className={`shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        f.alertLevel === 'CRITICAL'
                          ? 'bg-rose-100 text-rose-800'
                          : f.alertLevel === 'HIGH'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {f.alertLevel}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {transferRecommendations.length > 0 && (
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 text-xs font-bold">
                Smart transfer recommendations ({transferRecommendations.length})
              </div>
              <div className="overflow-x-auto max-h-64 overflow-y-auto">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-slate-100 dark:bg-slate-900">
                    <tr>
                      <th className="py-2 px-3 text-left font-semibold">SKU</th>
                      <th className="py-2 px-3 text-left font-semibold">From</th>
                      <th className="py-2 px-3 text-left font-semibold">To</th>
                      <th className="py-2 px-3 text-right font-semibold">Qty</th>
                      <th className="py-2 px-3 text-center font-semibold">Priority</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transferRecommendations.slice(0, 40).map((t, i) => (
                      <tr
                        key={`${t.sku}-${t.fromBranch}-${t.toBranch}-${i}`}
                        className="border-t border-slate-100 dark:border-slate-800"
                      >
                        <td className="py-1.5 px-3 font-mono text-[11px]">{t.sku}</td>
                        <td className="py-1.5 px-3">{t.fromBranch}</td>
                        <td className="py-1.5 px-3">{t.toBranch}</td>
                        <td className="py-1.5 px-3 text-right tabular-nums font-semibold">
                          {t.quantity}
                        </td>
                        <td className="py-1.5 px-3 text-center">
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              t.priority === 'CRITICAL'
                                ? 'bg-rose-100 text-rose-800'
                                : t.priority === 'HIGH'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {t.priority}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
