/**
 * AI Intelligence & Insights Panel
 *
 * Executive summary strip that surfaces the output of two analytical engines:
 *  - demandForecastEngine: natural-language demand forecasting alerts per category
 *  - smartRedistributionEngine: aging-stock transfer recommendations between branches
 *
 * Presentational: engine output arrives through props (see useAIInsightsPanelProps).
 * The store is refreshed the moment an upload has been parsed, so the banner updates live.
 */
import React, { useMemo, useState } from 'react';
import {
  Sparkles,
  TrendingUp,
  ArrowRightLeft,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Wallet,
} from 'lucide-react';
import type { DemandForecastResult } from '../utils/demandForecastEngine';
import type { SmartTransferRecommendation } from '../utils/smartRedistributionEngine';
import type { InsightsStatus } from '../store/aiInsightsStore';

export interface AIIntelligencePanelProps {
  /** Demand forecast alerts from demandForecastEngine. */
  forecasts: DemandForecastResult[];
  /** Branch transfer recommendations from smartRedistributionEngine. */
  transfers: SmartTransferRecommendation[];
  status: InsightsStatus;
  /** Number of inventory rows the results were computed from. */
  rowCount: number;
  /** Epoch milliseconds of the last calculation. */
  computedAt: number | null;
  errorMessage?: string | null;
  /** Currency symbol used for capital figures. */
  currencySymbol?: string;
  /** Optional navigation callback to open the full analysis module. */
  onNavigate?: (view: string, report?: string) => void;
  /** Maximum number of items shown per column. */
  maxItems?: number;
  /** Start collapsed (header-only strip). Default true for cockpit placement. */
  defaultCollapsed?: boolean;
  /** When expanded, stretch to full report-style width. */
  expandToFullPage?: boolean;
}

type ForecastLevel = DemandForecastResult['alertLevel'];
type TransferPriority = SmartTransferRecommendation['priority'];

const FORECAST_STYLE: Record<ForecastLevel, { badge: string; bar: string; label: string }> = {
  CRITICAL: {
    badge: 'bg-[#FEF2F2] text-[#DC2626] ring-[#FECACA]',
    bar: 'bg-[#DC2626]',
    label: 'Critical',
  },
  HIGH: {
    badge: 'bg-[#FFFBEB] text-[#D97706] ring-[#FDE68A]',
    bar: 'bg-[#D97706]',
    label: 'High',
  },
  MEDIUM: {
    badge: 'bg-[#FFFBEB] text-[#D97706] ring-[#FDE68A]',
    bar: 'bg-[#D97706]',
    label: 'Medium',
  },
  INFO: {
    badge: 'bg-[#F0FDF4] text-[#16A34A] ring-[#BBF7D0]',
    bar: 'bg-[#16A34A]',
    label: 'Stable',
  },
};

const TRANSFER_STYLE: Record<TransferPriority, { badge: string; label: string }> = {
  CRITICAL: {
    badge: 'bg-[#FEF2F2] text-[#DC2626] ring-[#FECACA]',
    label: 'Critical',
  },
  HIGH: {
    badge: 'bg-[#FFFBEB] text-[#D97706] ring-[#FDE68A]',
    label: 'High',
  },
  MEDIUM: {
    badge: 'bg-[#FFFBEB] text-[#D97706] ring-[#FDE68A]',
    label: 'Medium',
  },
};

const numberFormat = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });

const formatTurn = (turn: number): string =>
  Number.isFinite(turn) ? `${turn.toFixed(2)}x` : 'Stock-out';

export const AIIntelligencePanel: React.FC<AIIntelligencePanelProps> = ({
  forecasts,
  transfers,
  status,
  rowCount,
  computedAt,
  errorMessage,
  currencySymbol = '',
  onNavigate,
  maxItems = 4,
  defaultCollapsed = true,
  expandToFullPage = false,
}) => {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);

  const summary = useMemo(() => {
    const actionable = forecasts.filter((f) => f.alertLevel !== 'INFO');
    const capital = transfers.reduce((sum, t) => sum + t.capitalReleased, 0);
    const confidence = forecasts.length
      ? Math.round(forecasts.reduce((sum, f) => sum + f.confidence, 0) / forecasts.length)
      : 0;
    return { actionableCount: actionable.length, capital, confidence };
  }, [forecasts, transfers]);

  const listLimit = !collapsed && expandToFullPage ? Math.max(maxItems, 10) : maxItems;

  const visibleForecasts = useMemo(() => {
    const actionable = forecasts.filter((f) => f.alertLevel !== 'INFO');
    return (actionable.length ? actionable : forecasts).slice(0, listLimit);
  }, [forecasts, listLimit]);

  const visibleTransfers = transfers.slice(0, listLimit);
  const hasData = rowCount > 0;
  const money = (value: number) => `${currencySymbol}${numberFormat.format(value)}`;

  const kpis = [
    {
      label: 'Demand Alerts',
      value: String(summary.actionableCount),
      hint: 'Categories needing review',
      icon: TrendingUp,
    },
    {
      label: 'Transfer Actions',
      value: String(transfers.length),
      hint: 'Recommended branch moves',
      icon: ArrowRightLeft,
    },
    {
      label: 'Capital Releasable',
      value: money(summary.capital),
      hint: 'From aging stock transfers',
      icon: Wallet,
    },
    {
      label: 'Forecast Confidence',
      value: summary.confidence ? `${summary.confidence}%` : 'N/A',
      hint: 'Average across categories',
      icon: CheckCircle2,
    },
  ];

  const isFullReport = expandToFullPage && !collapsed;

  return (
    <section
      aria-label="AI Intelligence and Insights"
      className={[
        'dmx-ai-panel overflow-hidden rounded-2xl border border-sky-200/80 bg-white shadow-[0_6px_24px_rgba(11,37,69,0.08)] dark:border-slate-700 dark:bg-slate-900 transition-all duration-300',
        isFullReport ? 'min-h-[min(70vh,720px)] ring-2 ring-sky-300/40 shadow-[0_12px_40px_rgba(11,37,69,0.12)]' : '',
      ].join(' ')}
    >
      {/* Header — always visible; body expands to full report style */}
      <header className="dmx-ai-header flex flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-5">
        <div className="flex items-center gap-3">
          <span className="dmx-ai-icon flex h-9 w-9 items-center justify-center rounded-xl">
            <Sparkles className="h-4 w-4" />
          </span>
          <div>
            <h2 className="dmx-ai-title text-sm font-bold tracking-wide sm:text-base">AI Intelligence &amp; Insights</h2>
            <p className="dmx-ai-sub text-[11px]">
              {collapsed
                ? `${summary.actionableCount} demand alerts · ${transfers.length} transfer actions · tap Expand for full report`
                : 'Demand forecasting and branch redistribution, recalculated live from your data'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="dmx-ai-chip inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold">
            <span
              className={`h-1.5 w-1.5 rounded-full ${status === 'error' ? 'bg-red-400' : 'bg-emerald-400'}`}
            />
            {status === 'error' ? 'Error' : 'Live'} &middot; {numberFormat.format(rowCount)} rows
            {computedAt && status === 'ready' ? (
              <span className="opacity-75">
                {' '}
                &middot; {new Date(computedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            ) : null}
          </span>
          <button
            type="button"
            onClick={() => setCollapsed((value) => !value)}
            aria-expanded={!collapsed}
            className="dmx-ai-toggle inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition-colors bg-sky-600 text-white hover:bg-sky-700 dark:bg-sky-500"
          >
            {collapsed ? 'Expand full report' : 'Collapse'}
            {collapsed ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronUp className="h-3.5 w-3.5" />}
          </button>
        </div>
      </header>

      {!collapsed && (
        <div className="space-y-4 p-4 sm:p-5">
          {status === 'error' ? (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-4 text-sm text-red-700">
              The AI engines could not process this dataset{errorMessage ? `: ${errorMessage}` : '.'}
            </div>
          ) : !hasData ? (
            <div className="rounded-xl border border-dashed border-sky-200 bg-sky-50/60 px-4 py-8 text-center text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-800/40 dark:text-slate-300">
              No inventory data is loaded yet. Upload stock and sales files through Daily Intake to generate
              forecasts and redistribution recommendations.
            </div>
          ) : (
            <>
              {/* KPI strip */}
              <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                {kpis.map((kpi) => (
                  <div
                    key={kpi.label}
                    className="rounded-xl border border-sky-100 bg-gradient-to-b from-white to-sky-50/60 px-3.5 py-3 dark:border-slate-700 dark:from-slate-900 dark:to-slate-800/60"
                  >
                    <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      <kpi.icon className="h-3.5 w-3.5 text-sky-600" />
                      {kpi.label}
                    </div>
                    <div className="mt-1 text-xl font-extrabold tabular-nums text-[#0B2545] dark:text-white">
                      {kpi.value}
                    </div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400">{kpi.hint}</div>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
                {/* Demand forecasting alerts */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center justify-between border-b border-slate-100 px-4 py-2.5 dark:border-slate-800">
                    <h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0B2545] dark:text-slate-100">
                      <TrendingUp className="h-3.5 w-3.5 text-sky-600" />
                      Demand Forecast Alerts
                    </h3>
                    {onNavigate && (
                      <button
                        type="button"
                        onClick={() => onNavigate('reports', 'demand_booster')}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-sky-700 hover:text-sky-900 dark:text-sky-300"
                      >
                        Full analysis <ArrowRight className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                  <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                    {visibleForecasts.length === 0 && (
                      <li className="px-4 py-6 text-center text-xs text-slate-500">
                        Not enough sales history to forecast demand yet.
                      </li>
                    )}
                    {visibleForecasts.map((forecast) => {
                      const style = FORECAST_STYLE[forecast.alertLevel];
                      const isRising = forecast.predictedIncreasePercentage > 0;
                      return (
                        <li key={forecast.category} className="flex gap-3 px-4 py-3">
                          <span className={`mt-1 h-10 w-1 shrink-0 rounded-full ${style.bar}`} />
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-sm font-bold text-[#0B2545] dark:text-slate-100">
                                {forecast.category}
                              </span>
                              <span
                                className={`rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ring-inset ${style.badge}`}
                              >
                                {style.label}
                              </span>
                              {forecast.eventName && (
                                <span className="text-[10px] font-medium text-slate-500">{forecast.eventName}</span>
                              )}
                            </div>
                            <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                              {forecast.alert}
                            </p>
                            <p className="mt-1 text-[10px] text-slate-400">
                              {forecast.upcomingMonth} forecast: {numberFormat.format(forecast.predictedMonthlyDemand)}{' '}
                              avg. units per item line &middot; Confidence {forecast.confidence}%
                            </p>
                          </div>
                          <div
                            className={`shrink-0 self-start text-right text-sm font-extrabold tabular-nums ${
                              isRising ? 'text-emerald-600' : 'text-slate-500'
                            }`}
                          >
                            {isRising ? '+' : ''}
                            {Math.round(forecast.predictedIncreasePercentage)}%
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                </div>

                {/* Redistribution recommendations */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center justify-between border-b border-slate-100 px-4 py-2.5 dark:border-slate-800">
                    <h3 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#0B2545] dark:text-slate-100">
                      <ArrowRightLeft className="h-3.5 w-3.5 text-sky-600" />
                      Branch Redistribution Recommendations
                    </h3>
                    {onNavigate && (
                      <button
                        type="button"
                        onClick={() => onNavigate('movement_aging')}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-sky-700 hover:text-sky-900 dark:text-sky-300"
                      >
                        Movement &amp; Aging <ArrowRight className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                  <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                    {visibleTransfers.length === 0 && (
                      <li className="flex items-center justify-center gap-2 px-4 py-6 text-xs text-slate-500">
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                        No aging stock requires redistribution right now.
                      </li>
                    )}
                    {visibleTransfers.map((transfer, index) => {
                      const style = TRANSFER_STYLE[transfer.priority];
                      return (
                        <li key={`${transfer.sku}-${transfer.fromBranch}-${transfer.toBranch}-${index}`} className="px-4 py-3">
                          <div className="flex flex-wrap items-center gap-2">
                            <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
                            <span className="text-sm font-bold text-[#0B2545] dark:text-slate-100">
                              {transfer.styleName || transfer.sku}
                            </span>
                            <span
                              className={`rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ring-inset ${style.badge}`}
                            >
                              {style.label}
                            </span>
                            <span className="ml-auto text-xs font-bold tabular-nums text-emerald-600">
                              {money(transfer.capitalReleased)} released
                            </span>
                          </div>
                          <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
                            {transfer.alert}
                          </p>
                          <p className="mt-1 text-[10px] text-slate-400">
                            Source stock age {Math.round(transfer.sourceAgeDays)} days &middot; Destination turn{' '}
                            {formatTurn(transfer.destinationTurnRate)}
                          </p>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </section>
  );
};

export default AIIntelligencePanel;
