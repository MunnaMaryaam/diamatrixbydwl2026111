import React, { useMemo, useState, useEffect } from 'react';
import {
  Building2,
  Gem,
  Filter,
  X,
  Search,
  Layers,
  ChevronDown,
  ChevronUp,
  Settings2,
} from 'lucide-react';
import { RawInventoryRecord } from '../types';
import {
  getOutletFamilyCodes,
  isOnlineBranch,
  isExcludedOutlet,
  isTrailingSOutlet,
  isWarehouseBranchCode,
} from '../utils/dataIdentityEngine';

export interface ReportFilters {
  branchId: string;
  ctsFrom: string;
  ctsTo: string;
  mainCategory: string;
  subCategory: string;
  /** Style / SKU code from Reports Hub dropdown (NP7SD1, NP2SD1, …) */
  styleCode: string;
  /** Exact range/carat key from Reports Hub (0.05, K30, …) */
  range: string;
}

interface ReportFilterBarProps {
  rawRecords: RawInventoryRecord[];
  filters: ReportFilters;
  onFiltersChange: (f: ReportFilters) => void;
  filteredCount: number;
  totalCount: number;
}

/** Parse weight/carat string to number (also Oracle range codes K30→0.30, L01→1.01) */
export function parseCaratValue(weight: string): number | null {
  if (!weight) return null;
  // Support composite keys "0.05 · NP7SD1" or "K30 · DESIGN"
  const base = String(weight).split('·')[0].trim();
  // Oracle range codes
  const range = base.match(/^([A-Za-z])(\d{2,3})$/);
  if (range) {
    const letter = range[1].toUpperCase();
    const digits = parseInt(range[2], 10);
    if (!isNaN(digits)) {
      if (letter === 'K') return digits / 100;
      if (letter === 'L') return 1 + digits / 100;
      return letter.charCodeAt(0) - 64 + digits / 1000;
    }
  }
  const cleaned = base.replace(/[^\d.]/g, '');
  const n = parseFloat(cleaned);
  return isNaN(n) ? null : n;
}

const isWarehouseBranchName = (branch: string) => isWarehouseBranchCode(branch);

export function applyReportFilters(
  records: RawInventoryRecord[],
  filters: ReportFilters
): RawInventoryRecord[] {
  const rangeKey = (filters.range || '').trim();
  // Range dropdown sets an exact carat/range key; merge into from/to when explicit from/to empty
  const fromRaw = filters.ctsFrom.trim() || rangeKey;
  const toRaw = filters.ctsTo.trim() || rangeKey;
  // Parse both decimal (0.30) and Oracle range codes (K30 → 0.30, L01 → 1.01)
  const fromN = fromRaw !== '' ? parseCaratValue(fromRaw) : null;
  const toN = toRaw !== '' ? parseCaratValue(toRaw) : null;
  const branchQ = filters.branchId.trim().toLowerCase();
  const mainCat = filters.mainCategory.trim().toLowerCase();
  // Style/SKU dropdown (styleCode) and free-text Sub Category both mean design filter
  const subCat = (filters.subCategory || filters.styleCode || '').trim().toLowerCase();
  const styleOnly = (filters.styleCode || '').trim().toLowerCase();

  return records.filter((r) => {
    // Online / FAIR / invalid codes never enter report filters
    if (isOnlineBranch(r.branch) || isExcludedOutlet(r.branch)) return false;

    const isWh = isWarehouseBranchName(r.branch);

    if (branchQ) {
      const b = (r.branch || '').toLowerCase().trim();
      const q = branchQ.trim().toLowerCase();
      // Exact sub-store (blys, dnms, rans, sav, mohs…) → only that outlet (never drop S.Branch rows)
      const isExactSub = isTrailingSOutlet(q) || isTrailingSOutlet(q.toUpperCase());
      if (isExactSub) {
        const parentQ = q.endsWith('s') ? q.slice(0, -1) : q;
        const matchesExactSub =
          b === q ||
          b === q.toUpperCase().toLowerCase() ||
          b === parentQ + 's';
        if (!isWh && !matchesExactSub) return false;
      } else {
        // Parent (bly, dnm, ran, rup): match whole family (parent + sub-stores)
        const family = getOutletFamilyCodes(q).map((c) => c.toLowerCase());
        const matchesFamily =
          family.includes(b) ||
          b === q ||
          b === q + 's' ||
          b.startsWith(q);
        if (!isWh && !matchesFamily) return false;
      }
    }

    // Range / Cts From–To filter
    if (fromRaw || toRaw) {
      const w = parseCaratValue(r.weight);
      const weightKey = String(r.weight || '')
        .toUpperCase()
        .split('·')[0]
        .trim();

      if (w != null && (fromN != null || toN != null)) {
        // Numeric compare (works for 0.30 cents AND K30/L01 range codes)
        if (fromN != null && w < fromN - 1e-9) return false;
        if (toN != null && w > toN + 1e-9) return false;
      } else if (w == null) {
        // Non-numeric weight keys: alphabetical range on the code itself
        const fromKey = fromRaw.toUpperCase();
        const toKey = toRaw.toUpperCase();
        if (fromKey && weightKey < fromKey) return false;
        if (toKey && weightKey > toKey) return false;
      } else if (fromN == null && fromRaw) {
        // User typed a code we couldn't parse numerically — exact/prefix match on key
        if (!weightKey.startsWith(fromRaw.toUpperCase()) && weightKey !== fromRaw.toUpperCase()) {
          // also try: if only "from" set without numeric value, keep keys >= text
          if (weightKey < fromRaw.toUpperCase()) return false;
        }
      }
    }

    if (mainCat) {
      const c = `${r.category || ''} ${r.itemName || ''}`.toLowerCase();
      if (!c.includes(mainCat)) return false;
    }

    if (subCat) {
      // Exact design/style code match only (NP7SD1 must NOT match NP7SD10)
      // Also match composite weight keys like "0.08 · NP7SD1"
      // styleCode (Style/SKU dropdown) and subCategory share the same match rules
      const code = (r.itemCode || r.variant || '').toLowerCase().trim();
      const weightDesign = String(r.weight || '')
        .toLowerCase()
        .split('·')
        .map((p) => p.trim())
        .filter(Boolean);
      const designFromWeight = weightDesign.length >= 2 ? weightDesign.slice(1).join(' · ') : '';
      const exactCode =
        code === subCat ||
        designFromWeight === subCat ||
        (r.variant || '').toLowerCase().trim() === subCat ||
        (r.itemCode || '').toLowerCase().trim() === subCat;
      if (!exactCode) {
        // Skip loose name fallback when user picked an exact Style/SKU code from dropdown
        if (styleOnly && styleOnly === subCat) return false;
        // Fallback: whole-token match inside itemName (word boundary style)
        const hay = `${r.itemName || ''}`.toLowerCase();
        const tokenRe = new RegExp(
          `(^|[^a-z0-9])${subCat.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z0-9]|$)`
        );
        if (!tokenRe.test(hay)) return false;
      }
    }

    return true;
  });
}

export const EMPTY_FILTERS: ReportFilters = {
  branchId: '',
  ctsFrom: '',
  ctsTo: '',
  mainCategory: '',
  subCategory: '',
  styleCode: '',
  range: '',
};

/** Shared control height — filter inputs, Go, and Clear must match exactly */
const CONTROL_H = 'h-9';
const fieldCls =
  `${CONTROL_H} w-full rounded-lg border border-[#A9D9F0] bg-white px-3 text-[13px] !font-bold !text-[#0B2545] placeholder:!text-[#5B7A99] shadow-[inset_0_1px_3px_rgba(11,37,69,0.08)] focus:outline-none focus:border-[#14B4E8] focus:ring-2 focus:ring-[#BFE6F8] transition-all caret-[#0D9488] box-border`;

/**
 * SAP Fiori–style filter bar:
 * compact fields, Go / Adapt Filters / Clear, active filter chips
 */
export const ReportFilterBar: React.FC<ReportFilterBarProps> = ({
  rawRecords,
  filters,
  onFiltersChange,
  filteredCount,
  totalCount,
}) => {
  const [draft, setDraft] = useState<ReportFilters>(filters);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    setDraft(filters);
  }, [filters]);

  const branchOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.branch) set.add(r.branch);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const categoryOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.category) set.add(r.category);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const caratOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.weight) {
        const base = String(r.weight).split('·')[0].trim();
        if (base) set.add(base);
      }
    });
    return Array.from(set).sort((a, b) => {
      const na = parseFloat(a);
      const nb = parseFloat(b);
      if (!isNaN(na) && !isNaN(nb)) return na - nb;
      return a.localeCompare(b);
    });
  }, [rawRecords]);

  const styleOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.itemCode) set.add(r.itemCode);
      if (r.variant) set.add(r.variant);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b)).slice(0, 300);
  }, [rawRecords]);

  const activeChips: { key: keyof ReportFilters; label: string }[] = [];
  if (filters.branchId) activeChips.push({ key: 'branchId', label: `Branch: ${filters.branchId}` });
  if (filters.ctsFrom || filters.ctsTo) {
    activeChips.push({
      key: 'ctsFrom',
      label: `Range: ${filters.ctsFrom || '…'} – ${filters.ctsTo || '…'}`,
    });
  }
  if (filters.mainCategory) activeChips.push({ key: 'mainCategory', label: `Category: ${filters.mainCategory}` });
  if (filters.subCategory) activeChips.push({ key: 'subCategory', label: `Design: ${filters.subCategory}` });
  if (filters.styleCode) activeChips.push({ key: 'styleCode', label: `Style: ${filters.styleCode}` });
  if (filters.range) activeChips.push({ key: 'range', label: `Range: ${filters.range}` });

  const hasActive = activeChips.length > 0;

  const handleGo = () => onFiltersChange({ ...draft });

  const handleClear = () => {
    setDraft(EMPTY_FILTERS);
    onFiltersChange(EMPTY_FILTERS);
  };

  const removeChip = (key: keyof ReportFilters) => {
    const next = { ...filters };
    if (key === 'ctsFrom') {
      next.ctsFrom = '';
      next.ctsTo = '';
    } else {
      next[key] = '';
    }
    setDraft(next);
    onFiltersChange(next);
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleGo();
  };

  return (
    <div
      id="sap-filter-bar"
      data-filter-bar="true"
      className="rounded-2xl border border-[#B7DDF1] bg-white/95 backdrop-blur-md text-[#0B2545] shadow-[0_6px_20px_rgba(11,37,69,0.08)] overflow-hidden"
      role="search"
      aria-label="SAP-style filter bar"
    >
      {/* Header strip */}
      <div className="h-[34px] flex items-center justify-between px-4 border-b border-[#D3E8F6] bg-[#EAF7FD]">
        <div className="flex items-center gap-1.5 text-[12px] !font-bold !text-[#0B2545]">
          <Filter className="w-3.5 h-3.5 text-cyan-400" />
          <span className="!text-[#0B2545] !font-bold">Filter</span>
          <span className="!font-bold !text-[#0B2545]">
            · {filteredCount.toLocaleString()} of {totalCount.toLocaleString()}
            {hasActive ? ' (filtered)' : ''}
          </span>
        </div>
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          className="inline-flex items-center gap-1 text-[11px] !font-bold !text-[#0B2545] hover:text-[#0C94D0] hover:underline h-8 px-1 transition-colors"
        >
          <Settings2 className="w-3 h-3" />
          Adapt Filters
          {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>
      </div>

      {/* Primary filter row — always visible (SAP compact) */}
      <div className="px-4 py-2.5 flex flex-wrap items-end gap-x-3 gap-y-2 bg-white">
        {/* Branch */}
        <div className="min-w-[150px] flex-1 max-w-[220px]">
          <label className="block text-[11px] !font-bold !text-[#0B2545] mb-1 leading-[14px]" style={{ color: '#0B2545', fontWeight: 700 }}>
            <Building2 className="w-3 h-3 inline mr-0.5 text-cyan-400" />
            Branch
          </label>
          <input
            type="text"
            list="sap-branch-options"
            value={draft.branchId}
            onChange={(e) => setDraft({ ...draft, branchId: e.target.value })}
            onKeyDown={onKey}
            placeholder="All"
            className={fieldCls}
          />
          <datalist id="sap-branch-options">
            {branchOptions.map((b) => (
              <option key={b} value={b} />
            ))}
          </datalist>
        </div>

        {/* Range / Cts From — works for 0.02 cents OR K30 range codes */}
        <div className="min-w-[110px] w-[130px]">
          <label className="block text-[11px] !font-bold !text-[#0B2545] mb-1 leading-[14px]" style={{ color: '#0B2545', fontWeight: 700 }}>
            <Gem className="w-3 h-3 inline mr-0.5 text-cyan-400" />
            Range / Cts From
          </label>
          <input
            type="text"
            list="sap-cts-from"
            value={draft.ctsFrom}
            onChange={(e) => setDraft({ ...draft, ctsFrom: e.target.value })}
            onKeyDown={onKey}
            placeholder="0.02 or K30"
            className={fieldCls}
          />
          <datalist id="sap-cts-from">
            {caratOptions.map((c) => (
              <option key={`f-${c}`} value={c} />
            ))}
          </datalist>
        </div>

        {/* Range / Cts To */}
        <div className="min-w-[110px] w-[130px]">
          <label className="block text-[11px] !font-bold !text-[#0B2545] mb-1 leading-[14px]" style={{ color: '#0B2545', fontWeight: 700 }}>Range / Cts To</label>
          <input
            type="text"
            list="sap-cts-to"
            value={draft.ctsTo}
            onChange={(e) => setDraft({ ...draft, ctsTo: e.target.value })}
            onKeyDown={onKey}
            placeholder="0.20 or L10"
            className={fieldCls}
          />
          <datalist id="sap-cts-to">
            {caratOptions.map((c) => (
              <option key={`t-${c}`} value={c} />
            ))}
          </datalist>
        </div>

        {/* Category */}
        <div className="min-w-[170px] flex-1 max-w-[260px]">
          <label className="block text-[11px] !font-bold !text-[#0B2545] mb-1 leading-[14px]" style={{ color: '#0B2545', fontWeight: 700 }}>
            <Layers className="w-3 h-3 inline mr-0.5 text-cyan-400" />
            Category
          </label>
          <input
            type="text"
            list="sap-cat-options"
            value={draft.mainCategory}
            onChange={(e) => setDraft({ ...draft, mainCategory: e.target.value })}
            onKeyDown={onKey}
            placeholder="All categories"
            className={fieldCls}
          />
          <datalist id="sap-cat-options">
            {categoryOptions.map((c) => (
              <option key={c} value={c} />
            ))}
          </datalist>
        </div>

        {/* Style / Design / Sub-category — exact match for codes */}
        <div className="min-w-[170px] flex-1 max-w-[260px]">
          <label className="block text-[11px] !font-bold !text-[#0B2545] mb-1 leading-[14px]" style={{ color: '#0B2545', fontWeight: 700 }}>
            <Gem className="w-3 h-3 inline mr-0.5 text-cyan-400" />
            Design / Sub-Cat
          </label>
          <input
            type="text"
            list="sap-style-options"
            value={draft.subCategory}
            onChange={(e) => setDraft({ ...draft, subCategory: e.target.value })}
            onKeyDown={onKey}
            placeholder="NP7SD1 or sub-cat…"
            className={fieldCls}
          />
          <datalist id="sap-style-options">
            {styleOptions.map((s) => (
              <option key={s} value={s} />
            ))}
          </datalist>
        </div>

        {/* Actions — same h-9 + 1px border as fieldCls so heights match pixel-perfect */}
        <div className="flex items-end gap-1.5 self-end shrink-0">
          <button
            type="button"
            onClick={handleGo}
            className={`${CONTROL_H} min-w-[72px] px-3.5 box-border bg-gradient-to-b from-emerald-500 to-emerald-600 text-white text-[12px] font-bold border border-emerald-600 rounded-lg inline-flex items-center justify-center gap-1.5 shadow-sm hover:from-emerald-400 hover:to-emerald-500 active:brightness-95 transition-all`}
          >
            <Search className="w-3.5 h-3.5 shrink-0" />
            Go
          </button>
          <button
            type="button"
            onClick={handleClear}
            disabled={!hasActive && !draft.branchId && !draft.ctsFrom && !draft.ctsTo && !draft.mainCategory && !draft.subCategory}
            className={`${CONTROL_H} min-w-[36px] w-9 px-0 box-border bg-white border border-[#A9D9F0] text-[12px] font-bold text-[#0B2545] hover:bg-[#EAF7FD] disabled:opacity-40 inline-flex items-center justify-center rounded-lg transition-all`}
            title="Clear filters"
            aria-label="Clear filters"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Adapted / secondary filters */}
      {expanded && (
        <div className="px-3 pb-2 flex flex-wrap items-end gap-x-3 gap-y-2 border-t border-[#D3E8F6] pt-2 bg-[#F8FCFF]">
          <p className="text-[10px] text-[#4F6B88] max-w-lg leading-snug self-center">
            Leave <strong className="text-[#0B2545]">Design Name</strong> empty → main category (e.g. Nosepin 7 Stone) carat-wise stock &amp; sales report.
            Enter a design code and press Go → design-specific breakdown report (NP7SD1, NP7SD2…).
          </p>
        </div>
      )}

      {/* Active filter chips */}
      {hasActive && (
        <div className="px-3 py-1.5 border-t border-[#D3E8F6] bg-[#F8FCFF] flex flex-wrap items-center gap-1.5">
          <span className="text-[10px] font-semibold text-[#4F6B88] mr-1">Active:</span>
          {activeChips.map((chip) => (
            <button
              key={chip.key}
              type="button"
              onClick={() => removeChip(chip.key)}
              className="inline-flex items-center gap-1 h-6 px-2 text-[11px] bg-[#EAF7FD] text-[#0B2545] border border-[#B7DDF1] rounded-md hover:bg-[#DDF3FC] transition-colors"
              title="Remove filter"
            >
              {chip.label}
              <X className="w-3 h-3" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
