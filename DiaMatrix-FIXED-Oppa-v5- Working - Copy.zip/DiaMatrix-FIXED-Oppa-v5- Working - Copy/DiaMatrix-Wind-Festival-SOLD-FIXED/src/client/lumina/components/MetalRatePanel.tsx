import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ChevronDown, RefreshCw, Coins, Save, Pencil } from 'lucide-react';

export interface MetalRateRow {
  label: string;
  purity?: number | null;
  perGramBdt: number;
}

export interface MetalRateBlock {
  source: string;
  sourceUrl?: string;
  updatedAt: string;
  usdPerOz?: number;
  usdBdt?: number;
  pure24kPerGramBdt?: number;
  rates: MetalRateRow[];
}

interface GoldRatesResponse {
  ok: boolean;
  fetchedAt: string;
  cached?: boolean;
  bangladesh: MetalRateBlock;
  international: MetalRateBlock | null;
}

type Tab = 'bd' | 'intl';

const TROY_OZ_G = 31.1034768;
const BAJUS_STORAGE_KEY = 'dmx.bajus.metalRates.v1';

/** Default BAJUS reference rates until user enters their own. */
const BAJUS_DEFAULT: MetalRateBlock = {
  source: 'BAJUS — manual entry',
  updatedAt: '',
  rates: [
    { label: '22 KT', purity: 22, perGramBdt: 0 },
    { label: '21 KT', purity: 21, perGramBdt: 0 },
    { label: '18 KT', purity: 18, perGramBdt: 0 },
    { label: 'Platinum', purity: null, perGramBdt: 0 },
  ],
};

const fmtBdt = (n: number) =>
  n > 0 ? `৳ ${Math.round(n).toLocaleString('en-BD')}` : '—';

const fmtDate = (raw: string) => {
  if (!raw) return '—';
  if (/^\d{2}[-/]\d{2}[-/]\d{4}$/.test(raw)) return raw.replace(/\//g, '-');
  if (/^\d{4}-\d{2}-\d{2}/.test(raw)) {
    const d = new Date(raw);
    if (!Number.isNaN(d.getTime())) {
      const dd = String(d.getDate()).padStart(2, '0');
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      return `${dd}-${mm}-${d.getFullYear()}`;
    }
  }
  const d = new Date(raw);
  if (!Number.isNaN(d.getTime())) {
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    return `${dd}-${mm}-${d.getFullYear()}`;
  }
  return raw;
};

const todayInputValue = () => {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
};

function loadStoredBajus(): MetalRateBlock | null {
  try {
    const raw = localStorage.getItem(BAJUS_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as MetalRateBlock;
    if (!parsed?.rates?.length) return null;
    return {
      source: parsed.source || 'BAJUS — manual entry',
      updatedAt: parsed.updatedAt || '',
      rates: parsed.rates.map((r) => ({
        label: r.label,
        purity: r.purity ?? null,
        perGramBdt: Number(r.perGramBdt) || 0,
      })),
    };
  } catch {
    return null;
  }
}

function saveStoredBajus(block: MetalRateBlock) {
  try {
    localStorage.setItem(BAJUS_STORAGE_KEY, JSON.stringify(block));
  } catch {
    /* ignore quota */
  }
}

async function fetchJson(url: string, signal?: AbortSignal): Promise<any> {
  const res = await fetch(url, { signal, headers: { Accept: '*/*' } });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

/** International spot — auto only (Coinbase + USD/BDT). */
async function fetchInternationalClient(signal?: AbortSignal): Promise<MetalRateBlock | null> {
  let usdPerOz: number | null = null;
  let computedAt = new Date().toISOString();

  try {
    const cb = await fetchJson('https://api.coinbase.com/v2/prices/XAU-USD/spot', signal);
    const amt = Number(cb?.data?.amount);
    if (Number.isFinite(amt) && amt > 0) usdPerOz = amt;
  } catch {
    try {
      const gp = await fetchJson('https://api.goldprice.dev/v1/prices?symbol=XAU-USD-SPOT', signal);
      const row = gp?.symbols?.[0];
      const p = Number(row?.price);
      if (Number.isFinite(p) && p > 0) {
        usdPerOz = p;
        if (row?.computed_at) computedAt = row.computed_at;
      }
    } catch {
      /* ignore */
    }
  }

  if (!usdPerOz) return null;

  let usdBdt = 122.5;
  try {
    const fx = await fetchJson('https://open.er-api.com/v6/latest/USD', signal);
    if (fx?.rates?.BDT) usdBdt = Number(fx.rates.BDT);
  } catch {
    try {
      const fx2 = await fetchJson('https://api.exchangerate-api.com/v4/latest/USD', signal);
      if (fx2?.rates?.BDT) usdBdt = Number(fx2.rates.BDT);
    } catch {
      /* keep default */
    }
  }

  const purePerGramBdt = (usdPerOz / TROY_OZ_G) * usdBdt;
  const karat = (k: number) => Math.round(purePerGramBdt * (k / 24));

  return {
    source: 'International spot (auto) · Coinbase XAU + USD/BDT',
    updatedAt: computedAt,
    usdPerOz: Math.round(usdPerOz * 100) / 100,
    usdBdt: Math.round(usdBdt * 100) / 100,
    pure24kPerGramBdt: Math.round(purePerGramBdt),
    rates: [
      { label: '24 KT', purity: 24, perGramBdt: karat(24) },
      { label: '22 KT', purity: 22, perGramBdt: karat(22) },
      { label: '21 KT', purity: 21, perGramBdt: karat(21) },
      { label: '18 KT', purity: 18, perGramBdt: karat(18) },
    ],
  };
}

/**
 * Metal Rate panel:
 * - International → auto-refresh
 * - BAJUS (BD) → manual rates + rate date, saved locally
 */
export const MetalRatePanel: React.FC<{ className?: string }> = ({ className = '' }) => {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<Tab>('bd');
  const [intl, setIntl] = useState<MetalRateBlock | null>(null);
  const [bajus, setBajus] = useState<MetalRateBlock>(() => loadStoredBajus() || { ...BAJUS_DEFAULT });
  const [editRates, setEditRates] = useState<MetalRateRow[]>(() => (loadStoredBajus() || BAJUS_DEFAULT).rates);
  const [editDate, setEditDate] = useState(() => {
    const stored = loadStoredBajus();
    if (stored?.updatedAt && /^\d{4}-\d{2}-\d{2}/.test(stored.updatedAt)) {
      return stored.updatedAt.slice(0, 10);
    }
    if (stored?.updatedAt && /^\d{2}-\d{2}-\d{4}$/.test(stored.updatedAt)) {
      const [dd, mm, yyyy] = stored.updatedAt.split('-');
      return `${yyyy}-${mm}-${dd}`;
    }
    return todayInputValue();
  });
  const [editing, setEditing] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  const loadIntl = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    setError(null);
    const ctrl = new AbortController();
    try {
      const block = await fetchInternationalClient(ctrl.signal);
      setIntl(block);
      if (!block) setError('International spot unavailable');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load international rates');
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadIntl(true);
    const id = window.setInterval(() => void loadIntl(true), 30 * 60 * 1000);
    return () => window.clearInterval(id);
  }, [loadIntl]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const saveBajus = () => {
    const next: MetalRateBlock = {
      source: 'BAJUS — manual entry',
      updatedAt: editDate || todayInputValue(),
      rates: editRates.map((r) => ({
        ...r,
        perGramBdt: Number(r.perGramBdt) || 0,
      })),
    };
    saveStoredBajus(next);
    setBajus(next);
    setEditing(false);
    setSavedMsg('Saved');
    window.setTimeout(() => setSavedMsg(''), 2000);
  };

  const block = tab === 'bd' ? bajus : intl;
  const rows = tab === 'bd' && editing ? editRates : block?.rates || [];
  const headerDate =
    tab === 'bd'
      ? bajus.updatedAt || editDate
      : intl?.updatedAt || '';

  return (
    <div ref={boxRef} className={`relative ${className}`}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="dmx-metal-rate-btn inline-flex items-center gap-1.5 px-2.5 py-2 rounded-lg border border-[#0F766E]/40 bg-gradient-to-b from-[#0F766E] to-[#0D9488] text-[11px] font-extrabold tracking-wide shadow-sm hover:brightness-110 cursor-pointer"
        style={{ color: '#FFFFFF' }}
        title="Gold & metal rates — BAJUS (manual) & International (auto)"
        aria-expanded={open}
      >
        <Coins className="w-3.5 h-3.5" style={{ color: '#FFFFFF' }} />
        <span className="hidden sm:inline" style={{ color: '#FFFFFF' }}>METAL RATE</span>
        <ChevronDown
          className={`w-3.5 h-3.5 transition-transform ${open ? 'rotate-180' : ''}`}
          style={{ color: '#FFFFFF' }}
        />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-[min(92vw,340px)] rounded-xl overflow-hidden shadow-2xl shadow-[#0B2545]/20 border border-[#0F766E]/30 bg-white z-[1200]">
          <div className="flex items-stretch">
            <div className="w-8 bg-[#0F766E] text-white flex items-center justify-center">
              <span
                className="text-[10px] font-extrabold tracking-widest"
                style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}
              >
                METAL RATE
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2 px-3 py-2 bg-[#0F766E] text-white">
                <div className="text-[11px] font-semibold">
                  Updated on:{' '}
                  <span className="font-bold">{fmtDate(headerDate)}</span>
                </div>
                {tab === 'intl' ? (
                  <button
                    type="button"
                    onClick={() => void loadIntl(false)}
                    disabled={loading}
                    className="p-1 rounded hover:bg-white/15 cursor-pointer disabled:opacity-50"
                    title="Refresh international (auto)"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setEditRates(bajus.rates.map((r) => ({ ...r })));
                      setEditing(true);
                    }}
                    className="p-1 rounded hover:bg-white/15 cursor-pointer"
                    title="Edit BAJUS rates"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="flex border-b border-[#E2E8F0] bg-[#F8FAFC]">
                <button
                  type="button"
                  onClick={() => setTab('bd')}
                  className={`flex-1 px-2 py-1.5 text-[11px] font-bold cursor-pointer ${
                    tab === 'bd'
                      ? 'text-[#0F766E] border-b-2 border-[#0F766E] bg-white'
                      : 'text-[#64748B] hover:text-[#0F766E]'
                  }`}
                >
                  Bangladesh (BAJUS)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTab('intl');
                    setEditing(false);
                  }}
                  className={`flex-1 px-2 py-1.5 text-[11px] font-bold cursor-pointer ${
                    tab === 'intl'
                      ? 'text-[#0F766E] border-b-2 border-[#0F766E] bg-white'
                      : 'text-[#64748B] hover:text-[#0F766E]'
                  }`}
                >
                  International (Auto)
                </button>
              </div>

              <div className="bg-white">
                {tab === 'bd' && editing && (
                  <div className="px-3 pt-2 pb-1 space-y-2 border-b border-[#F1F5F9] bg-[#F0FDFA]">
                    <label className="block text-[10px] font-bold uppercase tracking-wide text-[#0F766E]">
                      Rate date
                      <input
                        type="date"
                        value={editDate}
                        onChange={(e) => setEditDate(e.target.value)}
                        className="mt-0.5 w-full h-8 rounded-md border border-[#99F6E4] bg-white px-2 text-[12px] font-semibold text-[#0B2545]"
                      />
                    </label>
                    <p className="text-[10px] text-[#64748B]">
                      Enter BAJUS retail rates (৳ per gram). Saved on this device.
                    </p>
                  </div>
                )}

                {tab === 'intl' && !rows.length && (
                  <div className="px-3 py-4 text-xs text-[#64748B]">
                    {error ? (
                      <span className="text-rose-700">{error}</span>
                    ) : (
                      'International spot unavailable. Try refresh.'
                    )}
                  </div>
                )}

                {tab === 'bd' && !editing && rows.every((r) => !r.perGramBdt) && (
                  <div className="px-3 py-3 text-[11px] text-[#64748B]">
                    No BAJUS rates yet. Click the pencil to enter rates and date.
                  </div>
                )}

                {rows.length > 0 && (
                  <table className="w-full text-[12px]">
                    <tbody>
                      {rows.map((r, idx) => (
                        <tr key={r.label} className="border-b border-[#F1F5F9] last:border-0">
                          <td className="px-3 py-2 font-semibold text-[#0B2545]">{r.label}</td>
                          <td className="px-3 py-2 text-right font-bold tabular-nums text-[#0B2545]">
                            {tab === 'bd' && editing ? (
                              <input
                                type="number"
                                min={0}
                                step={1}
                                value={r.perGramBdt || ''}
                                onChange={(e) => {
                                  const v = Number(e.target.value);
                                  setEditRates((prev) =>
                                    prev.map((row, i) =>
                                      i === idx
                                        ? { ...row, perGramBdt: Number.isFinite(v) ? v : 0 }
                                        : row,
                                    ),
                                  );
                                }}
                                className="w-[110px] h-7 rounded border border-[#99F6E4] px-2 text-right text-[12px] font-bold"
                                placeholder="৳ /gm"
                              />
                            ) : (
                              <>
                                {fmtBdt(r.perGramBdt)}
                                {r.perGramBdt > 0 && (
                                  <span className="text-[10px] font-medium text-[#64748B]">/gm</span>
                                )}
                              </>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {tab === 'bd' && editing && (
                  <div className="flex items-center gap-2 px-3 py-2 border-t border-[#F1F5F9] bg-[#F8FAFC]">
                    <button
                      type="button"
                      onClick={saveBajus}
                      className="inline-flex items-center gap-1 rounded-md bg-[#0F766E] text-white px-3 py-1.5 text-[11px] font-extrabold hover:brightness-110 cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save rates
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditRates(bajus.rates.map((r) => ({ ...r })));
                        setEditing(false);
                      }}
                      className="rounded-md border border-slate-200 bg-white px-3 py-1.5 text-[11px] font-bold text-slate-600 hover:bg-slate-50 cursor-pointer"
                    >
                      Cancel
                    </button>
                    {savedMsg && (
                      <span className="text-[11px] font-bold text-[#0F766E] ml-auto">{savedMsg}</span>
                    )}
                  </div>
                )}

                {tab === 'bd' && !editing && (
                  <div className="px-3 py-1.5 text-[10px] text-[#64748B] border-t border-[#F1F5F9] flex items-center justify-between">
                    <span>{bajus.source}</span>
                    {savedMsg && <span className="font-bold text-[#0F766E]">{savedMsg}</span>}
                  </div>
                )}

                {tab === 'intl' && intl && (
                  <div className="px-3 py-1.5 text-[10px] text-[#64748B] border-t border-[#F1F5F9] space-y-0.5">
                    {intl.usdPerOz != null && (
                      <div>
                        Spot XAU:{' '}
                        <span className="font-semibold text-[#0B2545]">
                          ${intl.usdPerOz.toLocaleString()}/oz
                        </span>
                      </div>
                    )}
                    {intl.usdBdt != null && (
                      <div>
                        USD/BDT:{' '}
                        <span className="font-semibold text-[#0B2545]">{intl.usdBdt}</span>
                      </div>
                    )}
                    <div className="opacity-80">{intl.source}</div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
