import React, { useEffect, useRef } from 'react';
import { D } from './diamatrixParticleMask';

/**
 * DW + diamond particle logo (ported from diamatrix.html).
 *
 * - Particles sit on the real logo mask and always drift/flow (never static).
 * - Fast cursor swipe scatters them, then they spring back into the logo.
 * - Colors are "space" colors (cyan / blue / violet / magenta nebula) drawn
 *   with normal blending so they stay visible on the light module-card background.
 */

/** Space palette: [core, mid, edge] as r,g,b */
const PALETTE: [number, number, number][] = [
  [0, 168, 255], // cyan-blue
  [41, 98, 255], // electric blue
  [99, 66, 235], // indigo-violet
  [147, 51, 234], // violet
  [219, 39, 160], // magenta
  [14, 165, 190], // teal
];
const STAR: [number, number, number] = [255, 179, 0]; // golden star twinkle
const DIAMOND: [number, number, number][] = [
  [0, 120, 255],
  [80, 60, 240],
  [0, 190, 220],
];

function makeSprite([r, g, b]: [number, number, number]): HTMLCanvasElement {
  const s = 32;
  const c = document.createElement('canvas');
  c.width = c.height = s;
  const g2 = c.getContext('2d')!;
  const grad = g2.createRadialGradient(16, 16, 0, 16, 16, 16);
  grad.addColorStop(0, `rgba(${Math.min(255, r + 70)},${Math.min(255, g + 70)},${Math.min(255, b + 70)},1)`);
  grad.addColorStop(0.16, `rgba(${r},${g},${b},0.98)`);
  grad.addColorStop(0.42, `rgba(${r},${g},${b},0.34)`);
  grad.addColorStop(1, `rgba(${r},${g},${b},0)`);
  g2.fillStyle = grad;
  g2.fillRect(0, 0, s, s);
  return c;
}

type Particle = {
  hx: number;
  hy: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  w: number;
  s: number;
  a: number;
  ph: number;
  dia: boolean;
  star: boolean;
  spr: number; // sprite index
  /** orbit radius / speed for the constant flow */
  orb: number;
  spd: number;
};

export const DiaMatrixParticleLogo: React.FC<{ className?: string }> = ({ className }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;

    const LW = D.w;
    const LH = D.h;
    const unpack = (b: string, n: number) => {
      const s = atob(b);
      const o = new Uint8Array(n);
      for (let i = 0; i < n; i++) o[i] = (s.charCodeAt(i >> 3) >> (7 - (i & 7))) & 1;
      return o;
    };
    const SM = unpack(D.sm, LW * LH);
    const DM = unpack(D.dm, LW * LH);
    const SPT: number[] = [];
    const DPT: number[] = [];
    for (let i = 0; i < LW * LH; i++) {
      if (DM[i]) DPT.push(i);
      else if (SM[i]) SPT.push(i);
    }
    const ALL = SPT.length + DPT.length;

    // Sprites
    const SPR_SPACE = PALETTE.map(makeSprite);
    const SPR_STAR = makeSprite(STAR);
    const SPR_DIA = DIAMOND.map(makeSprite);

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const motion = reduce ? 0.35 : 1; // still moving, just calmer

    let W = 0;
    let H = 0;
    let dpr = 1;
    let scale = 1;
    let OX = 0;
    let OY = 0;
    let P: Particle[] = [];
    let dust: { x: number; y: number; vx: number; vy: number; r: number; a: number; spr: number }[] = [];
    let last = 0;
    let raf = 0;

    const mouse = { x: -9999, y: -9999, px: -9999, py: -9999, on: false, speed: 0, dx: 0, dy: 0 };

    const layout = () => {
      const r = cv.getBoundingClientRect();
      if (!r.width || !r.height) return;
      dpr = Math.min(window.devicePixelRatio || 1, 1.25);
      W = r.width;
      H = r.height;
      cv.width = W * dpr;
      cv.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      scale = Math.min(W / LW, H / LH) * 0.84;
      OX = (W - LW * scale) / 2;
      OY = (H - LH * scale) / 2;

      const area = ALL * scale * scale;
      const N = Math.round(Math.max(1500, Math.min(W < 640 ? 2000 : 4200, area / 15)));
      const old = P;
      P = [];
      for (let i = 0; i < N; i++) {
        const dia = Math.random() < (DPT.length * 2.2) / (SPT.length + DPT.length * 2.2);
        const idx = dia ? DPT[(Math.random() * DPT.length) | 0] : SPT[(Math.random() * SPT.length) | 0];
        const px = idx % LW;
        const py = (idx / LW) | 0;
        // colour follows position across the logo -> smooth nebula gradient
        const t = (px / LW) * 0.7 + (py / LH) * 0.3;
        const base = Math.min(PALETTE.length - 1, Math.floor(t * PALETTE.length));
        const jitter = Math.random() < 0.22 ? ((Math.random() * PALETTE.length) | 0) : base;
        const o = old[i];
        P.push({
          hx: OX + (px + Math.random()) * scale,
          hy: OY + (py + Math.random()) * scale,
          x: o ? o.x : Math.random() * W,
          y: o ? o.y : Math.random() * H,
          vx: 0,
          vy: 0,
          w: 1.3 + Math.random() * 0.9,
          s: 0.6 + Math.random() * 0.7,
          a: 0.62 + Math.random() * 0.38,
          ph: Math.random() * 6.283,
          dia,
          star: Math.random() < 0.03,
          spr: dia ? (Math.random() * SPR_DIA.length) | 0 : jitter,
          orb: (0.35 + Math.random() * 0.9) * scale,
          spd: 0.0006 + Math.random() * 0.0014,
        });
      }

      // ambient space dust drifting behind the logo
      dust = [];
      const dn = Math.round(Math.min(50, (W * H) / 25000));
      for (let i = 0; i < dn; i++) {
        dust.push({
          x: Math.random() * W,
          y: Math.random() * H,
          vx: (Math.random() - 0.5) * 8,
          vy: (Math.random() - 0.5) * 8,
          r: 1.5 + Math.random() * 3.2,
          a: 0.12 + Math.random() * 0.28,
          spr: (Math.random() * PALETTE.length) | 0,
        });
      }
    };

    let visible = true;
    const frame = (t: number) => {
      raf = requestAnimationFrame(frame);
      if (!visible || document.hidden) {
        last = 0;
        return;
      }
      // cap at ~40fps to keep the rest of the app responsive
      if (last && t - last < 24) return;
      const dt = Math.min(0.05, (t - (last || t)) / 1000) || 0.025;
      last = t;

      if (mouse.on && mouse.px > -9000) {
        const mx = mouse.x - mouse.px;
        const my = mouse.y - mouse.py;
        const len = Math.hypot(mx, my);
        const inst = len / dt;
        mouse.speed += (inst - mouse.speed) * 0.35;
        if (inst > 1) {
          mouse.dx += (mx / len - mouse.dx) * 0.4;
          mouse.dy += (my / len - mouse.dy) * 0.4;
        }
      } else mouse.speed *= 0.8;
      mouse.px = mouse.x;
      mouse.py = mouse.y;

      const strength = mouse.on ? Math.min(1.7, Math.pow(Math.max(0, mouse.speed - 60) / 1100, 1.15)) : 0;
      const R = Math.max(110, Math.min(W, H) * 0.26);
      const R2 = R * R;

      ctx.globalCompositeOperation = 'source-over';
      ctx.clearRect(0, 0, W, H);

      // dust (always moving)
      for (const d of dust) {
        d.x += d.vx * dt * motion;
        d.y += d.vy * dt * motion;
        if (d.x < -10) d.x = W + 10;
        else if (d.x > W + 10) d.x = -10;
        if (d.y < -10) d.y = H + 10;
        else if (d.y > H + 10) d.y = -10;
        ctx.globalAlpha = d.a;
        ctx.drawImage(SPR_SPACE[d.spr], d.x - d.r * 2, d.y - d.r * 2, d.r * 4, d.r * 4);
      }

      const sz = Math.max(2.8, scale * 0.04);
      const zeta = 0.82;

      for (let i = 0; i < P.length; i++) {
        const p = P[i];

        if (strength > 0.001) {
          const dx = p.x - mouse.x;
          const dy = p.y - mouse.y;
          const d2 = dx * dx + dy * dy;
          if (d2 < R2) {
            const d = Math.sqrt(d2) + 0.001;
            const f = 1 - d / R;
            const rnd = 0.35 + Math.random() * 0.9;
            const kick = strength * f * f * 8000 * dt * rnd;
            p.vx += ((dx / d) * 0.7 + mouse.dx * 0.35 + (Math.random() - 0.5) * 0.7) * kick;
            p.vy += ((dy / d) * 0.7 + mouse.dy * 0.35 + (Math.random() - 0.5) * 0.7) * kick;
          }
        }

        // constant flowing orbit around the home point + a slow travelling wave across the logo
        const ang = t * p.spd * 2.2 + p.ph;
        const hx = p.hx + Math.cos(ang) * p.orb * 0.6 * motion;
        const hy = p.hy + Math.sin(ang) * p.orb * 0.6 * motion;

        const w = p.w;
        p.vx += (-w * w * (p.x - hx) - 2 * zeta * w * p.vx) * dt;
        p.vy += (-w * w * (p.y - hy) - 2 * zeta * w * p.vy) * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;

        const glow = Math.min(1, (Math.abs(p.x - p.hx) + Math.abs(p.y - p.hy)) / 80 + (Math.abs(p.vx) + Math.abs(p.vy)) / 900);
        let fl = 0;
        if (p.star) {
          const q = Math.sin(t * 0.0014 + p.ph * 3);
          fl = q > 0.8 ? (q - 0.8) * 5 : 0;
        }
        const s = sz * p.s * (p.dia ? 1.15 : 1) * (1 + glow * 0.8 + fl * 2.2);
        ctx.globalAlpha = Math.min(1, p.a * (0.85 + glow * 0.4 + fl));
        const spr = fl > 0.25 ? SPR_STAR : p.dia ? SPR_DIA[p.spr] : SPR_SPACE[p.spr];
        ctx.drawImage(spr, p.x - s, p.y - s, s * 2, s * 2);
      }
      ctx.globalAlpha = 1;
    };

    const pos = (e: PointerEvent) => {
      const r = cv.getBoundingClientRect();
      mouse.x = e.clientX - r.left;
      mouse.y = e.clientY - r.top;
    };
    const onEnter = (e: PointerEvent) => {
      pos(e);
      mouse.px = mouse.x;
      mouse.py = mouse.y;
      mouse.on = true;
    };
    const onMove = (e: PointerEvent) => {
      pos(e);
      mouse.on = true;
    };
    const onOff = () => {
      mouse.on = false;
      mouse.px = -9999;
    };

    cv.addEventListener('pointerenter', onEnter);
    cv.addEventListener('pointermove', onMove);
    cv.addEventListener('pointerdown', onEnter);
    cv.addEventListener('pointerleave', onOff);
    cv.addEventListener('pointercancel', onOff);
    cv.addEventListener('pointerup', onOff);

    const io = new IntersectionObserver((e) => {
      visible = e[0]?.isIntersecting ?? true;
    });
    io.observe(cv);
    const ro = new ResizeObserver(layout);
    ro.observe(cv);
    layout();
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      cv.removeEventListener('pointerenter', onEnter);
      cv.removeEventListener('pointermove', onMove);
      cv.removeEventListener('pointerdown', onEnter);
      cv.removeEventListener('pointerleave', onOff);
      cv.removeEventListener('pointercancel', onOff);
      cv.removeEventListener('pointerup', onOff);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      role="img"
      aria-label="Particles forming the DW monogram with a diamond"
      style={{
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        display: 'block',
        cursor: 'crosshair',
        touchAction: 'none',
      }}
    />
  );
};
