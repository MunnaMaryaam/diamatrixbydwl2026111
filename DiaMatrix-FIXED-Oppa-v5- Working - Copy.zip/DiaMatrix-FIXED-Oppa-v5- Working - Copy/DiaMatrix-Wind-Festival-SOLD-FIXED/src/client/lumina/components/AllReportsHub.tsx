import React, { useEffect, useMemo, useState } from 'react';
import {
  Building2,
  FileSpreadsheet,
  Gem,
  PackagePlus,
  ArrowRightLeft,
  Flame,
  Sparkles,
  Search,
  X,
  BarChart3,
  Package,
  TrendingUp,
  Warehouse,
  LayoutGrid,
  Gauge,
  FolderOpen,
  Shuffle,
  FilePlus2,
  ClipboardList,
  Layers,
  Boxes,
} from 'lucide-react';
import { RawInventoryRecord } from '../types';
import { ReportFilters, EMPTY_FILTERS, parseCaratValue, applyReportFilters } from './ReportFilterBar';
import { calculateRedistributionReport } from '../utils/redistributionEngine';
import type { AllocationMode, SalesTimeframe, SpecialMonth } from '../types';
import {
  downloadExecutionWorkbook,
  downloadExecutionPdf,
  saveExecutionReportsToFolder,
  type ExecutionReportMode,
} from '../utils/executionReportExport';
import { BRAND } from '../brand';
import { OPEN_NEW_ORDER_EVENT } from '../utils/refillOrderStore';

export type ReportKey =
  | 'refill_demand'
  | 'excel_sheet'
  | 'outlet_design_matrix'
  | 'movement_summary'
  | 'branches'
  | 'weights'
  | 'demand_booster'
  | 'ai_crossmatch'
  | 'execution'
  | 'stock_turn_rate';

/** External module targets that live outside the report-key shell. */
export type ExternalModuleKey = 'movement_aging' | 'new_order';

interface AllReportsHubProps {
  rawRecords: RawInventoryRecord[];
  filters: ReportFilters;
  onFiltersChange: (f: ReportFilters) => void;
  period: string;
  activeReport: ReportKey;
  onSelectReport: (key: ReportKey, mode?: 'manual' | 'ai') => void;
  filteredCount: number;
  totalCount: number;
  selectedTimeframe: SalesTimeframe;
  specialMonths?: SpecialMonth[];
  /** Optional: open full-page modules (Movement & Aging, New Order). */
  onOpenExternalModule?: (module: ExternalModuleKey) => void;
}

type HubLink =
  | { kind: 'report'; key: ReportKey; mode?: 'manual' | 'ai'; label: string; hint: string; icon: React.ReactNode }
  | { kind: 'external'; module: ExternalModuleKey; label: string; hint: string; icon: React.ReactNode };

type HubFolder = {
  id: string;
  title: string;
  subtitle: string;
  accent: string;
  border: string;
  headerBg: string;
  icon: React.ReactNode;
  links: HubLink[];
};

const FOLDERS: HubFolder[] = [
  {
    id: 'inventory_audit',
    title: 'Inventory & Supply Chain Audit',
    subtitle: 'Core Operations',
    accent: 'text-teal-700',
    border: 'border-teal-300',
    headerBg: 'from-teal-700 to-slate-800',
    icon: <Boxes className="w-5 h-5" />,
    links: [
      {
        kind: 'report',
        key: 'weights',
        label: 'Style Inventory Matrix',
        hint: 'Design-wise stock · category / all designs / single',
        icon: <Layers className="w-3.5 h-3.5" />,
      },
      {
        kind: 'external',
        module: 'movement_aging',
        label: 'Shelf Aging & Movement Report',
        hint: 'Aging buckets · dead stock tracker',
        icon: <ArrowRightLeft className="w-3.5 h-3.5" />,
      },
      {
        kind: 'report',
        key: 'stock_turn_rate',
        label: 'Stock Turn-Rate Ranking',
        hint: 'Top fast vs slow-moving showrooms',
        icon: <Gauge className="w-3.5 h-3.5" />,
      },
    ],
  },
  {
    id: 'ai_procurement',
    title: 'AI Demand & Procurement Planning',
    subtitle: 'Sourcing Team',
    accent: 'text-amber-700',
    border: 'border-amber-300',
    headerBg: 'from-amber-600 to-orange-800',
    icon: <Flame className="w-5 h-5" />,
    links: [
      {
        kind: 'report',
        key: 'demand_booster',
        label: 'AI Demand & Lost Opportunity',
        hint: 'Unmet shortage and revenue loss',
        icon: <TrendingUp className="w-3.5 h-3.5" />,
      },
      {
        kind: 'report',
        key: 'refill_demand',
        label: 'Automated Purchase Order Advice',
        hint: 'AI restock orders from baseline gaps',
        icon: <PackagePlus className="w-3.5 h-3.5" />,
      },
      {
        kind: 'report',
        key: 'ai_crossmatch',
        mode: 'ai',
        label: 'AI Crossmatch Briefing',
        hint: 'Intelligence overlay on stock gaps',
        icon: <Sparkles className="w-3.5 h-3.5" />,
      },
    ],
  },
  {
    id: 'redistribution',
    title: 'Inter-Branch Redistribution Engine',
    subtitle: 'Merchandising',
    accent: 'text-indigo-700',
    border: 'border-indigo-300',
    headerBg: 'from-indigo-700 to-slate-800',
    icon: <Shuffle className="w-5 h-5" />,
    links: [
      {
        kind: 'report',
        key: 'movement_summary',
        label: 'Have vs Deserve Gaps',
        hint: 'Real-time supply-demand gaps',
        icon: <BarChart3 className="w-3.5 h-3.5" />,
      },
      {
        kind: 'external',
        module: 'movement_aging',
        label: 'Cross-Outlet Redistribution Logic',
        hint: 'Automated transfer optimization',
        icon: <Shuffle className="w-3.5 h-3.5" />,
      },
      {
        kind: 'report',
        key: 'execution',
        label: 'Distribution Execution Pack',
        hint: 'Contribution · Baseline · Hybrid exports',
        icon: <ArrowRightLeft className="w-3.5 h-3.5" />,
      },
    ],
  },
  {
    id: 'billing',
    title: 'Supplier Billing & Invoice Hub',
    subtitle: 'Accounts & Procurement',
    accent: 'text-blue-700',
    border: 'border-blue-300',
    headerBg: 'from-blue-700 to-slate-800',
    icon: <ClipboardList className="w-5 h-5" />,
    links: [
      {
        kind: 'external',
        module: 'new_order',
        label: 'Refill Demand Purchase Order Generator',
        hint: 'Dynamic invoice · Diamond World branding',
        icon: <FilePlus2 className="w-3.5 h-3.5" />,
      },
      {
        kind: 'report',
        key: 'refill_demand',
        label: 'Historic PO Log & Print Archive',
        hint: 'Invoice management and print logs',
        icon: <ClipboardList className="w-3.5 h-3.5" />,
      },
      {
        kind: 'report',
        key: 'excel_sheet',
        label: 'Master Excel Matrix Workbook',
        hint: 'Full export hub · multi-sheet',
        icon: <FileSpreadsheet className="w-3.5 h-3.5" />,
      },
    ],
  },
];

const fieldCls =
  'h-8 w-full border border-[#89919a] bg-white px-2 text-[12px] text-[#32363a] focus:outline-none focus:border-[#0B6FB8] focus:ring-1 focus:ring-[#0B6FB8]/25';

/**
 * All Reports hub — Odoo-style 2×2 corporate folder cards + legacy filter strip.
 */
export const AllReportsHub: React.FC<AllReportsHubProps> = ({
  rawRecords,
  filters,
  onFiltersChange,
  period,
  activeReport,
  onSelectReport,
  filteredCount,
  totalCount,
  selectedTimeframe,
  specialMonths = [],
  onOpenExternalModule,
}) => {
  const [draft, setDraft] = useState<ReportFilters>(filters);
  const [sBranch, setSBranch] = useState('');
  const [savingExecutionReports, setSavingExecutionReports] = useState(false);
  const [executionMessage, setExecutionMessage] = useState('');

  useEffect(() => {
    setDraft(filters);
  }, [filters]);

  const branchOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.branch) set.add(r.branch);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const categoryOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.category) set.add(r.category);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const rangeOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.weight) {
        const base = String(r.weight).split('·')[0].trim();
        if (base) set.add(base);
      }
    });
    return Array.from(set).sort((a, b) => {
      const na = parseCaratValue(a);
      const nb = parseCaratValue(b);
      if (na != null && nb != null) return na - nb;
      return a.localeCompare(b);
    });
  }, [rawRecords]);

  const styleOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      const c = (r.itemCode || r.variant || '').trim();
      if (c) set.add(c);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const executionRecords = useMemo(() => applyReportFilters(rawRecords, filters), [rawRecords, filters]);
  // Enable design mode when user filters a style OR only style-layer data exists
  // (otherwise same-carat designs collapse and Design-wise search finds nothing)
  const executionHasDesignLayer = useMemo(
    () => rawRecords.some((r) => !!(r.itemCode || r.variant || '').trim()),
    [rawRecords],
  );
  const executionHasCategoryLayer = useMemo(
    () => rawRecords.some((r) => !(r.itemCode || r.variant || '').trim()),
    [rawRecords],
  );
  const executionDesignMode =
    !!(filters.subCategory || filters.styleCode || '').trim() ||
    (executionHasDesignLayer && !executionHasCategoryLayer);
  const executionPreserveTrailingS = /^[a-zA-Z]{2,4}s$/i.test(filters.branchId.trim());
  const executionReports = useMemo(() => {
    const make = (mode: AllocationMode) =>
      calculateRedistributionReport(
        executionRecords,
        period,
        undefined,
        undefined,
        undefined,
        selectedTimeframe,
        mode,
        specialMonths,
        executionDesignMode,
        executionPreserveTrailingS,
      );
    return {
      contribution: make('contribution'),
      baseline: make('baseline'),
      hybrid: make('hybrid'),
      liquidity: make('liquidity'),
      demand_backup: make('demand_backup'),
      coverage: make('coverage'),
    };
  }, [
    executionRecords,
    period,
    selectedTimeframe,
    specialMonths,
    executionDesignMode,
    executionPreserveTrailingS,
  ]);

  const executionModeLabel = (mode: ExecutionReportMode) =>
    mode === 'contribution'
      ? 'Contribution'
      : mode === 'baseline'
        ? '3-Month Baseline'
        : mode === 'hybrid'
          ? 'Hybrid'
          : mode === 'liquidity'
            ? 'Capital Liquidity'
            : mode === 'demand_backup'
              ? 'Demand-Backup & Safety'
              : 'Universal Coverage';

  const downloadExecution = async (mode: ExecutionReportMode) => {
    const label = executionModeLabel(mode);
    setExecutionMessage(`${label} Excel is being generated…`);
    try {
      await downloadExecutionWorkbook(executionReports[mode], mode);
      setExecutionMessage(`${label} Excel report generated.`);
    } catch (error) {
      setExecutionMessage(error instanceof Error ? error.message : `${label} Excel export failed.`);
    }
  };

  const downloadExecutionPdfFile = async (mode: ExecutionReportMode) => {
    const label = executionModeLabel(mode);
    setExecutionMessage(`${label} PDF is being generated…`);
    try {
      await downloadExecutionPdf(executionReports[mode], mode);
      setExecutionMessage(`${label} PDF report generated.`);
    } catch (error) {
      setExecutionMessage(error instanceof Error ? error.message : `${label} PDF export failed.`);
    }
  };

  const saveAllExecutionReports = async () => {
    setSavingExecutionReports(true);
    setExecutionMessage('');
    try {
      await saveExecutionReportsToFolder(executionReports);
      setExecutionMessage('Execution Report folder saved with all independent Excel files.');
    } catch (error) {
      setExecutionMessage(error instanceof Error ? error.message : 'Folder save was cancelled.');
    } finally {
      setSavingExecutionReports(false);
    }
  };

  const applyFilters = () => {
    const next = { ...draft };
    if (sBranch.trim()) {
      next.branchId = sBranch.trim().toUpperCase();
    }
    onFiltersChange(next);
  };

  const clearFilters = () => {
    setDraft(EMPTY_FILTERS);
    setSBranch('');
    onFiltersChange(EMPTY_FILTERS);
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') applyFilters();
  };

  const openLink = (link: HubLink) => {
    if (link.kind === 'report') {
      onSelectReport(link.key, link.mode);
      return;
    }
    if (onOpenExternalModule) {
      onOpenExternalModule(link.module);
      return;
    }
    if (link.module === 'new_order') {
      window.dispatchEvent(new CustomEvent(OPEN_NEW_ORDER_EVENT));
      return;
    }
    if (link.module === 'movement_aging') {
      window.dispatchEvent(new CustomEvent('dmx:open-movement-aging'));
    }
  };

  const isLinkActive = (link: HubLink) => {
    if (link.kind === 'report') return activeReport === link.key;
    return false;
  };

  // Dropdown navigation (replaces 2×2 folder cards)
  const activeFolderId = useMemo(() => {
    for (const f of FOLDERS) {
      if (f.links.some((l) => isLinkActive(l))) return f.id;
    }
    return FOLDERS[0]?.id || '';
  }, [activeReport]);

  const [reportGroupId, setReportGroupId] = useState(activeFolderId);
  useEffect(() => {
    if (activeFolderId) setReportGroupId(activeFolderId);
  }, [activeFolderId]);

  const selectedFolder = useMemo(
    () => FOLDERS.find((f) => f.id === reportGroupId) || FOLDERS[0],
    [reportGroupId],
  );

  const selectedLinkKey = useMemo(() => {
    const links = selectedFolder?.links || [];
    const active = links.find((l) => isLinkActive(l));
    if (active) {
      return active.kind === 'report' ? `report:${active.key}` : `external:${active.module}`;
    }
    return '';
  }, [selectedFolder, activeReport]);

  const onPickReport = (value: string) => {
    if (!value || !selectedFolder) return;
    const [kind, id] = value.split(':');
    const link = selectedFolder.links.find((l) =>
      kind === 'report' && l.kind === 'report'
        ? l.key === id
        : l.kind === 'external' && l.module === id,
    );
    if (link) openLink(link);
  };

  return (
    <div className="space-y-4">
      {/* Filter strip */}
      <div className="rounded-xl border border-[#cbd5e1] bg-white shadow-sm overflow-hidden">
        <div className="bg-[#E6F4FC] px-3 py-2 border-b border-[#CFE6F5] flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <FolderOpen className="w-4 h-4 text-[#0B2545]" />
            <div>
              <div className="text-sm font-extrabold text-[#0B2545]">{BRAND.short} Reports Hub</div>
              <div className="text-[10px] text-[#4F6B88]">
                Corporate folders · {filteredCount.toLocaleString()} / {totalCount.toLocaleString()} records ·{' '}
                {period || 'Current period'}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={applyFilters}
              className="inline-flex items-center gap-1 rounded-lg bg-[#14B4E8] text-white px-3 py-1.5 text-[11px] font-extrabold hover:bg-[#0B8FBA] cursor-pointer"
            >
              <Search className="w-3.5 h-3.5" /> Apply
            </button>
            <button
              type="button"
              onClick={clearFilters}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white text-slate-700 px-3 py-1.5 text-[11px] font-bold hover:bg-slate-50 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" /> Clear
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 p-3 bg-[#F8FAFC]" onKeyDown={onKey}>
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase">Branch</label>
            <select
              className={fieldCls}
              value={draft.branchId}
              onChange={(e) => setDraft({ ...draft, branchId: e.target.value })}
            >
              <option value="">All</option>
              {branchOptions.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase">S.Branch</label>
            <input
              className={fieldCls}
              value={sBranch}
              onChange={(e) => setSBranch(e.target.value)}
              placeholder="Exact code"
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase">Category</label>
            <select
              className={fieldCls}
              value={draft.mainCategory}
              onChange={(e) => setDraft({ ...draft, mainCategory: e.target.value })}
            >
              <option value="">All</option>
              {categoryOptions.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase">Sub Category</label>
            <input
              className={fieldCls}
              value={draft.subCategory}
              onChange={(e) => setDraft({ ...draft, subCategory: e.target.value })}
              placeholder="Optional"
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase">Range / Carat</label>
            <select
              className={fieldCls}
              value={draft.range}
              onChange={(e) => setDraft({ ...draft, range: e.target.value })}
            >
              <option value="">All</option>
              {rangeOptions.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase">Style / SKU</label>
            <select
              className={fieldCls}
              value={draft.styleCode}
              onChange={(e) => setDraft({ ...draft, styleCode: e.target.value })}
            >
              <option value="">All</option>
              {styleOptions.slice(0, 400).map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Report Group + Report dropdowns (compact — replaces 2×2 folder cards) */}
      <div className="rounded-xl border border-[#cbd5e1] bg-white shadow-sm overflow-hidden">
        <div className="bg-gradient-to-r from-slate-800 to-teal-800 px-3 py-2 flex items-center gap-2">
          <LayoutGrid className="w-4 h-4 text-white/90" />
          <div className="text-sm font-extrabold text-white">Open report</div>
          <div className="text-[10px] text-white/70 ml-1">Pick group → report</div>
        </div>
        <div className="p-3 grid grid-cols-1 md:grid-cols-2 gap-3 items-end">
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
              Report group
            </label>
            <select
              className="mt-1 h-10 w-full rounded-lg border border-[#A9D9F0] bg-white px-3 text-[13px] font-bold text-[#0B2545] focus:outline-none focus:border-[#14B4E8] focus:ring-2 focus:ring-[#BFE6F8]"
              value={reportGroupId}
              onChange={(e) => setReportGroupId(e.target.value)}
            >
              {FOLDERS.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.subtitle} — {f.title}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">
              Report
            </label>
            <select
              className="mt-1 h-10 w-full rounded-lg border border-[#A9D9F0] bg-white px-3 text-[13px] font-bold text-[#0B2545] focus:outline-none focus:border-[#14B4E8] focus:ring-2 focus:ring-[#BFE6F8]"
              value={selectedLinkKey}
              onChange={(e) => onPickReport(e.target.value)}
            >
              <option value="">Select a report…</option>
              {(selectedFolder?.links || []).map((link, idx) => {
                const value =
                  link.kind === 'report' ? `report:${link.key}` : `external:${link.module}`;
                return (
                  <option key={`${selectedFolder?.id}-${idx}`} value={value}>
                    {link.label}
                  </option>
                );
              })}
            </select>
            {selectedFolder && (
              <p className="mt-1 text-[10px] text-slate-500">
                {(selectedFolder.links.find((l) =>
                  l.kind === 'report'
                    ? selectedLinkKey === `report:${l.key}`
                    : selectedLinkKey === `external:${l.module}`,
                )?.hint) || 'Choose a report from this group'}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Execution export pack when that report is selected */}
      {activeReport === 'execution' && (
        <div className="rounded-xl border border-[#cbd5e1] bg-white shadow-[0_10px_28px_rgba(10,15,29,0.10)] overflow-hidden">
          <div className="bg-[#E6F4FC] px-3 py-2.5 text-[#0B2545] border-b border-[#CFE6F5] flex items-center justify-between">
            <div>
              <div className="text-sm font-extrabold">Execution Report</div>
              <div className="text-[10px] text-[#4F6B88] mt-0.5">
                Important distribution report · choose one calculation method
              </div>
            </div>
            <button
              type="button"
              onClick={saveAllExecutionReports}
              disabled={savingExecutionReports}
              className="rounded-lg bg-[#14B4E8] text-white px-3 py-2 text-[11px] font-extrabold shadow-[0_4px_0_#0B8FBA] hover:-translate-y-0.5 disabled:opacity-60 cursor-pointer"
            >
              {savingExecutionReports ? 'Saving…' : 'Save All Reports'}
            </button>
          </div>
          <div className="px-3 pt-3 text-[10px] font-semibold text-[#475569]">
            Category-wise execution options are calculated independently from the same filtered
            dataset.
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 p-3 bg-[#F4F6F9]">
            {(
              [
                ['contribution', 'Contribution', 'Full pool by sales share', '#2A75D3'],
                ['baseline', '3-Month Baseline', 'Velocity / baseline target', '#0F4C81'],
                ['hybrid', 'Hybrid', 'Higher of contribution vs baseline', '#E6A100'],
                ['liquidity', 'Capital Liquidity', 'Sales ÷ aging; scale if >90d', '#0B6E4F'],
                ['demand_backup', 'Demand-Backup', '3M + 20% HP + stock-out safety', '#7C3AED'],
                ['coverage', 'Universal Coverage', '≥1 pc each; max 30 pcs/outlet', '#BE123C'],
              ] as const
            ).map(([mode, label, hint, accent]) => (
              <div
                key={mode}
                className="rounded-xl border border-[#d7dde5] bg-white p-3 shadow-[0_5px_0_#dbe2ea,0_12px_22px_rgba(10,15,29,0.08)]"
              >
                <div className="flex items-center justify-between">
                  <div className="font-extrabold text-[#0A0F1D] text-xs">{label}</div>
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: accent }} />
                </div>
                <div className="text-[10px] text-[#475569] mt-1">{hint}</div>
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <button
                    type="button"
                    onClick={() => downloadExecution(mode)}
                    className="rounded-lg bg-[#0B2545] text-white px-2 py-1.5 text-[10px] font-bold cursor-pointer"
                  >
                    Excel
                  </button>
                  <button
                    type="button"
                    onClick={() => downloadExecutionPdfFile(mode)}
                    className="rounded-lg border border-slate-300 text-slate-700 px-2 py-1.5 text-[10px] font-bold cursor-pointer"
                  >
                    PDF
                  </button>
                </div>
              </div>
            ))}
          </div>
          {executionMessage && (
            <div className="px-3 pb-3 text-[11px] font-semibold text-[#0B2545]">{executionMessage}</div>
          )}
        </div>
      )}
    </div>
  );
};
