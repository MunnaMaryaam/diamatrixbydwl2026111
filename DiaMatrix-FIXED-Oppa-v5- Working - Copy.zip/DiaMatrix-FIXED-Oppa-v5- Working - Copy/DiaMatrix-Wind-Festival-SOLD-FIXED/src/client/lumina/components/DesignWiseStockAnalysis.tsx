import React, { useMemo, useState } from 'react';
import {
  Gem,
  Layers,
  Package,
  TrendingUp,
  AlertTriangle,
  Search,
  Download,
  ChevronRight,
} from 'lucide-react';
import { RedistributionReport } from '../types';
import {
  isWarehouseBranchCode,
  getBranchDisplayName,
  isOnlineBranch,
  isExcludedOutlet,
  isLockedRetailOutletCode,
  toLockedOutletShortcut,
  getLockedRetailOutletsOrdered,
  compareOutletsByLockedOrder,
} from '../utils/dataIdentityEngine';
import { getReportDimension } from '../utils/reportDimension';
import {
  exportDesignWiseStockExcel,
  exportStyledRowsExcel,
  distributionModeLabel,
  distributionModeExplanation,
} from '../utils/styledReportExport';
import { getReportCategoryLabel } from '../utils/redistributionEngine';
import type { AllocationMode } from '../types';

interface DesignWiseStockAnalysisProps {
  /** Screen report (category by default; design when Style filter on) */
  report: RedistributionReport;
  /** Optional pure category-layer report for Main Category view / Excel sheet 1 */
  categoryReport?: RedistributionReport;
  /** Design-layer report always computed when style sheets exist — Excel design sheets */
  designReport?: RedistributionReport;
  /** Active distribution mode — shown bold on screen + Excel */
  allocationMode?: AllocationMode | string;
  onSelectWeight?: (weight: string) => void;
}

type OutletCell = {
  stock: number;
  sold: number;
  moveIn: number;
  moveOut: number;
  netMove: number;
};

type DesignRow = {
  design: string;
  carat: string;
  itemKey: string;
  stock: number;
  sold: number;
  refill: number;
  /** DWL / warehouse reserve pcs for this item (not a retail outlet column) */
  dwlStock?: number;
  moveIn: number;
  moveOut: number;
  turnover: number;
  velocity: string;
  byOutlet: Record<string, OutletCell>;
};

type DesignGroup = {
  design: string;
  stock: number;
  sold: number;
  refill: number;
  lines: number;
  rows: DesignRow[];
};

function splitItemKey(key: string): { carat: string; design: string } {
  const parts = String(key || '').split(' · ');
  if (parts.length >= 2) {
    return { carat: parts[0].trim(), design: parts.slice(1).join(' · ').trim() };
  }
  return { carat: key, design: '(Category / No Style)' };
}

/** DWL / Diamond World LTD = warehouse reserve — never a retail report column */
function isWarehouseBranch(b: string) {
  return isWarehouseBranchCode(b);
}

/**
 * Design-wise Stock Analysis
 * Groups matrix rows by Oracle style code (NP7SD1, NP7SD10…) when present;
 * shows per-outlet Stock / Sold / Move like the Excel matrix so export is easy to read.
 */
export const DesignWiseStockAnalysis: React.FC<DesignWiseStockAnalysisProps> = ({
  report,
  categoryReport,
  designReport,
  allocationMode = 'contribution',
  onSelectWeight,
}) => {
  /** category = main category sheet view; all = every design serial; single = one design */
  const [viewMode, setViewMode] = useState<'category' | 'all' | 'single'>('all');
  /** summary = Move IN/OUT breakdown only; report = full matrix (switchable) */
  const [panelMode, setPanelMode] = useState<'summary' | 'report'>('report');
  const [search, setSearch] = useState('');
  const [selectedDesign, setSelectedDesign] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'sold' | 'stock' | 'refill' | 'turnover'>('sold');
  const [showOutlets, setShowOutlets] = useState(true);
  const reportDimension = getReportDimension(report);
  const dimensionLabel = reportDimension.label;

  const outletColumns = useMemo(() => {
    /**
     * Always show the full locked outlet master list (GUL…SYL) in fixed order —
     * even when an outlet has zero stock/sold in the current upload.
     * Map matrix branch keys → canonical shortcuts so cells still resolve.
     */
    const matrixBranches = report.matrix?.branches || report.branchSummaries.map((b) => b.branch);
    const byShortcut = new Map<string, string>();
    matrixBranches.forEach((b) => {
      if (!b || isWarehouseBranch(b) || isOnlineBranch(b) || isExcludedOutlet(b)) return;
      if (!isLockedRetailOutletCode(b)) return;
      const sc = toLockedOutletShortcut(b);
      // Prefer exact code match as map key for cell lookup
      if (!byShortcut.has(sc)) byShortcut.set(sc, b);
      const up = String(b).toUpperCase().trim();
      if (up === sc) byShortcut.set(sc, b);
    });
    // Column identity = canonical code (GUL, BCT, …); cell lookup uses matrix key when present
    return getLockedRetailOutletsOrdered().map((code) => byShortcut.get(code) || code);
  }, [report.matrix?.branches, report.branchSummaries]);

  /** DWL / warehouse stock kept for distribution — shown as Reserve, not as outlet Move */
  const warehouseReserve = useMemo(() => {
    // Prefer category layer for total reserve (DWL stock files rarely have style codes)
    const sources = [categoryReport, report, designReport].filter(Boolean) as typeof report[];
    let stock = 0;
    for (const src of sources) {
      const cells = src.matrix?.cells || {};
      const branches = src.matrix?.branches || src.branchSummaries.map((b) => b.branch);
      const wh = branches.filter(isWarehouseBranch);
      let local = 0;
      wh.forEach((b) => {
        const byWeight = cells[b] || {};
        Object.values(byWeight).forEach((c: any) => {
          local += Number(c?.stock || 0);
        });
      });
      if (local === 0) {
        (src.branchSummaries || []).forEach((b) => {
          if (b.isWarehouse) local += Number(b.totalCurrentStock || 0);
        });
      }
      if (local > stock) stock = local;
    }
    return stock;
  }, [report, categoryReport, designReport]);

  const warehouseBranches = useMemo(() => {
    // Merge warehouse codes from all layers so design view still finds DWL
    const set = new Set<string>();
    [report, categoryReport, designReport].forEach((src) => {
      if (!src) return;
      const branches = [
        ...(src.matrix?.branches || []),
        ...Object.keys(src.matrix?.cells || {}),
        ...(src.branchSummaries || []).map((b) => b.branch),
      ];
      branches.filter(isWarehouseBranch).forEach((b) => set.add(b));
      // Also pick branches flagged isWarehouse in summaries (even if name not matched)
      (src.branchSummaries || []).forEach((b) => {
        if (b.isWarehouse && b.branch) set.add(b.branch);
      });
    });
    // Hard fallbacks used in Oracle / uploads
    ['DWL', 'WHL', 'Diamond World LTD', 'Diamond World'].forEach((b) => set.add(b));
    return Array.from(set);
  }, [report, categoryReport, designReport]);

  /** Sum stock for a key across every warehouse branch in the given cells map. */
  const sumWhStock = (cells: Record<string, any>, key: string): number => {
    if (!key) return 0;
    let s = 0;
    warehouseBranches.forEach((b) => {
      const cell = cells[b]?.[key];
      if (cell) s += Number(cell.stock || 0);
    });
    // Also scan any branch key that looks like warehouse (in case set missed it)
    Object.keys(cells || {}).forEach((b) => {
      if (warehouseBranches.includes(b)) return;
      if (!isWarehouseBranch(b)) return;
      s += Number(cells[b]?.[key]?.stock || 0);
    });
    return s;
  };

  /** Try itemKey, carat-only, and loose key variants so DWL never goes nil when stock exists. */
  const resolveDwlForKey = (cells: Record<string, any>, itemKey: string, carat?: string): number => {
    const keys: string[] = [];
    if (itemKey) keys.push(itemKey);
    const c = (carat || String(itemKey || '').split(' · ')[0] || '').trim();
    if (c && !keys.includes(c)) keys.push(c);
    // Normalize decimal forms: 0.02 / .02 / 0.020
    if (c) {
      const n = parseFloat(c);
      if (!isNaN(n)) {
        const alt = n.toFixed(2);
        if (!keys.includes(alt)) keys.push(alt);
        const bare = String(n);
        if (!keys.includes(bare)) keys.push(bare);
      }
    }
    for (const k of keys) {
      const s = sumWhStock(cells, k);
      if (s > 0) return s;
    }
    return 0;
  };

  const { groups, hasDesign, flatRows } = useMemo(() => {
    const cells = report.matrix?.cells || {};
    const catCells = categoryReport?.matrix?.cells || {};
    const designCells = designReport?.matrix?.cells || {};
    // Exact design-key DWL only (no carat fallback yet — avoids double-count before split)
    const exactDwl = (itemKey: string): number => {
      let s = resolveDwlForKey(cells, itemKey);
      if (s <= 0 && designReport) s = resolveDwlForKey(designCells, itemKey);
      return s;
    };
    const caratDwlPool = (carat: string): number => {
      let s = resolveDwlForKey(cells, carat, carat);
      // Category-layer report often holds DWL when design matrix key differs
      if (s <= 0 && categoryReport) {
        s = resolveDwlForKey(catCells, carat, carat);
      }
      if (s <= 0 && designReport) {
        s = resolveDwlForKey(designCells, carat, carat);
      }
      return s;
    };

    const rows: DesignRow[] = report.weightSummaries.map((w) => {
      const { carat, design } = splitItemKey(w.weight);
      const byOutlet: Record<string, OutletCell> = {};
      outletColumns.forEach((b) => {
        const c = cells[b]?.[w.weight];
        byOutlet[b] = {
          stock: c?.stock ?? 0,
          sold: c?.sold ?? 0,
          moveIn: c?.moveIn ?? 0,
          moveOut: c?.moveOut ?? 0,
          netMove: c?.netMove ?? 0,
        };
      });
      return {
        design,
        carat,
        itemKey: w.weight,
        stock: w.currentStock,
        sold: w.soldQty,
        refill: w.unmetShortage || 0,
        dwlStock: exactDwl(w.weight),
        moveIn: w.moveInNeeded || 0,
        moveOut: w.moveOutNeeded || 0,
        turnover: w.turnoverRatio || 0,
        velocity: w.velocityCategory || '—',
        byOutlet,
      };
    });

    // Category-layer DWL (no style code) → split across designs that share the same carat
    const byCarat = new Map<string, DesignRow[]>();
    rows.forEach((r) => {
      if (r.design === '(Category / No Style)') return;
      const list = byCarat.get(r.carat) || [];
      list.push(r);
      byCarat.set(r.carat, list);
    });
    byCarat.forEach((list, carat) => {
      const already = list.reduce((s, r) => s + Number(r.dwlStock || 0), 0);
      if (already > 0) return;
      const pool = caratDwlPool(carat);
      if (pool <= 0) return;
      const weights = list.map((r) => Math.max(0, r.stock + r.sold));
      const totalW = weights.reduce((s, x) => s + x, 0);
      if (totalW <= 0) {
        // Equal share when no retail activity
        const each = Math.round(pool / list.length);
        list.forEach((r, i) => {
          r.dwlStock = i === list.length - 1 ? pool - each * (list.length - 1) : each;
        });
      } else {
        let assigned = 0;
        list.forEach((r, i) => {
          if (i === list.length - 1) {
            r.dwlStock = Math.max(0, pool - assigned);
          } else {
            const share = Math.round((pool * weights[i]) / totalW);
            r.dwlStock = share;
            assigned += share;
          }
        });
      }
    });

    const hasDesign = rows.some((r) => r.design !== '(Category / No Style)');
    const map = new Map<string, DesignGroup>();

    rows.forEach((r) => {
      if (!map.has(r.design)) {
        map.set(r.design, {
          design: r.design,
          stock: 0,
          sold: 0,
          refill: 0,
          lines: 0,
          rows: [],
        });
      }
      const g = map.get(r.design)!;
      g.stock += r.stock;
      g.sold += r.sold;
      g.refill += r.refill;
      g.lines += 1;
      g.rows.push(r);
    });

    const groups = Array.from(map.values()).sort((a, b) => b.sold - a.sold);
    return { groups, hasDesign, flatRows: rows };
  }, [report.weightSummaries, report.matrix?.cells, outletColumns, warehouseBranches, categoryReport, designReport]);

  /** Design-layer groups for Excel — always from designReport when style sheets exist */
  const designGroupsForExport = useMemo(() => {
    const src = designReport;
    if (!src?.weightSummaries?.length) return [] as DesignGroup[];
    const cells = src.matrix?.cells || {};
    const branches = Array.from(new Set([
      ...(src.matrix?.branches || []),
      ...Object.keys(src.matrix?.cells || {}),
      ...(src.branchSummaries || []).map((b) => b.branch),
    ]));
    const cols = branches.filter((b) => !isWarehouseBranch(b)).sort(compareOutletsByLockedOrder);
    const catCells = categoryReport?.matrix?.cells || {};
    const exactDwl = (itemKey: string) => resolveDwlForKey(cells, itemKey);
    const caratDwlPool = (carat: string) => {
      let s = resolveDwlForKey(cells, carat, carat);
      if (s <= 0 && categoryReport) s = resolveDwlForKey(catCells, carat, carat);
      return s;
    };
    const pending: DesignRow[] = [];
    const map = new Map<string, DesignGroup>();
    src.weightSummaries.forEach((w) => {
      const { carat, design } = splitItemKey(w.weight);
      if (!design || design === '(Category / No Style)') return;
      const byOutlet: Record<string, OutletCell> = {};
      cols.forEach((b) => {
        const c = cells[b]?.[w.weight];
        byOutlet[b] = {
          stock: c?.stock ?? 0,
          sold: c?.sold ?? 0,
          moveIn: c?.moveIn ?? 0,
          moveOut: c?.moveOut ?? 0,
          netMove: c?.netMove ?? 0,
        };
      });
      if (!map.has(design)) {
        map.set(design, { design, stock: 0, sold: 0, refill: 0, lines: 0, rows: [] });
      }
      const g = map.get(design)!;
      const row: DesignRow = {
        design,
        carat,
        itemKey: w.weight,
        stock: w.currentStock,
        sold: w.soldQty,
        refill: w.unmetShortage || 0,
        dwlStock: exactDwl(w.weight),
        moveIn: w.moveInNeeded || 0,
        moveOut: w.moveOutNeeded || 0,
        turnover: w.turnoverRatio || 0,
        velocity: w.velocityCategory || '—',
        byOutlet,
      };
      g.stock += row.stock;
      g.sold += row.sold;
      g.refill += row.refill;
      g.lines += 1;
      g.rows.push(row);
      pending.push(row);
    });
    // Split category-layer DWL (plain carat on warehouse) across designs sharing that carat
    const byCarat = new Map<string, DesignRow[]>();
    pending.forEach((r) => {
      const list = byCarat.get(r.carat) || [];
      list.push(r);
      byCarat.set(r.carat, list);
    });
    byCarat.forEach((list, carat) => {
      const already = list.reduce((s, r) => s + Number(r.dwlStock || 0), 0);
      if (already > 0) return;
      const pool = caratDwlPool(carat);
      if (pool <= 0) return;
      const weights = list.map((r) => Math.max(0, r.stock + r.sold));
      const totalW = weights.reduce((s, x) => s + x, 0);
      if (totalW <= 0) {
        const each = Math.round(pool / list.length);
        list.forEach((r, i) => {
          r.dwlStock = i === list.length - 1 ? pool - each * (list.length - 1) : each;
        });
      } else {
        let assigned = 0;
        list.forEach((r, i) => {
          if (i === list.length - 1) {
            r.dwlStock = Math.max(0, pool - assigned);
          } else {
            const share = Math.round((pool * weights[i]) / totalW);
            r.dwlStock = share;
            assigned += share;
          }
        });
      }
    });
    return Array.from(map.values()).sort((a, b) =>
      a.design.localeCompare(b.design, undefined, { numeric: true, sensitivity: 'base' }),
    );
  }, [designReport, categoryReport, warehouseBranches]);

  /** Category-layer groups (Main Category view / Excel sheet 1) */
  const categoryGroups = useMemo(() => {
    const src = categoryReport || report;
    const cells = src.matrix?.cells || {};
    const branches = Array.from(new Set([
      ...(src.matrix?.branches || []),
      ...Object.keys(src.matrix?.cells || {}),
      ...(src.branchSummaries || []).map((b) => b.branch),
    ]));
    // Retail outlets only in columns — DWL stock still in row totals via weightSummaries
    // Order = Stock/Sold serial (LOCKED list), not A–Z
    const cols = branches.filter((b) => !isWarehouseBranch(b)).sort(compareOutletsByLockedOrder);
    const dwlFor = (itemKey: string) => resolveDwlForKey(cells, itemKey);
    const rows: DesignRow[] = (src.weightSummaries || []).map((w) => {
      const { carat, design } = splitItemKey(w.weight);
      const byOutlet: Record<string, OutletCell> = {};
      cols.forEach((b) => {
        const c = cells[b]?.[w.weight];
        byOutlet[b] = {
          stock: c?.stock ?? 0,
          sold: c?.sold ?? 0,
          moveIn: c?.moveIn ?? 0,
          moveOut: c?.moveOut ?? 0,
          netMove: c?.netMove ?? 0,
        };
      });
      return {
        design: design || '(Category / No Style)',
        carat,
        itemKey: w.weight,
        stock: w.currentStock,
        sold: w.soldQty,
        refill: w.unmetShortage || 0,
        dwlStock: dwlFor(w.weight),
        moveIn: w.moveInNeeded || 0,
        moveOut: w.moveOutNeeded || 0,
        turnover: w.turnoverRatio || 0,
        velocity: w.velocityCategory || '—',
        byOutlet,
      };
    });
    const map = new Map<string, DesignGroup>();
    rows.forEach((r) => {
      const key = '(Category / No Style)';
      if (!map.has(key)) {
        map.set(key, { design: key, stock: 0, sold: 0, refill: 0, lines: 0, rows: [] });
      }
      const g = map.get(key)!;
      g.rows.push(r);
      g.stock += r.stock;
      g.sold += r.sold;
      g.refill += r.refill;
      g.lines += 1;
    });
    return Array.from(map.values());
  }, [categoryReport, report, warehouseBranches]);

  const filteredGroups = useMemo(() => {
    // View switch: category | all designs serial | single design
    let source = groups;
    if (viewMode === 'category') {
      source = categoryGroups;
    } else if (viewMode === 'single' && selectedDesign !== 'ALL') {
      source = groups.filter((g) => g.design === selectedDesign);
    } else {
      // all — designs first (A–Z), category bucket last if present
      source = [...groups].sort((a, b) => {
        const aCat = a.design === '(Category / No Style)';
        const bCat = b.design === '(Category / No Style)';
        if (aCat !== bCat) return aCat ? 1 : -1;
        return a.design.localeCompare(b.design, undefined, { numeric: true, sensitivity: 'base' });
      });
    }
    const q = search.trim().toLowerCase();
    return source
      .filter((g) => {
        if (viewMode === 'single' && selectedDesign !== 'ALL') return g.design === selectedDesign;
        if (viewMode === 'all' && selectedDesign !== 'ALL' && selectedDesign !== '') return g.design === selectedDesign;
        return true;
      })
      .map((g) => {
        let rows = g.rows;
        if (q) {
          // Exact design match preferred; also allow carat / key contains
          rows = rows.filter((r) => {
            const d = r.design.toLowerCase();
            if (d === q) return true;
            // word-boundary style so NP7SD1 does not match NP7SD10
            const tokenRe = new RegExp(
              `(^|[^a-z0-9])${q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z0-9]|$)`
            );
            return (
              tokenRe.test(d) ||
              r.carat.toLowerCase().includes(q) ||
              r.itemKey.toLowerCase().includes(q)
            );
          });
        }
        rows = [...rows].sort((a, b) => {
          if (sortBy === 'sold') return b.sold - a.sold;
          if (sortBy === 'stock') return b.stock - a.stock;
          if (sortBy === 'refill') return b.refill - a.refill;
          return b.turnover - a.turnover;
        });
        return {
          ...g,
          rows,
          stock: rows.reduce((s, r) => s + r.stock, 0),
          sold: rows.reduce((s, r) => s + r.sold, 0),
          refill: rows.reduce((s, r) => s + r.refill, 0),
          lines: rows.length,
        };
      })
      .filter((g) => g.lines > 0);
  }, [groups, categoryGroups, search, selectedDesign, sortBy, viewMode]);

  const totals = useMemo(() => {
    const base = filteredGroups.reduce(
      (acc, g) => ({
        stock: acc.stock + g.stock,
        sold: acc.sold + g.sold,
        refill: acc.refill + g.refill,
        designs: acc.designs + 1,
        lines: acc.lines + g.lines,
        dwlStock: acc.dwlStock,
      }),
      { stock: 0, sold: 0, refill: 0, designs: 0, lines: 0, dwlStock: 0 },
    );
    let dwlStock = 0;
    const byOutlet: Record<string, { stock: number; sold: number; net: number }> = {};
    outletColumns.forEach((o) => {
      byOutlet[o] = { stock: 0, sold: 0, net: 0 };
    });
    filteredGroups.forEach((g) => {
      g.rows.forEach((r) => {
        dwlStock += Number(r.dwlStock || 0);
        outletColumns.forEach((o) => {
          const c = r.byOutlet[o] || { stock: 0, sold: 0, moveIn: 0, moveOut: 0, netMove: 0 };
          const net = c.netMove !== 0 ? c.netMove : c.moveIn - c.moveOut;
          byOutlet[o].stock += c.stock;
          byOutlet[o].sold += c.sold;
          byOutlet[o].net += net;
        });
      });
    });
    return { ...base, dwlStock, byOutlet };
  }, [filteredGroups, outletColumns]);

  /**
   * Summary breakdown matrix (same shape as full report):
   * - Columns across top = carat (or design · carat when design filtered)
   * - Rows down left = outlets
   * - Cell = only Move IN/OUT net (blank if 0)
   * Follows Style / Design / search filter.
   */
  const moveMatrix = useMemo(() => {
    type Col = { key: string; label: string; carat: string; design: string };
    const colMap = new Map<string, Col>();
    const cellMap = new Map<string, number>(); // `${outlet}__${colKey}` → net

    filteredGroups.forEach((g) => {
      g.rows.forEach((r) => {
        const isCat = !r.design || r.design === '(Category / No Style)';
        const colKey = isCat ? r.carat : `${r.design}||${r.carat}`;
        if (!colMap.has(colKey)) {
          colMap.set(colKey, {
            key: colKey,
            label: isCat ? String(r.carat) : `${r.design} · ${r.carat}`,
            carat: r.carat,
            design: r.design,
          });
        }
        outletColumns.forEach((o) => {
          const c = r.byOutlet[o] || { stock: 0, sold: 0, moveIn: 0, moveOut: 0, netMove: 0 };
          const net = Math.round(c.netMove !== 0 ? c.netMove : c.moveIn - c.moveOut);
          if (net === 0) return;
          const k = `${o}__${colKey}`;
          cellMap.set(k, (cellMap.get(k) || 0) + net);
        });
      });
    });

    // Sort columns by carat numeric, then design
    const columns = Array.from(colMap.values()).sort((a, b) => {
      const na = parseFloat(a.carat);
      const nb = parseFloat(b.carat);
      if (!isNaN(na) && !isNaN(nb) && na !== nb) return na - nb;
      return a.label.localeCompare(b.label, undefined, { numeric: true });
    });

    // Only keep columns that have at least one non-zero move
    const activeCols = columns.filter((col) =>
      outletColumns.some((o) => (cellMap.get(`${o}__${col.key}`) || 0) !== 0),
    );

    const rows = outletColumns
      .map((outlet) => {
        const cells = activeCols.map((col) => cellMap.get(`${outlet}__${col.key}`) || 0);
        const inQty = cells.reduce((s, n) => s + (n > 0 ? n : 0), 0);
        const outQty = cells.reduce((s, n) => s + (n < 0 ? -n : 0), 0);
        return { outlet, cells, inQty, outQty, hasMove: inQty > 0 || outQty > 0 };
      })
      .filter((r) => r.hasMove);

    const totalIn = rows.reduce((s, r) => s + r.inQty, 0);
    const totalOut = rows.reduce((s, r) => s + r.outQty, 0);
    const colTotals = activeCols.map((_, i) =>
      rows.reduce((s, r) => s + r.cells[i], 0),
    );

    return {
      columns: activeCols,
      rows,
      totalIn,
      totalOut,
      colTotals,
      outletCount: rows.length,
    };
  }, [filteredGroups, outletColumns]);

  /**
   * Full report matrix (transposed like Excel print layout):
   * LEFT = Branch/Outlet rows | TOP = Design · Carat/Cent columns (Stock|Sold|Move)
   */
  const reportMatrix = useMemo(() => {
    type Col = {
      key: string;
      label: string;
      carat: string;
      design: string;
      itemKey: string;
      dwlStock: number;
      stock: number;
      sold: number;
      refill: number;
    };
    // Always include design name in column header when style is present
    // (single-design filter must still show e.g. "NP12SD1 · 0.07", not only "0.07")
    const colMap = new Map<string, Col>();
    const cellMap = new Map<
      string,
      { stock: number; sold: number; net: number }
    >();

    filteredGroups.forEach((g) => {
      g.rows.forEach((r) => {
        const key = r.itemKey || `${g.design}||${r.carat}`;
        if (!colMap.has(key)) {
          const isCat = !g.design || g.design === '(Category / No Style)';
          const label = isCat ? String(r.carat) : `${g.design} · ${r.carat}`;
          colMap.set(key, {
            key,
            label,
            carat: r.carat,
            design: g.design,
            itemKey: r.itemKey,
            dwlStock: Number(r.dwlStock || 0),
            stock: r.stock,
            sold: r.sold,
            refill: r.refill,
          });
        }
        outletColumns.forEach((o) => {
          const c = r.byOutlet[o] || { stock: 0, sold: 0, moveIn: 0, moveOut: 0, netMove: 0 };
          const net = c.netMove !== 0 ? c.netMove : c.moveIn - c.moveOut;
          cellMap.set(`${o}__${key}`, { stock: c.stock, sold: c.sold, net });
        });
      });
    });

    // Safety net: re-resolve DWL from live matrix cells (upload keys are plain carat on DWL branch)
    const allColumns = Array.from(colMap.values());
    allColumns.forEach((col) => {
      if (col.dwlStock > 0) return;
      const fromCells =
        resolveDwlForKey(report.matrix?.cells || {}, col.itemKey || col.carat, col.carat) ||
        resolveDwlForKey(categoryReport?.matrix?.cells || {}, col.itemKey || col.carat, col.carat) ||
        resolveDwlForKey(designReport?.matrix?.cells || {}, col.itemKey || col.carat, col.carat);
      if (fromCells > 0) col.dwlStock = fromCells;
    });

    allColumns.sort((a, b) => {
      const na = parseFloat(a.carat);
      const nb = parseFloat(b.carat);
      if (!isNaN(na) && !isNaN(nb) && na !== nb) return na - nb;
      return a.label.localeCompare(b.label, undefined, { numeric: true });
    });

    // Drop zero-activity carats — keeps matrix printable (stock/sold/move all 0)
    const columns = allColumns.filter((col) => {
      if (col.stock > 0 || col.sold > 0 || col.dwlStock > 0 || col.refill > 0) return true;
      return outletColumns.some((o) => {
        const c = cellMap.get(`${o}__${col.key}`);
        return !!c && (c.stock > 0 || c.sold > 0 || c.net !== 0);
      });
    });

    const rows = outletColumns
      .map((outlet) => {
        let tStock = 0;
        let tSold = 0;
        let tIn = 0;
        let tOut = 0;
        const cells = columns.map((col) => {
          const c = cellMap.get(`${outlet}__${col.key}`) || { stock: 0, sold: 0, net: 0 };
          tStock += c.stock;
          tSold += c.sold;
          if (c.net > 0) tIn += c.net;
          if (c.net < 0) tOut += -c.net;
          return c;
        });
        return {
          outlet,
          cells,
          tStock,
          tSold,
          tIn,
          tOut,
          tRefill: tIn,
          isWarehouse: false as boolean,
        };
      })
      .filter((r) => r.tStock > 0 || r.tSold > 0 || r.tIn > 0 || r.tOut > 0);

    // DWL warehouse row — shows per-carat stock from upload (classic Excel has DWL as a branch)
    const dwlCells = columns.map((col) => ({
      stock: Number(col.dwlStock || 0),
      sold: 0,
      net: 0,
    }));
    const dwlRowStock = dwlCells.reduce((s, c) => s + c.stock, 0);
    if (dwlRowStock > 0 || warehouseReserve > 0) {
      rows.unshift({
        outlet: 'DWL',
        cells: dwlCells.map((c) =>
          c.stock > 0 ? c : { stock: 0, sold: 0, net: 0 },
        ),
        // If per-carat sum is 0 but card has reserve, still show a row with total on lead
        tStock: dwlRowStock > 0 ? dwlRowStock : warehouseReserve,
        tSold: 0,
        tIn: 0,
        tOut: 0,
        tRefill: 0,
        isWarehouse: true,
      });
      // If we only had warehouseReserve, put it on first carat cell so something is visible
      if (dwlRowStock <= 0 && warehouseReserve > 0 && rows[0].cells.length > 0) {
        rows[0].cells[0] = { stock: warehouseReserve, sold: 0, net: 0 };
      }
    }

    const colTotals = columns.map((col, i) => {
      let stock = 0;
      let sold = 0;
      let net = 0;
      rows.forEach((r) => {
        if (r.isWarehouse) return; // don't double-count DWL into retail totals
        stock += r.cells[i].stock;
        sold += r.cells[i].sold;
        net += r.cells[i].net;
      });
      return { stock, sold, net, dwl: col.dwlStock, refill: col.refill };
    });

    // grandStock / grandSold = pure retail (exclude DWL warehouse row)
    const retailRows = rows.filter((r) => !r.isWarehouse);
    const grandStock = retailRows.reduce((s, r) => s + r.tStock, 0);
    const grandSold = retailRows.reduce((s, r) => s + r.tSold, 0);
    const grandDwl = columns.reduce((s, c) => s + Number(c.dwlStock || 0), 0) || warehouseReserve;

    return {
      columns,
      rows,
      colTotals,
      grandStock,
      grandSold,
      grandRefill: columns.reduce((s, c) => s + c.refill, 0),
      grandDwl,
      droppedZeroCols: allColumns.length - columns.length,
    };
  }, [filteredGroups, outletColumns, report, categoryReport, designReport, warehouseReserve]);

  /**
   * Print-ready Excel — single sheet:
   * - Prefer design-wise columns when designReport has style data
   * - One worksheet only; print page breaks only AFTER complete Stock|Sold|Move groups
   * - Lead cols (Branch / totals) freeze + repeat on every printed page
   */
  const handleExportPrintable = async () => {
    try {
      const useDesign = designGroupsForExport.length > 0;
      const sourceGroups: DesignGroup[] = useDesign
        ? designGroupsForExport
        : viewMode === 'category'
          ? categoryGroups
          : groups.filter((g) => g.design !== '(Category / No Style)').length
            ? groups.filter((g) => g.design !== '(Category / No Style)')
            : groups;

      type PCol = {
        key: string;
        label: string;
        carat: string;
        design: string;
        dwlStock: number;
        stock: number;
        sold: number;
        refill: number;
      };
      const colMap = new Map<string, PCol>();
      const cellMap = new Map<string, { stock: number; sold: number; net: number }>();

      sourceGroups.forEach((g) => {
        g.rows.forEach((r) => {
          const key = r.itemKey || `${g.design}||${r.carat}`;
          if (!colMap.has(key)) {
            const isCat = !g.design || g.design === '(Category / No Style)';
            const label = isCat ? String(r.carat) : `${g.design} · ${r.carat}`;
            colMap.set(key, {
              key,
              label,
              carat: r.carat,
              design: g.design,
              dwlStock: Number(r.dwlStock || 0),
              stock: r.stock,
              sold: r.sold,
              refill: r.refill,
            });
          }
          outletColumns.forEach((o) => {
            const c = r.byOutlet[o] || { stock: 0, sold: 0, moveIn: 0, moveOut: 0, netMove: 0 };
            const net = c.netMove !== 0 ? c.netMove : c.moveIn - c.moveOut;
            cellMap.set(`${o}__${key}`, { stock: c.stock, sold: c.sold, net });
          });
        });
      });

      const allColumns = Array.from(colMap.values()).sort((a, b) => {
        const d = a.design.localeCompare(b.design, undefined, { numeric: true, sensitivity: 'base' });
        if (d !== 0) {
          const aCat = a.design === '(Category / No Style)';
          const bCat = b.design === '(Category / No Style)';
          if (aCat !== bCat) return aCat ? 1 : -1;
          return d;
        }
        const na = parseFloat(a.carat);
        const nb = parseFloat(b.carat);
        if (!isNaN(na) && !isNaN(nb) && na !== nb) return na - nb;
        return a.label.localeCompare(b.label, undefined, { numeric: true });
      });

      const columns = allColumns.filter((col) => {
        if (col.stock > 0 || col.sold > 0 || col.dwlStock > 0 || col.refill > 0) return true;
        return outletColumns.some((o) => {
          const c = cellMap.get(`${o}__${col.key}`);
          return !!c && (c.stock > 0 || c.sold > 0 || c.net !== 0);
        });
      });

      if (!columns.length || !outletColumns.length) {
        window.alert('No printable rows — all carats have zero stock/sold.');
        return;
      }

      const period = report.period || designReport?.period || categoryReport?.period;
      const modeKey = String(allocationMode);
      const modeLbl = distributionModeLabel(modeKey);
      const modeHint = distributionModeExplanation(modeKey);

      const LEAD = 5; // Branch | Total Stock | DWL | Total Sold | Refill
      const GROUP_SPAN = 3; // Stock | Sold | Move
      // ~5 complete groups per landscape page; break only after Move column
      const GROUPS_PER_PAGE = 5;

      const body = outletColumns.map((outlet) => {
        let tStock = 0;
        let tSold = 0;
        let tIn = 0;
        const cells = columns.map((col) => {
          const c = cellMap.get(`${outlet}__${col.key}`) || { stock: 0, sold: 0, net: 0 };
          tStock += c.stock;
          tSold += c.sold;
          if (c.net > 0) tIn += c.net;
          return c;
        });
        return { outlet, cells, tStock, tSold, tRefill: tIn };
      });
      // Keep all locked outlets (universal coverage) — zeros still print

      const header1: (string | number)[] = [
        'Branch / Outlet',
        'Total Stock',
        'DWL',
        'Total Sold',
        'Refill',
      ];
      columns.forEach((c) => {
        header1.push(c.label, '', '');
      });
      const header2: (string | number)[] = ['', '', '', '', ''];
      columns.forEach(() => {
        header2.push('Stock', 'Sold', 'Move');
      });

      const headerMerges: [number, number, number, number][] = [];
      for (let c = 1; c <= LEAD; c++) headerMerges.push([1, c, 2, c]);
      const itemGroups: { startCol: number; span: number }[] = [];
      columns.forEach((_, i) => {
        const start = LEAD + i * GROUP_SPAN + 1;
        headerMerges.push([1, start, 1, start + 2]);
        itemGroups.push({ startCol: start, span: GROUP_SPAN });
      });
      const movementCols = columns.map((_, i) => LEAD + i * GROUP_SPAN + 3);

      // Column page-break AFTER every GROUPS_PER_PAGE complete groups (after Move)
      const colPageBreaks: number[] = [];
      for (let g = GROUPS_PER_PAGE; g < columns.length; g += GROUPS_PER_PAGE) {
        colPageBreaks.push(LEAD + g * GROUP_SPAN); // last col of last group on previous page
      }

      const totalDwl = columns.reduce((s, c) => s + Number(c.dwlStock || 0), 0);
      const rows: (string | number)[][] = body.map((row) => [
        toLockedOutletShortcut(row.outlet),
        Math.round(row.tStock),
        '', // DWL once at front — blank on outlet rows
        Math.round(row.tSold),
        row.tRefill > 0 ? Math.round(row.tRefill) : '',
        ...row.cells.flatMap((c) => [
          c.stock || '',
          c.sold || '',
          c.net !== 0 ? c.net : '',
        ]),
      ]);

      // DWL warehouse row (same as on-screen matrix)
      if (totalDwl > 0) {
        rows.unshift([
          'DWL',
          Math.round(totalDwl),
          Math.round(totalDwl),
          '',
          '',
          ...columns.flatMap((col) => {
            const d = Math.round(Number(col.dwlStock || 0));
            return [d > 0 ? d : '', '', ''];
          }),
        ]);
      }

      const colTotals = columns.map((col) => {
        let stock = 0;
        let sold = 0;
        let net = 0;
        body.forEach((r) => {
          const c = cellMap.get(`${r.outlet}__${col.key}`) || { stock: 0, sold: 0, net: 0 };
          stock += c.stock;
          sold += c.sold;
          net += c.net;
        });
        return { stock, sold, net, refill: col.refill, dwl: col.dwlStock };
      });
      rows.push([
        'TOTAL',
        Math.round(colTotals.reduce((s, t) => s + t.stock, 0)),
        totalDwl > 0 ? Math.round(totalDwl) : '',
        Math.round(colTotals.reduce((s, t) => s + t.sold, 0)),
        Math.round(colTotals.reduce((s, t) => s + t.refill, 0)) || '',
        ...colTotals.flatMap((t) => [
          Math.round(t.stock) || '',
          Math.round(t.sold) || '',
          t.net !== 0 ? Math.round(t.net) : '',
        ]),
      ]);

      const designHint = useDesign ? 'Design-wise' : 'Category';
      const catTitle = getReportCategoryLabel(report);
      await exportStyledRowsExcel(
        [
          {
            name: 'Excel Printable',
            title: catTitle
              ? `${catTitle} — Excel Printable · ${designHint}`
              : `Excel Printable — ${designHint} · Active Stock`,
            period,
            categoryName: catTitle,
            modeLabel: `${modeLbl} — ${modeHint}`,
            theme: 'emerald',
            headerRows: [header1, header2],
            headerMerges,
            rows,
            movementCols,
            refillCols: [4],
            branchGroups: itemGroups,
            freezeCols: LEAD,
            colPageBreaks,
            columnWidths: [
              16,
              9,
              8,
              9,
              7,
              ...columns.flatMap(() => [7, 6, 6]),
            ],
          },
        ],
        'Excel_Printable.xlsx',
      );
    } catch (error) {
      console.error('Printable export failed:', error);
      window.alert(
        `Excel Printable failed: ${error instanceof Error ? error.message : 'Please try again.'}`,
      );
    }
  };

  const handleExport = async () => {
    try {
      const period = report.period || designReport?.period || categoryReport?.period;
      const modeKey = String(allocationMode);
      const modeLbl = distributionModeLabel(modeKey);
      const modeHint = distributionModeExplanation(modeKey);

      // Summary breakdown → only Move IN/OUT matrix Excel (not full stock report)
      if (panelMode === 'summary') {
        if (!moveMatrix.rows.length || !moveMatrix.columns.length) {
          window.alert('No Move IN / OUT for current filter — nothing to export.');
          return;
        }
        const header = [
          'Outlet',
          ...moveMatrix.columns.map((c) => c.label),
          'Move IN total',
          'Move OUT total',
        ];
        const body = moveMatrix.rows.map((row) => [
          row.outlet,
          ...row.cells.map((n) => (n === 0 ? '' : n)),
          row.inQty > 0 ? row.inQty : '',
          row.outQty > 0 ? -row.outQty : '',
        ]);
        const totalRow = [
          'TOTAL',
          ...moveMatrix.colTotals.map((n) => (n === 0 ? '' : n)),
          moveMatrix.totalIn > 0 ? moveMatrix.totalIn : '',
          moveMatrix.totalOut > 0 ? -moveMatrix.totalOut : '',
        ];
        // movementCols = all carat columns + IN/OUT (1-based; col1=Outlet)
        const movementCols = [
          ...moveMatrix.columns.map((_, i) => i + 2),
          moveMatrix.columns.length + 2,
          moveMatrix.columns.length + 3,
        ];
        await exportStyledRowsExcel(
          [
            {
              name: 'Move Summary',
              title: 'Summary breakdown — Move IN / OUT',
              period,
              categoryName: getReportCategoryLabel(report),
              modeLabel: `${modeLbl} — ${modeHint}`,
              theme: 'emerald',
              headerRows: [header],
              rows: [...body, totalRow],
              movementCols,
              freezeCols: 1,
              columnWidths: [22, ...moveMatrix.columns.map(() => 12), 12, 12],
            },
          ],
          'summary_move_in_out.xlsx',
        );
        return;
      }

      // Full report → respect current design filter (screen + Excel stay in sync)
      const isDesignFiltered =
        (viewMode === 'single' && selectedDesign !== 'ALL') ||
        (viewMode === 'all' && selectedDesign !== 'ALL' && selectedDesign !== '');
      const fromScreen = filteredGroups.filter((g) => g.design !== '(Category / No Style)');
      // When a single design is filtered, export only that; otherwise full design set
      let designGs: DesignGroup[];
      if (isDesignFiltered && fromScreen.length > 0) {
        designGs = fromScreen;
      } else if (designGroupsForExport.length > 0) {
        designGs = designGroupsForExport;
      } else {
        designGs = groups
          .filter((g) => g.design !== '(Category / No Style)')
          .slice()
          .sort((a, b) =>
            a.design.localeCompare(b.design, undefined, { numeric: true, sensitivity: 'base' }),
          );
      }
      const toExport = (gs: DesignGroup[]) =>
        gs.map((g) => ({
          design: g.design,
          rows: g.rows.map((r) => ({
            carat: r.carat,
            stock: r.stock,
            sold: r.sold,
            refill: r.refill,
            byOutlet: r.byOutlet,
            dwlStock: r.dwlStock,
          })),
        }));
      // Category sheet only when not locked to a single design
      const catForExport = isDesignFiltered ? [] : categoryGroups;
      await exportDesignWiseStockExcel(
        toExport(designGs.length ? designGs : filteredGroups),
        outletColumns,
        period,
        dimensionLabel,
        toExport(catForExport),
        modeKey,
        getReportCategoryLabel(report),
      );
    } catch (error) {
      console.error('Design-wise export failed:', error);
      window.alert(
        `Excel export failed: ${error instanceof Error ? error.message : 'Please try again.'}`
      );
    }
  };

  const periodLabel = report.period || '—';
  const modeLabel = distributionModeLabel(String(allocationMode));
  const modeHint = distributionModeExplanation(String(allocationMode));

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="bg-white border border-[#d0d7de] px-3 py-2.5 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-bold text-[#0f2744] flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#0B6FB8]" />
            Design-wise Stock Analysis
          </h2>
          <p className="text-[11px] text-[#6a6d70] mt-0.5">
            {hasDesign || designGroupsForExport.length > 0
              ? 'Style sheets detected — Excel: Main Category + Design-wise sheets · screen follows filter'
              : 'Category-level data — upload Oracle style sheets for design breakdown'}
            {' · '}
            Period: <strong className="text-[#32363a]">{periodLabel}</strong>
          </p>
          <div className="mt-1.5 inline-flex flex-wrap items-center gap-x-2 gap-y-0.5 rounded-md border border-amber-300 bg-amber-50 px-2.5 py-1">
            <span className="text-[10px] font-bold uppercase tracking-wide text-amber-800">Distribution mode</span>
            <span className="text-[13px] font-black text-[#0B2545]">{modeLabel}</span>
            <span className="text-[11px] text-[#475569]">— {modeHint}</span>
          </div>
          <p className="text-[11px] text-[#64748b] mt-1">
            <strong className="text-[#0B2545]">DWL / Diamond World LTD</strong> is warehouse reserve
            ({warehouseReserve} pcs) — shown <strong>once at the front</strong> (classic layout), not under every carat. Outlet <strong>Total Stock</strong> / <strong>Stk</strong> are retail only; DWL value appears on the TOTAL row.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Switch: Summary breakdown ↔ Full report — 3D buttons */}
          <div className="flex h-9 overflow-hidden rounded-md">
            <button
              type="button"
              onClick={() => setPanelMode('summary')}
              className={`px-3.5 text-[12px] font-extrabold tracking-wide transition-all active:translate-y-[2px] active:shadow-none ${
                panelMode === 'summary'
                  ? 'bg-gradient-to-b from-[#1a8fd4] to-[#0B6FB8] text-white border border-[#0a5a96] shadow-[0_3px_0_#084a7a,0_4px_8px_rgba(11,111,184,0.35)]'
                  : 'bg-gradient-to-b from-white to-[#e8eef3] text-[#0f2744] border border-[#89919a] shadow-[0_3px_0_#c5ced6,0_4px_6px_rgba(0,0,0,0.08)] hover:from-[#f8fafc]'
              }`}
            >
              Summary breakdown
            </button>
            <button
              type="button"
              onClick={() => setPanelMode('report')}
              className={`px-3.5 text-[12px] font-extrabold tracking-wide border-l-0 transition-all active:translate-y-[2px] active:shadow-none ${
                panelMode === 'report'
                  ? 'bg-gradient-to-b from-[#1a8fd4] to-[#0B6FB8] text-white border border-[#0a5a96] shadow-[0_3px_0_#084a7a,0_4px_8px_rgba(11,111,184,0.35)]'
                  : 'bg-gradient-to-b from-white to-[#e8eef3] text-[#0f2744] border border-[#89919a] shadow-[0_3px_0_#c5ced6,0_4px_6px_rgba(0,0,0,0.08)] hover:from-[#f8fafc]'
              }`}
            >
              Full report
            </button>
          </div>
          {panelMode === 'report' && (
            <label className="inline-flex items-center gap-1.5 text-[12px] font-bold text-[#0f2744] cursor-pointer select-none">
              <input
                type="checkbox"
                checked={showOutlets}
                onChange={(e) => setShowOutlets(e.target.checked)}
                className="rounded border-[#89919a]"
              />
              Show outlets
            </label>
          )}
          <button
            type="button"
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 h-9 px-4 text-[12px] font-extrabold tracking-wide text-white rounded-md border border-[#0a5a96] bg-gradient-to-b from-[#1a8fd4] to-[#0B6FB8] shadow-[0_3px_0_#084a7a,0_4px_10px_rgba(11,111,184,0.4)] hover:from-[#2a9fe0] hover:to-[#0B8BD6] active:translate-y-[2px] active:shadow-[0_1px_0_#084a7a] transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            {panelMode === 'summary' ? 'Export Move Summary' : 'Export Full Report'}
          </button>
          <button
            type="button"
            onClick={handleExportPrintable}
            className="inline-flex items-center gap-1.5 h-9 px-4 text-[12px] font-extrabold tracking-wide text-white rounded-md border border-[#047857] bg-gradient-to-b from-[#34d399] to-[#059669] shadow-[0_3px_0_#047857,0_4px_10px_rgba(5,150,105,0.35)] hover:from-[#6ee7b7] hover:to-[#10b981] active:translate-y-[2px] active:shadow-[0_1px_0_#047857] transition-all"
            title="Landscape print-ready matrix — Stock / Sold / Move through each page"
          >
            <Download className="w-3.5 h-3.5" />
            Excel Printable
          </button>
        </div>
      </div>

      {/* KPI strip — points on top (both modes) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
        {[
          { label: 'Designs', value: totals.designs, icon: Layers, color: 'text-[#0B6FB8]' },
          { label: `${dimensionLabel} lines`, value: totals.lines, icon: Gem, color: 'text-amber-700' },
          { label: 'Total Stock', value: totals.stock, icon: Package, color: 'text-emerald-700' },
          { label: 'DWL Reserve', value: warehouseReserve, icon: Package, color: 'text-[#0B6FB8]' },
          { label: 'Total Sold', value: totals.sold, icon: TrendingUp, color: 'text-blue-700' },
          { label: 'Refill Need', value: totals.refill, icon: AlertTriangle, color: 'text-red-700' },
          { label: 'Move IN', value: moveMatrix.totalIn, icon: TrendingUp, color: 'text-emerald-700' },
          { label: 'Move OUT', value: moveMatrix.totalOut, icon: AlertTriangle, color: 'text-rose-700' },
        ].map((k) => (
          <div key={k.label} className="bg-white border border-[#d0d7de] px-3 py-2">
            <div className="text-[10px] font-semibold text-[#6a6d70] uppercase tracking-wide flex items-center gap-1">
              <k.icon className={`w-3 h-3 ${k.color}`} />
              {k.label}
            </div>
            <div className="text-lg font-bold text-[#29445F] font-mono tabular-nums">
              {k.value.toLocaleString()}
            </div>
          </div>
        ))}
      </div>

      {/* ===== SUMMARY BREAKDOWN — same matrix shape as full report =====
          Top: carat (cent) columns | Left: outlets | Cell: Move IN/OUT only
          Filter → design columns; Excel still exports Main Category + Design-wise */}
      {panelMode === 'summary' && (
      <div className="bg-white border border-[#d0d7de] overflow-hidden">
        <div className="px-3 py-2 bg-[#f6f8fa] border-b border-[#d0d7de] flex flex-wrap items-center justify-between gap-2">
          <div className="text-[12px] font-bold text-[#0f2744]">
            Summary breakdown — Move IN / OUT
            <span className="ml-2 text-[11px] font-medium text-[#6a6d70]">
              {dimensionLabel} across top · Outlet left · only move cells · filter = design
            </span>
          </div>
          <div className="text-[11px] font-semibold text-[#32363a]">
            <span className="text-emerald-700">IN +{moveMatrix.totalIn.toLocaleString()}</span>
            <span className="mx-1.5 text-[#94a3b8]">·</span>
            <span className="text-rose-700">OUT −{moveMatrix.totalOut.toLocaleString()}</span>
            <span className="mx-1.5 text-[#94a3b8]">·</span>
            <span>{moveMatrix.outletCount} outlet{moveMatrix.outletCount === 1 ? '' : 's'}</span>
          </div>
        </div>
        {moveMatrix.rows.length === 0 || moveMatrix.columns.length === 0 ? (
          <div className="px-3 py-6 text-center text-[12px] text-[#6a6d70]">
            No Move IN / OUT for current filter — balanced or no data.
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[420px]">
            <table
              className="text-[11px] border-collapse"
              style={{ tableLayout: 'fixed', width: 'max-content', minWidth: '100%' }}
            >
              <colgroup>
                <col style={{ width: 72 }} />
                {moveMatrix.columns.map((col) => (
                  <col key={`mcg-${col.key}`} style={{ width: 52 }} />
                ))}
                <col style={{ width: 44 }} />
                <col style={{ width: 44 }} />
              </colgroup>
              <thead className="sticky top-0 z-10">
                <tr className="bg-[#edf0f4]">
                  <th className="border border-[#d0d7de] px-1.5 py-1 text-left font-extrabold text-[#0f2744] sticky left-0 bg-[#edf0f4] z-20 tracking-wide">
                    Branch
                  </th>
                  {moveMatrix.columns.map((col) => {
                    const hasDesign = col.design && col.design !== '(Category / No Style)';
                    return (
                      <th
                        key={col.key}
                        className="border border-[#d0d7de] px-0.5 py-1 text-center font-extrabold text-[#0f2744] bg-[#e8f0fe] align-bottom"
                        title={col.label}
                      >
                        <div className="leading-tight break-words whitespace-normal px-0.5">
                          {hasDesign && (
                            <div className="text-[8px] font-extrabold text-[#0B6FB8] break-all leading-tight">
                              {col.design}
                            </div>
                          )}
                          <div className="text-[10px] font-extrabold text-[#0f2744]">{col.carat}</div>
                        </div>
                      </th>
                    );
                  })}
                  <th className="border border-[#d0d7de] px-1 py-1 text-right font-extrabold text-emerald-900 bg-emerald-50 whitespace-nowrap">
                    IN
                  </th>
                  <th className="border border-[#d0d7de] px-1 py-1 text-right font-extrabold text-rose-900 bg-rose-50 whitespace-nowrap">
                    OUT
                  </th>
                </tr>
              </thead>
              <tbody>
                {moveMatrix.rows.map((row) => (
                  <tr key={row.outlet} className="hover:bg-[#f8fafc]">
                    <td className="border border-[#e6e8eb] px-2 py-1 font-extrabold text-[#0f2744] sticky left-0 bg-white z-10 whitespace-nowrap">
                      {toLockedOutletShortcut(row.outlet)}
                    </td>
                    {row.cells.map((net, i) => (
                      <td
                        key={`${row.outlet}-${moveMatrix.columns[i].key}`}
                        className={`border border-[#e6e8eb] px-1 py-1 text-center font-mono tabular-nums font-semibold ${
                          net > 0
                            ? 'bg-emerald-50 text-emerald-800'
                            : net < 0
                              ? 'bg-rose-50 text-rose-700'
                              : 'text-slate-300'
                        }`}
                      >
                        {net > 0 ? `+${net}` : net < 0 ? `${net}` : '—'}
                      </td>
                    ))}
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono font-bold text-emerald-700 bg-emerald-50/50">
                      {row.inQty > 0 ? `+${row.inQty}` : '—'}
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono font-bold text-rose-700 bg-rose-50/50">
                      {row.outQty > 0 ? `−${row.outQty}` : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-[#e8eef5] text-[#0f2744] font-extrabold border-t-2 border-[#0B6FB8]">
                  <td className="border border-[#c5d0dc] px-2 py-1.5 sticky left-0 bg-[#e8eef5] z-20">
                    TOTAL
                  </td>
                  {moveMatrix.colTotals.map((n, i) => (
                    <td
                      key={`ct-${moveMatrix.columns[i].key}`}
                      className={`border border-[#c5d0dc] px-1 py-1.5 text-center font-mono ${
                        n > 0 ? 'bg-emerald-50 text-emerald-800' : n < 0 ? 'bg-rose-50 text-rose-700' : 'text-[#64748b]'
                      }`}
                    >
                      {n > 0 ? `+${n}` : n < 0 ? `${n}` : '—'}
                    </td>
                  ))}
                  <td className="border border-[#c5d0dc] px-2 py-1.5 text-right font-mono text-emerald-800 bg-emerald-50">
                    +{moveMatrix.totalIn}
                  </td>
                  <td className="border border-[#c5d0dc] px-2 py-1.5 text-right font-mono text-rose-700 bg-rose-50">
                    −{moveMatrix.totalOut}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
      )}

      {/* ===== FULL REPORT (switch) ===== */}
      {panelMode === 'report' && (
      <>
      {/* Toolbar */}
      <div className="bg-[#edf0f4] border border-[#d9d9d9] px-3 py-2 flex flex-wrap items-end gap-2">
        <div className="min-w-[140px]">
          <label className="block text-[10px] font-bold text-[#6a6d70] mb-0.5 uppercase tracking-wide">Report view</label>
          <div className="flex h-9 overflow-hidden rounded-md">
            <button
              type="button"
              onClick={() => { setViewMode('category'); setSelectedDesign('ALL'); }}
              className={`px-2.5 text-[11px] font-extrabold transition-all active:translate-y-[2px] active:shadow-none ${
                viewMode === 'category'
                  ? 'bg-gradient-to-b from-[#1a8fd4] to-[#0B6FB8] text-white border border-[#0a5a96] shadow-[0_3px_0_#084a7a]'
                  : 'bg-gradient-to-b from-white to-[#e8eef3] text-[#0f2744] border border-[#89919a] shadow-[0_3px_0_#c5ced6]'
              }`}
            >
              Main Category
            </button>
            <button
              type="button"
              onClick={() => { setViewMode('all'); setSelectedDesign('ALL'); }}
              className={`px-2.5 text-[11px] font-extrabold border-l-0 transition-all active:translate-y-[2px] active:shadow-none ${
                viewMode === 'all'
                  ? 'bg-gradient-to-b from-[#1a8fd4] to-[#0B6FB8] text-white border border-[#0a5a96] shadow-[0_3px_0_#084a7a]'
                  : 'bg-gradient-to-b from-white to-[#e8eef3] text-[#0f2744] border border-[#89919a] shadow-[0_3px_0_#c5ced6]'
              }`}
            >
              All Designs
            </button>
            <button
              type="button"
              onClick={() => setViewMode('single')}
              className={`px-2.5 text-[11px] font-extrabold border-l-0 transition-all active:translate-y-[2px] active:shadow-none ${
                viewMode === 'single'
                  ? 'bg-gradient-to-b from-[#1a8fd4] to-[#0B6FB8] text-white border border-[#0a5a96] shadow-[0_3px_0_#084a7a]'
                  : 'bg-gradient-to-b from-white to-[#e8eef3] text-[#0f2744] border border-[#89919a] shadow-[0_3px_0_#c5ced6]'
              }`}
            >
              Single Design
            </button>
          </div>
        </div>
        <div className="min-w-[140px]">
          <label className="block text-[10px] text-[#6a6d70] mb-0.5">Design / Style</label>
          <select
            value={selectedDesign}
            onChange={(e) => {
              setSelectedDesign(e.target.value);
              if (e.target.value !== 'ALL') setViewMode('single');
              else if (viewMode === 'single') setViewMode('all');
            }}
            className="h-8 border border-[#89919a] bg-white px-2 text-[12px] min-w-[140px]"
            disabled={viewMode === 'category'}
          >
            <option value="ALL">All designs</option>
            {groups.filter((g) => g.design !== '(Category / No Style)').map((g) => (
              <option key={g.design} value={g.design}>
                {g.design} ({g.lines})
              </option>
            ))}
          </select>
        </div>
        <div className="min-w-[100px]">
          <label className="block text-[10px] text-[#6a6d70] mb-0.5">Sort by</label>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="h-8 border border-[#89919a] bg-white px-2 text-[12px]"
          >
            <option value="sold">Sold</option>
            <option value="stock">Stock</option>
            <option value="refill">Refill</option>
            <option value="turnover">Sell-through</option>
          </select>
        </div>
        <div className="flex-1 min-w-[160px]">
          <label className="block text-[10px] text-[#6a6d70] mb-0.5">Search (exact design preferred)</label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-[#89919a]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="NP7SD1, 0.05…"
              className="w-full h-8 border border-[#89919a] bg-white pl-7 pr-2 text-[12px]"
            />
          </div>
        </div>
      </div>

      {/* Design summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {filteredGroups.map((g) => {
          const sellThrough = g.stock + g.sold > 0 ? (g.sold / (g.stock + g.sold)) * 100 : 0;
          return (
            <button
              key={g.design}
              type="button"
              onClick={() => setSelectedDesign(selectedDesign === g.design ? 'ALL' : g.design)}
              className={`text-left bg-white border px-3 py-2.5 hover:border-[#0B6FB8] transition-colors ${
                selectedDesign === g.design ? 'border-[#0B6FB8] ring-1 ring-[#0B6FB8]/30' : 'border-[#d0d7de]'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-[13px] font-bold text-[#0f2744] font-mono truncate">{g.design}</span>
                <ChevronRight className="w-3.5 h-3.5 text-[#89919a] shrink-0" />
              </div>
              <div className="mt-1.5 grid grid-cols-3 gap-1 text-[11px]">
                <div>
                  <div className="text-[#6a6d70]">Stock</div>
                  <div className="font-bold font-mono">{g.stock.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-[#6a6d70]">Sold</div>
                  <div className="font-bold font-mono text-blue-700">{g.sold.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-[#6a6d70]">Refill</div>
                  <div className={`font-bold font-mono ${g.refill > 0 ? 'text-red-600' : 'text-emerald-700'}`}>
                    {g.refill.toLocaleString()}
                  </div>
                </div>
              </div>
              <div className="mt-1.5 h-1.5 bg-[#e8e8e8] overflow-hidden">
                <div
                  className="h-full bg-[#0B6FB8]"
                  style={{ width: `${Math.min(100, sellThrough)}%` }}
                />
              </div>
              <div className="text-[10px] text-[#6a6d70] mt-0.5">
                {g.lines} carat lines · sell-through {sellThrough.toFixed(0)}%
              </div>
            </button>
          );
        })}
      </div>

      {/* Detail grid — Branch left, Design/Carat on top (print layout) */}
      <div className="bg-white border border-[#d0d7de] overflow-hidden">
        <div className="px-3 py-1.5 bg-[#f6f8fa] border-b border-[#d0d7de] text-[11px] font-semibold text-[#32363a] flex flex-wrap items-center justify-between gap-2">
          <span>
            Branch left · {dimensionLabel} / Design on top
            {selectedDesign !== 'ALL' ? ` · ${selectedDesign}` : ''}
            {' · '}
            <span className="font-normal text-[#6a6d70]">Period: {periodLabel}</span>
          </span>
          <span className="font-normal text-[#6a6d70]">
            Green = Move IN · Pink = Move OUT · DWL {reportMatrix.grandDwl.toLocaleString()} pcs (front column once, classic layout)
          </span>
        </div>
        <div className="overflow-x-auto max-h-[560px]">
          <table
            className="dmx-detail-matrix text-[11px] border-collapse"
            style={{ tableLayout: 'fixed', width: 'max-content', minWidth: '100%' }}
          >
            <colgroup>
              <col style={{ width: 72 }} />
              <col style={{ width: 52 }} />
              <col style={{ width: 48 }} />
              <col style={{ width: 48 }} />
              <col style={{ width: 44 }} />
              {reportMatrix.columns.map((col) => (
                <React.Fragment key={`cg-${col.key}`}>
                  <col style={{ width: 40 }} />
                  <col style={{ width: 40 }} />
                  <col style={{ width: 44 }} />
                </React.Fragment>
              ))}
            </colgroup>
            <thead className="sticky top-0 bg-[#f6f8fa] z-10">
              <tr>
                <th className="dmx-col-head border border-[#d0d7de] px-1.5 py-1 text-left font-extrabold text-[#0f2744] whitespace-nowrap sticky left-0 bg-[#f6f8fa] z-20 tracking-wide">
                  Branch
                </th>
                <th className="dmx-col-head border border-[#d0d7de] px-1 py-1 text-right font-extrabold text-[#0f2744] tracking-wide">
                  T.Stock
                </th>
                <th className="dmx-col-head border border-[#d0d7de] px-1 py-1 text-right font-extrabold text-cyan-900 bg-cyan-50 tracking-wide" title="Warehouse reserve — shown once at front">
                  DWL
                </th>
                <th className="dmx-col-head border border-[#d0d7de] px-1 py-1 text-right font-extrabold text-[#0f2744] tracking-wide">
                  T.Sold
                </th>
                <th className="dmx-col-head border border-[#d0d7de] px-1 py-1 text-right font-extrabold text-[#0f2744] tracking-wide">
                  Refill
                </th>
                {reportMatrix.columns.map((col) => {
                  const hasDesign = col.design && col.design !== '(Category / No Style)';
                  return (
                    <th
                      key={col.key}
                      colSpan={3}
                      className="dmx-outlet-head border border-[#d0d7de] px-0.5 py-1 text-center font-extrabold bg-[#e8f0fe] text-[#0f2744] align-bottom"
                      title={col.label}
                    >
                      <div className="leading-tight break-words whitespace-normal px-0.5">
                        {hasDesign && (
                          <div className="text-[8px] font-extrabold text-[#0B6FB8] break-all leading-tight">
                            {col.design}
                          </div>
                        )}
                        <div className="text-[10px] font-extrabold text-[#0f2744]">{col.carat}</div>
                      </div>
                    </th>
                  );
                })}
              </tr>
              <tr>
                <th className="border border-[#d0d7de] px-0.5 py-0.5 sticky left-0 bg-[#f6f8fa] z-20" />
                <th className="border border-[#d0d7de] px-0.5 py-0.5" />
                <th className="border border-[#d0d7de] px-0.5 py-0.5 bg-cyan-50" />
                <th className="border border-[#d0d7de] px-0.5 py-0.5" />
                <th className="border border-[#d0d7de] px-0.5 py-0.5" />
                {reportMatrix.columns.map((col) => (
                  <React.Fragment key={`${col.key}-sub`}>
                    <th className="dmx-sub-head border border-[#d0d7de] px-0.5 py-0.5 text-[9px] font-extrabold text-[#0f2744] text-right">
                      Stk
                    </th>
                    <th className="dmx-sub-head border border-[#d0d7de] px-0.5 py-0.5 text-[9px] font-extrabold text-[#0f2744] text-right">
                      Sold
                    </th>
                    <th className="dmx-sub-head border border-[#d0d7de] px-0.5 py-0.5 text-[9px] font-extrabold text-[#0f2744] text-right">
                      Move
                    </th>
                  </React.Fragment>
                ))}
              </tr>
            </thead>
            <tbody>
              {reportMatrix.rows.length === 0 || reportMatrix.columns.length === 0 ? (
                <tr>
                  <td
                    colSpan={5 + Math.max(1, reportMatrix.columns.length) * 3}
                    className="px-3 py-8 text-center text-[#6a6d70]"
                  >
                    No design rows — upload stock/sold style sheets or clear filters.
                  </td>
                </tr>
              ) : (
                reportMatrix.rows.map((row) => {
                  const isWh = !!(row as { isWarehouse?: boolean }).isWarehouse;
                  return (
                  <tr
                    key={row.outlet}
                    className={isWh ? 'bg-cyan-50/80 hover:bg-cyan-50' : 'hover:bg-[#eef5ff]'}
                  >
                    <td className={`border border-[#e6e8eb] px-1.5 py-0.5 font-extrabold sticky left-0 z-10 whitespace-nowrap ${isWh ? 'text-cyan-900 bg-cyan-50' : 'text-[#0f2744] bg-white'}`}>
                      {isWh ? 'DWL' : toLockedOutletShortcut(row.outlet)}
                    </td>
                    <td className={`border border-[#e6e8eb] px-1 py-0.5 text-right font-mono font-bold ${isWh ? 'text-cyan-900' : ''}`}>
                      {Math.round(row.tStock).toLocaleString()}
                    </td>
                    <td className="border border-[#e6e8eb] px-1 py-0.5 text-right font-mono font-bold text-cyan-900 bg-cyan-50/50">
                      {isWh ? Math.round(row.tStock).toLocaleString() : '—'}
                    </td>
                    <td className="border border-[#e6e8eb] px-1 py-0.5 text-right font-mono font-bold text-blue-700">
                      {isWh ? '—' : Math.round(row.tSold).toLocaleString()}
                    </td>
                    <td
                      className={`border border-[#e6e8eb] px-1 py-0.5 text-right font-mono font-bold ${
                        !isWh && row.tRefill > 0 ? 'text-red-600' : 'text-slate-400'
                      }`}
                    >
                      {!isWh && row.tRefill > 0 ? row.tRefill : '—'}
                    </td>
                    {row.cells.map((c, i) => (
                      <React.Fragment key={`${row.outlet}-${reportMatrix.columns[i].key}`}>
                        <td className={`border border-[#e6e8eb] px-0.5 py-0.5 text-right font-mono tabular-nums ${isWh ? 'font-bold text-cyan-900 bg-cyan-50/40' : ''}`}>
                          {c.stock || '—'}
                        </td>
                        <td className="border border-[#e6e8eb] px-0.5 py-0.5 text-right font-mono tabular-nums text-blue-700">
                          {isWh ? '—' : c.sold || '—'}
                        </td>
                        <td
                          className={`border border-[#e6e8eb] px-0.5 py-0.5 text-right font-mono tabular-nums font-semibold ${
                            isWh
                              ? 'text-slate-400'
                              : c.net > 0
                                ? 'bg-emerald-50 text-emerald-800'
                                : c.net < 0
                                  ? 'bg-red-50 text-red-700'
                                  : 'text-slate-400'
                          }`}
                        >
                          {isWh ? '—' : c.net > 0 ? `+${c.net}` : c.net < 0 ? `${c.net}` : '—'}
                        </td>
                      </React.Fragment>
                    ))}
                  </tr>
                  );
                })
              )}
            </tbody>
            {reportMatrix.rows.length > 0 && reportMatrix.columns.length > 0 && (
              <tfoot className="sticky bottom-0 z-10">
                <tr className="bg-[#e8eef5] text-[#0f2744] font-extrabold border-t-2 border-[#0B6FB8]">
                  <td className="border border-[#c5d0dc] px-1.5 py-1 sticky left-0 bg-[#e8eef5] z-20">
                    TOTAL
                  </td>
                  <td className="border border-[#c5d0dc] px-1 py-1 text-right font-mono">
                    {Math.round(reportMatrix.grandStock).toLocaleString()}
                  </td>
                  <td className="border border-[#c5d0dc] px-1 py-1 text-right font-mono font-bold text-cyan-900 bg-cyan-50">
                    {Math.round(reportMatrix.grandDwl > 0 ? reportMatrix.grandDwl : warehouseReserve).toLocaleString()}
                  </td>
                  <td className="border border-[#c5d0dc] px-1 py-1 text-right font-mono text-blue-800">
                    {Math.round(reportMatrix.grandSold).toLocaleString()}
                  </td>
                  <td className="border border-[#c5d0dc] px-1 py-1 text-right font-mono text-amber-800">
                    {Math.round(reportMatrix.grandRefill).toLocaleString()}
                  </td>
                  {reportMatrix.colTotals.map((t, i) => (
                    <React.Fragment key={`ct-${reportMatrix.columns[i].key}`}>
                      <td className="border border-[#c5d0dc] px-0.5 py-1 text-right font-mono">
                        {Math.round(t.stock).toLocaleString()}
                      </td>
                      <td className="border border-[#c5d0dc] px-0.5 py-1 text-right font-mono text-blue-800">
                        {Math.round(t.sold).toLocaleString()}
                      </td>
                      <td
                        className={`border border-[#c5d0dc] px-0.5 py-1 text-right font-mono ${
                          t.net > 0
                            ? 'bg-emerald-50 text-emerald-800'
                            : t.net < 0
                              ? 'bg-rose-50 text-rose-700'
                              : 'text-[#64748b]'
                        }`}
                      >
                        {t.net > 0 ? `+${Math.round(t.net)}` : t.net < 0 ? `${Math.round(t.net)}` : '—'}
                      </td>
                    </React.Fragment>
                  ))}
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
      </>
      )}
    </div>
  );
};
