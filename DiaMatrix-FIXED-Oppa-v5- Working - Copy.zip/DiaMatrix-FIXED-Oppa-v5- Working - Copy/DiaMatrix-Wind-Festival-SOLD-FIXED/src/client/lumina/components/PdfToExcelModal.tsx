import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, UploadCloud, FileSpreadsheet, Download, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import type { LabelReport } from '../../../shared/label-pdf-report/core';

interface PdfToExcelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const fmt = (n: number, d = 0) => n.toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d });

/**
 * Upload a label PDF (branch-wise barcode cards) → get the branch-wise Excel report.
 * pdf.js + exceljs are loaded lazily, so they don't bloat the main bundle.
 */
export const PdfToExcelModal: React.FC<PdfToExcelModalProps> = ({ isOpen, onClose }) => {
  const [fileName, setFileName] = useState('');
  const [report, setReport] = useState<LabelReport | null>(null);
  const [busy, setBusy] = useState<'reading' | 'building' | null>(null);
  const [error, setError] = useState('');
  const [includeDesign, setIncludeDesign] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen) {
      setFileName('');
      setReport(null);
      setBusy(null);
      setError('');
      setIncludeDesign(false);
    }
  }, [isOpen]);

  const handleFile = useCallback(async (file: File | undefined | null) => {
    if (!file) return;
    setError('');
    setReport(null);
    if (!/\.pdf$/i.test(file.name) && file.type !== 'application/pdf') {
      setError('Please choose a PDF file.');
      return;
    }
    setFileName(file.name);
    setBusy('reading');
    try {
      const { readLabelPdf } = await import('../../../shared/label-pdf-report/browser');
      const r = await readLabelPdf(file);
      if (!r.sections.some((s) => s.cards.length)) {
        setError('No label cards were found in this PDF. Is it the correct report?');
      } else {
        setReport(r);
      }
    } catch (e) {
      console.error(e);
      setError(`Could not read this PDF: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBusy(null);
    }
  }, []);

  const handleDownload = useCallback(async () => {
    if (!report) return;
    setBusy('building');
    setError('');
    try {
      const { buildLabelExcelBlob, downloadBlob } = await import('../../../shared/label-pdf-report/browser');
      const blob = await buildLabelExcelBlob(report, { includeDesign });
      downloadBlob(blob, `${fileName.replace(/\.pdf$/i, '') || 'Branch_Report'}_Branch_Report.xlsx`);
    } catch (e) {
      console.error(e);
      setError(`Could not build the Excel file: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBusy(null);
    }
  }, [report, includeDesign, fileName]);

  const totals = useMemo(() => {
    const secs = (report?.sections ?? []).filter((s) => s.cards.length);
    return {
      rows: secs.map((s) => ({
        branch: s.branch,
        pcs: s.cards.length,
        gross: s.cards.reduce((a, c) => a + (c.grossWt ?? 0), 0),
        net: s.cards.reduce((a, c) => a + (c.netWt ?? 0), 0),
        price: s.cards.reduce((a, c) => a + (c.price ?? 0), 0),
      })),
    };
  }, [report]);

  if (!isOpen || typeof document === 'undefined') return null;

  return createPortal(
    <div className="fixed inset-0 z-[2100] flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        <div className="px-6 py-4 bg-slate-950/70 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center">
              <FileSpreadsheet className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">PDF → Excel (Branch Wise)</h2>
              <p className="text-xs text-slate-400">Image · Barcode · Carat · Gross Wt · Net Wt · Price</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4">
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => { e.preventDefault(); setDragOver(false); void handleFile(e.dataTransfer.files?.[0]); }}
            onClick={() => inputRef.current?.click()}
            className={`cursor-pointer rounded-2xl border-2 border-dashed px-6 py-8 text-center transition-colors ${
              dragOver ? 'border-emerald-400 bg-emerald-500/10' : 'border-slate-700 hover:border-slate-500 bg-slate-950/40'
            }`}
          >
            <input ref={inputRef} type="file" accept="application/pdf,.pdf" className="hidden"
              onChange={(e) => { void handleFile(e.target.files?.[0]); e.target.value = ''; }} />
            {busy === 'reading' ? (
              <div className="flex flex-col items-center gap-2 text-slate-300">
                <Loader2 className="w-8 h-8 animate-spin text-emerald-400" />
                <span className="text-sm">Reading {fileName}…</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-slate-300">
                <UploadCloud className="w-8 h-8 text-slate-400" />
                <span className="text-sm font-semibold">{fileName || 'Drop the PDF here or click to choose'}</span>
                <span className="text-xs text-slate-500">Label PDF with branch-wise barcode cards</span>
              </div>
            )}
          </div>

          {error && (
            <div className="flex items-start gap-2 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {report && (
            <>
              <div className="flex items-center gap-2 text-sm text-emerald-300">
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {totals.rows.reduce((a, r) => a + r.pcs, 0)} items found in {totals.rows.length} branches
                  {report.runOn ? ` · ${report.runOn}` : ''}
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-800">
                <table className="w-full text-xs text-slate-200">
                  <thead className="bg-slate-950/70 text-slate-400">
                    <tr>
                      <th className="px-3 py-2 text-left">Branch</th>
                      <th className="px-3 py-2 text-right">Pcs</th>
                      <th className="px-3 py-2 text-right">Gross Wt</th>
                      <th className="px-3 py-2 text-right">Net Wt</th>
                      <th className="px-3 py-2 text-right">Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {totals.rows.map((r) => (
                      <tr key={r.branch} className="border-t border-slate-800">
                        <td className="px-3 py-2 font-semibold">{r.branch}</td>
                        <td className="px-3 py-2 text-right">{r.pcs}</td>
                        <td className="px-3 py-2 text-right">{fmt(r.gross, 4)}</td>
                        <td className="px-3 py-2 text-right">{fmt(r.net, 2)}</td>
                        <td className="px-3 py-2 text-right">{fmt(r.price)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {report.warnings.length > 0 && (
                <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200 space-y-1 max-h-32 overflow-y-auto">
                  <div className="font-bold">Please check ({report.warnings.length})</div>
                  {report.warnings.slice(0, 20).map((w, i) => <div key={i}>• {w}</div>)}
                </div>
              )}

              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                <input type="checkbox" checked={includeDesign} onChange={(e) => setIncludeDesign(e.target.checked)} />
                Also add Design No &amp; Design Date columns
              </label>
            </>
          )}
        </div>

        <div className="px-6 py-4 bg-slate-950/70 border-t border-slate-800 flex justify-end gap-3">
          <button onClick={onClose} className="px-4 py-2 rounded-xl text-sm text-slate-300 hover:bg-slate-800">Close</button>
          <button
            onClick={() => void handleDownload()}
            disabled={!report || busy !== null}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {busy === 'building' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            Download Excel
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
};
