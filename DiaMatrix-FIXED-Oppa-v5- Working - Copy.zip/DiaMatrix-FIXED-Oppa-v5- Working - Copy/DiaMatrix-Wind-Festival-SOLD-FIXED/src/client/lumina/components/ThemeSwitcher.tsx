import React from 'react';
import { AppTheme, applyThemeToDocument, getStoredSettings, saveStoredSettings } from '../utils/settingsEngine';

const THEMES: { id: AppTheme; label: string; tip: string; swatch: string }[] = [
  {
    id: 'cosmic',
    label: 'Executive Dark',
    tip: 'Deep navy night · diamond-blue accent',
    swatch: 'linear-gradient(135deg,#06142B 0%,#0B2545 55%,#14B4E8 100%)',
  },
  {
    id: 'light',
    label: 'Diamond Blue Classic',
    tip: 'Original ice-white surfaces · Diamond World blue',
    swatch: 'linear-gradient(135deg,#F6FAFD 0%,#CFE6F5 40%,#14B4E8 70%,#0B2545 100%)',
  },
  {
    id: 'silver',
    label: 'Luxury Silver',
    tip: 'Pearl silver surfaces · graphite text',
    swatch: 'linear-gradient(135deg,#C9CBCD 0%,#A8A9AD 58%,#74777D 100%)',
  },
  {
    id: 'metallic',
    label: 'Shiny Metallic',
    tip: 'Shiny platinum chrome · brushed metal surfaces',
    swatch: 'linear-gradient(135deg,#fcfcfc 0%,#e5e4e2 25%,#b8b7b5 50%,#e5e4e2 75%,#ffffff 100%)',
  },
  {
    id: 'corporate-blue',
    label: 'Corporate Blue',
    tip: 'Professional steel blue · sapphire accent',
    swatch: 'linear-gradient(135deg,#EEF2F6 0%,#CAD7E4 58%,#1769AA 100%)',
  },
];

interface ThemeSwitcherProps {
  theme: AppTheme;
  onThemeChange: (theme: AppTheme) => void;
  compact?: boolean;
}

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({
  theme,
  onThemeChange,
  compact = true,
}) => {
  const select = (next: AppTheme) => {
    if (next === theme) return;
    applyThemeToDocument(next);
    const current = getStoredSettings();
    saveStoredSettings({ ...current, theme: next });
    onThemeChange(next);
  };

  return (
    <div className="theme-switcher" role="group" aria-label="Quick color themes" title="Quick themes: Diamond Blue, Silver, Corporate Blue and Executive Dark. More palettes are in Settings → Theme & Appearance.">
      {THEMES.map((t) => (
        <button
          key={t.id}
          type="button"
      className={t.id === theme ? 'active' : ''}
          title={t.tip}
          aria-label={t.tip}
          aria-pressed={t.id === theme}
          onClick={() => select(t.id)}
          style={{ background: t.swatch }}
        >
          {!compact && <span className="sr-only">{t.label}</span>}
        </button>
      ))}
    </div>
  );
};
