/**
 * Movement & Aging Report — Odoo / Tally hierarchical accordion grid.
 * Metal family → Product type → Style / SKU leaf rows.
 * Preserves daily snapshot audit, AI insights panel, and export pipelines.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import type { RedistributionReport, RawInventoryRecord, WeightSummary } from '../types';
import {
  Hourglass,
  Activity,
  Flame,
  Clock,
  Building2,
  Layers,
  ChevronRight,
  ChevronDown,
  Search,
  Sparkles,
  Home,
  ArrowDownRight,
  ArrowUpRight,
} from 'lucide-react';
import { AIIntelligencePanel } from './AIIntelligencePanel';
import { useAIInsightsPanelProps } from '../store/aiInsightsStore';
import {
  ensureInitialHistoricalData,
  compareSnapshots,
  type DailyInventorySnapshot,
  type MovementAgingAnalysisResult,
} from '../utils/dailyStorageEngine';
import {
  detectMetalCategory,
  type MetalCategory,
} from '../utils/smartRedistributionEngine';

/* -------------------------------------------------------------------------- */
/* Props                                                                       */
/* -------------------------------------------------------------------------- */

interface MovementAndAgingReportViewProps {
  report: RedistributionReport;
  rawRecords?: RawInventoryRecord[];
  onSelectBranch?: (branch: string) => void;
  onSelectWeight?: (weight: string) => void;
  onBackToHome?: () => void;
}

/* -------------------------------------------------------------------------- */
/* Hierarchy types                                                             */
/* -------------------------------------------------------------------------- */

const AGING_THRESHOLD_DAYS = 90;

const METAL_ORDER: MetalCategory[] = ['Diamond', 'Gold', 'Platinum', 'Mixed', 'Unknown'];

const METAL_TITLE: Record<MetalCategory, string> = {
  Diamond: 'DIAMOND INVENTORY',
  Gold: 'GOLD INVENTORY',
  Platinum: 'PLATINUM INVENTORY',
  Mixed: 'MIXED METAL INVENTORY',
  Unknown: 'GENERAL / UNCLASSIFIED',
};

const METAL_ACCENT: Record<MetalCategory, string> = {
  Diamond: 'from-sky-800 to-slate-800 border-sky-700',
  Gold: 'from-amber-700 to-yellow-900 border-amber-600',
  Platinum: 'from-slate-600 to-slate-800 border-slate-500',
  Mixed: 'from-violet-800 to-slate-800 border-violet-600',
  Unknown: 'from-slate-600 to-slate-700 border-slate-500',
};

interface StyleLeaf {
  id: string;
  sku: string;
  sold: number;
  stock: number;
  ageDays: number;
  isAging: boolean;
  velocity: WeightSummary['velocityCategory'];
  turnoverRatio: number;
  unmetShortage: number;
}

interface ProductTypeGroup {
  key: string;
  label: string;
  variants: StyleLeaf[];
  totalStock: number;
  totalSold: number;
  agingCount: number;
}

interface MetalSection {
  metal: MetalCategory;
  title: string;
  productTypes: ProductTypeGroup[];
  totalStock: number;
  totalSold: number;
  styleCount: number;
  agingCount: number;
}

/** Day-over-day movement leaf (from snapshot compare). */
interface MovementLeaf {
  id: string;
  branch: string;
  weight: string;
  previousStock: number;
  currentStock: number;
  stockDelta: number;
  detectedUnitsSold: number;
  daysBetween: number;
  dailySalesVelocity: number;
  daysToStockout: number;
  movementStatus: string;
}

interface MovementProductGroup {
  key: string;
  label: string;
  items: MovementLeaf[];
  totalStock: number;
  soldUnits: number;
}

interface MovementMetalSection {
  metal: MetalCategory;
  title: string;
  productTypes: MovementProductGroup[];
  totalStock: number;
  itemCount: number;
}

/* -------------------------------------------------------------------------- */
/* Helpers                                                                     */
/* -------------------------------------------------------------------------- */

function detectProductType(text: string): string {
  const t = text.toLowerCase();
  if (/\b(nosepin|nose\s*pin|nath|nathni)\b/.test(t)) return 'Nosepins';
  if (/\b(earring|ear\s*ring|jhumka|bali|stud)\b/.test(t)) return 'Earrings';
  if (/\b(ring|band|solitaire)\b/.test(t)) return 'Rings';
  if (/\b(necklace|haar|mangalsutra)\b/.test(t)) return 'Necklaces';
  if (/\b(pendant|locket)\b/.test(t)) return 'Pendants';
  if (/\b(bangle|kada|bracelet)\b/.test(t)) return 'Bangles & Bracelets';
  if (/\b(chain)\b/.test(t)) return 'Chains';
  if (/\b(set|parure)\b/.test(t)) return 'Sets';
  return 'Other Styles';
}

function metalFromText(text: string): MetalCategory {
  return detectMetalCategory({
    category: '',
    itemName: text,
    variant: text,
    itemCode: text,
    weight: text,
  });
}

function buildWeightHierarchy(weights: WeightSummary[]): MetalSection[] {
  const byMetal = new Map<MetalCategory, Map<string, StyleLeaf[]>>();

  weights.forEach((w) => {
    const metal = metalFromText(w.weight);
    const productType = detectProductType(w.weight);
    const ageDays = Number(w.averageAgeDays) || 0;
    const leaf: StyleLeaf = {
      id: w.weight,
      sku: w.weight,
      sold: Number(w.soldQty) || 0,
      stock: Number(w.currentStock) || 0,
      ageDays,
      isAging: ageDays > AGING_THRESHOLD_DAYS,
      velocity: w.velocityCategory,
      turnoverRatio: Number(w.turnoverRatio) || 0,
      unmetShortage: Number(w.unmetShortage) || 0,
    };
    if (!byMetal.has(metal)) byMetal.set(metal, new Map());
    const types = byMetal.get(metal)!;
    if (!types.has(productType)) types.set(productType, []);
    types.get(productType)!.push(leaf);
  });

  return METAL_ORDER.filter((m) => byMetal.has(m)).map((metal) => {
    const types = byMetal.get(metal)!;
    const productTypes: ProductTypeGroup[] = Array.from(types.entries())
      .map(([key, variants]) => {
        const sorted = [...variants].sort((a, b) => b.ageDays - a.ageDays || b.stock - a.stock);
        return {
          key,
          label: key,
          variants: sorted,
          totalStock: sorted.reduce((s, v) => s + v.stock, 0),
          totalSold: sorted.reduce((s, v) => s + v.sold, 0),
          agingCount: sorted.filter((v) => v.isAging).length,
        };
      })
      .sort((a, b) => b.totalStock - a.totalStock);

    return {
      metal,
      title: METAL_TITLE[metal],
      productTypes,
      totalStock: productTypes.reduce((s, p) => s + p.totalStock, 0),
      totalSold: productTypes.reduce((s, p) => s + p.totalSold, 0),
      styleCount: productTypes.reduce((s, p) => s + p.variants.length, 0),
      agingCount: productTypes.reduce((s, p) => s + p.agingCount, 0),
    };
  });
}

function buildMovementHierarchy(
  items: MovementAgingAnalysisResult['items'],
): MovementMetalSection[] {
  const byMetal = new Map<MetalCategory, Map<string, MovementLeaf[]>>();

  items.forEach((item, idx) => {
    const metal = metalFromText(item.weight);
    const productType = detectProductType(item.weight);
    const leaf: MovementLeaf = {
      id: `${item.branch}-${item.weight}-${idx}`,
      branch: item.branch,
      weight: item.weight,
      previousStock: item.previousStock,
      currentStock: item.currentStock,
      stockDelta: item.stockDelta,
      detectedUnitsSold: item.detectedUnitsSold,
      daysBetween: item.daysBetween,
      dailySalesVelocity: item.dailySalesVelocity,
      daysToStockout: item.daysToStockout,
      movementStatus: item.movementStatus,
    };
    if (!byMetal.has(metal)) byMetal.set(metal, new Map());
    const types = byMetal.get(metal)!;
    if (!types.has(productType)) types.set(productType, []);
    types.get(productType)!.push(leaf);
  });

  return METAL_ORDER.filter((m) => byMetal.has(m)).map((metal) => {
    const types = byMetal.get(metal)!;
    const productTypes: MovementProductGroup[] = Array.from(types.entries())
      .map(([key, rows]) => ({
        key,
        label: key,
        items: rows,
        totalStock: rows.reduce((s, r) => s + r.currentStock, 0),
        soldUnits: rows.reduce((s, r) => s + r.detectedUnitsSold, 0),
      }))
      .sort((a, b) => b.soldUnits - a.soldUnits);

    return {
      metal,
      title: METAL_TITLE[metal],
      productTypes,
      totalStock: productTypes.reduce((s, p) => s + p.totalStock, 0),
      itemCount: productTypes.reduce((s, p) => s + p.items.length, 0),
    };
  });
}

function AgingChip({ ageDays, isAging }: { ageDays: number; isAging: boolean }) {
  if (!ageDays || ageDays <= 0) {
    return <span className="text-[10px] text-slate-400">—</span>;
  }
  if (isAging) {
    return (
      <span className="inline-flex items-center gap-0.5 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 px-1.5 py-0.5 text-[10px] font-bold ring-1 ring-rose-200/80 dark:ring-rose-800/50">
        <Clock className="w-3 h-3" />
        &gt;{AGING_THRESHOLD_DAYS}d aging · {Math.round(ageDays)}d
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-0.5 text-[10px] text-slate-500 dark:text-slate-400">
      <Clock className="w-3 h-3" />
      {Math.round(ageDays)}d
    </span>
  );
}

function StockBadge({ stock }: { stock: number }) {
  return (
    <span className="inline-flex items-center rounded-full bg-white/20 text-white px-2 py-0.5 text-[10px] font-bold tabular-nums">
      Stock {stock.toLocaleString()}
    </span>
  );
}

function MovementStatusBadge({ status }: { status: string }) {
  if (status === 'RAPID_SELL_OUT') {
    return (
      <span className="px-2 py-0.5 bg-rose-100 text-rose-800 rounded font-bold text-[10px]">
        Rapid Sell-out
      </span>
    );
  }
  if (status === 'STEADY_MOVEMENT') {
    return (
      <span className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded font-bold text-[10px]">
        Steady Movement
      </span>
    );
  }
  if (status === 'REPLENISHED') {
    return (
      <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded font-bold text-[10px]">
        Inbound Stock
      </span>
    );
  }
  return (
    <span className="px-2 py-0.5 bg-slate-100 text-slate-500 rounded text-[10px]">Stagnant Idle</span>
  );
}

/* -------------------------------------------------------------------------- */
/* Component                                                                   */
/* -------------------------------------------------------------------------- */

export const MovementAndAgingReportView: React.FC<MovementAndAgingReportViewProps> = ({
  report,
  rawRecords = [],
  onSelectBranch,
  onSelectWeight,
  onBackToHome,
}) => {
  const aiInsightsProps = useAIInsightsPanelProps();
  const [activeSubTab, setActiveSubTab] = useState<'daily_movement' | 'aging' | 'velocity'>(
    'daily_movement',
  );
  const [selectedAgingBucket, setSelectedAgingBucket] = useState<string>('all');
  const [snapshots, setSnapshots] = useState<DailyInventorySnapshot[]>([]);
  const [prevSnapshotId, setPrevSnapshotId] = useState<string>('');
  const [currSnapshotId, setCurrSnapshotId] = useState<string>('');
  const [movementSearch, setMovementSearch] = useState('');
  const [movementFilter, setMovementFilter] = useState<'ALL' | 'SOLD' | 'REPLENISHED' | 'STAGNANT'>(
    'ALL',
  );
  const [expandedTypes, setExpandedTypes] = useState<Set<string>>(new Set());
  const [collapsedMetals, setCollapsedMetals] = useState<Set<MetalCategory>>(new Set());

  useEffect(() => {
    const list = ensureInitialHistoricalData(rawRecords);
    setSnapshots(list);
    if (list.length >= 2) {
      setCurrSnapshotId(list[0].id);
      setPrevSnapshotId(list[1].id);
    } else if (list.length === 1) {
      setCurrSnapshotId(list[0].id);
      setPrevSnapshotId(list[0].id);
    }
  }, [rawRecords]);

  const movementResult: MovementAgingAnalysisResult | null = useMemo(() => {
    if (snapshots.length < 2) return null;
    const curr = snapshots.find((s) => s.id === currSnapshotId) || snapshots[0];
    const prev = snapshots.find((s) => s.id === prevSnapshotId) || snapshots[1] || snapshots[0];
    return compareSnapshots(prev, curr);
  }, [snapshots, currSnapshotId, prevSnapshotId]);

  const filteredMovementItems = useMemo(() => {
    if (!movementResult) return [];
    return movementResult.items.filter((item) => {
      const matchesSearch =
        item.branch.toLowerCase().includes(movementSearch.toLowerCase()) ||
        item.weight.toLowerCase().includes(movementSearch.toLowerCase());
      let matchesFilter = true;
      if (movementFilter === 'SOLD') matchesFilter = item.detectedUnitsSold > 0;
      else if (movementFilter === 'REPLENISHED') matchesFilter = item.replenishedUnits > 0;
      else if (movementFilter === 'STAGNANT')
        matchesFilter = item.detectedUnitsSold === 0 && item.replenishedUnits === 0;
      return matchesSearch && matchesFilter;
    });
  }, [movementResult, movementSearch, movementFilter]);

  const movementHierarchy = useMemo(
    () => buildMovementHierarchy(filteredMovementItems),
    [filteredMovementItems],
  );

  const agingBuckets = report.agingBuckets || [];
  const itemLabel = report.categoryConfig?.itemLabel || 'Item / SKU / Variant';

  const weightHierarchy = useMemo(() => {
    let weights = report.weightSummaries || [];
    if (selectedAgingBucket !== 'all' && agingBuckets.length) {
      const bucket = agingBuckets.find((b) => b.bucket === selectedAgingBucket);
      if (bucket) {
        const trapped = new Set(bucket.trappedItems.map((t) => t.weight));
        weights = weights.filter((w) => trapped.has(w.weight));
      }
    }
    return buildWeightHierarchy(weights);
  }, [report.weightSummaries, selectedAgingBucket, agingBuckets]);

  const velocityHierarchy = useMemo(
    () => buildWeightHierarchy(report.weightSummaries || []),
    [report.weightSummaries],
  );

  const toggleMetal = useCallback((metal: MetalCategory) => {
    setCollapsedMetals((prev) => {
      const next = new Set(prev);
      if (next.has(metal)) next.delete(metal);
      else next.add(metal);
      return next;
    });
  }, []);

  const toggleType = useCallback((key: string) => {
    setExpandedTypes((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  const handleExportMovementExcel = () => {
    if (!movementResult) return;
    const headers = [
      'Branch',
      itemLabel,
      'Previous Stock',
      'Current Stock',
      'Stock Delta',
      'Detected Units Sold',
      'Days Between Audits',
      'Daily Sales Velocity',
      'Average Stock',
      'Estimated Days to Stockout',
      'Movement Status',
    ];
    const rows = movementResult.items.map((item) => [
      item.branch,
      item.weight,
      item.previousStock,
      item.currentStock,
      item.stockDelta,
      item.detectedUnitsSold,
      item.daysBetween,
      item.dailySalesVelocity,
      item.averageStock,
      item.daysToStockout >= 999 ? 'N/A (No sales)' : item.daysToStockout,
      item.movementStatus,
    ]);
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    XLSX.utils.book_append_sheet(wb, ws, 'Movement_Aging_Audit');
    XLSX.writeFile(wb, `Day_Over_Day_Movement_Audit_${movementResult.currentSnapshot.date}.xlsx`);
  };

  const renderMetalAccordion = (
    sections: MetalSection[],
    mode: 'aging' | 'velocity',
  ) => {
    if (!sections.length) {
      return (
        <div className="p-8 text-center text-sm text-slate-500">
          No inventory styles available for this view.
        </div>
      );
    }
    return (
      <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-950">
        {sections.map((section) => {
          const metalOpen = !collapsedMetals.has(section.metal);
          return (
            <div key={section.metal}>
              <button
                type="button"
                onClick={() => toggleMetal(section.metal)}
                className={`w-full flex items-center justify-between gap-3 px-4 py-3 text-left bg-gradient-to-r ${METAL_ACCENT[section.metal]} text-white cursor-pointer`}
              >
                <div className="flex items-center gap-2 min-w-0">
                  {metalOpen ? (
                    <ChevronDown className="w-4 h-4 shrink-0" />
                  ) : (
                    <ChevronRight className="w-4 h-4 shrink-0" />
                  )}
                  <span className="text-sm font-extrabold tracking-wide truncate">
                    {section.title}
                  </span>
                  <span className="text-[10px] font-semibold bg-white/15 rounded-full px-2 py-0.5">
                    {section.styleCount} styles · {section.productTypes.length} types
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <StockBadge stock={section.totalStock} />
                  {section.agingCount > 0 && (
                    <span className="inline-flex items-center gap-0.5 rounded-full bg-rose-400/90 text-slate-900 px-2 py-0.5 text-[10px] font-bold">
                      <Clock className="w-3 h-3" />
                      {section.agingCount} aging
                    </span>
                  )}
                </div>
              </button>

              {metalOpen &&
                section.productTypes.map((pt) => {
                  const typeKey = `${mode}-${section.metal}::${pt.key}`;
                  const typeOpen = expandedTypes.has(typeKey);
                  return (
                    <div key={typeKey} className="border-t border-slate-100 dark:border-slate-800">
                      <button
                        type="button"
                        onClick={() => toggleType(typeKey)}
                        className="w-full flex items-center justify-between gap-3 px-4 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-900/60 cursor-pointer"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          {typeOpen ? (
                            <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                          ) : (
                            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                          )}
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                            {pt.label}
                          </span>
                          <span className="text-[10px] text-slate-500">
                            {pt.variants.length} variant{pt.variants.length === 1 ? '' : 's'}
                          </span>
                          <span className="inline-flex items-center rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 px-2 py-0.5 text-[10px] font-bold tabular-nums">
                            Stock {pt.totalStock.toLocaleString()}
                          </span>
                          {pt.agingCount > 0 && (
                            <span className="inline-flex items-center gap-0.5 rounded-md bg-rose-50 text-rose-700 px-1.5 py-0.5 text-[10px] font-semibold">
                              <Clock className="w-3 h-3" />
                              {pt.agingCount} aging
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] tabular-nums text-slate-500 shrink-0">
                          Sales {pt.totalSold.toLocaleString()}
                        </div>
                      </button>

                      {typeOpen && (
                        <div className="overflow-x-auto bg-slate-50/70 dark:bg-slate-950/50 border-t border-slate-100 dark:border-slate-800">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-300">
                                <th className="py-2 px-3 text-left font-semibold">#</th>
                                <th className="py-2 px-3 text-left font-semibold">SKU / Style</th>
                                <th className="py-2 px-3 text-right font-semibold">Stock</th>
                                <th className="py-2 px-3 text-right font-semibold">Sold</th>
                                <th className="py-2 px-3 text-left font-semibold">Aging</th>
                                <th className="py-2 px-3 text-left font-semibold">Velocity</th>
                                <th className="py-2 px-3 text-right font-semibold">Turnover</th>
                              </tr>
                            </thead>
                            <tbody>
                              {pt.variants.map((v, idx) => (
                                <tr
                                  key={v.id}
                                  onClick={() => onSelectWeight?.(v.sku)}
                                  className={`border-t border-slate-100 dark:border-slate-800/60 cursor-pointer hover:bg-indigo-50/40 dark:hover:bg-indigo-950/20 ${
                                    v.isAging
                                      ? 'bg-rose-50/80 dark:bg-rose-950/30'
                                      : idx % 2 === 0
                                        ? 'bg-white dark:bg-slate-950'
                                        : 'bg-slate-50/80 dark:bg-slate-900/40'
                                  }`}
                                >
                                  <td className="py-2 px-3 text-slate-400">{idx + 1}</td>
                                  <td className="py-2 px-3 font-mono text-[11px] font-semibold text-slate-800 dark:text-slate-100">
                                    {v.sku}
                                  </td>
                                  <td className="py-2 px-3 text-right tabular-nums font-medium">
                                    {v.stock.toLocaleString()}
                                  </td>
                                  <td className="py-2 px-3 text-right tabular-nums">
                                    {v.sold.toLocaleString()}
                                  </td>
                                  <td className="py-2 px-3">
                                    <AgingChip ageDays={v.ageDays} isAging={v.isAging} />
                                  </td>
                                  <td className="py-2 px-3 text-[10px] text-slate-500">
                                    {v.velocity}
                                  </td>
                                  <td className="py-2 px-3 text-right tabular-nums font-semibold">
                                    {v.turnoverRatio.toFixed(2)}×
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-6" id="movement-aging-root">
      <AIIntelligencePanel
        {...aiInsightsProps}
        currencySymbol={report.categoryConfig?.currencySymbol}
        maxItems={4}
        defaultCollapsed
        expandToFullPage
      />

      {/* Sub-navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 sm:p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            {onBackToHome && (
              <button
                type="button"
                onClick={onBackToHome}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-300 transition-all cursor-pointer"
                title="Return to Home / Executive Dashboard"
              >
                <Home className="w-3.5 h-3.5 text-indigo-600" />
                <span>Back to Home</span>
              </button>
            )}
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Activity className="w-5 h-5 text-indigo-600" />
              Inventory Movement & Stock Aging Analysis
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Hierarchical metal → product type → style grid with day-over-day movement and aging
            alerts.
          </p>
        </div>

        <div className="inline-flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 text-xs self-start sm:self-auto overflow-x-auto">
          {(
            [
              { id: 'daily_movement' as const, label: 'Daily Movement Audit', icon: Sparkles },
              { id: 'aging' as const, label: 'Aging Buckets', icon: Clock },
              { id: 'velocity' as const, label: 'Product Velocity', icon: Flame },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSubTab(tab.id)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeSubTab === tab.id
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* 1. DAILY MOVEMENT */}
      {activeSubTab === 'daily_movement' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 sm:p-6 rounded-2xl border border-indigo-900/50 shadow-md space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Automated Daily Audit Engine
                </span>
                <h3 className="text-xl font-bold text-white mt-1">
                  Day-over-Day Stock Delta & Sales Detection
                </h3>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                  Compares baseline vs current stock snapshots. Sold units, velocity, and stockout
                  runway are derived automatically.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3 bg-slate-800/80 p-2.5 rounded-xl border border-slate-700/60">
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Baseline Date</span>
                  <select
                    value={prevSnapshotId}
                    onChange={(e) => setPrevSnapshotId(e.target.value)}
                    className="bg-slate-900 border border-slate-600 rounded-lg text-xs px-2 py-1.5 text-white"
                  >
                    {snapshots.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.date}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Current Date</span>
                  <select
                    value={currSnapshotId}
                    onChange={(e) => setCurrSnapshotId(e.target.value)}
                    className="bg-slate-900 border border-slate-600 rounded-lg text-xs px-2 py-1.5 text-white"
                  >
                    {snapshots.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.date}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  type="button"
                  onClick={handleExportMovementExcel}
                  disabled={!movementResult}
                  className="mt-4 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-xs font-bold cursor-pointer"
                >
                  Export Excel
                </button>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[180px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search branch or style…"
                value={movementSearch}
                onChange={(e) => setMovementSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
            </div>
            {(['ALL', 'SOLD', 'REPLENISHED', 'STAGNANT'] as const).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setMovementFilter(f)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                  movementFilter === f
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                {f}
              </button>
            ))}
          </div>

          {!movementResult ? (
            <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-10 text-center text-sm text-slate-500">
              Need at least two daily stock snapshots to compute day-over-day movement. Upload
              consecutive daily files to activate this audit.
            </div>
          ) : movementHierarchy.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              No movement rows match the current search / filter.
            </div>
          ) : (
            <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-950">
              {movementHierarchy.map((section) => {
                const metalOpen = !collapsedMetals.has(section.metal);
                return (
                  <div key={`mv-${section.metal}`}>
                    <button
                      type="button"
                      onClick={() => toggleMetal(section.metal)}
                      className={`w-full flex items-center justify-between gap-3 px-4 py-3 text-left bg-gradient-to-r ${METAL_ACCENT[section.metal]} text-white cursor-pointer`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        {metalOpen ? (
                          <ChevronDown className="w-4 h-4" />
                        ) : (
                          <ChevronRight className="w-4 h-4" />
                        )}
                        <span className="text-sm font-extrabold tracking-wide">{section.title}</span>
                        <span className="text-[10px] font-semibold bg-white/15 rounded-full px-2 py-0.5">
                          {section.itemCount} lines
                        </span>
                      </div>
                      <StockBadge stock={section.totalStock} />
                    </button>
                    {metalOpen &&
                      section.productTypes.map((pt) => {
                        const typeKey = `mv-${section.metal}::${pt.key}`;
                        const typeOpen = expandedTypes.has(typeKey);
                        return (
                          <div key={typeKey} className="border-t border-slate-100 dark:border-slate-800">
                            <button
                              type="button"
                              onClick={() => toggleType(typeKey)}
                              className="w-full flex items-center justify-between gap-3 px-4 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-900/60 cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                {typeOpen ? (
                                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                                ) : (
                                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                                )}
                                <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                                  {pt.label}
                                </span>
                                <span className="inline-flex rounded-full bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-[10px] font-bold tabular-nums">
                                  Stock {pt.totalStock.toLocaleString()}
                                </span>
                              </div>
                              <span className="text-[11px] text-slate-500 tabular-nums">
                                Sold {pt.soldUnits.toLocaleString()}
                              </span>
                            </button>
                            {typeOpen && (
                              <div className="overflow-x-auto bg-slate-50/70 dark:bg-slate-950/50 border-t border-slate-100 dark:border-slate-800">
                                <table className="w-full text-xs">
                                  <thead>
                                    <tr className="bg-slate-100 dark:bg-slate-900 text-slate-600">
                                      <th className="py-2 px-3 text-left font-semibold">Branch</th>
                                      <th className="py-2 px-3 text-left font-semibold">SKU</th>
                                      <th className="py-2 px-3 text-right font-semibold">Prev</th>
                                      <th className="py-2 px-3 text-right font-semibold">Curr</th>
                                      <th className="py-2 px-3 text-right font-semibold">Delta</th>
                                      <th className="py-2 px-3 text-right font-semibold">Sold</th>
                                      <th className="py-2 px-3 text-right font-semibold">Velocity</th>
                                      <th className="py-2 px-3 text-center font-semibold">Status</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {pt.items.map((item) => (
                                      <tr
                                        key={item.id}
                                        className="border-t border-slate-100 dark:border-slate-800 hover:bg-indigo-50/30 cursor-pointer"
                                        onClick={() => {
                                          onSelectBranch?.(item.branch);
                                          onSelectWeight?.(item.weight);
                                        }}
                                      >
                                        <td className="py-2 px-3 font-medium">{item.branch}</td>
                                        <td className="py-2 px-3 font-mono text-[11px]">{item.weight}</td>
                                        <td className="py-2 px-3 text-right tabular-nums">
                                          {item.previousStock}
                                        </td>
                                        <td className="py-2 px-3 text-right tabular-nums font-semibold">
                                          {item.currentStock}
                                        </td>
                                        <td className="py-2 px-3 text-right tabular-nums">
                                          <span
                                            className={`inline-flex items-center gap-0.5 ${
                                              item.stockDelta < 0
                                                ? 'text-rose-600'
                                                : item.stockDelta > 0
                                                  ? 'text-emerald-600'
                                                  : 'text-slate-500'
                                            }`}
                                          >
                                            {item.stockDelta < 0 ? (
                                              <ArrowDownRight className="w-3 h-3" />
                                            ) : item.stockDelta > 0 ? (
                                              <ArrowUpRight className="w-3 h-3" />
                                            ) : null}
                                            {item.stockDelta}
                                          </span>
                                        </td>
                                        <td className="py-2 px-3 text-right tabular-nums">
                                          {item.detectedUnitsSold}
                                        </td>
                                        <td className="py-2 px-3 text-right tabular-nums">
                                          {item.dailySalesVelocity.toFixed(2)}/d
                                        </td>
                                        <td className="py-2 px-3 text-center">
                                          <MovementStatusBadge status={item.movementStatus} />
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        );
                      })}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 2. AGING */}
      {activeSubTab === 'aging' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            <button
              type="button"
              onClick={() => setSelectedAgingBucket('all')}
              className={`rounded-xl border p-3 text-left cursor-pointer transition ${
                selectedAgingBucket === 'all'
                  ? 'border-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 ring-1 ring-indigo-300'
                  : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900'
              }`}
            >
              <div className="text-[10px] uppercase font-bold text-slate-500">All Buckets</div>
              <div className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                {(report.weightSummaries || []).length}
              </div>
              <div className="text-[10px] text-slate-500">styles</div>
            </button>
            {agingBuckets.map((bucket) => {
              const isSelected = selectedAgingBucket === bucket.bucket;
              return (
                <button
                  key={bucket.bucket}
                  type="button"
                  onClick={() => setSelectedAgingBucket(bucket.bucket)}
                  className={`rounded-xl border p-3 text-left cursor-pointer transition ${
                    isSelected
                      ? 'border-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 ring-1 ring-indigo-300'
                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-slate-500">
                    <Hourglass className="w-3 h-3" />
                    {bucket.bucket}
                  </div>
                  <div className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
                    {bucket.totalPieces.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-slate-500">
                    {bucket.percentage.toFixed(1)}% · {bucket.status.replace('_', ' ')}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
            <Layers className="w-3.5 h-3.5" />
            Hierarchical aging matrix — expand a product type to inspect individual styles.
          </div>
          {renderMetalAccordion(weightHierarchy, 'aging')}
        </div>
      )}

      {/* 3. VELOCITY */}
      {activeSubTab === 'velocity' && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
            <Flame className="w-3.5 h-3.5 text-amber-500" />
            Product velocity by metal family and product type. Aging styles are highlighted in rose.
          </div>
          {renderMetalAccordion(velocityHierarchy, 'velocity')}

          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 text-xs font-bold flex items-center gap-2">
              <Building2 className="w-3.5 h-3.5" />
              Outlet stock presence
            </div>
            <div className="overflow-x-auto max-h-56 overflow-y-auto">
              <table className="w-full text-xs">
                <thead className="sticky top-0 bg-slate-100 dark:bg-slate-900">
                  <tr>
                    <th className="py-2 px-3 text-left font-semibold">Outlet</th>
                    <th className="py-2 px-3 text-right font-semibold">Stock</th>
                    <th className="py-2 px-3 text-right font-semibold">Sold</th>
                  </tr>
                </thead>
                <tbody>
                  {(report.branchSummaries || [])
                    .filter((b) => b.totalCurrentStock > 0 && !b.isWarehouse)
                    .map((b) => (
                      <tr
                        key={b.branch}
                        className="border-t border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer"
                        onClick={() => onSelectBranch?.(b.branch)}
                      >
                        <td className="py-1.5 px-3 font-medium">{b.branch}</td>
                        <td className="py-1.5 px-3 text-right tabular-nums">
                          {b.totalCurrentStock.toLocaleString()}
                        </td>
                        <td className="py-1.5 px-3 text-right tabular-nums">
                          {b.totalSold.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
