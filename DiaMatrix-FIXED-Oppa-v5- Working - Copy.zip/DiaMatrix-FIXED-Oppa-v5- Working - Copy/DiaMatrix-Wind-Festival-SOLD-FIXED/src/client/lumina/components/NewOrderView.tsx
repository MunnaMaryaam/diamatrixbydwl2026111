import React, { useEffect, useMemo, useState } from 'react';
import {
  FilePlus2,
  Plus,
  Trash2,
  Download,
  Wand2,
  Store,
  Truck,
  ClipboardList,
  Zap,
  PencilLine,
  Sparkles,
} from 'lucide-react';
import type { RedistributionReport } from '../types';
import {
  getBranchDisplayName,
  isOnlineBranch,
  isExcludedOutlet,
  isWarehouseBranchCode,
} from '../utils/dataIdentityEngine';
import { exportRefillInvoicePdf } from '../utils/styledReportExport';
import {
  useRefillOrders,
  createOrder,
  updateOrder,
  deleteOrder,
  selectOrder,
  DEFAULT_SUPPLIER,
  type RefillOrder,
  type RefillOrderLine,
} from '../utils/refillOrderStore';
import { useAIInsightsStore } from '../store/aiInsightsStore';
import type { SmartTransferRecommendation } from '../utils/smartRedistributionEngine';
import { DiamondWorldLogo } from './DiamondWorldLogo';
import { BRAND } from '../brand';

const SUPPLIER_KEY = 'dmx_refill_suppliers';
const ALL_OUTLETS_LABEL = 'All Outlets (Central Requisition)';

function loadSuppliers(): string[] {
  try {
    const saved = JSON.parse(localStorage.getItem(SUPPLIER_KEY) || '[]');
    if (Array.isArray(saved)) return Array.from(new Set([DEFAULT_SUPPLIER, ...saved.map(String)]));
  } catch {
    /* ignore */
  }
  return [DEFAULT_SUPPLIER];
}

const money = (n: number) =>
  n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const toNum = (v: string) => {
  const n = parseFloat(v);
  return Number.isFinite(n) && n >= 0 ? n : 0;
};
const orderTotal = (o: RefillOrder) => o.lines.reduce((s, l) => s + l.qty * l.price, 0);
const fmtDate = (iso: string) => new Date(iso).toLocaleDateString('en-GB').replace(/\//g, '-');

/** Infer a display category from a design / weight code and report config. */
function resolveCategory(designCode: string, report: RedistributionReport): string {
  const label = report.categoryConfig?.itemLabel || 'Jewelry';
  if (!designCode) return label;
  const lower = designCode.toLowerCase();
  if (/\b(gold|au|18k|22k|24k)\b/.test(lower)) return 'Gold';
  if (/\b(diamond|dia|cvd|lab)\b/.test(lower)) return 'Diamond';
  if (/\b(platinum|pt)\b/.test(lower)) return 'Platinum';
  if (/\b(nosepin|earring|ring|bangle|chain|pendant|necklace)\b/.test(lower)) {
    const match = lower.match(/\b(nosepin|earring|ring|bangle|chain|pendant|necklace)\b/);
    if (match) return match[1].charAt(0).toUpperCase() + match[1].slice(1);
  }
  return label;
}

interface Props {
  report: RedistributionReport;
}

export const NewOrderView: React.FC<Props> = ({ report }) => {
  const { orders, selectedId } = useRefillOrders();
  const order = orders.find((o) => o.id === selectedId) || null;
  const [suppliers, setSuppliers] = useState<string[]>(loadSuppliers);
  const [newSupplier, setNewSupplier] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [aiHint, setAiHint] = useState('');

  const transfers = useAIInsightsStore((s) => s.transfers);
  const insightsStatus = useAIInsightsStore((s) => s.status);

  const defaultPrice = report.categoryConfig?.estimatedAvgUnitPrice || 0;

  const outletOptions = useMemo(
    () =>
      (report.matrix?.branches || [])
        .filter(
          (b) =>
            b &&
            b !== 'WHL' &&
            !isWarehouseBranchCode(b) &&
            !isOnlineBranch(b) &&
            !isExcludedOutlet(b),
        )
        .map((code) => ({ code, name: getBranchDisplayName(code) })),
    [report],
  );
  const designCodes = useMemo(() => report.matrix?.weights || [], [report]);

  const addSupplier = () => {
    const name = newSupplier.trim();
    if (!name) return;
    const next = Array.from(new Set([...suppliers, name]));
    setSuppliers(next);
    setNewSupplier('');
    if (order) updateOrder(order.id, { supplier: name });
    try {
      localStorage.setItem(
        SUPPLIER_KEY,
        JSON.stringify(next.filter((s) => s !== DEFAULT_SUPPLIER)),
      );
    } catch {
      /* ignore */
    }
  };

  const setLines = (lines: RefillOrderLine[]) => order && updateOrder(order.id, { lines });
  const patchLine = (lineId: number, patch: Partial<RefillOrderLine>) =>
    order && setLines(order.lines.map((l) => (l.id === lineId ? { ...l, ...patch } : l)));
  const addLine = () => {
    if (!order) return;
    const nextId = Math.max(0, ...order.lines.map((l) => l.id)) + 1;
    setLines([
      ...order.lines,
      { id: nextId, designCode: '', qty: 0, price: defaultPrice, category: '' },
    ]);
  };
  const removeLine = (lineId: number) =>
    order && order.lines.length > 1 && setLines(order.lines.filter((l) => l.id !== lineId));

  /**
   * Have vs Deserve gap for one outlet:
   * - Have  = current stock in the matrix cell
   * - Deserve = sold demand (or AI inbound transfer quantity when stock is aging elsewhere)
   * Gap = max(0, Deserve - Have)
   * Merges matrix shortages with smartRedistributionEngine inbound recommendations.
   */
  const buildAiPredictedLines = (outletCode: string): RefillOrderLine[] => {
    if (!outletCode) return [];

    const gapBySku = new Map<string, number>();

    // 1) Matrix Have vs Deserve (sold - stock)
    designCodes.forEach((w) => {
      const cell = report.matrix?.cells?.[outletCode]?.[w];
      if (!cell) return;
      const have = Number(cell.stock ?? 0);
      const deserve = Number(cell.sold ?? 0);
      const gap = Math.round(deserve - have);
      if (gap > 0) gapBySku.set(w, Math.max(gapBySku.get(w) || 0, gap));
    });

    // 2) AI transfer recommendations targeting this outlet (inbound demand)
    const inbound: SmartTransferRecommendation[] = (transfers || []).filter(
      (t) => t.toBranch === outletCode && t.quantity > 0,
    );
    inbound.forEach((t) => {
      const sku = t.sku || t.styleName;
      if (!sku) return;
      const prev = gapBySku.get(sku) || 0;
      gapBySku.set(sku, Math.max(prev, Math.round(t.quantity)));
    });

    const found: RefillOrderLine[] = [];
    let id = 1;
    gapBySku.forEach((qty, designCode) => {
      if (qty <= 0) return;
      found.push({
        id: id++,
        designCode,
        qty,
        price: defaultPrice,
        category: resolveCategory(designCode, report),
      });
    });

    // Sort by qty desc so highest gaps appear first
    found.sort((a, b) => b.qty - a.qty);
    return found.map((l, i) => ({ ...l, id: i + 1 }));
  };

  /** Manual / button-driven fill using the same AI + matrix gap logic. */
  const fillFromOutletShortage = () => {
    if (!order) return;
    if (!order.outlet) {
      setError('Select an outlet first.');
      return;
    }
    const found = buildAiPredictedLines(order.outlet);
    if (!found.length) {
      setError('No low-stock or AI-predicted demand gaps found for this outlet.');
      setAiHint('');
      return;
    }
    setError('');
    setAiHint(
      insightsStatus === 'ready'
        ? `AI + matrix: ${found.length} SKU gap(s) populated (Have vs Deserve).`
        : `Matrix gaps: ${found.length} SKU(s) populated. AI insights ${insightsStatus}.`,
    );
    setLines(found);
  };

  /** When the user changes the outlet, auto-populate predicted demand rows. */
  const onOutletChange = (outletCode: string) => {
    if (!order) return;
    updateOrder(order.id, { outlet: outletCode });
    setError('');
    if (!outletCode) {
      setAiHint('');
      return;
    }
    const found = buildAiPredictedLines(outletCode);
    if (found.length) {
      setLines(found);
      setAiHint(
        insightsStatus === 'ready'
          ? `Auto-filled ${found.length} AI-predicted demand row(s) for ${getBranchDisplayName(outletCode)}.`
          : `Auto-filled ${found.length} matrix demand gap(s) for ${getBranchDisplayName(outletCode)}.`,
      );
    } else {
      setAiHint(`No Have-vs-Deserve gaps for ${getBranchDisplayName(outletCode)}. Add rows manually.`);
    }
  };

  // Keep category in sync when design code is edited
  useEffect(() => {
    if (!order) return;
    const needsPatch = order.lines.some(
      (l) => l.designCode && !(l as RefillOrderLine & { category?: string }).category,
    );
    if (!needsPatch) return;
    setLines(
      order.lines.map((l) => ({
        ...l,
        category:
          (l as RefillOrderLine & { category?: string }).category ||
          resolveCategory(l.designCode, report),
      })),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order?.id]);

  const download = async () => {
    if (!order) return;
    const lines = order.lines.filter((l) => l.designCode.trim() && l.qty > 0);
    if (!order.supplier) return setError('Select a Supplier.');
    if (!lines.length) return setError('Add at least one design with quantity.');
    setError('');
    setBusy(true);
    try {
      await exportRefillInvoicePdf({
        poNumber: order.id,
        date: fmtDate(order.createdAt),
        outletName: order.outlet ? getBranchDisplayName(order.outlet) : ALL_OUTLETS_LABEL,
        supplierName: order.supplier,
        currency: 'BDT',
        lines: lines.map((l) => ({
          designCode: l.designCode,
          qty: l.qty,
          price: l.price,
          category: (l as RefillOrderLine & { category?: string }).category || resolveCategory(l.designCode, report),
        })),
        notes: order.notes,
      });
    } catch (e) {
      console.error(e);
      setError('PDF generation failed. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  const field =
    'w-full px-2.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs focus:outline-none focus:border-blue-500';
  const label =
    'text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1 mb-1';
  const th = 'border border-slate-300 dark:border-slate-700 px-2 py-2';
  const td = 'border border-slate-300 dark:border-slate-700';

  const lineAmounts = order ? order.lines.map((l) => l.qty * l.price) : [];
  const totalQty = order ? order.lines.reduce((s, l) => s + l.qty, 0) : 0;
  const grand = lineAmounts.reduce((s, a) => s + a, 0);

  const billFromName = order?.supplier || DEFAULT_SUPPLIER;
  const billToName = order?.outlet ? getBranchDisplayName(order.outlet) : ALL_OUTLETS_LABEL;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-gradient-to-r from-[#475569] via-[#172554] to-[#1e1b4b] border border-slate-800 p-4 sm:p-5 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-amber-400">
            <ClipboardList className="w-4 h-4" /> <span>Purchase Orders</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">New Order</h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Select an outlet to auto-fill AI predicted demand (Have vs Deserve). Edit, then download the
            corporate invoice PDF.
          </p>
        </div>
        <button
          onClick={() => {
            setError('');
            setAiHint('');
            createOrder({
              source: 'manual',
              lines: [{ id: 1, designCode: '', qty: 0, price: defaultPrice, category: '' }],
            });
          }}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white border border-blue-500 text-xs font-semibold cursor-pointer active:scale-95 transition"
        >
          <FilePlus2 className="w-4 h-4" /> <span>Create Manual Order</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-4 items-start">
        {/* Orders list */}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 overflow-hidden">
          <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200">
            Orders ({orders.length})
          </div>
          {orders.length === 0 ? (
            <div className="p-4 text-xs text-slate-500">
              No orders yet. Click <strong>Requisition</strong> in Refill Demand to auto-generate one, or
              create a manual order.
            </div>
          ) : (
            <ul className="max-h-[560px] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
              {orders.map((o) => (
                <li key={o.id}>
                  <button
                    onClick={() => {
                      setError('');
                      setAiHint('');
                      selectOrder(o.id);
                    }}
                    className={`w-full text-left px-4 py-3 cursor-pointer transition-colors ${
                      o.id === selectedId
                        ? 'bg-blue-50 dark:bg-blue-950/40'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-100 font-mono">
                        {o.id}
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          o.source === 'requisition'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {o.source === 'requisition' ? (
                          <Zap className="w-3 h-3" />
                        ) : (
                          <PencilLine className="w-3 h-3" />
                        )}
                        {o.source === 'requisition' ? 'Auto' : 'Manual'}
                      </span>
                    </div>
                    <div className="mt-1 text-[11px] text-slate-500 truncate">
                      {fmtDate(o.createdAt)} · {o.outlet ? getBranchDisplayName(o.outlet) : 'All outlets'}
                    </div>
                    <div className="text-[11px] text-slate-600 dark:text-slate-300">
                      {o.lines.length} item{o.lines.length === 1 ? '' : 's'} · BDT {money(orderTotal(o))}
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Premium corporate invoice editor */}
        {!order ? (
          <div className="rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 p-10 text-center text-sm text-slate-500">
            Select an order from the list.
          </div>
        ) : (
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 shadow-sm overflow-hidden">
            {/* Invoice chrome header */}
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 sm:px-5 py-3 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-slate-100 via-slate-50 to-blue-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950">
              <div className="flex items-center gap-3">
                <DiamondWorldLogo variant="full" className="h-8 w-auto max-w-[160px]" />
                <div>
                  <div className="text-sm font-bold text-slate-800 dark:text-slate-100 font-mono">
                    {order.id}
                  </div>
                  <div className="text-[10px] uppercase tracking-wider text-slate-500">
                    Purchase Order / Invoice · {BRAND.company}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={fillFromOutletShortage}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-bold cursor-pointer active:scale-95 transition"
                >
                  <Wand2 className="w-3.5 h-3.5" /> <span>AI Fill (Have vs Deserve)</span>
                </button>
                <button
                  onClick={() => {
                    if (window.confirm(`Delete ${order.id}?`)) deleteOrder(order.id);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-rose-300 text-rose-600 hover:bg-rose-50 text-xs font-bold cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" /> <span>Delete</span>
                </button>
              </div>
            </div>

            <div className="p-4 sm:p-5 space-y-4">
              {/* Controls row */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className={label}>
                    <Store className="w-3 h-3" /> Outlet
                  </label>
                  <select
                    className={field}
                    value={order.outlet}
                    onChange={(e) => onOutletChange(e.target.value)}
                  >
                    <option value="">{ALL_OUTLETS_LABEL}</option>
                    {outletOptions.map((o) => (
                      <option key={o.code} value={o.code}>
                        {o.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className={label}>
                    <Truck className="w-3 h-3" /> Supplier
                  </label>
                  <select
                    className={field}
                    value={order.supplier}
                    onChange={(e) => updateOrder(order.id, { supplier: e.target.value })}
                  >
                    {Array.from(new Set([...suppliers, order.supplier])).map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                  <div className="flex gap-1.5 mt-1.5">
                    <input
                      className={field}
                      placeholder="New supplier name"
                      value={newSupplier}
                      onChange={(e) => setNewSupplier(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') addSupplier();
                      }}
                    />
                    <button
                      onClick={addSupplier}
                      className="px-2.5 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold cursor-pointer"
                    >
                      Add
                    </button>
                  </div>
                </div>
                <div>
                  <label className={label}>Notes (optional)</label>
                  <input
                    className={field}
                    value={order.notes}
                    onChange={(e) => updateOrder(order.id, { notes: e.target.value })}
                    placeholder="Delivery note…"
                  />
                </div>
              </div>

              {aiHint && (
                <div className="flex items-start gap-2 rounded-xl border border-blue-200 dark:border-blue-900/50 bg-blue-50/80 dark:bg-blue-950/30 px-3 py-2 text-xs text-blue-800 dark:text-blue-200">
                  <Sparkles className="w-3.5 h-3.5 mt-0.5 shrink-0 text-blue-500" />
                  <span>{aiHint}</span>
                </div>
              )}

              {/* Premium Bill From / Bill To meta blocks */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="rounded-xl border border-slate-300 dark:border-slate-600 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-950 p-3.5 shadow-sm">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5">
                    Bill From / Supplier
                  </div>
                  <div className="text-sm font-bold text-[#0B2545] dark:text-slate-100">{billFromName}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{BRAND.company} · Central Hub</div>
                  <div className="text-[11px] text-slate-500">PO Date: {fmtDate(order.createdAt)}</div>
                </div>
                <div className="rounded-xl border border-slate-300 dark:border-slate-600 bg-gradient-to-br from-blue-50 to-slate-50 dark:from-slate-900 dark:to-blue-950/40 p-3.5 shadow-sm">
                  <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1.5">
                    Bill To / Outlet
                  </div>
                  <div className="text-sm font-bold text-[#0B2545] dark:text-slate-100">{billToName}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Requesting showroom / branch</div>
                  <div className="text-[11px] text-slate-500 font-mono">Ref: {order.id}</div>
                </div>
              </div>

              <datalist id="dmx-po-design-codes">
                {designCodes.map((d) => (
                  <option key={d} value={d} />
                ))}
              </datalist>

              {/* Itemized financial table */}
              <div className="overflow-x-auto rounded-xl border border-slate-300 dark:border-slate-700 shadow-sm">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#0B2545] text-white">
                      <th className={`${th} border-slate-500 w-10`}>SL</th>
                      <th className={`${th} border-slate-500 text-left`}>SKU</th>
                      <th className={`${th} border-slate-500 text-left w-28`}>Category</th>
                      <th className={`${th} border-slate-500 w-24`}>Qty</th>
                      <th className={`${th} border-slate-500 w-28`}>Price</th>
                      <th className={`${th} border-slate-500 w-32 text-right`}>Total Amount</th>
                      <th className={`${th} border-slate-500 w-10`} />
                    </tr>
                  </thead>
                  <tbody>
                    {order.lines.map((l, i) => {
                      const cat =
                        (l as RefillOrderLine & { category?: string }).category ||
                        resolveCategory(l.designCode, report);
                      return (
                        <tr
                          key={l.id}
                          className={i % 2 === 0 ? 'bg-white dark:bg-slate-950' : 'bg-slate-50 dark:bg-slate-900/80'}
                        >
                          <td className={`${td} text-center text-slate-500`}>{i + 1}</td>
                          <td className={`${td} p-1`}>
                            <input
                              list="dmx-po-design-codes"
                              className={field}
                              placeholder="e.g. Category_Nosepin7Stone"
                              value={l.designCode}
                              onChange={(e) =>
                                patchLine(l.id, {
                                  designCode: e.target.value,
                                  category: resolveCategory(e.target.value, report),
                                })
                              }
                            />
                          </td>
                          <td className={`${td} p-1`}>
                            <input
                              className={field}
                              placeholder="Category"
                              value={cat}
                              onChange={(e) => patchLine(l.id, { category: e.target.value } as Partial<RefillOrderLine>)}
                            />
                          </td>
                          <td className={`${td} p-1`}>
                            <input
                              type="number"
                              min={0}
                              className={`${field} text-right`}
                              value={l.qty || ''}
                              onChange={(e) => patchLine(l.id, { qty: toNum(e.target.value) })}
                            />
                          </td>
                          <td className={`${td} p-1`}>
                            <input
                              type="number"
                              min={0}
                              step="0.01"
                              className={`${field} text-right`}
                              value={l.price || ''}
                              onChange={(e) => patchLine(l.id, { price: toNum(e.target.value) })}
                            />
                          </td>
                          <td
                            className={`${td} px-2 text-right font-bold tabular-nums text-slate-800 dark:text-slate-100`}
                          >
                            {money(lineAmounts[i])}
                          </td>
                          <td className={`${td} text-center`}>
                            <button
                              onClick={() => removeLine(l.id)}
                              className="text-rose-500 hover:text-rose-700 cursor-pointer"
                              title="Remove row"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-100 dark:bg-slate-900 font-bold text-slate-800 dark:text-slate-100">
                      <td colSpan={3} className={`${td} px-2 py-2 text-right`}>
                        Total
                      </td>
                      <td className={`${td} px-2 text-right tabular-nums`}>
                        {totalQty.toLocaleString()}
                      </td>
                      <td className={td} />
                      <td className={`${td} px-2 text-right tabular-nums`}>{money(grand)}</td>
                      <td className={td} />
                    </tr>
                    <tr className="bg-emerald-100 dark:bg-emerald-900/40 font-extrabold text-slate-900 dark:text-emerald-100">
                      <td colSpan={5} className={`${td} px-2 py-2 text-right`}>
                        GRAND TOTAL (BDT)
                      </td>
                      <td className={`${td} px-2 text-right tabular-nums`}>{money(grand)}</td>
                      <td className={td} />
                    </tr>
                  </tfoot>
                </table>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <button
                  onClick={addLine}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Add row
                </button>
                <div className="flex items-center gap-3">
                  {error && <span className="text-xs font-semibold text-rose-600">{error}</span>}
                  <button
                    onClick={download}
                    disabled={busy}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-xs font-bold cursor-pointer active:scale-95 transition"
                  >
                    <Download className="w-4 h-4" />{' '}
                    <span>{busy ? 'Generating…' : 'Download Invoice PDF'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
