/**
 * Stock Turn Rate Dashboard — Odoo / Tally style hierarchical inventory grid.
 *
 * Layout:
 *   Metal family (DIAMOND / GOLD / PLATINUM)  →  Product type accordion  →  SKU leaf rows
 *
 * Preserves outlet KPIs, Top Fast/Slow cards, AIIntelligencePanel, and search filters.
 */
import React, { useCallback, useMemo, useState } from 'react';
import {
  Gauge,
  Search,
  Zap,
  Turtle,
  AlertTriangle,
  TrendingUp,
  Building2,
  ChevronRight,
  ChevronDown,
  ArrowDown,
  ArrowUp,
  Clock,
  Layers,
} from 'lucide-react';
import type { RedistributionReport, BranchSummary, WeightSummary } from '../types';
import { AIIntelligencePanel } from './AIIntelligencePanel';
import { useAIInsightsPanelProps } from '../store/aiInsightsStore';
import { getBranchDisplayName } from '../utils/dataIdentityEngine';
import {
  detectMetalCategory,
  type MetalCategory,
} from '../utils/smartRedistributionEngine';

/* -------------------------------------------------------------------------- */
/* Types                                                                       */
/* -------------------------------------------------------------------------- */

interface StockTurnRateDashboardProps {
  report: RedistributionReport;
  onSelectBranch?: (branch: string) => void;
  onNavigate?: (view: string, report?: string) => void;
}

type TurnStatus = 'FAST' | 'AVERAGE' | 'SLOW' | 'STOCKOUT';

interface TurnRow {
  branch: string;
  displayName: string;
  totalSold: number;
  totalCurrentStock: number;
  turnRate: number | null;
  status: TurnStatus;
  isWarehouse: boolean;
}

/** Have vs Deserve posture for a style line. */
type StockPosture = 'SHORTAGE' | 'STABILIZED' | 'OVERSTOCK';

/** Leaf SKU / style variant inside a product-type accordion. */
interface StyleVariantRow {
  id: string;
  sku: string;
  displayLabel: string;
  sold: number;
  stock: number;
  /** max(0, sold - stock) — units the network still needs */
  deserveGap: number;
  posture: StockPosture;
  turnRate: number | null;
  ageDays: number;
  isAging: boolean;
  velocity: WeightSummary['velocityCategory'];
}

/** Collapsible product-type group (Nosepins, Rings, …). */
interface ProductTypeGroup {
  key: string;
  label: string;
  variants: StyleVariantRow[];
  totalSold: number;
  totalStock: number;
  shortageCount: number;
  agingCount: number;
}

/** Top-level metal family section. */
interface MetalSection {
  metal: MetalCategory;
  title: string;
  productTypes: ProductTypeGroup[];
  totalSold: number;
  totalStock: number;
  styleCount: number;
  shortageCount: number;
}

/* -------------------------------------------------------------------------- */
/* Constants                                                                   */
/* -------------------------------------------------------------------------- */

const FAST_THRESHOLD = 6.5;
const SLOW_THRESHOLD = 3.2;
const AGING_DAYS = 90;

const METAL_ORDER: MetalCategory[] = ['Diamond', 'Gold', 'Platinum', 'Mixed', 'Unknown'];

const METAL_TITLE: Record<MetalCategory, string> = {
  Diamond: 'DIAMOND INVENTORY',
  Gold: 'GOLD INVENTORY',
  Platinum: 'PLATINUM INVENTORY',
  Mixed: 'MIXED METAL INVENTORY',
  Unknown: 'GENERAL / UNCLASSIFIED',
};

const METAL_ACCENT: Record<MetalCategory, string> = {
  Diamond: 'from-sky-800 to-slate-800 border-sky-700',
  Gold: 'from-amber-700 to-yellow-900 border-amber-600',
  Platinum: 'from-slate-600 to-slate-800 border-slate-500',
  Mixed: 'from-violet-800 to-slate-800 border-violet-600',
  Unknown: 'from-slate-600 to-slate-700 border-slate-500',
};

/* -------------------------------------------------------------------------- */
/* Pure helpers                                                                */
/* -------------------------------------------------------------------------- */

function computeTurn(b: BranchSummary): TurnRow {
  const sold = b.totalSold || 0;
  const stock = b.totalCurrentStock || 0;
  let turnRate: number | null = null;
  let status: TurnStatus = 'AVERAGE';

  if (stock === 0) {
    if (sold > 0) {
      turnRate = null;
      status = 'STOCKOUT';
    } else {
      turnRate = 0;
      status = 'SLOW';
    }
  } else {
    turnRate = sold / stock;
    if (turnRate >= FAST_THRESHOLD) status = 'FAST';
    else if (turnRate <= SLOW_THRESHOLD) status = 'SLOW';
    else status = 'AVERAGE';
  }

  return {
    branch: b.branch,
    displayName: getBranchDisplayName?.(b.branch) ?? b.branch,
    totalSold: sold,
    totalCurrentStock: stock,
    turnRate,
    status,
    isWarehouse: !!b.isWarehouse,
  };
}

function detectProductType(text: string): string {
  const t = text.toLowerCase();
  if (/\b(nosepin|nose\s*pin|nath|nathni)\b/.test(t)) return 'Nosepins';
  if (/\b(earring|ear\s*ring|jhumka|bali|stud)\b/.test(t)) return 'Earrings';
  if (/\b(ring|band|solitaire)\b/.test(t)) return 'Rings';
  if (/\b(necklace|haar|mangalsutra)\b/.test(t)) return 'Necklaces';
  if (/\b(pendant|locket)\b/.test(t)) return 'Pendants';
  if (/\b(bangle|kada|bracelet)\b/.test(t)) return 'Bangles & Bracelets';
  if (/\b(chain)\b/.test(t)) return 'Chains';
  if (/\b(set|parure)\b/.test(t)) return 'Sets';
  if (/\b(bracelet)\b/.test(t)) return 'Bracelets';
  return 'Other Styles';
}

function postureFromGap(sold: number, stock: number, unmetShortage: number): StockPosture {
  const gap = Math.max(0, unmetShortage > 0 ? unmetShortage : sold - stock);
  if (gap > 0 || (sold > 0 && stock === 0)) return 'SHORTAGE';
  if (stock > 0 && sold === 0) return 'OVERSTOCK';
  if (stock > sold * 1.5 && sold > 0) return 'OVERSTOCK';
  return 'STABILIZED';
}

function buildStyleRow(w: WeightSummary): StyleVariantRow {
  const sold = Number(w.soldQty) || 0;
  const stock = Number(w.currentStock) || 0;
  const gap = Math.max(0, Number(w.unmetShortage) || Math.max(0, sold - stock));
  const ageDays = Number(w.averageAgeDays) || 0;
  const turnRate = stock > 0 ? sold / stock : sold > 0 ? null : 0;

  return {
    id: w.weight,
    sku: w.weight,
    displayLabel: w.weight,
    sold,
    stock,
    deserveGap: gap,
    posture: postureFromGap(sold, stock, Number(w.unmetShortage) || 0),
    turnRate,
    ageDays,
    isAging: ageDays > AGING_DAYS,
    velocity: w.velocityCategory,
  };
}

function buildMetalHierarchy(weights: WeightSummary[]): MetalSection[] {
  type Bucket = Map<string, StyleVariantRow[]>;
  const byMetal = new Map<MetalCategory, Bucket>();

  weights.forEach((w) => {
    const metal = detectMetalCategory({
      category: '',
      itemName: w.weight,
      variant: w.weight,
      itemCode: w.weight,
      weight: w.weight,
    });
    const productType = detectProductType(w.weight);
    if (!byMetal.has(metal)) byMetal.set(metal, new Map());
    const types = byMetal.get(metal)!;
    if (!types.has(productType)) types.set(productType, []);
    types.get(productType)!.push(buildStyleRow(w));
  });

  return METAL_ORDER.filter((m) => byMetal.has(m)).map((metal) => {
    const types = byMetal.get(metal)!;
    const productTypes: ProductTypeGroup[] = Array.from(types.entries())
      .map(([key, variants]) => {
        const sorted = [...variants].sort((a, b) => b.deserveGap - a.deserveGap || b.sold - a.sold);
        return {
          key,
          label: key,
          variants: sorted,
          totalSold: sorted.reduce((s, v) => s + v.sold, 0),
          totalStock: sorted.reduce((s, v) => s + v.stock, 0),
          shortageCount: sorted.filter((v) => v.posture === 'SHORTAGE').length,
          agingCount: sorted.filter((v) => v.isAging).length,
        };
      })
      .sort((a, b) => b.totalSold - a.totalSold);

    return {
      metal,
      title: METAL_TITLE[metal],
      productTypes,
      totalSold: productTypes.reduce((s, p) => s + p.totalSold, 0),
      totalStock: productTypes.reduce((s, p) => s + p.totalStock, 0),
      styleCount: productTypes.reduce((s, p) => s + p.variants.length, 0),
      shortageCount: productTypes.reduce((s, p) => s + p.shortageCount, 0),
    };
  });
}

/* -------------------------------------------------------------------------- */
/* Presentational badges                                                       */
/* -------------------------------------------------------------------------- */

function HaveDeserveBadge({ posture, gap }: { posture: StockPosture; gap: number }) {
  if (posture === 'SHORTAGE') {
    return (
      <span className="inline-flex items-center gap-0.5 rounded-full bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-200 px-2 py-0.5 text-[10px] font-bold ring-1 ring-amber-300/60 dark:ring-amber-700/50">
        <ArrowDown className="w-3 h-3" />
        Shortage{gap > 0 ? ` · ${gap}` : ''}
      </span>
    );
  }
  if (posture === 'OVERSTOCK') {
    return (
      <span className="inline-flex items-center gap-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 px-2 py-0.5 text-[10px] font-bold ring-1 ring-slate-300/60">
        <ArrowUp className="w-3 h-3" />
        Overstock
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300 px-2 py-0.5 text-[10px] font-bold ring-1 ring-emerald-300/60 dark:ring-emerald-700/50">
      <ArrowUp className="w-3 h-3" />
      Stabilized
    </span>
  );
}

function AgingChip({ ageDays, isAging }: { ageDays: number; isAging: boolean }) {
  if (!ageDays || ageDays <= 0) {
    return <span className="text-[10px] text-slate-400">—</span>;
  }
  if (isAging) {
    return (
      <span className="inline-flex items-center gap-0.5 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 px-1.5 py-0.5 text-[10px] font-semibold">
        <Clock className="w-3 h-3" />
        {Math.round(ageDays)}d aging
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-0.5 text-[10px] text-slate-500 dark:text-slate-400">
      <Clock className="w-3 h-3" />
      {Math.round(ageDays)}d
    </span>
  );
}

function OutletStatusBadge({ status }: { status: TurnStatus }) {
  const map: Record<TurnStatus, string> = {
    FAST: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300',
    AVERAGE: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
    SLOW: 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300',
    STOCKOUT: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300',
  };
  const label: Record<TurnStatus, string> = {
    FAST: 'FAST',
    AVERAGE: 'AVG',
    SLOW: 'SLOW',
    STOCKOUT: 'STOCKOUT',
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${map[status]}`}>
      {label[status]}
    </span>
  );
}

/* -------------------------------------------------------------------------- */
/* Component                                                                   */
/* -------------------------------------------------------------------------- */

export const StockTurnRateDashboard: React.FC<StockTurnRateDashboardProps> = ({
  report,
  onSelectBranch,
  onNavigate,
}) => {
  const aiInsightsProps = useAIInsightsPanelProps();
  const [searchTerm, setSearchTerm] = useState('');
  /** Expanded product-type accordion keys: `${metal}::${productType}` */
  const [expandedTypes, setExpandedTypes] = useState<Set<string>>(new Set());
  /** Collapsed metal sections (all expanded by default) */
  const [collapsedMetals, setCollapsedMetals] = useState<Set<MetalCategory>>(new Set());

  const rows = useMemo(
    () => (report.branchSummaries || []).filter((b) => !b.isWarehouse).map(computeTurn),
    [report.branchSummaries],
  );

  const kpis = useMemo(() => {
    const totalSold = rows.reduce((s, r) => s + r.totalSold, 0);
    const totalStock = rows.reduce((s, r) => s + r.totalCurrentStock, 0);
    const overall = totalStock > 0 ? totalSold / totalStock : null;
    const fast = rows.filter((r) => r.status === 'FAST' || r.status === 'STOCKOUT').length;
    const slow = rows.filter((r) => r.status === 'SLOW').length;
    const stockout = rows.filter((r) => r.status === 'STOCKOUT').length;
    return { totalSold, totalStock, overall, fast, slow, stockout, outlets: rows.length };
  }, [rows]);

  const topFast = useMemo(
    () =>
      [...rows]
        .sort((a, b) => {
          const va = a.turnRate === null ? Number.POSITIVE_INFINITY : a.turnRate;
          const vb = b.turnRate === null ? Number.POSITIVE_INFINITY : b.turnRate;
          return vb - va;
        })
        .slice(0, 5),
    [rows],
  );

  const topSlow = useMemo(
    () =>
      [...rows]
        .filter((r) => r.turnRate !== null)
        .sort((a, b) => (a.turnRate ?? 0) - (b.turnRate ?? 0))
        .slice(0, 5),
    [rows],
  );

  const metalSections = useMemo(() => {
    const hierarchy = buildMetalHierarchy(report.weightSummaries || []);
    const q = searchTerm.trim().toLowerCase();
    if (!q) return hierarchy;

    return hierarchy
      .map((section) => {
        const productTypes = section.productTypes
          .map((pt) => {
            const variants = pt.variants.filter(
              (v) =>
                v.sku.toLowerCase().includes(q) ||
                v.displayLabel.toLowerCase().includes(q) ||
                pt.label.toLowerCase().includes(q) ||
                section.title.toLowerCase().includes(q),
            );
            if (!variants.length) return null;
            return {
              ...pt,
              variants,
              totalSold: variants.reduce((s, v) => s + v.sold, 0),
              totalStock: variants.reduce((s, v) => s + v.stock, 0),
              shortageCount: variants.filter((v) => v.posture === 'SHORTAGE').length,
              agingCount: variants.filter((v) => v.isAging).length,
            };
          })
          .filter((pt): pt is ProductTypeGroup => pt !== null);

        if (!productTypes.length) return null;
        return {
          ...section,
          productTypes,
          totalSold: productTypes.reduce((s, p) => s + p.totalSold, 0),
          totalStock: productTypes.reduce((s, p) => s + p.totalStock, 0),
          styleCount: productTypes.reduce((s, p) => s + p.variants.length, 0),
          shortageCount: productTypes.reduce((s, p) => s + p.shortageCount, 0),
        };
      })
      .filter((s): s is MetalSection => s !== null);
  }, [report.weightSummaries, searchTerm]);

  const toggleMetal = useCallback((metal: MetalCategory) => {
    setCollapsedMetals((prev) => {
      const next = new Set(prev);
      if (next.has(metal)) next.delete(metal);
      else next.add(metal);
      return next;
    });
  }, []);

  const toggleType = useCallback((key: string) => {
    setExpandedTypes((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  const expandAllTypes = useCallback(() => {
    const keys = new Set<string>();
    metalSections.forEach((s) =>
      s.productTypes.forEach((pt) => keys.add(`${s.metal}::${pt.key}`)),
    );
    setExpandedTypes(keys);
    setCollapsedMetals(new Set());
  }, [metalSections]);

  const collapseAllTypes = useCallback(() => {
    setExpandedTypes(new Set());
  }, []);

  const fmtRate = (r: number | null) => (r === null ? '∞' : r.toFixed(2) + '×');

  return (
    <div className="space-y-4">
      {/* Header + filter bar */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Gauge className="w-4 h-4 text-emerald-600" />
              Stock Turn Rate Dashboard
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Hierarchical inventory · Metal → Product type → Style · {kpis.outlets} retail outlets ·{' '}
              {report.period || 'Current'}
            </p>
          </div>
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search style, product type, metal…"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mt-4">
          {[
            { label: 'Total Sales', value: kpis.totalSold.toLocaleString(), icon: TrendingUp, color: 'text-blue-600' },
            { label: 'Total Stock', value: kpis.totalStock.toLocaleString(), icon: Building2, color: 'text-slate-600' },
            {
              label: 'Overall Turn',
              value: kpis.overall === null ? '∞' : kpis.overall.toFixed(2) + '×',
              icon: Gauge,
              color: 'text-emerald-600',
            },
            { label: 'Fast Outlets', value: String(kpis.fast), icon: Zap, color: 'text-emerald-600' },
            { label: 'Slow Outlets', value: String(kpis.slow), icon: Turtle, color: 'text-red-600' },
            { label: 'Stock-Out Risk', value: String(kpis.stockout), icon: AlertTriangle, color: 'text-amber-600' },
          ].map((k) => (
            <div
              key={k.label}
              className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 px-3 py-2"
            >
              <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-slate-500 font-semibold">
                <k.icon className={`w-3 h-3 ${k.color}`} />
                {k.label}
              </div>
              <div className={`text-lg font-bold mt-0.5 ${k.color}`}>{k.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* AI Intelligence panel — live from aiInsightsStore */}
      <AIIntelligencePanel
        {...aiInsightsProps}
        currencySymbol={report.categoryConfig?.currencySymbol}
        onNavigate={onNavigate}
        defaultCollapsed={false}
        expandToFullPage
      />

      {/* Top 5 Fast / Slow outlets */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-emerald-200 dark:border-emerald-900 shadow-sm overflow-hidden">
          <div className="bg-emerald-700 text-white px-4 py-2.5 flex items-center gap-2 text-sm font-bold">
            <Zap className="w-4 h-4" /> Top 5 Fast-Moving Outlets
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-emerald-50 dark:bg-emerald-950/30 text-emerald-900 dark:text-emerald-200">
                <th className="py-2 px-3 text-left">#</th>
                <th className="py-2 px-3 text-left">Outlet</th>
                <th className="py-2 px-3 text-right">Sales</th>
                <th className="py-2 px-3 text-right">Stock</th>
                <th className="py-2 px-3 text-right">Turn</th>
              </tr>
            </thead>
            <tbody>
              {topFast.map((r, i) => (
                <tr
                  key={r.branch}
                  className="border-t border-emerald-100 dark:border-emerald-900/40 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/20 cursor-pointer"
                  onClick={() => onSelectBranch?.(r.branch)}
                >
                  <td className="py-2 px-3 text-slate-500">{i + 1}</td>
                  <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-100">{r.displayName}</td>
                  <td className="py-2 px-3 text-right tabular-nums">{r.totalSold.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right tabular-nums">{r.totalCurrentStock.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right font-bold text-emerald-700 dark:text-emerald-400">
                    {fmtRate(r.turnRate)}
                  </td>
                </tr>
              ))}
              {topFast.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-4 text-center text-slate-400">
                    No outlet data
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl border border-rose-200 dark:border-rose-900 shadow-sm overflow-hidden">
          <div className="bg-rose-700 text-white px-4 py-2.5 flex items-center gap-2 text-sm font-bold">
            <Turtle className="w-4 h-4" /> Top 5 Slow-Moving Outlets
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-rose-50 dark:bg-rose-950/30 text-rose-900 dark:text-rose-200">
                <th className="py-2 px-3 text-left">#</th>
                <th className="py-2 px-3 text-left">Outlet</th>
                <th className="py-2 px-3 text-right">Sales</th>
                <th className="py-2 px-3 text-right">Stock</th>
                <th className="py-2 px-3 text-right">Turn</th>
              </tr>
            </thead>
            <tbody>
              {topSlow.map((r, i) => (
                <tr
                  key={r.branch}
                  className="border-t border-rose-100 dark:border-rose-900/40 hover:bg-rose-50/50 dark:hover:bg-rose-950/20 cursor-pointer"
                  onClick={() => onSelectBranch?.(r.branch)}
                >
                  <td className="py-2 px-3 text-slate-500">{i + 1}</td>
                  <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-100">{r.displayName}</td>
                  <td className="py-2 px-3 text-right tabular-nums">{r.totalSold.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right tabular-nums">{r.totalCurrentStock.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right font-bold text-rose-700 dark:text-rose-400">
                    {fmtRate(r.turnRate)}
                  </td>
                </tr>
              ))}
              {topSlow.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-4 text-center text-slate-400">
                    No outlet data
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Hierarchical inventory accordion */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-slate-600 dark:text-slate-300" />
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-white">
                Style Inventory Matrix
              </div>
              <div className="text-[10px] text-slate-500 uppercase tracking-wide">
                Metal family → Product type → SKU / carat variant
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={expandAllTypes}
              className="text-[11px] font-semibold px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              Expand all
            </button>
            <button
              type="button"
              onClick={collapseAllTypes}
              className="text-[11px] font-semibold px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              Collapse styles
            </button>
          </div>
        </div>

        {metalSections.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No style inventory found. Upload a stock sheet to populate the matrix.
          </div>
        ) : (
          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            {metalSections.map((section) => {
              const metalOpen = !collapsedMetals.has(section.metal);
              return (
                <div key={section.metal} className="bg-white dark:bg-slate-950">
                  {/* Metal family header */}
                  <button
                    type="button"
                    onClick={() => toggleMetal(section.metal)}
                    className={`w-full flex items-center justify-between gap-3 px-4 py-3 text-left bg-gradient-to-r ${METAL_ACCENT[section.metal]} text-white cursor-pointer`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      {metalOpen ? (
                        <ChevronDown className="w-4 h-4 shrink-0 opacity-90" />
                      ) : (
                        <ChevronRight className="w-4 h-4 shrink-0 opacity-90" />
                      )}
                      <span className="text-sm font-extrabold tracking-wide truncate">
                        {section.title}
                      </span>
                      <span className="text-[10px] font-semibold bg-white/15 rounded-full px-2 py-0.5 shrink-0">
                        {section.styleCount} styles · {section.productTypes.length} types
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] font-semibold shrink-0">
                      <span>Sales {section.totalSold.toLocaleString()}</span>
                      <span className="opacity-80">Stock {section.totalStock.toLocaleString()}</span>
                      {section.shortageCount > 0 && (
                        <span className="inline-flex items-center gap-0.5 rounded-full bg-amber-400/90 text-slate-900 px-2 py-0.5 text-[10px] font-bold">
                          <ArrowDown className="w-3 h-3" />
                          {section.shortageCount} short
                        </span>
                      )}
                    </div>
                  </button>

                  {metalOpen && (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
                      {section.productTypes.map((pt) => {
                        const typeKey = `${section.metal}::${pt.key}`;
                        const typeOpen = expandedTypes.has(typeKey);
                        return (
                          <div key={typeKey}>
                            {/* Product type accordion row */}
                            <button
                              type="button"
                              onClick={() => toggleType(typeKey)}
                              className="w-full flex items-center justify-between gap-3 px-4 py-2.5 text-left hover:bg-slate-50 dark:hover:bg-slate-900/60 cursor-pointer transition-colors"
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                {typeOpen ? (
                                  <ChevronDown className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                                ) : (
                                  <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                                )}
                                <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
                                  {pt.label}
                                </span>
                                <span className="text-[10px] text-slate-500 font-medium">
                                  {pt.variants.length} variant{pt.variants.length === 1 ? '' : 's'}
                                </span>
                                {pt.shortageCount > 0 && (
                                  <HaveDeserveBadge posture="SHORTAGE" gap={pt.shortageCount} />
                                )}
                                {pt.agingCount > 0 && (
                                  <span className="inline-flex items-center gap-0.5 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 px-1.5 py-0.5 text-[10px] font-semibold">
                                    <Clock className="w-3 h-3" />
                                    {pt.agingCount} aging
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-4 text-[11px] tabular-nums text-slate-600 dark:text-slate-300 shrink-0">
                                <span>
                                  <span className="text-slate-400 mr-1">Sales</span>
                                  {pt.totalSold.toLocaleString()}
                                </span>
                                <span>
                                  <span className="text-slate-400 mr-1">Stock</span>
                                  {pt.totalStock.toLocaleString()}
                                </span>
                              </div>
                            </button>

                            {/* Leaf SKU table — only when expanded */}
                            {typeOpen && (
                              <div className="overflow-x-auto border-t border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/40">
                                <table className="w-full text-xs border-collapse">
                                  <thead>
                                    <tr className="bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-300">
                                      <th className="py-2 px-3 text-left font-semibold w-10">#</th>
                                      <th className="py-2 px-3 text-left font-semibold">SKU / Style</th>
                                      <th className="py-2 px-3 text-right font-semibold">Have</th>
                                      <th className="py-2 px-3 text-right font-semibold">Sold</th>
                                      <th className="py-2 px-3 text-center font-semibold">Have vs Deserve</th>
                                      <th className="py-2 px-3 text-right font-semibold">Turn</th>
                                      <th className="py-2 px-3 text-left font-semibold">Aging</th>
                                      <th className="py-2 px-3 text-left font-semibold">Velocity</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {pt.variants.map((v, idx) => (
                                      <tr
                                        key={v.id}
                                        className={`border-t border-slate-100 dark:border-slate-800/60 ${
                                          v.isAging
                                            ? 'bg-rose-50/70 dark:bg-rose-950/25'
                                            : v.posture === 'SHORTAGE'
                                              ? 'bg-amber-50/40 dark:bg-amber-950/15'
                                              : idx % 2 === 0
                                                ? 'bg-white dark:bg-slate-950'
                                                : 'bg-slate-50/80 dark:bg-slate-900/40'
                                        }`}
                                      >
                                        <td className="py-2 px-3 text-slate-400">{idx + 1}</td>
                                        <td className="py-2 px-3 font-mono text-[11px] font-semibold text-slate-800 dark:text-slate-100">
                                          {v.displayLabel}
                                        </td>
                                        <td className="py-2 px-3 text-right tabular-nums font-medium">
                                          {v.stock.toLocaleString()}
                                        </td>
                                        <td className="py-2 px-3 text-right tabular-nums">
                                          {v.sold.toLocaleString()}
                                        </td>
                                        <td className="py-2 px-3 text-center">
                                          <HaveDeserveBadge posture={v.posture} gap={v.deserveGap} />
                                        </td>
                                        <td className="py-2 px-3 text-right tabular-nums font-semibold text-slate-700 dark:text-slate-200">
                                          {fmtRate(v.turnRate)}
                                        </td>
                                        <td className="py-2 px-3">
                                          <AgingChip ageDays={v.ageDays} isAging={v.isAging} />
                                        </td>
                                        <td className="py-2 px-3 text-[10px] text-slate-500 dark:text-slate-400">
                                          {v.velocity}
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Compact outlet ranking (secondary, non-overwhelming) */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2">
          <Building2 className="w-3.5 h-3.5" />
          Outlet Turn Ranking
          <span className="font-normal text-slate-400">({rows.length} showrooms)</span>
        </div>
        <div className="overflow-x-auto max-h-64 overflow-y-auto">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-slate-100 dark:bg-slate-900">
              <tr className="text-slate-600 dark:text-slate-300">
                <th className="py-2 px-3 text-left font-semibold">Outlet</th>
                <th className="py-2 px-3 text-right font-semibold">Sales</th>
                <th className="py-2 px-3 text-right font-semibold">Stock</th>
                <th className="py-2 px-3 text-right font-semibold">Turn</th>
                <th className="py-2 px-3 text-center font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {[...rows]
                .sort((a, b) => {
                  const va = a.turnRate === null ? Number.POSITIVE_INFINITY : a.turnRate;
                  const vb = b.turnRate === null ? Number.POSITIVE_INFINITY : b.turnRate;
                  return vb - va;
                })
                .map((r) => (
                  <tr
                    key={r.branch}
                    className="border-t border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer"
                    onClick={() => onSelectBranch?.(r.branch)}
                  >
                    <td className="py-1.5 px-3 font-medium text-slate-800 dark:text-slate-100">
                      {r.displayName}
                    </td>
                    <td className="py-1.5 px-3 text-right tabular-nums">{r.totalSold.toLocaleString()}</td>
                    <td className="py-1.5 px-3 text-right tabular-nums">
                      {r.totalCurrentStock.toLocaleString()}
                    </td>
                    <td className="py-1.5 px-3 text-right font-semibold tabular-nums">
                      {fmtRate(r.turnRate)}
                    </td>
                    <td className="py-1.5 px-3 text-center">
                      <OutletStatusBadge status={r.status} />
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
