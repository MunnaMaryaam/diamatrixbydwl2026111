import React, { useEffect, useRef } from 'react';
import { D } from './diamatrixLogoData';

/**
 * Particle system using the same physics rules as OpenAI GPT-Astra:
 *
 *   drag = 2.3 / sqrt(mass)
 *   disp  = disp * exp(-age) + vel * (exp(-age) - exp(-drag*age)) / (drag - 1)
 *   vel  *= exp(-drag * age)
 *
 * Rest positions form the DiaMatrix logo. Mouse applies impulse only.
 * Between impulses the analytical solution is evaluated — no per-frame spring.
 */
export const DiaMatrixVortexCanvas: React.FC<{ className?: string }> = ({
  className,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;

    const LW = D.w;
    const LH = D.h;

    function unpack(b: string, n: number): Uint8Array {
      const s = atob(b);
      const o = new Uint8Array(n);
      for (let i = 0; i < n; i++) {
        o[i] = (s.charCodeAt(i >> 3) >> (7 - (i & 7))) & 1;
      }
      return o;
    }

    const SM = unpack(D.sm, LW * LH);
    const DM = unpack(D.dm, LW * LH);
    const SPT: [number, number][] = [];
    const DPT: [number, number][] = [];
    for (let i = 0; i < LW * LH; i++) {
      if (SM[i]) SPT.push([i % LW, (i / LW) | 0]);
      else if (DM[i]) DPT.push([i % LW, (i / LW) | 0]);
    }

    type Branch = { a: number; b: number; p: number[][] };
    const BR = D.br as Branch[];
    const INC: { b: number; end: number }[][] = [[], []];
    BR.forEach((b, i) => {
      if (b.a >= 0) INC[b.a].push({ b: i, end: 0 });
      if (b.b >= 0) INC[b.b].push({ b: i, end: 1 });
    });
    const BW = BR.map((b) => b.p.reduce((s, q) => s + q[2], 0));
    const BWT = BW.reduce((a, c) => a + c, 0);
    function pickBranch() {
      let k = Math.random() * BWT;
      let i = 0;
      while (k > BW[i] && i < BR.length - 1) {
        k -= BW[i];
        i++;
      }
      return i;
    }

    function sprite(): HTMLCanvasElement {
      const s = 64;
      const c = document.createElement('canvas');
      c.width = c.height = s;
      const g = c.getContext('2d')!;
      const r = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      r.addColorStop(0, 'rgba(235,248,255,1)');
      r.addColorStop(0.12, 'rgba(140,210,255,.95)');
      r.addColorStop(0.35, 'rgba(40,130,255,.35)');
      r.addColorStop(1, 'rgba(20,80,255,0)');
      g.fillStyle = r;
      g.fillRect(0, 0, s, s);
      return c;
    }
    const SP = sprite();

    /**
     * Astra particle state (same as OpenAI shader):
     *   rx, ry  – rest position on logo
     *   dx, dy  – displacement from rest  (state.xy)
     *   vx, vy  – velocity                (state.zw)
     *   mass    – 0.65 (small) … 2.4 (large)
     *   drag    – 2.3 / sqrt(mass)
     *   impulseTime – time of last impulse → age = now - impulseTime
     */
    type Particle = {
      rx: number;
      ry: number;
      dx: number;
      dy: number;
      vx: number;
      vy: number;
      mass: number;
      drag: number;
      impulseTime: number;
      s: number;
      a: number;
      ph: number;
      star: boolean;
      flow: boolean;
      bi?: number;
      u?: number;
      dir?: number;
      du?: number;
      off?: number;
      born: number;
      e: number;
    };

    let W = 0;
    let H = 0;
    let dpr = 1;
    let P: Particle[] = [];
    let scale = 1;
    let OX = 0;
    let OY = 0;
    let CX = 0;
    let CY = 0;
    let last = 0;
    let raf = 0;

    const mouse = {
      x: -9999,
      y: -9999,
      px: -9999,
      py: -9999,
      on: false,
      k: 0,
      vx: 0,
      vy: 0,
    };
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

    function placeFlow(q: Particle, t: number) {
      q.bi = pickBranch();
      q.u = Math.random() * (BR[q.bi!].p.length - 1);
      q.dir = Math.random() < 0.5 ? -1 : 1;
      q.born = t || 0;
    }

    /** Exact OpenAI Astra analytical solution */
    function evalAstra(
      dx: number,
      dy: number,
      vx: number,
      vy: number,
      age: number,
      drag: number,
    ): { dx: number; dy: number; vx: number; vy: number } {
      if (age < 1e-5) return { dx, dy, vx, vy };
      const e1 = Math.exp(-age);
      const e2 = Math.exp(-drag * age);
      const inv = 1 / (drag - 1);
      return {
        dx: dx * e1 + vx * (e1 - e2) * inv,
        dy: dy * e1 + vy * (e1 - e2) * inv,
        vx: vx * e2,
        vy: vy * e2,
      };
    }

    function layout() {
      const r = cv.getBoundingClientRect();
      dpr = Math.min(devicePixelRatio || 1, 2);
      W = r.width;
      H = r.height;
      cv.width = W * dpr;
      cv.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      scale = Math.min(W / LW, H / LH) * 0.82;
      OX = (W - LW * scale) / 2;
      OY = (H - LH * scale) / 2;
      CX = OX + (LW * scale) / 2;
      CY = OY + (LH * scale) / 2;

      const N = W < 640 ? 4200 : 8500;
      const old = P;
      P = [];
      const m0 = reduce ? 0 : 1;

      for (let i = 0; i < N; i++) {
        const o = old[i];
        // size → mass (Astra values: large 2.4, small 0.65)
        const s = 0.45 + Math.random() * 1.1;
        const mass = 0.65 + ((s - 0.45) / 1.1) * (2.4 - 0.65);
        const drag = 2.3 / Math.sqrt(mass);

        const q: Particle = {
          rx: o ? o.rx : Math.random() * W,
          ry: o ? o.ry : Math.random() * H,
          dx: o ? o.dx : 0,
          dy: o ? o.dy : 0,
          vx: o ? o.vx : 0,
          vy: o ? o.vy : 0,
          mass,
          drag,
          impulseTime: -1e9,
          s,
          a: 0.5 + Math.random() * 0.5,
          ph: Math.random() * 6.28,
          star: Math.random() < 0.05,
          flow: false,
          born: -1e9,
          e: 1,
        };

        if (Math.random() < 0.5) {
          q.flow = true;
          placeFlow(q, -1e9);
          // slower path travel (was 9–22)
          q.du = (2.2 + Math.random() * 3.5) * m0;
          q.off = (Math.random() * 2 - 1) * 1.05;
        } else {
          const m =
            Math.random() < 0.2
              ? DPT[(Math.random() * DPT.length) | 0]
              : SPT[(Math.random() * SPT.length) | 0];
          q.rx = OX + (m[0] + Math.random()) * scale;
          q.ry = OY + (m[1] + Math.random()) * scale;
        }
        P.push(q);
      }
    }

    function frame(t: number) {
      const now = t * 0.001;
      const dt = Math.min(0.05, (t - (last || t)) / 1000);
      last = t;

      ctx.globalCompositeOperation = 'source-over';
      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = 'lighter';

      mouse.k += ((mouse.on ? 1 : 0) - mouse.k) * (mouse.on ? 0.2 : 0.045);
      mouse.vx *= 0.87;
      mouse.vy *= 0.87;

      const R = Math.max(130, Math.min(W, H) * 0.3);
      const R2 = R * R;
      const k = mouse.k;
      const sz = Math.max(3.6, scale * 0.027);

      for (let i = 0; i < P.length; i++) {
        const p = P[i];

        // update rest position for flow particles
        if (p.flow) {
          let B = BR[p.bi!];
          let L = B.p;
          let m = L.length - 1;
          let snap = false;

          p.u! +=
            p.dir! *
            p.du! *
            dt *
            Math.min(
              2.3,
              10 / Math.max(4, L[Math.max(0, Math.min(m, p.u! | 0))][2]),
            );

          if (p.u! >= m || p.u! <= 0) {
            const end = p.u! >= m ? 1 : 0;
            const node = end ? B.b : B.a;
            if (node >= 0) {
              let c = INC[node].filter(
                (o) => !(o.b === p.bi && o.end === end),
              );
              if (!c.length) c = INC[node];
              const o = c[(Math.random() * c.length) | 0];
              p.bi = o.b;
              p.dir = o.end ? -1 : 1;
              p.u = o.end ? BR[o.b].p.length - 1 : 0;
            } else {
              placeFlow(p, t);
              snap = true;
            }
            B = BR[p.bi!];
            L = B.p;
            m = L.length - 1;
          }

          const su = Math.max(0, Math.min(m - 0.001, p.u!));
          const i0 = su | 0;
          const f = su - i0;
          const A = L[i0];
          const C = L[i0 + 1] || A;
          const dx = C[0] - A[0];
          const dy = C[1] - A[1];
          const ln = Math.hypot(dx, dy) || 1;
          const rr = (A[2] + (C[2] - A[2]) * f) * p.off!;
          const cx = A[0] + dx * f;
          const cy = A[1] + dy * f;
          let gx = cx - (dy / ln) * rr;
          let gy = cy + (dx / ln) * rr;
          if (!SM[(gy | 0) * LW + (gx | 0)]) {
            gx = cx;
            gy = cy;
          }
          p.rx = OX + (gx + 0.5) * scale;
          p.ry = OY + (gy + 0.5) * scale;

          const fe = Math.min(
            B.a < 0 ? su / 10 : 1,
            B.b < 0 ? (m - su) / 10 : 1,
          );
          p.e =
            Math.max(0, Math.min(1, fe)) *
            Math.min(1, (t - p.born) / 550);
          if (snap) {
            p.dx = p.dy = p.vx = p.vy = 0;
            p.impulseTime = -1e9;
          }
        }

        const rx = p.rx;
        const ry = p.ry;

        // mouse impulse — strength depends on how fast the mouse is moving
        if (k > 0.02) {
          const px = rx + p.dx;
          const py = ry + p.dy;
          const mdx = px - mouse.x;
          const mdy = py - mouse.y;
          const d2 = mdx * mdx + mdy * mdy;
          if (d2 < R2) {
            const d = Math.sqrt(d2) + 0.001;
            const f = 1 - d / R;
            const f2 = f * f;
            const mv = Math.hypot(mouse.vx, mouse.vy);

            // only apply force when mouse is actually moving
            if (mv > 0.35) {
              // evaluate state to "now", then add impulse
              const age = Math.max(0, now - p.impulseTime);
              const cur = evalAstra(p.dx, p.dy, p.vx, p.vy, age, p.drag);
              p.dx = cur.dx;
              p.dy = cur.dy;
              p.vx = cur.vx;
              p.vy = cur.vy;

              const nx = mdx / d;
              const ny = mdy / d;
              // soft radial component (very weak when mouse is slow)
              const speedFactor = Math.min(1.4, mv / 12);
              const push =
                ((3 + f * 8) * k * f2 * speedFactor) / p.mass;
              p.vx += nx * push;
              p.vy += ny * push;
              // main force = mouse velocity direction & magnitude
              p.vx += (mouse.vx * 0.35 * f * k * speedFactor) / p.mass;
              p.vy += (mouse.vy * 0.35 * f * k * speedFactor) / p.mass;
              p.impulseTime = now;
            }
          }
        }

        // evaluate analytical solution for current age
        const age = Math.max(0, now - p.impulseTime);
        const st = evalAstra(p.dx, p.dy, p.vx, p.vy, age, p.drag);
        const x = rx + st.dx;
        const y = ry + st.dy;

        const speed = Math.hypot(st.vx, st.vy);
        const heat = Math.min(1, speed / 40);
        const fl = p.star
          ? Math.pow(Math.max(0, Math.sin(t * 0.0013 + p.ph * 3)), 13)
          : 0;
        const s = sz * p.s * (1 + heat * 0.55 + fl * 2.0);
        ctx.globalAlpha = Math.min(
          1,
          p.a *
            p.e *
            (0.7 + heat * 0.4 + fl) *
            (0.85 + 0.15 * Math.sin(t * 0.0035 * p.s + p.ph)),
        );
        ctx.drawImage(SP, x - s, y - s, s * 2, s * 2);
      }

      ctx.globalAlpha = 1;
      if (k > 0.01) {
        const g = ctx.createRadialGradient(
          mouse.x,
          mouse.y,
          0,
          mouse.x,
          mouse.y,
          R * 0.42,
        );
        g.addColorStop(0, `rgba(180,220,255,${0.09 * k})`);
        g.addColorStop(1, 'rgba(40,120,255,0)');
        ctx.fillStyle = g;
        ctx.fillRect(mouse.x - R, mouse.y - R, R * 2, R * 2);
      }

      raf = requestAnimationFrame(frame);
    }

    function pos(e: PointerEvent) {
      const r = cv.getBoundingClientRect();
      const nx = e.clientX - r.left;
      const ny = e.clientY - r.top;
      mouse.vx = nx - mouse.x;
      mouse.vy = ny - mouse.y;
      mouse.px = mouse.x;
      mouse.py = mouse.y;
      mouse.x = nx;
      mouse.y = ny;
    }

    const onEnter = (e: PointerEvent) => {
      pos(e);
      mouse.on = true;
    };
    const onMove = (e: PointerEvent) => {
      pos(e);
      mouse.on = true;
    };
    const onDown = (e: PointerEvent) => {
      pos(e);
      mouse.on = true;
    };
    const onOff = () => {
      mouse.on = false;
    };

    cv.addEventListener('pointerenter', onEnter);
    cv.addEventListener('pointermove', onMove);
    cv.addEventListener('pointerdown', onDown);
    cv.addEventListener('pointerleave', onOff);
    cv.addEventListener('pointercancel', onOff);
    cv.addEventListener('pointerup', onOff);

    const ro = new ResizeObserver(layout);
    ro.observe(cv);
    layout();
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      cv.removeEventListener('pointerenter', onEnter);
      cv.removeEventListener('pointermove', onMove);
      cv.removeEventListener('pointerdown', onDown);
      cv.removeEventListener('pointerleave', onOff);
      cv.removeEventListener('pointercancel', onOff);
      cv.removeEventListener('pointerup', onOff);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={className}
      role="img"
      aria-label="Particles forming the DW monogram with a diamond"
      style={{
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        display: 'block',
        cursor: 'crosshair',
        touchAction: 'none',
      }}
    />
  );
};
