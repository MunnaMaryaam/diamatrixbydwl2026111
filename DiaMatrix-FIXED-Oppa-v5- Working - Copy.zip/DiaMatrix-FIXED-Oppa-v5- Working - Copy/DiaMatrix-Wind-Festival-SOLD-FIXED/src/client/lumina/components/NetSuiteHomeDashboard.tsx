import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import PALM_SRC from '../assets/dashboard/palm-sprite.webp?url';
import SCENE_EDGE_L from '../assets/dashboard/scene-edge-left.webp?url';
import SCENE_EDGE_R from '../assets/dashboard/scene-edge-right.webp?url';
import SCENE_EDGE_T from '../assets/dashboard/scene-edge-top.webp?url';
import SCENE_CLEAN from '../assets/dashboard/scene-clean.webp?url'; // scene with the hanging modules cut out (they are the thread-/tag-/tassel-*.webp pieces)
import SCENE_ORIG from '../assets/dashboard/scene.webp?url'; // original picture with the modules baked in: safe fallback if the pieces cannot be loaded
import { RIP_N, RippleSystem, childAbs, swing, tagAbs, tasselAbs, type Motion } from '../utils/hubSway';
import { createPortal } from 'react-dom';
import type { RawInventoryRecord, RedistributionReport, SalesTimeframe } from '../types';
import { AIIntelligencePanel } from './AIIntelligencePanel';
import { useAIInsightsPanelProps } from '../store/aiInsightsStore';

/**
 * Cockpit home dashboard (light theme).
 *
 * WHY SHADOW DOM: index.css contains hundreds of global theme rules
 * (html.theme-light .software-shell span/button/p ..., [style*="#14B4E8"], metallic /
 * forest-luxury / corporate-blue overrides). Those rules were recolouring buttons and
 * text on this page, which caused the unreadable text / mismatched colours.
 * Rendering the cockpit inside a shadow root makes it immune to every global rule, so
 * the colours below are exactly what is shown, in every theme.
 *
 * AI Intelligence Panel is rendered OUTSIDE the shadow root so it can use the
 * normal app theme + React portals, and so it recomputes live from `rawRecords`
 * whenever Daily Intake finishes (universalParser → onImportRecords → setRawRecords).
 */

interface NetSuiteHomeDashboardProps {
  report: RedistributionReport;
  onNavigateView: (view: any, report?: any) => void;
  onSelectBranch?: (branch: string) => void;
  onSelectWeight?: (weight: string) => void;
  selectedTimeframe: SalesTimeframe;
  onTimeframeChange: (tf: SalesTimeframe) => void;
  onOpenDailyUpload: () => void;
  /** Working dataset that feeds the AI Intelligence & Insights panel. */
  rawRecords?: RawInventoryRecord[];
  /** Guest / Educational: pure view-only — no module navigation or intake. */
  readOnly?: boolean;
}

const TF_OPTIONS: SalesTimeframe[] = ['1M', '3M', '6M', '9M', '1Y', '2Y'];

/* ─────────────────────────── Shadow root host ─────────────────────────── */
const ShadowScope: React.FC<{ css: string; children: React.ReactNode }> = ({ css, children }) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const [root, setRoot] = useState<ShadowRoot | null>(null);
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    setRoot(host.shadowRoot ?? host.attachShadow({ mode: 'open' }));
  }, []);
  return (
    <div ref={hostRef} style={{ display: 'block', width: '100%' }}>
      {root && createPortal(<><style>{css}</style>{children}</>, root)}
    </div>
  );
};

/* ───────────────────────────── Icons (inline) ───────────────────────────── */
const ICONS: Record<string, React.ReactNode> = {
  cockpit: <><rect x="3" y="4" width="18" height="12" rx="2" /><path d="M8 20h8M12 16v4" /></>,
  matrix: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M3 10h18M3 15h18M9 4v16M15 4v16" /></>,
  movement: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  refill: <><path d="M12 2l9 5v10l-9 5-9-5V7z" /><path d="M3 7l9 5 9-5M12 12v10" /></>,
  showrooms: <><path d="M5 21V4a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v17M15 9h3a1 1 0 0 1 1 1v11M3 21h18" /><path d="M9 7h2M9 11h2M9 15h2" /></>,
  design: <><path d="M6 3h12l4 6-10 12L2 9z" /><path d="M2 9h20M9 3l-2 6 5 12M15 3l2 6-5 12" /></>,
  trend: <path d="M3 17l6-6 4 4 8-8M15 7h6v6" />,
  bell: <><path d="M6 9a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8" /><path d="M10 21a2 2 0 0 0 4 0" /></>,
};

const Icon: React.FC<{ name: string; size?: number }> = ({ name, size = 18 }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {ICONS[name]}
  </svg>
);

/* ───────────────────────────── Helpers ───────────────────────────── */
function heatColor(t: number): string {
  const stops = [
    { at: 0.0, c: [234, 244, 255] }, { at: 0.2, c: [191, 222, 250] }, { at: 0.4, c: [118, 177, 240] },
    { at: 0.6, c: [43, 120, 214] }, { at: 0.8, c: [14, 72, 160] }, { at: 1.0, c: [11, 37, 69] },
  ];
  const v = Math.min(1, Math.max(0, t));
  for (let i = 1; i < stops.length; i += 1) {
    if (v <= stops[i].at) {
      const a = stops[i - 1]; const b = stops[i];
      const k = (v - a.at) / (b.at - a.at);
      const rgb = a.c.map((ch, idx) => Math.round(ch + (b.c[idx] - ch) * k));
      return `rgb(${rgb[0]}, ${rgb[1]}, ${rgb[2]})`;
    }
  }
  return 'rgb(11, 37, 69)';
}
/** Always pick black or white text that is readable on the given rgb() background. */
function readableOn(bg: string): string {
  const m = bg.match(/\d+/g);
  if (!m) return '#0B2545';
  const [r, g, b] = m.map(Number);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.55 ? '#0B2545' : '#FFFFFF';
}

/* ───────────────────────── Neural tree hub (SVG) ───────────────────────── */
type HubNode = { id: string; lines: string[]; icon: string; x: number; y: number; ox: number; oy: number; view: string; report?: string };
const HW = 760;
const HH = 790;
const VB_TOP = -340; // extra sky above the tree
const HEX_R = 74;
const PALM_BOX = { x: 133.9, y: 36.0, w: 487.4, h: 560 }; // palm sprite placement (tree units); trunk centre sits on x=380
// where each module's kite string is tied on the palm crown (relative to the module centre)
const PALM_TIES: Record<string, [number, number]> = {"cockpit": [-25.1, 101.0], "design": [99.9, 29.0], "matrix": [-75.1, 72.0], "movement": [-73.1, -74.0], "showrooms": [53.9, -89.0], "refill": [-52.1, -90.0]};
/* Picture scene: the whole hub (sky, diamond palm, soil, roots) is ONE picture, and the modules hang from its leaves on golden threads.
   Set SCENE_IMAGE to false to go back to the old drawn tree. Picture pixels -> tree units: x * SCENE_K, y * SCENE_K + SCENE_Y0. */
const SCENE_IMAGE = true;
const SCENE_PX = { w: 1184, h: 2096 };
const SCENE_K = HW / SCENE_PX.w;
const SCENE_H = SCENE_PX.h * SCENE_K;
const SCENE_Y0 = HH - SCENE_H; // picture bottom sits on the bottom of the card
const SCENE_SIDE = 900; // how far the picture's edge is softly extended outwards on wide cards
const SCENE_FADE = 36; // picture pixels at the outer edge that blend into the extension (no visible seam)
const SCENE_PAD = 1400; // extra pixels in the top extension strip
// Edge blend: the picture dissolves into its soft extension. The blend is narrow beside tags (so no tag is ever faded) and wide elsewhere (so there is no visible seam).
const FADE_ROW = 32;
const fadeW = (y: number, a: number, b: number) => {
  const d = y < a ? a - y : y > b ? y - b : 0;
  return SCENE_FADE + Math.min(1, d / 140) * (170 - SCENE_FADE);
};
const FADE_ROWS = Array.from({ length: Math.ceil(SCENE_PX.h / FADE_ROW) }, (_, i) => {
  const yc = i * FADE_ROW + FADE_ROW / 2;
  return { y: i * FADE_ROW, wl: fadeW(yc, 900, 1210), wr: fadeW(yc, 835, 1450) };
});
const SCENE_HEX_R = 54; // tag size (same as the tags in the picture)
// The six module tags are part of the picture itself (pixel-exact). Each one gets an invisible click area (outline in picture pixels)
// plus the obstacle badge position. Nothing is drawn on top of the tag, so there is no ghosting or misalignment.
const SCENE_TAGS: Record<string, { pts: string; badge: [number, number] }> = {
  cockpit: { pts: '583,757 708,825 705,960 585,1025 462,955 460,825', badge: [680, 850] },
  design: { pts: '200,912 340,965 338,1120 205,1200 65,1125 62,965', badge: [315, 990] },
  matrix: { pts: '968,845 1105,900 1105,1055 970,1125 835,1050 833,905', badge: [1080, 925] },
  movement: { pts: '778,1068 887,1125 887,1235 780,1300 670,1235 668,1128', badge: [862, 1148] },
  showrooms: { pts: '355,1175 478,1235 478,1355 355,1418 237,1352 235,1235', badge: [452, 1255] },
  refill: { pts: '985,1190 1107,1250 1107,1375 985,1445 870,1380 868,1250', badge: [1082, 1272] },
};
/* Hanging modules: each one is cut out of the picture into pieces (thread, tag, tassels) that move on their own.
   See utils/hubSway.ts for the motion model. Coordinates are picture pixels; "tie" = knot where the thread meets the tree,
   "eye" = where the tag hangs from the thread's end (the tag turns around this point). amp = how far the thread swings (degrees),
   T = length of its main swing in seconds, seed = makes every module move differently. */
const SPRITES = import.meta.glob('../assets/dashboard/{tag,thread,tassel}-*.webp', { eager: true, query: '?url', import: 'default' }) as Record<string, string>;
const spr = (n: string): string => SPRITES[`../assets/dashboard/${n}.webp`];
type Piece = { n: string; x: number; y: number; w: number; h: number };
type HubMod = { thread?: Piece; tag: Piece; tie: [number, number]; eye: [number, number]; motion: Motion; tassels?: { piece: Piece; at: [number, number] }[]; parent?: string };
const HUB_MODS: Record<string, HubMod> = {
  cockpit: { thread: { n: 'thread-cockpit', x: 567, y: 573, w: 36, h: 186 }, tag: { n: 'tag-cockpit', x: 452, y: 741, w: 263, h: 286 }, tie: [589.5, 584], eye: [585, 745], motion: { amp: 1.9, seed: 1, T: 8.4 } },
  design: {
    thread: { n: 'thread-design', x: 186, y: 621, w: 60, h: 293 }, tag: { n: 'tag-design', x: 59, y: 896, w: 287, h: 424 }, tie: [200.5, 632], eye: [210.5, 900], motion: { amp: 1.5, seed: 2, T: 9.6 },
    tassels: [{ piece: { n: 'tassel-l', x: 40, y: 1141, w: 68, h: 160 }, at: [80, 1145] }, { piece: { n: 'tassel-r', x: 171, y: 1208, w: 64, h: 114 }, at: [209, 1212] }],
  },
  matrix: { thread: { n: 'thread-matrix', x: 936, y: 645, w: 55, h: 202 }, tag: { n: 'tag-matrix', x: 827, y: 829, w: 281, h: 298 }, tie: [951, 656], eye: [960.5, 833], motion: { amp: 1.7, seed: 3, T: 8.9 } },
  movement: { thread: { n: 'thread-movement', x: 759, y: 856, w: 41, h: 214 }, tag: { n: 'tag-movement', x: 665, y: 1052, w: 228, h: 250 }, tie: [777, 867], eye: [780, 1056], motion: { amp: 2.0, seed: 4, T: 7.9 } },
  showrooms: { thread: { n: 'thread-showrooms', x: 336, y: 955, w: 52, h: 222 }, tag: { n: 'tag-showrooms', x: 233, y: 1159, w: 250, h: 261 }, tie: [354.5, 966], eye: [365.5, 1163], motion: { amp: 1.7, seed: 5, T: 9.3 } },
  // hangs from the bottom of Item Allocation Matrix on a short rod
  refill: { tag: { n: 'tag-refill', x: 865, y: 1120, w: 245, h: 327 }, tie: [981, 1128], eye: [981, 1128], motion: { amp: 1.3, seed: 6, T: 7.2 }, parent: 'matrix' },
};
// where the water is disturbed (Showrooms and Refill Demand touch it) - the surface wobbles a little there
const WATER_PATCHES = [{ cx: 356, cy: 1452, rx: 250, ry: 80 }, { cx: 990, cy: 1458, rx: 250, ry: 80 }];
const KITE_GAP = 128; // branch tip -> module centre distance (module radius + thread)
const HUB_NODES: HubNode[] = [
  { id: 'cockpit', lines: ['Cockpit'], icon: 'cockpit', x: 380, y: -48, ox: 380, oy: 251, view: 'dashboard' },
  { id: 'design', lines: ['Design', 'Analysis'], icon: 'design', x: 135, y: 115, ox: 374, oy: 381, view: 'reports', report: 'weights' },
  { id: 'matrix', lines: ['Item', 'Allocation', 'Matrix'], icon: 'matrix', x: 612, y: 50, ox: 386, oy: 342, view: 'reports', report: 'excel_sheet' },
  { id: 'movement', lines: ['Movement', '& Aging'], icon: 'movement', x: 650, y: 258, ox: 388, oy: 414, view: 'movement_aging' },
  { id: 'showrooms', lines: ['Showrooms'], icon: 'showrooms', x: 115, y: 401, ox: 370, oy: 479, view: 'reports', report: 'branches' },
  { id: 'refill', lines: ['Refill', 'Demand'], icon: 'refill', x: 590, y: 459, ox: 392, oy: 505, view: 'reports', report: 'refill_demand' },
];

type P = [number, number];
const f1 = (n: number) => n.toFixed(1);
const bez = (p0: P, p1: P, p2: P, p3: P, t: number): P => {
  const u = 1 - t;
  return [
    u * u * u * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t * t * t * p3[0],
    u * u * u * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t * t * t * p3[1],
  ];
};
const bezTan = (p0: P, p1: P, p2: P, p3: P, t: number): number => {
  const u = 1 - t;
  const dx = 3 * u * u * (p1[0] - p0[0]) + 6 * u * t * (p2[0] - p1[0]) + 3 * t * t * (p3[0] - p2[0]);
  const dy = 3 * u * u * (p1[1] - p0[1]) + 6 * u * t * (p2[1] - p1[1]) + 3 * t * t * (p3[1] - p2[1]);
  return Math.atan2(dy, dx);
};

/** Closed polygon of a tapered stroke along a sampled centre line (organic branch / root). */
const taper = (pts: P[], w0: number, w1: number, ease = 1): string => {
  const n = pts.length;
  const L: string[] = [];
  const R: string[] = [];
  for (let i = 0; i < n; i += 1) {
    const a = pts[Math.max(0, i - 1)];
    const b = pts[Math.min(n - 1, i + 1)];
    const dx = b[0] - a[0]; const dy = b[1] - a[1];
    const len = Math.hypot(dx, dy) || 1;
    const nx = -dy / len; const ny = dx / len;
    const t = i / (n - 1);
    const w = (w0 + (w1 - w0) * Math.pow(t, ease)) / 2;
    L.push(`${f1(pts[i][0] + nx * w)} ${f1(pts[i][1] + ny * w)}`);
    R.push(`${f1(pts[i][0] - nx * w)} ${f1(pts[i][1] - ny * w)}`);
  }
  return `M${L.join(' L')} L${R.reverse().join(' L')} Z`;
};
const sampleBez = (p0: P, p1: P, p2: P, p3: P, n = 20): P[] => Array.from({ length: n + 1 }, (_, i) => bez(p0, p1, p2, p3, i / n));
const sampleQuad = (p0: P, c: P, p1: P, n = 10): P[] =>
  Array.from({ length: n + 1 }, (_, i) => {
    const t = i / n; const u = 1 - t;
    return [u * u * p0[0] + 2 * u * t * c[0] + t * t * p1[0], u * u * p0[1] + 2 * u * t * c[1] + t * t * p1[1]] as P;
  });

const LEAF_COLORS = ['#2F6B35', '#3F7D3A', '#4F8F3F', '#5E9E47', '#6FAE4E', '#7AB648', '#3A7A44'];
const GROUND_Y = 592;

function buildTree() {
  let seed = 11;
  const rnd = () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const twigs: { d: string }[] = [];
  const leaves: { x: number; y: number; rx: number; ry: number; rot: number; c: string; o: number }[] = [];
  const roots: { d: string; thin: boolean }[] = [];
  const rootPts: { pts: P[]; w: number }[] = [];

  const leaf = (x: number, y: number, ang: number, big = 1) => {
    leaves.push({
      x, y,
      rx: (5.5 + rnd() * 3.5) * big,
      ry: (2.6 + rnd() * 1.8) * big,
      rot: (ang * 180) / Math.PI + (rnd() - 0.5) * 120,
      c: LEAF_COLORS[Math.floor(rnd() * LEAF_COLORS.length)],
      o: 0.82 + rnd() * 0.16,
    });
  };

  // Natural twig: curved, tapering, forks 2-3 times, ends in a leaf cluster.
  const grow = (x: number, y: number, ang: number, len: number, depth: number, w: number) => {
    const bend = (rnd() - 0.5) * 0.9;
    const endAng = ang + bend;
    const c: P = [x + Math.cos(ang) * len * 0.55, y + Math.sin(ang) * len * 0.55];
    const e: P = [x + Math.cos(ang) * len * 0.5 + Math.cos(endAng) * len * 0.5, y + Math.sin(ang) * len * 0.5 + Math.sin(endAng) * len * 0.5];
    const wEnd = Math.max(0.7, w * 0.62);
    twigs.push({ d: taper(sampleQuad([x, y], c, e, 8), w, wEnd) });
    if (depth <= 1 && rnd() < 0.7) { const m = sampleQuad([x, y], c, e, 8)[5]; leaf(m[0], m[1], endAng + (rnd() < 0.5 ? 1.2 : -1.2)); }
    if (depth === 0) {
      const n = 4 + Math.floor(rnd() * 3);
      for (let i = 0; i < n; i += 1) leaf(e[0] + (rnd() - 0.5) * 12, e[1] + (rnd() - 0.5) * 12, endAng + (rnd() - 0.5) * 2.4);
      return;
    }
    const n = rnd() > 0.65 ? 3 : 2;
    for (let i = 0; i < n; i += 1) {
      const spread = n === 2 ? (i === 0 ? -1 : 1) * (0.35 + rnd() * 0.45) : (i - 1) * (0.5 + rnd() * 0.3);
      grow(e[0], e[1], endAng + spread, len * (0.68 + rnd() * 0.14), depth - 1, wEnd);
    }
  };

  // Trunk: smooth, tapering, flared where it meets the ground. Branch origins sit inside it.
  const SYT = 1.3; const SXT = 1.6; // taller / thicker trunk than the original design
  const ty = (y: number) => GROUND_Y - (GROUND_Y - y) * SYT;
  const tx = (x: number) => 380 + (x - 380) * SXT;
  const trunk = `M${f1(tx(326))} ${GROUND_Y + 16} C${f1(tx(346))} ${GROUND_Y + 2}, ${f1(tx(356))} ${f1(ty(566))}, ${f1(tx(359))} ${f1(ty(524))} C${f1(tx(362))} ${f1(ty(470))}, ${f1(tx(364))} ${f1(ty(402))}, ${f1(tx(368))} ${f1(ty(322))} C${f1(tx(370))} ${f1(ty(312))}, ${f1(tx(374))} ${f1(ty(306))}, 380 ${f1(ty(304))} C${f1(tx(386))} ${f1(ty(306))}, ${f1(tx(390))} ${f1(ty(312))}, ${f1(tx(392))} ${f1(ty(322))} C${f1(tx(396))} ${f1(ty(402))}, ${f1(tx(398))} ${f1(ty(470))}, ${f1(tx(401))} ${f1(ty(524))} C${f1(tx(404))} ${f1(ty(566))}, ${f1(tx(414))} ${GROUND_Y + 2}, ${f1(tx(434))} ${GROUND_Y + 16} Z`;
  // bark furrows
  const bark: string[] = [];
  for (let i = 0; i < 9; i += 1) {
    const off = (-16 + i * 4 + (rnd() - 0.5) * 2) * SXT;
    const y0 = ty(330 + rnd() * 60); const y1 = GROUND_Y - 4 - rnd() * 24;
    const flare = Math.max(0, Math.abs(off) / 16) * 0;
    bark.push(`M${f1(380 + off * 0.82)} ${f1(y0)} C${f1(380 + off * 0.9 + (rnd() - 0.5) * 4)} ${f1(y0 + (y1 - y0) * 0.35)}, ${f1(380 + off * 1.05 + (rnd() - 0.5) * 5 + flare)} ${f1(y0 + (y1 - y0) * 0.7)}, ${f1(380 + off * 1.35)} ${f1(y1)}`);
  }

  // primary branches — one thick limb + two slimmer shoots per module, each tapering to its node
  const primary: { d: string; hl: string }[] = [];
  const flows: { id: string; d: string }[] = [];
  const ties: Record<string, P> = {}; // kite-string tie point on the branch, relative to each module centre
  HUB_NODES.forEach((n) => {
    const O: P = [n.ox, n.oy];
    const T: P = [n.x, n.y + (n.id === 'cockpit' ? 40 : 0)];
    const sgn = Math.sign(T[0] - O[0]) || 0;
    let idxE = 26;
    [0, 1, 2].forEach((k) => {
      const spread = (k - 1) * 20;
      const c1: P = n.id === 'cockpit' ? [O[0] + spread * 0.4, O[1] - 70] : [O[0] + sgn * 26 + spread * 0.3, O[1] - 95 + spread * 0.5];
      const c2: P = n.id === 'cockpit' ? [T[0] + spread * 0.6, T[1] + 90] : [T[0] + (O[0] - T[0]) * 0.32 + spread * 0.4, T[1] + 125 + spread];
      const full = sampleBez(O, c1, c2, T, 26);
      if (k === 0) {
        // the limb ends in the air, a kite-string's length from the module (see ties / the thread drawn with each module)
        for (let i = 26; i >= 0; i -= 1) { if (Math.hypot(full[i][0] - n.x, full[i][1] - n.y) >= KITE_GAP) { idxE = i; break; } }
        ties[n.id] = [full[idxE][0] - n.x, full[idxE][1] - n.y];
      }
      const keep = k === 0 ? idxE + 1 : k === 1 ? Math.max(6, Math.min(17, idxE - 2)) : Math.max(8, Math.min(21, idxE - 1)); // shoots stop short and fork into twigs
      const pts = full.slice(0, keep);
      const w0 = k === 0 ? 25 : k === 1 ? 12 : 9;
      const w1 = k === 0 ? 8 : k === 1 ? 4 : 3.2;
      primary.push({
        d: taper(pts, w0, w1, 0.8),
        hl: k === 0 ? `M${pts.map((p, i) => `${f1(p[0] - (w0 * (1 - i / 26) * 0.22))} ${f1(p[1])}`).join(' L')}` : '',
      });
      if (k > 0) {
        const e = pts[pts.length - 1]; const q = pts[pts.length - 2];
        const endAng = Math.atan2(e[1] - q[1], e[0] - q[0]);
        grow(e[0], e[1], endAng + (k === 1 ? -0.35 : 0.35), 34, 2, w1);
      }
      if (k === 0) {
        // sap path: roots -> up the trunk -> along this limb to its module
        flows.push({
          id: n.id,
          d: `M380 ${GROUND_Y + 92} C380 ${GROUND_Y + 30}, ${f1(O[0])} ${f1(O[1] + 110)}, ${f1(O[0])} ${f1(O[1])} ${full.slice(1, idxE + 1).map((p) => `L${f1(p[0])} ${f1(p[1])}`).join(' ')}`,
        });
      }
      if (k === 0) {
        for (let t = 0.14; t < Math.min(0.92, idxE / 26 - 0.03); t += 0.06) {
          const pt = bez(O, c1, c2, T, t);
          const tan = bezTan(O, c1, c2, T, t);
          const side = rnd() > 0.5 ? 1 : -1;
          const wHere = 11 * (1 - t) + 4;
          if (rnd() < 0.55) grow(pt[0], pt[1], tan + side * (0.6 + rnd() * 0.5), 30 + rnd() * 30, 2, Math.max(2, wHere * 0.45));
          if (rnd() < 0.3) grow(pt[0], pt[1], tan - side * (0.55 + rnd() * 0.5), 24 + rnd() * 22, 2, Math.max(1.8, wHere * 0.38));
        }
      }
    });
  });

  // upper crown shoots rising off the trunk
  for (let i = 0; i < 13; i += 1) {
    const y = ty(340 + i * 17); const side = i % 2 ? 1 : -1;
    grow(380 + side * 11, y, -Math.PI / 2 + side * (0.6 + rnd() * 0.7), 36 + rnd() * 24, 2, 4.2);
  }

  // roots — palm-style: a dense fibrous mat of thin, near-uniform roots fanning out from the base of the trunk
  const rootWalk = (x: number, y: number, ang: number, len: number, w: number, depth: number) => {
    const steps = 18; const step = len / steps;
    const pts: P[] = [[x, y]];
    let a = ang;
    const curl = (rnd() - 0.5) * 0.1;
    for (let i = 0; i < steps; i += 1) {
      a += curl + (rnd() - 0.5) * 0.22 + (Math.PI / 2 - a) * 0.02;
      x += Math.cos(a) * step; y = Math.min(HH - 8, y + Math.sin(a) * step);
      pts.push([x, y]);
    }
    roots.push({ d: taper(pts, w, Math.max(0.5, w * 0.35), 0.7), thin: true });
    rootPts.push({ pts, w });
    if (depth > 0) {
      [0.35, 0.6, 0.82].forEach((f) => {
        if (rnd() < 0.6) {
          const q = pts[Math.round(f * steps)];
          const dir = rnd() > 0.5 ? 1 : -1;
          rootWalk(q[0], q[1], a + dir * (0.7 + rnd() * 0.7), len * (0.25 + rnd() * 0.2), Math.max(0.7, w * 0.5), depth - 1);
        }
      });
    }
  };
  for (let i = 0; i < 64; i += 1) {
    const u = ((i + rnd() * 0.8) / 64) * 2 - 1; // -1..1 across the trunk base
    const spread = u * (0.55 + rnd() * 0.6) + (rnd() - 0.5) * 0.35;
    rootWalk(380 + u * 44, GROUND_Y + 5 + rnd() * 5, Math.PI / 2 + spread, 70 + rnd() * 150 + Math.abs(u) * 90, 2.2 + rnd() * 1.6, 1);
  }

  // surface roots flaring over the ground at the trunk base
  const surface: string[] = [];
  [-1, 1].forEach((sd) => {
    [0, 1].forEach((j) => {
      surface.push(taper(sampleQuad([380 + sd * 32, GROUND_Y - 22 + j * 6], [380 + sd * (70 + j * 19), GROUND_Y - 6], [380 + sd * (125 + j * 42), GROUND_Y + 6 + j * 4], 10), 26 - j * 8, 3));
    });
  });

  // soil speckle + stones
  const specks: { x: number; y: number; rx: number; ry: number; c: string; o: number }[] = [];
  for (let i = 0; i < 150; i += 1) {
    const sc = ['#7B5A3C', '#2E1E13', '#9A7B58', '#4A3322'][Math.floor(rnd() * 4)];
    specks.push({ x: -60 + rnd() * 880, y: GROUND_Y + 12 + rnd() * (HH - GROUND_Y - 14), rx: 1.2 + rnd() * 3.4, ry: 0.9 + rnd() * 2.2, c: sc, o: 0.25 + rnd() * 0.4 });
  }
  // grass blades along the surface
  const grass: { d: string; c: string }[] = [];
  for (let x = -70; x < HW + 70; x += 4 + rnd() * 3) {
    const h = 9 + rnd() * 15; const lean = (rnd() - 0.5) * 9;
    grass.push({ d: `M${f1(x)} ${GROUND_Y + 3} Q${f1(x + lean * 0.3)} ${f1(GROUND_Y - h * 0.55)} ${f1(x + lean)} ${f1(GROUND_Y - h)}`, c: ['#3F7D3A', '#4F8F3F', '#5E9E47', '#2F6B35'][Math.floor(rnd() * 4)] });
  }

  // Diamonds packed through the soil (side-view brilliants, big ones near the surface); soil only shows in the gaps.
  // Own RNG so the layout above is untouched.
  let gs = 2026;
  const grnd = () => {
    gs |= 0; gs = (gs + 0x6d2b79f5) | 0;
    let t = Math.imul(gs ^ (gs >>> 15), 1 | gs);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const gems: { x: number; y: number; s: number; rot: number; flip: number; cut: number; spark: boolean; front: boolean; delay: number; period: number }[] = [];
  for (let i = 0; i < 12000 && gems.length < 380; i += 1) {
    const depth = grnd();
    const size = (13 + grnd() * 12) * (1 - depth * 0.18);
    const gx = -140 + grnd() * (HW + 280);
    const gy = GROUND_Y + 8 + size * 0.55 + depth * (HH - GROUND_Y - 16 - size * 1.1);
    if (gems.some((g) => { const dx = (g.x - gx) / (g.s + size); const dy = (g.y - gy) / ((g.s + size) * 0.62); return dx * dx + dy * dy < 0.34; })) continue;
    gems.push({
      x: gx, y: gy, s: size,
      rot: (grnd() - 0.5) * 70,
      flip: grnd() < 0.5 ? -1 : 1,
      cut: Math.max(0, Math.min(3, Math.floor(depth * 4 + (grnd() - 0.5) * 1.6))), // deeper = a little darker
      spark: grnd() < 0.1,
      front: grnd() < 0.3,
      delay: grnd() * 5,
      period: 2.2 + grnd() * 2.4,
    });
  }
  gems.sort((a, b) => a.y - b.y); // lower ones overlap the ones behind
  return { flows, ties, trunk, bark, primary, twigs, leaves, roots, surface, specks, grass, gems };
}

/* Realistic diamond: side-view brilliant (table, crown, girdle, pavilion) in irregular ice-blue facets, like a studio photo of a blue diamond */
type Facet = { p: string; fill: string };
const _s = (p: P[]) => p.map((q) => `${q[0].toFixed(3)},${q[1].toFixed(3)}`).join(' ');
const RAMP = ['#1B4672', '#2A6498', '#3F87BF', '#69AEDD', '#9CD0EE', '#C9E8F8', '#F0FAFF'];
const ramp = (l: number) => {
  const x = Math.min(0.999, Math.max(0, l)) * (RAMP.length - 1); const i = Math.floor(x); const f = x - i;
  const ch = (h: string, k: number) => parseInt(h.slice(1 + k * 2, 3 + k * 2), 16);
  return '#' + [0, 1, 2].map((k) => Math.round(ch(RAMP[i], k) * (1 - f) + ch(RAMP[i + 1], k) * f).toString(16).padStart(2, '0')).join('');
};
function brilliantCut(variant: number): Facet[] {
  let sd = 77 + variant * 131;
  const r = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
  const shift = [0.06, 0, -0.07, -0.14][variant];
  const t: P[] = [-0.46, -0.23, 0, 0.23, 0.46].map((x) => [x, -0.52] as P);
  const b: P[] = Array.from({ length: 9 }, (_, i) => [-1 + i * 0.25, -0.14] as P);
  const p: P[] = Array.from({ length: 9 }, (_, i) => [-1 + i * 0.25, -0.05] as P);
  const m: P[] = [[-0.62, 0.22], [-0.31, 0.27], [0, 0.3], [0.31, 0.27], [0.62, 0.22]];
  const c: P = [0, 0.62];
  const out: Facet[] = [];
  const add = (pts: P[], base: number, wave: number) => {
    const cx = pts.reduce((a, q) => a + q[0], 0) / pts.length;
    let l = base + 0.2 * Math.sin(cx * wave + variant * 1.3) + (r() - 0.5) * 0.3 + shift;
    const k = r();
    if (k < 0.13) l += 0.3; else if (k > 0.82) l -= 0.3;
    out.push({ p: _s(pts), fill: ramp(l) });
  };
  add([[-0.46, -0.52], [-0.38, -0.6], [0.38, -0.6], [0.46, -0.52]], 0.93, 0);
  const crown: P[][] = [[b[0], t[0], b[1]], [b[1], t[0], b[2]], [t[0], t[1], b[2]], [b[2], t[1], b[3]], [t[1], t[2], b[3]], [b[3], t[2], b[4]], [t[2], b[4], b[5]], [t[2], t[3], b[5]], [b[5], t[3], b[6]], [t[3], t[4], b[6]], [b[6], t[4], b[7]], [b[7], t[4], b[8]]];
  crown.forEach((q) => add(q, 0.64, 4.2));
  for (let i = 0; i < 4; i += 1) add([b[i * 2], b[i * 2 + 2], p[i * 2 + 2], p[i * 2]], 0.48, 3);
  const pav: P[][] = [[p[0], p[1], m[0]], [p[1], p[2], m[0]], [p[2], p[3], m[1]], [m[0], p[2], m[1]], [p[3], p[4], m[1]], [p[4], m[1], m[2]], [p[4], m[2], m[3]], [p[4], p[5], m[3]], [p[5], p[6], m[3]], [m[3], p[6], m[4]], [p[6], p[7], m[4]], [p[7], p[8], m[4]]];
  pav.forEach((q) => add(q, 0.5, 5));
  const low: P[][] = [[m[0], m[1], c], [m[1], m[2], c], [m[2], m[3], c], [m[3], m[4], c], [p[0], m[0], c], [p[8], m[4], c]];
  low.forEach((q) => add(q, 0.4, 6));
  return out;
}
const CUT_FACETS = [0, 1, 2, 3].map(brilliantCut);
const CUT_OUTLINE = '-1,-0.14 -0.46,-0.52 0.46,-0.52 1,-0.14 1,-0.05 0,0.62 -1,-0.05';
const CUT_IDS = ['#dmxBrill0', '#dmxBrill1', '#dmxBrill2', '#dmxBrill3'];
const CutSymbols: React.FC = () => (
  <>
    {CUT_FACETS.map((fs, c) => (
      <g key={c} id={CUT_IDS[c].slice(1)}>
        {fs.map((ft, i) => <polygon key={i} points={ft.p} fill={ft.fill} stroke="#EAF8FF" strokeOpacity={0.5} strokeWidth={0.03} strokeLinejoin="round" />)}
        <polygon points={CUT_OUTLINE} fill="url(#dmxDiamondSheen)" stroke="#143459" strokeOpacity={0.6} strokeWidth={0.05} strokeLinejoin="round" />
        <circle cx={-0.34} cy={-0.34} r={0.06} fill="#FFFFFF" />
        <circle cx={0.22} cy={0.14} r={0.05} fill="#FFFFFF" fillOpacity={0.9} />
      </g>
    ))}
  </>
);

/* Fallback palm (only used when WebGL is not available): the trunk stays still; the crown is drawn as 5 overlapping, feather-masked bands that each sway a little
   about the crown base at their own pace (outer fronds sway the most), cross-faded with plus-lighter so the seams never show. */
const PALM_PIVOT = '380 385';
const PALM_BANDS = [
  { f: 0, a: 1.3, dur: 4.3, begin: -0.6 },
  { f: 0.25, a: 0.85, dur: 5.1, begin: -2.1 },
  { f: 0.5, a: 0.6, dur: 6.3, begin: -3.4 },
  { f: 0.75, a: 0.9, dur: 5.6, begin: -1.2 },
  { f: 1, a: 1.4, dur: 4.7, begin: -4.0 },
];
const PALM_Y0 = PALM_BOX.y + PALM_BOX.h * 0.7; // above this: crown (moves); below PALM_Y1: trunk (still)
const PALM_Y1 = PALM_BOX.y + PALM_BOX.h * 0.78;
const palmBandX = (i: number) => PALM_BOX.x + PALM_BOX.w * PALM_BANDS[Math.max(0, Math.min(PALM_BANDS.length - 1, i))].f;
const PalmDefs: React.FC = () => (
  <>
    <image id="dmxPalm" href={PALM_SRC} x={PALM_BOX.x} y={PALM_BOX.y} width={PALM_BOX.w} height={PALM_BOX.h} preserveAspectRatio="none" />
    <linearGradient id="dmxPalmCrownG" gradientUnits="userSpaceOnUse" x1="0" y1={PALM_Y0} x2="0" y2={PALM_Y1}>
      <stop offset="0" stopColor="#FFFFFF" /><stop offset="1" stopColor="#000000" />
    </linearGradient>
    <linearGradient id="dmxPalmStillG" gradientUnits="userSpaceOnUse" x1="0" y1={PALM_Y0} x2="0" y2={PALM_Y1}>
      <stop offset="0" stopColor="#000000" /><stop offset="1" stopColor="#FFFFFF" />
    </linearGradient>
    <mask id="dmxPalmCrownM" maskUnits="userSpaceOnUse" x={-400} y={-500} width={1560} height={1600}><rect x={-400} y={-500} width={1560} height={1600} fill="url(#dmxPalmCrownG)" /></mask>
    <mask id="dmxPalmStillM" maskUnits="userSpaceOnUse" x={-400} y={-500} width={1560} height={1600}><rect x={-400} y={-500} width={1560} height={1600} fill="url(#dmxPalmStillG)" /></mask>
    {PALM_BANDS.map((b, i) => {
      const first = i === 0; const last = i === PALM_BANDS.length - 1;
      return (
        <React.Fragment key={i}>
          <linearGradient id={`dmxPalmBandG${i}`} gradientUnits="userSpaceOnUse" x1={first ? palmBandX(0) : last ? palmBandX(i - 1) : palmBandX(i - 1)} y1="0" x2={first ? palmBandX(1) : last ? palmBandX(i) : palmBandX(i + 1)} y2="0">
            {first ? (<><stop offset="0" stopColor="#FFFFFF" /><stop offset="1" stopColor="#000000" /></>)
              : last ? (<><stop offset="0" stopColor="#000000" /><stop offset="1" stopColor="#FFFFFF" /></>)
              : (<><stop offset="0" stopColor="#000000" /><stop offset="0.5" stopColor="#FFFFFF" /><stop offset="1" stopColor="#000000" /></>)}
          </linearGradient>
          <mask id={`dmxPalmBandM${i}`} maskUnits="userSpaceOnUse" x={-400} y={-500} width={1560} height={1600}>
            <rect x={-400} y={-500} width={1560} height={1600} fill={`url(#dmxPalmBandG${i})`} mask="url(#dmxPalmCrownM)" />
          </mask>
        </React.Fragment>
      );
    })}
  </>
);
/* ───────── Palm in the wind: mesh warp ─────────
   The palm sprite is stretched over a fine grid (a mesh) and drawn with WebGL. Every frame the vertex shader nudges each
   grid point. palmWindAt() below is the same maths in JS; it also moves the kite tie knots so the strings stay on the leaf tips.
   - How far a point may move depends on its distance from the crown centre: ~0 at the base of a frond, the most at the tip
     (curve ^ WIND.curve). So every frond stays rooted while its tip travels. The trunk below the crown is masked to stay still.
   - A gust is a travelling wave: its phase is delayed across the width of the crown, so the push sweeps from the LEFT side
     to the RIGHT side instead of every leaf moving at once (flip the sign of WIND.lag to sweep the other way).
   - The push is applied across each frond (perpendicular to its length), plus a small fast flutter on the tips.
   Tune everything in WIND. If WebGL is not available the old rigid-band animation (PalmBands) is used instead. */
const WIND = {
  px: 378, py: 325,   // crown centre: every frond grows out from here and stays pinned
  r0: 26, r1: 300,    // distance from the centre: nothing moves below r0, full effect at r1 (frond tips)
  curve: 1.8,         // > 1 pushes the bending towards the tips
  amp: 0,             // peak tip travel, in tree units (0 = leaves completely still; set back to 10 to sway again)
  speed: 0.4,         // overall tempo: 1 = brisk breeze, 0.4 = slow, gentle sway, 0.25 = almost still air
  halfW: 245,         // half width of the crown (used for the left-to-right travel of the gusts)
  lag: 1.1,           // seconds a gust needs to cross half the crown (wind blows LEFT -> RIGHT; use a negative value to reverse)
  freq: 0.45,         // Hz: natural swing of a frond that a gust excites
  tipLag: 2.2,        // radians: the tip of a frond swings later than its base (bending travels outwards)
  flutter: 0.08,      // fast leaflet shimmer, as a fraction of amp (only really shows during gusts)
};
const WIND_TAU = Math.PI * 2;
const windSmooth = (a: number, b: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
/* Natural wind: slow irregular GUSTS travelling left -> right, a downwind LEAN that holds while the wind blows, a per-frond SWING
   (own phase, tip trails the base) and a small leaflet FLUTTER. Mirrors the vertex shader below; also moves the string tie points. */
const palmWindAt = (x: number, y: number, tReal: number): [number, number] => {
  const W = WIND;
  const t = tReal * W.speed;
  const dx = x - W.px;
  const dy = y - W.py;
  const r = Math.hypot(dx, dy);
  if (r < 0.001) return [0, 0];
  const u = Math.min(1, Math.max(0, (r - W.r0) / (W.r1 - W.r0)));
  const b = Math.pow(u, W.curve) * (1 - windSmooth(PALM_Y0, PALM_Y1, y));
  if (b <= 0) return [0, 0];
  const tx = dx / r;
  const ty = dy / r;
  const nx = -ty;
  const ny = tx;
  const tt = t - (W.lag * dx) / W.halfW;
  const n = 0.5 * Math.sin(0.34 * tt) + 0.3 * Math.sin(0.57 * tt + 1.2) + 0.2 * Math.sin(0.97 * tt + 2.1);
  const G = windSmooth(0.2, 0.8, 0.5 + 0.5 * n);
  const S = 0.2 + 0.8 * G;
  const lean = 0.35 + 0.65 * G;
  const pf = 1.6 * (2 * tx * ty) + 1.2 * (4 * tx * tx * tx - 3 * tx);
  const o1 = 0.6 * Math.sin(WIND_TAU * W.freq * tt - W.tipLag * u + pf) + 0.25 * Math.sin(WIND_TAU * 0.83 * tt + 1.9 - 1.4 * u + 1.3 * pf);
  const o2 = Math.sin(WIND_TAU * 0.6 * tt + 0.9 - 1.1 * u + 0.7 * pf) + 0.4 * Math.sin(WIND_TAU * 1.05 * tt + 2.4 + pf);
  const gx = lean + S * o1;
  const gy = 0.15 * lean + S * 0.5 * o2 * 0.6;
  const wn = gx * nx + gy * ny;
  const wt = gx * tx + gy * ty;
  const fl = W.flutter * (0.3 + 0.7 * S) * (Math.sin(WIND_TAU * 1.35 * t + r * 0.11 + dx * 0.13 + dy * 0.09 + pf) + 0.6 * Math.sin(WIND_TAU * 2.2 * t + r * 0.14 - dx * 0.07 + 1.7)) * b;
  return [W.amp * (b * (nx * wn + tx * wt * 0.3) + fl * nx), W.amp * (b * (ny * wn + ty * wt * 0.3) + fl * ny)];
};

const glf = (n: number) => n.toFixed(4);
const PALM_VS = `
attribute vec2 aPos;
attribute vec2 aUv;
uniform float uTime;
uniform vec4 uView;
varying vec2 vUv;
const float TAU = 6.2831853;
vec2 wind(vec2 p, float tReal) {
  float t = tReal * ${glf(WIND.speed)};
  vec2 d = p - vec2(${glf(WIND.px)}, ${glf(WIND.py)});
  float r = length(d);
  if (r < 0.001) return vec2(0.0);
  float u = clamp((r - ${glf(WIND.r0)}) / ${glf(WIND.r1 - WIND.r0)}, 0.0, 1.0);
  float b = pow(u, ${glf(WIND.curve)}) * (1.0 - smoothstep(${glf(PALM_Y0)}, ${glf(PALM_Y1)}, p.y));
  vec2 tg = d / r;
  vec2 nr = vec2(-tg.y, tg.x);
  float tt = t - ${glf(WIND.lag)} * d.x / ${glf(WIND.halfW)};
  float n = 0.5 * sin(0.34 * tt) + 0.3 * sin(0.57 * tt + 1.2) + 0.2 * sin(0.97 * tt + 2.1);
  float G = smoothstep(0.2, 0.8, 0.5 + 0.5 * n);
  float S = 0.2 + 0.8 * G;
  float lean = 0.35 + 0.65 * G;
  float pf = 1.6 * (2.0 * tg.x * tg.y) + 1.2 * (4.0 * tg.x * tg.x * tg.x - 3.0 * tg.x);
  float o1 = 0.6 * sin(TAU * ${glf(WIND.freq)} * tt - ${glf(WIND.tipLag)} * u + pf) + 0.25 * sin(TAU * 0.83 * tt + 1.9 - 1.4 * u + 1.3 * pf);
  float o2 = sin(TAU * 0.6 * tt + 0.9 - 1.1 * u + 0.7 * pf) + 0.4 * sin(TAU * 1.05 * tt + 2.4 + pf);
  float gx = lean + S * o1;
  float gy = 0.15 * lean + S * 0.5 * o2 * 0.6;
  float wn = dot(vec2(gx, gy), nr);
  float wt = dot(vec2(gx, gy), tg);
  float fl = ${glf(WIND.flutter)} * (0.3 + 0.7 * S) * (sin(TAU * 1.35 * t + r * 0.11 + d.x * 0.13 + d.y * 0.09 + pf) + 0.6 * sin(TAU * 2.2 * t + r * 0.14 - d.x * 0.07 + 1.7)) * b;
  return ${glf(WIND.amp)} * (b * (nr * wn + tg * wt * 0.3) + fl * nr);
}
void main() {
  vec2 q = aPos + wind(aPos, uTime);
  vec2 c = (q - uView.xy) / uView.zw;
  gl_Position = vec4(c.x * 2.0 - 1.0, 1.0 - c.y * 2.0, 0.0, 1.0);
  vUv = aUv;
}`;
const PALM_FS = `
precision mediump float;
uniform sampler2D uTex;
varying vec2 vUv;
void main() { gl_FragColor = texture2D(uTex, vUv); }`;

const PALM_PAD = 44; // extra room around the sprite so swaying tips are never clipped
type PalmMeshCb = { onReady: () => void; onFail: () => void; onFrame?: (t: number) => void };

/** Builds the mesh, uploads the sprite and runs the render loop. Returns a disposer. Throws if WebGL is unusable. */
const startPalmMesh = (canvas: HTMLCanvasElement, cb: React.MutableRefObject<PalmMeshCb>): (() => void) => {
  const opts = { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false };
  const gl = (canvas.getContext('webgl2', opts) || canvas.getContext('webgl', opts)) as WebGLRenderingContext | null;
  if (!gl) throw new Error('WebGL unavailable');

  const compile = (type: number, src: string) => {
    const sh = gl.createShader(type);
    if (!sh) throw new Error('createShader failed');
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh) || 'shader compile failed');
    return sh;
  };
  const prog = gl.createProgram();
  if (!prog) throw new Error('createProgram failed');
  gl.attachShader(prog, compile(gl.VERTEX_SHADER, PALM_VS));
  gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, PALM_FS));
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog) || 'program link failed');
  gl.useProgram(prog);

  // grid over the sprite: interleaved [x, y, u, v]
  const COLS = 64;
  const ROWS = 74;
  const verts = new Float32Array((COLS + 1) * (ROWS + 1) * 4);
  let k = 0;
  for (let j = 0; j <= ROWS; j += 1) {
    for (let i = 0; i <= COLS; i += 1) {
      const u = i / COLS;
      const v = j / ROWS;
      verts.set([PALM_BOX.x + u * PALM_BOX.w, PALM_BOX.y + v * PALM_BOX.h, u, v], k);
      k += 4;
    }
  }
  const idx = new Uint16Array(COLS * ROWS * 6);
  k = 0;
  for (let j = 0; j < ROWS; j += 1) {
    for (let i = 0; i < COLS; i += 1) {
      const a = j * (COLS + 1) + i;
      const c = a + COLS + 1;
      idx.set([a, a + 1, c, a + 1, c + 1, c], k);
      k += 6;
    }
  }
  const vbo = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  gl.bufferData(gl.ARRAY_BUFFER, verts, gl.STATIC_DRAW);
  const ibo = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
  const aPos = gl.getAttribLocation(prog, 'aPos');
  const aUv = gl.getAttribLocation(prog, 'aUv');
  gl.enableVertexAttribArray(aPos);
  gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 16, 0);
  gl.enableVertexAttribArray(aUv);
  gl.vertexAttribPointer(aUv, 2, gl.FLOAT, false, 16, 8);
  const uTime = gl.getUniformLocation(prog, 'uTime');
  gl.uniform4f(gl.getUniformLocation(prog, 'uView'), PALM_BOX.x - PALM_PAD, PALM_BOX.y - PALM_PAD, PALM_BOX.w + PALM_PAD * 2, PALM_BOX.h + PALM_PAD * 2);
  gl.uniform1i(gl.getUniformLocation(prog, 'uTex'), 0);
  gl.disable(gl.BLEND);
  gl.disable(gl.DEPTH_TEST);
  gl.clearColor(0, 0, 0, 0);

  let tex: WebGLTexture | null = null;
  let disposed = false;
  let started = false;
  let shown = false;
  let inView = true;
  let raf = 0;
  const t0 = performance.now();

  const fit = () => {
    const rc = canvas.getBoundingClientRect();
    if (rc.width < 1 || rc.height < 1) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.round(rc.width * dpr);
    const h = Math.round(rc.height * dpr);
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    gl.viewport(0, 0, canvas.width, canvas.height);
  };
  const frame = (now: number) => {
    raf = 0;
    if (disposed || !inView || document.hidden) return; // loop pauses off-screen; wake() restarts it
    const t = (now - t0) / 1000 + 2.5;
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(uTime, t);
    gl.drawElements(gl.TRIANGLES, idx.length, gl.UNSIGNED_SHORT, 0);
    if (cb.current.onFrame) cb.current.onFrame(t);
    if (!shown) {
      shown = true;
      cb.current.onReady();
    }
    raf = requestAnimationFrame(frame);
  };
  const wake = () => {
    if (!disposed && started && !raf && inView && !document.hidden) raf = requestAnimationFrame(frame);
  };
  const onLost = (e: Event) => {
    e.preventDefault();
    cb.current.onFail();
  };

  const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(() => fit()) : null;
  if (ro) ro.observe(canvas);
  const io = typeof IntersectionObserver !== 'undefined'
    ? new IntersectionObserver((entries) => { inView = entries.some((e) => e.isIntersecting); wake(); })
    : null;
  if (io) io.observe((canvas.closest('svg') as Element | null) || canvas);
  document.addEventListener('visibilitychange', wake);
  canvas.addEventListener('webglcontextlost', onLost);

  const img = new Image();
  img.onload = () => {
    if (disposed) return;
    try {
      gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
      tex = gl.createTexture();
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      if (typeof WebGL2RenderingContext !== 'undefined' && gl instanceof WebGL2RenderingContext) {
        gl.generateMipmap(gl.TEXTURE_2D); // smooth when the card is small (WebGL2 allows mipmaps on any size)
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
      } else {
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      }
      fit();
      started = true;
      wake();
    } catch (err) {
      cb.current.onFail();
    }
  };
  img.onerror = () => cb.current.onFail();
  img.src = PALM_SRC;

  return () => {
    disposed = true;
    if (raf) cancelAnimationFrame(raf);
    if (io) io.disconnect();
    if (ro) ro.disconnect();
    document.removeEventListener('visibilitychange', wake);
    canvas.removeEventListener('webglcontextlost', onLost);
    // free GPU objects but do NOT lose the context: React StrictMode re-runs the effect on the same canvas
    if (tex) gl.deleteTexture(tex);
    gl.deleteBuffer(vbo);
    gl.deleteBuffer(ibo);
    gl.deleteProgram(prog);
  };
};

const PalmMesh: React.FC<PalmMeshCb> = ({ onReady, onFail, onFrame }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cb = useRef<PalmMeshCb>({ onReady, onFail, onFrame });
  cb.current = { onReady, onFail, onFrame };
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;
    let dispose: (() => void) | null = null;
    try {
      dispose = startPalmMesh(canvas, cb);
    } catch (err) {
      cb.current.onFail();
    }
    return () => { if (dispose) dispose(); };
  }, []);
  return (
    <foreignObject x={PALM_BOX.x - PALM_PAD} y={PALM_BOX.y - PALM_PAD} width={PALM_BOX.w + PALM_PAD * 2} height={PALM_BOX.h + PALM_PAD * 2} pointerEvents="none">
      <canvas ref={canvasRef} style={{ display: 'block', width: '100%', height: '100%', pointerEvents: 'none' }} />
    </foreignObject>
  );
};

/* Fallback when WebGL is not available: the older rigid-band sway */
const PalmBands: React.FC = () => {
  return (
    <g style={{ isolation: 'isolate' }} pointerEvents="none" aria-hidden="true">
      <use href="#dmxPalm" mask="url(#dmxPalmStillM)" style={{ mixBlendMode: 'plus-lighter' }} />
      {PALM_BANDS.map((b, i) => (
        <g key={i} mask={`url(#dmxPalmBandM${i})`} style={{ mixBlendMode: 'plus-lighter' }}>
          <g>
            <animateTransform
              attributeName="transform"
              type="rotate"
              values={`${-b.a} ${PALM_PIVOT};${b.a} ${PALM_PIVOT};${(-b.a * 0.35).toFixed(2)} ${PALM_PIVOT};${-b.a} ${PALM_PIVOT}`}
              keyTimes="0;0.42;0.76;1"
              calcMode="spline"
              keySplines="0.45 0 0.55 1;0.45 0 0.55 1;0.45 0 0.55 1"
              dur={`${b.dur}s`}
              begin={`${b.begin}s`}
              repeatCount="indefinite"
            />
            <use href="#dmxPalm" />
          </g>
        </g>
      ))}
    </g>
  );
};

const PalmTree: React.FC<{ calm: boolean; onFrame?: (t: number) => void }> = ({ calm, onFrame }) => {
  const [mode, setMode] = useState<'mesh' | 'bands'>('mesh');
  const [shown, setShown] = useState(false);
  const onReady = useCallback(() => setShown(true), []);
  const onFail = useCallback(() => {
    setMode('bands');
    if (onFrame) onFrame(-1); // put the kite tie knots back
  }, [onFrame]);
  if (calm) return <use href="#dmxPalm" pointerEvents="none" aria-hidden="true" />;
  if (mode === 'bands') return <PalmBands />;
  return (
    <g pointerEvents="none" aria-hidden="true">
      {/* still sprite until the first WebGL frame is on screen, so the tree never flashes empty */}
      {!shown && <use href="#dmxPalm" />}
      <PalmMesh onReady={onReady} onFail={onFail} onFrame={onFrame} />
    </g>
  );
};

const renderGem = (g: { x: number; y: number; s: number; rot: number; flip: number; cut: number; spark: boolean; delay: number; period: number }, i: number, k: string) => (
  <g key={`${k}${i}`} transform={`translate(${f1(g.x)} ${f1(g.y)}) rotate(${f1(g.rot)}) scale(${f1(g.s * g.flip)} ${f1(g.s)})`}>
    {g.spark && <circle r={1.6} fill="url(#dmxGemHalo)" className="gem-halo" style={{ ['--p' as any]: `${g.period.toFixed(2)}s`, animationDelay: `${g.delay.toFixed(2)}s` }} />}
    <use href={CUT_IDS[g.cut]} />
    {g.spark && <g className="gem-spark" style={{ ['--p' as any]: `${g.period.toFixed(2)}s`, animationDelay: `${g.delay.toFixed(2)}s` }}><use href="#dmxStar" transform="translate(-0.4 -0.35) scale(0.8)" /></g>}
  </g>
);


type Obstacle = { count: number; label: string };

const CockpitHub: React.FC<{
  onNavigateView: (view: any, report?: any) => void;
  activeBranches: number;
  obstacles?: Record<string, Obstacle>;
  readOnly?: boolean;
}> = ({ onNavigateView, activeBranches, obstacles = {}, readOnly = false }) => {
  const tree = useMemo(buildTree, []);
  // kite tie knots sit on frond tips: move each module with the wind at its tie point so the strings never come off the leaf
  const kiteRefs = useRef<Record<string, SVGGElement | null>>({});
  const followWind = useCallback((t: number) => {
    HUB_NODES.forEach((n) => {
      const el = kiteRefs.current[n.id];
      const tie = PALM_TIES[n.id];
      if (!el || !tie) return;
      if (t < 0) { el.removeAttribute('transform'); return; }
      const [dx, dy] = palmWindAt(n.x + tie[0], n.y + tie[1], t);
      el.setAttribute('transform', `translate(${dx.toFixed(2)} ${dy.toFixed(2)})`);
    });
  }, []);
  const [hover, setHover] = useState<string | null>(null);
  // Fit the picture to the card: when the card is wider than the picture, show it full width and crop the roots a little at the bottom,
  // so no side extension is ever visible. Tall cards keep the whole picture.
  const svgRef = useRef<SVGSVGElement | null>(null);
  const swayRefs = useRef<Record<string, SVGGElement | null>>({});
  // The moving modules need all their picture files. Until every one has loaded (and if any is missing/corrupt on the server)
  // the hub shows the original static picture, so it can never end up with broken images.
  const [spritesOk, setSpritesOk] = useState(false);
  useEffect(() => {
    if (!SCENE_IMAGE) return undefined;
    let dead = false;
    const names = Object.values(HUB_MODS).flatMap((m) => [m.thread?.n, m.tag.n, ...(m.tassels?.map((t) => t.piece.n) ?? [])]).filter(Boolean) as string[];
    const urls = [SCENE_CLEAN, ...names.map((n) => spr(n))];
    Promise.all(
      urls.map((u) => new Promise<string | null>((resolve) => {
        if (!u) { resolve('(missing file)'); return; }
        const img = new Image();
        img.onload = () => resolve(img.naturalWidth > 0 ? null : u);
        img.onerror = () => resolve(u);
        img.src = u;
      })),
    ).then((bad) => {
      if (dead) return;
      const failed = bad.filter(Boolean);
      if (failed.length) console.warn('[DiaMatrix hub] picture pieces failed to load, showing the static picture instead:', failed);
      setSpritesOk(failed.length === 0);
    });
    return () => { dead = true; };
  }, []);
  const [vbH, setVbH] = useState(HH - VB_TOP);
  const [minH, setMinH] = useState(0);
  const [sideGap, setSideGap] = useState(false); // true only when the card is still wider than the picture (needs the soft side extension)
  useEffect(() => {
    const el = svgRef.current;
    if (!el || typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(() => {
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) return;
      const hv = Math.min(HH - VB_TOP, Math.max(300, (HW * r.height) / r.width)); // cover: the picture always fills the whole card
      setVbH((prev) => (Math.abs(prev - hv) > 2 ? hv : prev));
      setMinH((prev) => { const m = Math.min(900, Math.round((r.width * 580) / HW)); return Math.abs(prev - m) > 2 ? m : prev; });
      setSideGap(r.width / r.height > HW / hv + 0.03);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const vbY = vbH < 580 ? 120 - vbH / 2 : Math.min(HH - vbH, -170);
  const [calm] = useState(() => typeof window !== 'undefined' && !!window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const R = SCENE_IMAGE ? SCENE_HEX_R : HEX_R;
  const hexPts = [[0, -R], [R * 0.866, -R / 2], [R * 0.866, R / 2], [0, R], [-R * 0.866, R / 2], [-R * 0.866, -R / 2]].map((p) => p.join(',')).join(' ');
  const hexInner = [[0, -R + 6], [(R - 6) * 0.866, -(R - 6) / 2], [(R - 6) * 0.866, (R - 6) / 2], [0, R - 6], [-(R - 6) * 0.866, (R - 6) / 2], [-(R - 6) * 0.866, -(R - 6) / 2]].map((p) => p.join(',')).join(' ');

  // Click / hover area (and red badge) of one module, in picture pixels
  const hitArea = (id: string): React.ReactNode => {
    const n = HUB_NODES.find((h) => h.id === id)!;
    const tg = SCENE_TAGS[id];
    const active = hover === id;
    const ob = obstacles[id];
    const blocked = !!ob && ob.count > 0;
    const label = n.lines.join(' ');
    return (
      <g
        key={`hit-${id}`}
        className={`tag${active ? ' tag-on' : ''}`}
        role={readOnly ? undefined : 'button'}
        tabIndex={readOnly ? undefined : 0}
        aria-label={readOnly ? label : `Open ${label}${blocked ? ` — ${ob.count} ${ob.label}` : ''}`}
        onClick={readOnly ? undefined : () => onNavigateView(n.view, n.report)}
        onKeyDown={readOnly ? undefined : (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onNavigateView(n.view, n.report); } }}
        style={readOnly ? { cursor: 'default', pointerEvents: 'none' as const } : undefined}
        onMouseEnter={() => setHover(id)}
        onMouseLeave={() => setHover(null)}
        onFocus={() => setHover(id)}
        onBlur={() => setHover(null)}
      >
        <title>{blocked ? `${label}: ${ob.count} ${ob.label}` : label}</title>
        <polygon points={tg.pts} className="tag-hit" />
        {blocked && <circle cx={tg.badge[0]} cy={tg.badge[1]} r={15} fill="#E5484D" stroke="#FFFFFF" strokeWidth={3.5} className="obs-badge" pointerEvents="none" />}
      </g>
    );
  };
  const piece = (p: Piece) => <image href={spr(p.n)} x={p.x} y={p.y} width={p.w} height={p.h} pointerEvents="none" />;
  // One hanging module = thread (swings from its knot) -> tag (hangs from the thread's end, stays fairly upright) -> tassels / modules hanging below.
  const renderMod = (id: string): React.ReactNode => {
    const m = HUB_MODS[id];
    const [ex, ey] = m.eye;
    const kids = HUB_NODES.filter((h) => HUB_MODS[h.id].parent === id).map((h) => renderMod(h.id));
    const tagG = (
      <g ref={(el) => { swayRefs.current[`${id}:tag`] = el; }}>
        <g transform={`translate(${-ex} ${-ey})`}>
          {m.tassels?.map((ts, k) => (
            <g key={`ts${k}`} transform={`translate(${ts.at[0]} ${ts.at[1]})`}>
              <g ref={(el) => { swayRefs.current[`${id}:tassel${k}`] = el; }}>
                <g transform={`translate(${-ts.at[0]} ${-ts.at[1]})`}>{piece(ts.piece)}</g>
              </g>
            </g>
          ))}
          {kids}
          {piece(m.tag)}
          {hitArea(id)}
        </g>
      </g>
    );
    if (m.parent) return <g key={id} transform={`translate(${ex} ${ey})`}>{tagG}</g>;
    const [tx, ty] = m.tie;
    return (
      <g key={id} transform={`translate(${tx} ${ty})`}>
        <g ref={(el) => { swayRefs.current[`${id}:thread`] = el; }}>
          <g transform={`translate(${-tx} ${-ty})`}>
            {m.thread && piece(m.thread)}
            <g transform={`translate(${ex} ${ey})`}>{tagG}</g>
          </g>
        </g>
      </g>
    );
  };

  // Motion + water ripples (not run when the person asked the system for reduced motion)
  useEffect(() => {
    if (!SCENE_IMAGE || !spritesOk || calm) return undefined;
    const svg = svgRef.current;
    if (!svg) return undefined;
    const lights = Array.from(svg.querySelectorAll<SVGElement>('[data-rl]'));
    const darks = Array.from(svg.querySelectorAll<SVGElement>('[data-rd]'));
    const wob = WATER_PATCHES.map((_, i) => {
      const map = svg.querySelector<SVGElement>(`[data-wobble="${i}"]`);
      const group = svg.querySelector<SVGElement>(`[data-wgroup="${i}"]`);
      return map && group ? { map, group } : null;
    });
    const rip = new RippleSystem(lights, darks, wob);
    const R = swayRefs.current;
    const rot = (el: SVGGElement | null | undefined, a: number) => { if (el) el.setAttribute('transform', `rotate(${a.toFixed(3)})`); };
    const t0 = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const t = (now - t0) / 1000;
      for (const id of Object.keys(HUB_MODS)) {
        const m = HUB_MODS[id];
        if (m.parent) {
          const p = HUB_MODS[m.parent];
          rot(R[`${id}:tag`], childAbs(p.motion, m.motion, t, p.tie[0]) - tagAbs(p.motion, t, p.tie[0]));
          continue;
        }
        const x = m.tie[0];
        const th = swing(m.motion, t, x);
        const ta = tagAbs(m.motion, t, x);
        rot(R[`${id}:thread`], th);
        rot(R[`${id}:tag`], ta - th);
        m.tassels?.forEach((_, k) => rot(R[`${id}:tassel${k}`], tasselAbs(m.motion, t, x, k) - ta));
      }
      const sh = HUB_MODS.showrooms;
      const mx = HUB_MODS.matrix;
      rip.track('showrooms', t, swing(sh.motion, t, sh.tie[0]), sh.motion.amp, 356, 1430, 0);
      rip.track('refill', t, swing(mx.motion, t, mx.tie[0]), mx.motion.amp, 990, 1442, 1);
      rip.update(t);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [calm, spritesOk]);

  return (
    <section className="hub" aria-label="Cockpit navigation">
      <svg ref={svgRef} className="hub-svg" viewBox={`0 ${vbY.toFixed(1)} ${HW} ${vbH.toFixed(1)}`} role="group" aria-label="Module navigation tree" preserveAspectRatio="xMidYMax meet" overflow="visible" style={{ ['--hub-minh' as any]: `${minH}px` }}>
        <defs>
          <filter id="dmxGlow" x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="3.2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="dmxHexGlow" x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="10" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="dmxHex3d" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="5" stdDeviation="4.5" floodColor="#06183A" floodOpacity="0.5" />
            <feDropShadow dx="0" dy="1" stdDeviation="1.5" floodColor="#8EB1E4" floodOpacity="0.3" />
          </filter>
          <filter id="dmxLightBloom" x="-80%" y="-80%" width="260%" height="260%">
            <feGaussianBlur stdDeviation="3.5" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          {/* Natural materials */}
          <linearGradient id="dmxTrunkBark" gradientUnits="userSpaceOnUse" x1="326" y1="0" x2="434" y2="0">
            <stop offset="0" stopColor="#2E1F13" />
            <stop offset="0.28" stopColor="#5B3D26" />
            <stop offset="0.5" stopColor="#7A5535" />
            <stop offset="0.74" stopColor="#4F3420" />
            <stop offset="1" stopColor="#2A1B10" />
          </linearGradient>
          <linearGradient id="dmxBranchBark" gradientUnits="userSpaceOnUse" x1="0" y1="90" x2="0" y2="560">
            <stop offset="0" stopColor="#7A5535" />
            <stop offset="0.55" stopColor="#5B3D26" />
            <stop offset="1" stopColor="#3E2A1A" />
          </linearGradient>
          <linearGradient id="dmxRoot" gradientUnits="userSpaceOnUse" x1="0" y1="590" x2="0" y2="720">
            <stop offset="0" stopColor="#D4B07C" />
            <stop offset="1" stopColor="#A87E50" />
          </linearGradient>
          <linearGradient id="dmxSoil" gradientUnits="userSpaceOnUse" x1="0" y1="590" x2="0" y2="790">
            <stop offset="0" stopColor="#3B291B" />
            <stop offset="0.12" stopColor="#47311F" />
            <stop offset="0.34" stopColor="#6A4A2F" />
            <stop offset="0.62" stopColor="#80603D" />
            <stop offset="0.85" stopColor="#6E5238" />
            <stop offset="1" stopColor="#53402F" />
          </linearGradient>
          <filter id="dmxSoilFine" x="0" y="0" width="100%" height="100%" colorInterpolationFilters="sRGB">
            <feTurbulence type="fractalNoise" baseFrequency="0.55" numOctaves="2" seed="4" />
            <feColorMatrix values="0 0 0 0 0.07  0 0 0 0 0.04  0 0 0 0 0.02  3.4 0 0 0 -1.35" />
          </filter>
          <filter id="dmxSoilLight" x="0" y="0" width="100%" height="100%" colorInterpolationFilters="sRGB">
            <feTurbulence type="fractalNoise" baseFrequency="0.7" numOctaves="2" seed="11" />
            <feColorMatrix values="0 0 0 0 0.86  0 0 0 0 0.7  0 0 0 0 0.5  0 3.1 0 0 -1.45" />
          </filter>
          <filter id="dmxSoilMoist" x="0" y="0" width="100%" height="100%" colorInterpolationFilters="sRGB">
            <feTurbulence type="fractalNoise" baseFrequency="0.016 0.03" numOctaves="3" seed="7" />
            <feColorMatrix values="0 0 0 0 0.1  0 0 0 0 0.06  0 0 0 0 0.03  2.4 0 0 0 -1.0" />
          </filter>
          {/* Diamonds + platinum */}
          <linearGradient id="dmxDiamond" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#F6FEFF" />
            <stop offset="0.35" stopColor="#BDEBFB" />
            <stop offset="0.7" stopColor="#6CC0EC" />
            <stop offset="1" stopColor="#D2F2FF" />
          </linearGradient>
          <linearGradient id="dmxPlat" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#FFFFFF" />
            <stop offset="0.3" stopColor="#CBD3DA" />
            <stop offset="0.55" stopColor="#8E99A4" />
            <stop offset="0.8" stopColor="#E9EEF2" />
            <stop offset="1" stopColor="#A5AFB9" />
          </linearGradient>
          <radialGradient id="dmxGemHalo" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.75" />
            <stop offset="0.4" stopColor="#CFF1FF" stopOpacity="0.3" />
            <stop offset="1" stopColor="#CFF1FF" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="dmxDiamondSheen" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.5" />
            <stop offset="0.45" stopColor="#FFFFFF" stopOpacity="0" />
            <stop offset="1" stopColor="#7FC8FF" stopOpacity="0.22" />
          </linearGradient>
          <CutSymbols />
          <PalmDefs />
          <path id="dmxStar" d="M0 -1 L0.13 -0.13 L1 0 L0.13 0.13 L0 1 L-0.13 0.13 L-1 0 L-0.13 -0.13 Z" fill="#FFFFFF" />
          <radialGradient id="dmxSkyGlow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.55" />
            <stop offset="1" stopColor="#FFFFFF" stopOpacity="0" />
          </radialGradient>
          {/* Tag body: glossy cobalt blue with a lighter bevelled rim (colours taken from the picture) */}
          <linearGradient id="dmxHexFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#2C8AD0" />
            <stop offset="0.5" stopColor="#0B5CA8" />
            <stop offset="1" stopColor="#03438A" />
          </linearGradient>
          <linearGradient id="dmxHexSheen" x1="0" y1="0" x2="0.8" y2="1">
            <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.30" />
            <stop offset="0.35" stopColor="#CFE8FF" stopOpacity="0.08" />
            <stop offset="1" stopColor="#FFFFFF" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="dmxHexRim" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#9CCDF2" />
            <stop offset="0.5" stopColor="#3F8FD0" />
            <stop offset="1" stopColor="#7FB8E6" />
          </linearGradient>
          {SCENE_IMAGE && <image id="dmxSceneImg" href={spritesOk ? SCENE_CLEAN : SCENE_ORIG} x={0} y={0} width={SCENE_PX.w} height={SCENE_PX.h} />}
          {SCENE_IMAGE && (
            <>
              <radialGradient id="dmxWaterFade"><stop offset="0" stopColor="#fff" /><stop offset="0.5" stopColor="#fff" /><stop offset="1" stopColor="#000" /></radialGradient>
              <filter id="dmxRipBlur" filterUnits="userSpaceOnUse" x={0} y={1380} width={SCENE_PX.w} height={300}><feGaussianBlur stdDeviation="1.1" /></filter>
              {WATER_PATCHES.map((p, i) => (
                <React.Fragment key={`wd${i}`}>
                  <mask id={`dmxWaterMask${i}`} maskUnits="userSpaceOnUse" x={p.cx - p.rx} y={p.cy - p.ry} width={2 * p.rx} height={2 * p.ry}>
                    <ellipse cx={p.cx} cy={p.cy} rx={p.rx} ry={p.ry} fill="url(#dmxWaterFade)" />
                  </mask>
                  <filter id={`dmxWaterWobble${i}`} filterUnits="userSpaceOnUse" x={p.cx - p.rx} y={p.cy - p.ry} width={2 * p.rx} height={2 * p.ry} colorInterpolationFilters="sRGB">
                    <feTurbulence type="fractalNoise" baseFrequency="0.011 0.04" numOctaves={2} seed={7 + i * 5} result="n" />
                    <feDisplacementMap data-wobble={i} in="SourceGraphic" in2="n" scale={0} xChannelSelector="R" yChannelSelector="G" />
                  </filter>
                </React.Fragment>
              ))}
            </>
          )}
          {SCENE_IMAGE && (
            <>
              <linearGradient id="dmxFadeL" x1="0" y1="0" x2="1" y2="0"><stop offset={0} stopColor="#000" /><stop offset={1} stopColor="#fff" /></linearGradient>
              <linearGradient id="dmxFadeR" x1="0" y1="0" x2="1" y2="0"><stop offset={0} stopColor="#fff" /><stop offset={1} stopColor="#000" /></linearGradient>
              <linearGradient id="dmxFadeGy" gradientUnits="userSpaceOnUse" x1={0} y1={SCENE_Y0} x2={0} y2={SCENE_Y0 + SCENE_H}>
                <stop offset={0} stopColor="#000" />
                <stop offset={(SCENE_FADE * SCENE_K) / SCENE_H} stopColor="#fff" />
                <stop offset={1} stopColor="#fff" />
              </linearGradient>
              <mask id="dmxFadeX" maskUnits="userSpaceOnUse" x={-50} y={SCENE_Y0 - 50} width={HW + 100} height={SCENE_H + 100}>
                <rect x={-50} y={SCENE_Y0 - 50} width={HW + 100} height={SCENE_H + 100} fill="#fff" />
                {FADE_ROWS.map((r) => (
                  <g key={r.y}>
                    <rect x={0} y={SCENE_Y0 + r.y * SCENE_K} width={r.wl * SCENE_K} height={FADE_ROW * SCENE_K + 0.6} fill="url(#dmxFadeL)" />
                    <rect x={HW - r.wr * SCENE_K} y={SCENE_Y0 + r.y * SCENE_K} width={r.wr * SCENE_K} height={FADE_ROW * SCENE_K + 0.6} fill="url(#dmxFadeR)" />
                  </g>
                ))}
              </mask>
              <mask id="dmxFadeY" maskUnits="userSpaceOnUse" x={-50} y={SCENE_Y0 - 50} width={HW + 100} height={SCENE_H + 100}>
                <rect x={-50} y={SCENE_Y0 - 50} width={HW + 100} height={SCENE_H + 100} fill="url(#dmxFadeGy)" />
              </mask>
            </>
          )}
        </defs>

        {SCENE_IMAGE ? (
          <g className="scene-art" aria-hidden="true" pointerEvents="none">
            {/* wide / tall cards: the picture's outer edge continues as a soft blurred extension (no streaks, no repeated tree) */}
            <image href={SCENE_EDGE_T} x={-SCENE_SIDE - (SCENE_PAD * SCENE_K - SCENE_SIDE)} y={SCENE_Y0 - 1000} width={(SCENE_PX.w + SCENE_PAD * 2) * SCENE_K} height={1000 + SCENE_FADE * SCENE_K + 1} preserveAspectRatio="none" />
            <image href={SCENE_EDGE_L} x={-SCENE_SIDE} y={SCENE_Y0} width={SCENE_SIDE + 180 * SCENE_K} height={SCENE_H} preserveAspectRatio="none" />
            <image href={SCENE_EDGE_R} x={HW - 180 * SCENE_K} y={SCENE_Y0} width={SCENE_SIDE + 180 * SCENE_K} height={SCENE_H} preserveAspectRatio="none" />
            <g mask={sideGap ? 'url(#dmxFadeX)' : undefined}><g mask="url(#dmxFadeY)"><use href="#dmxSceneImg" transform={`translate(0 ${SCENE_Y0.toFixed(2)}) scale(${SCENE_K.toFixed(5)})`} /></g></g>
          </g>
        ) : (
          <>
        {/* Sky glow behind the crown */}
        <ellipse cx={380} cy={190} rx={340} ry={360} fill="url(#dmxSkyGlow)" />

        {/* Ground + soil (extends past the viewBox so it fills the card edge to edge) */}
        <path d={`M-1600 ${GROUND_Y + 2} C-200 ${GROUND_Y - 2}, 100 ${GROUND_Y + 4}, 380 ${GROUND_Y} S 700 ${GROUND_Y - 3}, 2400 ${GROUND_Y + 2} L2400 2200 L-1600 2200 Z`} fill="url(#dmxSoil)" />
        <path d={`M-1600 ${GROUND_Y + 2} C-200 ${GROUND_Y - 2}, 100 ${GROUND_Y + 4}, 380 ${GROUND_Y} S 700 ${GROUND_Y - 3}, 2400 ${GROUND_Y + 2} L2400 ${GROUND_Y + 9} C 700 ${GROUND_Y + 5}, 380 ${GROUND_Y + 9}, -1600 ${GROUND_Y + 8} Z`} fill="#4A7F34" />
        {/* Soil realism: moisture blotches, fine grain, light mineral grit, faint horizon bands */}
        <g aria-hidden="true" pointerEvents="none">
          <rect x={-800} y={GROUND_Y + 8} width={2360} height={HH - GROUND_Y} filter="url(#dmxSoilMoist)" opacity={0.55} />
          <path d={`M-800 ${GROUND_Y + 62} C-200 ${GROUND_Y + 52}, 150 ${GROUND_Y + 76}, 420 ${GROUND_Y + 60} S 900 ${GROUND_Y + 68}, 1560 ${GROUND_Y + 58} L1560 ${GROUND_Y + 96} C 900 ${GROUND_Y + 104}, 420 ${GROUND_Y + 88}, -800 ${GROUND_Y + 100} Z`} fill="#C79A63" opacity={0.1} />
          <rect x={-800} y={GROUND_Y + 8} width={2360} height={HH - GROUND_Y} filter="url(#dmxSoilFine)" opacity={0.7} />
          <rect x={-800} y={GROUND_Y + 8} width={2360} height={HH - GROUND_Y} filter="url(#dmxSoilLight)" opacity={0.4} />
        </g>
        <g>
          {tree.specks.map((p, i) => <ellipse key={`s${i}`} cx={p.x} cy={p.y} rx={p.rx} ry={p.ry} fill={p.c} fillOpacity={p.o} />)}
        </g>


        {/* Diamonds packed through the soil: the back layer sits behind the roots */}
        <g aria-hidden="true" pointerEvents="none">
          {tree.gems.filter((g) => !g.front).map((g, i) => renderGem(g, i, 'gb'))}
        </g>

        {/* Roots: fibrous palm roots threading through the diamonds */}
        <g fill="url(#dmxRoot)" stroke="#5A3A20" strokeWidth={0.5} strokeLinejoin="round">
          {tree.roots.map((r, i) => <path key={`r${i}`} d={r.d} fillOpacity={r.thin ? 0.9 : 1} />)}
        </g>

        {/* Front diamonds overlap the roots */}
        <g aria-hidden="true" pointerEvents="none">
          {tree.gems.filter((g) => g.front).map((g, i) => renderGem(g, i, 'gf'))}
        </g>

        {/* Palm tree: trunk still, fronds sway in the wind */}
        <PalmTree calm={calm} onFrame={followWind} />

        {/* Grass tufts over the base of the trunk */}
        <g fill="none" strokeLinecap="round" strokeWidth={1.4}>
          {tree.grass.map((g, i) => <path key={`g${i}`} d={g.d} stroke={g.c} />)}
        </g>

          </>
        )}

        {SCENE_IMAGE ? (
          spritesOk ? (
          <>
            <g transform={`translate(0 ${SCENE_Y0.toFixed(2)}) scale(${SCENE_K.toFixed(5)})`} pointerEvents="none" aria-hidden="true">
              {WATER_PATCHES.map((_, i) => (
                <g key={`wp${i}`} className="scene-art" mask={`url(#dmxWaterMask${i})`} data-wgroup={i} style={{ display: 'none' }}>
                  <g filter={`url(#dmxWaterWobble${i})`}><use href="#dmxSceneImg" /></g>
                </g>
              ))}
              <g filter="url(#dmxRipBlur)">
                {Array.from({ length: RIP_N }, (_, i) => (
                  <g key={`rp${i}`}>
                    <ellipse data-rd="" rx={1} ry={1} fill="none" stroke="#06182E" strokeOpacity={0} />
                    <ellipse data-rl="" rx={1} ry={1} fill="none" stroke="#E8F3FF" strokeOpacity={0} />
                  </g>
                ))}
              </g>
            </g>
            <g transform={`translate(0 ${SCENE_Y0.toFixed(2)}) scale(${SCENE_K.toFixed(5)})`}>
              {HUB_NODES.filter((n) => !HUB_MODS[n.id].parent).map((n) => renderMod(n.id))}
            </g>
          </>
          ) : (
            <g transform={`translate(0 ${SCENE_Y0.toFixed(2)}) scale(${SCENE_K.toFixed(5)})`}>
              {HUB_NODES.map((n) => hitArea(n.id))}
            </g>
          )
        ) : (
          <>
        {HUB_NODES.map((n) => {
          const pos = { x: n.x, y: n.y, tie: PALM_TIES[n.id] || ([0, -KITE_GAP] as [number, number]) };
          const tie = pos.tie;
          // thread: from the leaf down to the little eyelet at the top corner of the tag
          const eye: [number, number] = [0, -R + 7];
          const bend = tie[0] * 0.5 + (tie[0] >= 0 ? 3 : -3);
          const strPath = `M${f1(tie[0])} ${f1(tie[1])} Q${f1(bend)} ${f1((tie[1] + eye[1]) / 2)} ${f1(eye[0])} ${f1(eye[1])}`;
          const lineH = 14.5;
          const textTop = -(lineH * n.lines.length) / 2 + 2;
          const active = hover === n.id;
          const ob = obstacles[n.id];
          const blocked = !!ob && ob.count > 0;
          return (
            <g key={n.id} ref={(el) => { kiteRefs.current[n.id] = el; }}>
            <g transform={`translate(${pos.x} ${pos.y})`}>
              {/* golden thread with a small knot on the leaf */}
              <path d={strPath} fill="none" stroke="#3A2610" strokeOpacity={0.55} strokeWidth={2.6} strokeLinecap="round" />
              <path d={strPath} fill="none" stroke="#D9AE5A" strokeWidth={1.5} strokeLinecap="round" />
              <path d={strPath} fill="none" stroke="#FFE6A3" strokeOpacity={0.6} strokeWidth={0.5} strokeLinecap="round" />
              <circle cx={tie[0]} cy={tie[1]} r={2.6} fill="#B98532" stroke="#FFE6A3" strokeWidth={0.8} />
              <g
                className={`hex${active ? ' hex-on' : ''}`}
                role={readOnly ? undefined : 'button'}
                tabIndex={readOnly ? undefined : 0}
                aria-label={readOnly ? n.lines.join(' ') : `Open ${n.lines.join(' ')}${blocked ? ` — ${ob.count} ${ob.label}` : ''}`}
                filter="url(#dmxHex3d)"
                onClick={readOnly ? undefined : () => onNavigateView(n.view, n.report)}
                onKeyDown={readOnly ? undefined : (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onNavigateView(n.view, n.report); } }}
                style={readOnly ? { cursor: 'default', pointerEvents: 'none' as const } : undefined}
                onMouseEnter={() => setHover(n.id)}
                onMouseLeave={() => setHover(null)}
                onFocus={() => setHover(n.id)}
                onBlur={() => setHover(null)}
              >
                <title>{blocked ? `${n.lines.join(' ')}: ${ob.count} ${ob.label}` : n.lines.join(' ')}</title>
                <polygon points={hexPts} className="hex-glow" filter="url(#dmxHexGlow)" fill="#2C8AD0" />
                <polygon points={hexPts} className="hex-shape" fill="url(#dmxHexFill)" />
                <polygon points={hexPts} fill="url(#dmxHexSheen)" stroke="none" />
                <polygon points={hexInner} className="hex-inner" fill="none" />
                {n.lines.map((ln, i) => (
                  <text
                    key={ln}
                    x={0}
                    y={textTop + lineH * i + lineH / 2}
                    textAnchor="middle"
                    dominantBaseline="central"
                    className="hex-label"
                  >
                    {ln}
                  </text>
                ))}
                {/* eyelet the thread passes through */}
                <circle cx={eye[0]} cy={eye[1]} r={3.3} fill="#06376F" stroke="#E7C26E" strokeWidth={1.3} />
              </g>
              {/* small red dot on the upper-right corner = module has obstacles (count is in the tooltip) */}
              {blocked && <circle cx={R * 0.866} cy={-R / 2} r={6.5} fill="#E5484D" stroke="#FFFFFF" strokeWidth={2.2} className="obs-badge" pointerEvents="none" />}
            </g>
            </g>
          );
        })}

          </>
        )}

      </svg>
    </section>
  );
};

/* ───────────────────────────── Styles ───────────────────────────── */
const CSS = `
:host{display:block;width:100%}
.dmxc{all:initial;display:block;box-sizing:border-box;width:100%;font-family:Inter,"Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif;font-size:14px;line-height:1.45;color:#0B2545;background:linear-gradient(180deg,#F8FBFF 0%,#E9F1FA 100%);-webkit-font-smoothing:antialiased}
.dmxc *,.dmxc *::before,.dmxc *::after{box-sizing:border-box}
.dmxc h3,.dmxc p,.dmxc ul,.dmxc li{margin:0;padding:0;list-style:none}
/* Fill available width — no hard max-width so zoom-out / wide screens stay dense */
.wrap{width:100%;max-width:none;margin:0;padding:14px 16px 20px}
.toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-bottom:12px}
.toolbar .lbl{font-size:12px;font-weight:700;color:#3D5A78;margin-right:2px}
.btn{appearance:none;-webkit-appearance:none;font:inherit;font-size:13px;font-weight:700;line-height:1.2;border-radius:999px;padding:7px 14px;cursor:pointer;border:1px solid #8FB0D6;background:#FFFFFF;color:#0B2545;transition:background .15s,box-shadow .15s}
.btn:hover{background:#E4EEFA}
.btn:focus-visible,.link:focus-visible,.rowbtn:focus-visible{outline:3px solid #7FB5FF;outline-offset:2px}
.btn.on{background:#0B57D0;border-color:#0B57D0;color:#FFFFFF}
.btn.on:hover{background:#0A49AC}
.btn.primary{background:#0B57D0;border-color:#0B57D0;color:#FFFFFF;margin-left:auto;padding:8px 18px}
.btn.primary:hover{background:#0A49AC}
/* 3-column grid stretches to full width; columns share space evenly */
.grid{display:grid;grid-template-columns:minmax(240px,1fr) minmax(280px,1.6fr) minmax(260px,1.15fr);gap:12px;align-items:stretch}
.col{display:flex;flex-direction:column;gap:12px;min-width:0;height:100%}
.panel{background:#FFFFFF;border:1px solid #C5D7EC;border-radius:16px;box-shadow:0 4px 18px rgba(11,37,69,.07);padding:14px;flex:1 1 auto}
.kicker{font-size:11px;font-weight:800;letter-spacing:.07em;text-transform:uppercase;color:#3D5A78}
.title{font-size:14px;font-weight:800;color:#0B2545}
.note{font-size:12px;color:#3D5A78}
.big{font-size:38px;font-weight:800;line-height:1.1;color:#0B57D0;font-variant-numeric:tabular-nums;margin-top:4px}
.mid{font-size:30px;font-weight:800;line-height:1.1;color:#0B57D0;font-variant-numeric:tabular-nums;margin-top:4px}
.row{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
.iconbox{display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:12px;background:#E3EEFC;border:1px solid #B5CFEF;color:#0B57D0;flex:none}
.chip{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:3px 10px;font-size:11px;font-weight:800;border:1px solid transparent}
.chip-live{background:#E3F6EC;color:#065F46;border-color:#A7E3C3}
.chip-open{background:#DCEBFF;color:#0A3F96;border-color:#A9C9F5}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#10B981}
.tiles{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}
.tile{border-radius:12px;padding:10px;text-align:center;border:1px solid}
.tile .k{font-size:10.5px;font-weight:800;letter-spacing:.05em;text-transform:uppercase}
.tile .v{font-size:22px;font-weight:800;margin-top:2px;font-variant-numeric:tabular-nums}
.tile .s,.tile p.s{margin:2px 0 0;font-size:10px;font-weight:700;opacity:.75;letter-spacing:.02em}
.t-in{background:#DDF6E8;border-color:#9ADBB9;color:#065F46}
.t-out{background:#FDE4E4;border-color:#F3A9A9;color:#991B1B}
.t-buy{background:#FDF0CC;border-color:#EBCB72;color:#7A3E06}
.t-act{background:#DCEBFF;border-color:#A9C9F5;color:#0A3F96}
.rem{display:flex;gap:10px;margin-top:10px}
.rem .bang{flex:none;width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px}
.sev-high .bang{background:#FDE4E4;color:#991B1B}
.sev-med .bang{background:#FDF0CC;color:#7A3E06}
.rem .t{font-size:13px;font-weight:700;color:#0B2545}
.rem .d{font-size:12px;color:#3D5A78}
.two{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.top{display:grid;grid-template-columns:48px 1fr 40px;align-items:center;gap:8px;margin-top:10px;font-size:12px}
.top .w{font-weight:800;color:#0B2545;font-variant-numeric:tabular-nums}
.top .n{font-size:11px;color:#3D5A78;font-variant-numeric:tabular-nums}
.bar{height:8px;border-radius:99px;background:#DCE8F6;overflow:hidden;margin-top:3px}
.bar>i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#0B57D0,#22B8F0)}
.top .p{text-align:right;font-weight:800;color:#0B2545;font-variant-numeric:tabular-nums}
table{width:100%;border-collapse:collapse;font-size:12px}
th{padding:0 0 6px;text-align:left;font-size:10.5px;font-weight:800;letter-spacing:.05em;color:#3D5A78}
td{padding:7px 0;border-top:1px solid #DCE8F6;color:#0B2545;vertical-align:middle}
.r{text-align:right}
.badge{display:inline-block;border-radius:6px;padding:2px 8px;font-size:10.5px;font-weight:800;background:#FDF0CC;color:#7A3E06}
.link{white-space:nowrap;appearance:none;background:none;border:0;font:inherit;font-size:12px;font-weight:800;color:#0A49AC;cursor:pointer;padding:2px 4px;border-radius:6px}
.link:hover{text-decoration:underline}
.heat{display:grid;gap:4px;align-items:stretch}
.heat .ch{font-size:10px;font-weight:800;color:#0B2545;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.rowbtn{appearance:none;font:inherit;font-size:10.5px;font-weight:800;text-align:left;border-radius:7px;padding:6px 6px;min-width:0;cursor:pointer;background:#0B2545;color:#FFFFFF;border:1px solid #0B2545;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.rowbtn:hover{background:#0B57D0;border-color:#0B57D0}
.cell{display:flex;align-items:center;justify-content:center;min-height:30px;border-radius:7px;font-size:10.5px;font-weight:800;font-variant-numeric:tabular-nums;border:1px solid rgba(11,37,69,.12)}
.legend{display:flex;align-items:center;gap:8px;margin-top:10px;font-size:11px;font-weight:700;color:#3D5A78}
.legend i{flex:1;height:8px;border-radius:99px;background:linear-gradient(90deg,#EAF4FF,#76B1F0,#2B78D6,#0B2545)}
/* hub — living tree: sky above, soil + roots below */
.hub{position:relative;overflow:hidden;border-radius:22px;border:1px solid #7EB6D9;background:
  linear-gradient(180deg,rgba(12,40,80,.12) 0%,rgba(255,255,255,.08) 35%,rgba(255,255,255,.05) 55%,rgba(20,60,30,.18) 100%),
  #1B3A5C;
  box-shadow:0 1px 0 rgba(255,255,255,.95) inset,0 14px 44px rgba(11,37,69,.14),0 4px 14px rgba(20,120,180,.12);
  padding:0}
.hub>*{position:relative;z-index:1}
/* artwork a little calmer (~12% less brightness / saturation) so the data on both sides stands out */
.scene-art{filter:saturate(.87) brightness(.9)}
.btn.toggle{display:inline-flex;align-items:center;gap:6px}
.btn.toggle .sw{position:relative;width:26px;height:14px;border-radius:99px;background:#B5CFEF;transition:background .15s}
.btn.toggle .sw::after{content:"";position:absolute;top:2px;left:2px;width:10px;height:10px;border-radius:50%;background:#FFFFFF;transition:transform .15s}
.btn.toggle.on .sw{background:#FFFFFF}
.btn.toggle.on .sw::after{transform:translateX(12px);background:#0B57D0}
.clean{display:flex;flex-direction:column;gap:12px;min-width:0}
.clean .panel{flex:0 0 auto}
.clean table{margin-top:8px}
.clean th.r,.clean td.r{text-align:right}
.clean td{padding:8px 0}
.clean .open{appearance:none;font:inherit;font-size:11.5px;font-weight:800;border-radius:7px;padding:4px 10px;cursor:pointer;background:#0B2545;color:#FFFFFF;border:1px solid #0B2545}
.clean .open:hover{background:#0B57D0;border-color:#0B57D0}
.st-short{background:#FDE4E4;color:#991B1B}.st-over{background:#FDF0CC;color:#7A3E06}.st-ok{background:#DDF6E8;color:#065F46}
.num{font-variant-numeric:tabular-nums}
.hub-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;padding:2px 6px 0}
.hub-sub{font-size:12px;color:#3D5A78;margin-top:2px}
.hub-svg{display:block;width:100%;height:auto;min-height:max(540px,var(--hub-minh,0px));max-height:min(84vh,860px);margin:0 auto}
/* Wide layout: the tree card stretches to the full height of the row (same as the side columns),
   so there is no empty strip under it. The tree stays centered inside the card. */
@media (min-width:1241px){
  .hub-wrap{display:flex;min-width:0}
  .hub-wrap>.hub{flex:1 1 auto;display:flex;flex-direction:column;min-width:0}
  .hub-wrap>.hub .hub-svg{flex:1 1 0;height:auto;max-height:none}
}
.hub-foot{text-align:center;font-size:11.5px;font-weight:700;color:#F3E3CC;text-shadow:0 1px 2px rgba(0,0,0,.55);padding:6px 0 10px;position:relative;z-index:2}
.hex{cursor:pointer;outline:none;transform-origin:0 0;transition:transform .22s cubic-bezier(.2,.8,.2,1),filter .22s ease;filter:drop-shadow(0 7px 12px rgba(42,27,16,.35))}
.hex:hover,.hex-on{transform:scale(1.11);filter:drop-shadow(0 12px 22px rgba(20,60,140,.5))}
.hex-glow{opacity:.14}
.hex-shape{stroke:url(#dmxHexRim);stroke-width:2.6}
.hex-inner{stroke:#8CC4F0;stroke-width:1;opacity:.6}
.hex-on .hex-shape{stroke:#FFFFFF;stroke-width:3}
.hex:focus-visible .hex-shape{stroke:#FFFFFF;stroke-width:3.5}
.tag{cursor:pointer;outline:none}
.tag-hit{fill:rgba(255,255,255,0);stroke:none;transition:fill .2s ease}
.tag:hover .tag-hit,.tag-on .tag-hit{fill:rgba(255,255,255,.17)}
.tag:focus-visible .tag-hit{fill:rgba(255,255,255,.17);stroke:#FFFFFF;stroke-width:4;stroke-linejoin:round}
.hex-label{fill:#FFFFFF;font-size:12.5px;font-weight:800;letter-spacing:.01em;paint-order:stroke;stroke:rgba(5,25,60,.45);stroke-width:.8px}
.flow{stroke-dasharray:7 14;animation:dmxflow 2.6s linear infinite;filter:drop-shadow(0 0 4px rgba(20,180,232,.55))}
@keyframes dmxflow{to{stroke-dashoffset:-88}}
.dmx-light{animation:dmxtwinkle 2.4s ease-in-out infinite alternate}
.dmx-light:nth-child(3n){animation-delay:.4s}
.dmx-light:nth-child(3n+1){animation-delay:.9s}
.dmx-light:nth-child(3n+2){animation-delay:1.4s}
@keyframes dmxtwinkle{from{opacity:.72}to{opacity:1}}
@keyframes dmxsap{to{stroke-dashoffset:-100}}
@keyframes dmxring{0%{transform:scale(1);opacity:.95}100%{transform:scale(1.32);opacity:0}}
@keyframes dmxbadge{0%,100%{transform:scale(1)}50%{transform:scale(1.18)}}
.flow-ok{stroke-dasharray:3 22;animation:dmxsap 5s linear infinite}
.flow-hot{stroke-dasharray:9 16;animation:dmxsap 1.1s linear infinite;filter:drop-shadow(0 0 4px rgba(255,140,30,.9))}
.obs-ring{stroke:#FF8A1F;stroke-width:4;transform-origin:0 0;animation:dmxring 1.6s ease-out infinite;pointer-events:none}
.obs-badge{transform-box:fill-box;transform-origin:center;animation:dmxbadge 1.2s ease-in-out infinite}
.hex-warn .hex-shape{stroke:#FFB020}
.hex-warn.hex-on .hex-shape{stroke:#FFD36B}
/* kite modules: pendulum sway about the string's tie point + a slow 3-D-ish turn (squeeze + skew) */
@keyframes dmxkite{0%,100%{transform:rotate(calc(var(--a)*-.45deg)) translateY(0)}50%{transform:rotate(calc(var(--a)*1deg)) translateY(-2.5px)}}
@keyframes dmxturn{0%,100%{transform:scale(1,1) skewY(0deg)}25%{transform:scale(.93,1) skewY(-2.4deg)}50%{transform:scale(1,1) skewY(0deg)}75%{transform:scale(.94,1) skewY(2.4deg)}}
.kite{animation:dmxkite 7s ease-in-out infinite;will-change:transform}
.kite-turn{transform-origin:0 0;animation:dmxturn 8s ease-in-out infinite}
/* wind — trunk, branches and module nodes stay still; only the leaves flutter */
.lf{animation:dmxleaf 3.6s ease-in-out infinite;will-change:transform}
.lf1{animation-duration:4.3s}
.lf2{animation-duration:3.1s}
@keyframes dmxleaf{0%,100%{rotate:-13deg;translate:-.9px .5px}35%{rotate:4deg;translate:.4px -.3px}70%{rotate:15deg;translate:1.1px -.8px}}
/* sparkling gems in the soil */
@keyframes dmxspark{0%,52%,100%{opacity:0;transform:scale(.1) rotate(0deg)}16%{opacity:1;transform:scale(1.25) rotate(22deg)}30%{opacity:.55;transform:scale(.5) rotate(46deg)}}
@keyframes dmxhalo{0%,100%{opacity:.2}50%{opacity:.85}}
.gem-spark{transform-box:fill-box;transform-origin:center;opacity:0;animation:dmxspark var(--p,3s) ease-in-out infinite}
.gem-halo{animation:dmxhalo var(--p,3s) ease-in-out infinite}
@media (prefers-reduced-motion:reduce){.tag-hit{transition:none}.flow,.dmx-light,.flow-ok,.flow-hot,.obs-ring,.obs-badge,.lf,.gem-spark,.gem-halo{animation:none}.flow-dots{display:none}.kite,.kite-turn{animation:none}.hex{transition:none}}
@media (min-width:1280px){.grid{grid-template-columns:minmax(200px,.9fr) minmax(340px,1.9fr) minmax(220px,1fr)}}
@media (max-width:1240px){.grid{grid-template-columns:1fr 1fr}.hub-wrap{grid-column:1/-1;order:-1}}
@media (max-width:760px){.grid{grid-template-columns:1fr}.wrap{padding:12px}.btn.primary{margin-left:0}.hub-svg{min-height:max(440px,var(--hub-minh,0px))}}
`;

/* Clean (minimalist) centre column: the same navigation + branch numbers as plain tables, no artwork */
const CleanCenter: React.FC<{
  onNavigateView: (view: any, report?: any) => void;
  obstacles: Record<string, Obstacle>;
  branches: any[];
  onSelectBranch?: (b: string) => void;
  readOnly?: boolean;
}> = ({ onNavigateView, obstacles, branches, onSelectBranch, readOnly = false }) => (
  <div className="clean">
    <section className="panel" aria-label="Modules">
      <h3 className="title">Modules</h3>
      <p className="note" style={{ marginTop: 2 }}>Open a module. The count shows what needs attention now.</p>
      <table>
        <thead><tr><th>MODULE</th><th>NEEDS ATTENTION</th><th className="r" /></tr></thead>
        <tbody>
          {HUB_NODES.filter((n) => n.id !== 'cockpit').map((n) => {
            const o = obstacles[n.id];
            return (
              <tr key={n.id}>
                <td style={{ fontWeight: 700 }}>{n.lines.join(' ')}</td>
                <td>{o && o.count > 0 ? <><span className="badge num">{o.count}</span> <span className="note">{o.label}</span></> : <span className="note">All clear</span>}</td>
                <td className="r">{readOnly ? <span className="note">View only</span> : <button type="button" className="open" onClick={() => onNavigateView(n.view, n.report)}>Open</button>}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </section>
    <section className="panel" aria-label="Showroom status">
      <h3 className="title">Showroom status</h3>
      <div style={{ overflowX: 'auto' }}>
        <table>
          <thead><tr><th>BRANCH</th><th className="r">STOCK</th><th className="r">SOLD</th><th className="r">SELL-THRU</th><th className="r">STATUS</th></tr></thead>
          <tbody>
            {branches.length === 0 && <tr><td colSpan={5} style={{ textAlign: 'center', color: '#3D5A78' }}>Upload data to see branches.</td></tr>}
            {branches.map((b: any) => {
              const st = String(b.status || '');
              const cls = st === 'SHORTAGE' ? 'st-short' : st === 'OVERSTOCKED' ? 'st-over' : 'st-ok';
              const rate = Number(b.sellThroughRate || 0);
              return (
                <tr key={b.branch}>
                  <td><button type="button" className="link" style={{ padding: 0 }} onClick={() => onSelectBranch?.(b.branch)}>{b.branch}</button></td>
                  <td className="r num">{Number(b.totalCurrentStock || 0).toLocaleString()}</td>
                  <td className="r num">{Number(b.totalSold || 0).toLocaleString()}</td>
                  <td className="r num">{(rate <= 1 ? rate * 100 : rate).toFixed(1)}%</td>
                  <td className="r"><span className={`badge ${cls}`}>{st || '—'}</span></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  </div>
);

/* ───────────────────────────── Dashboard ───────────────────────────── */
export const NetSuiteHomeDashboard: React.FC<NetSuiteHomeDashboardProps> = ({
  report,
  onNavigateView,
  onSelectBranch,
  selectedTimeframe,
  onTimeframeChange,
  onOpenDailyUpload,
  readOnly = false,
}) => {
  // Live engine output (forecast alerts + redistribution recommendations) from the insights store.
  const aiInsightsProps = useAIInsightsPanelProps();
  // Clean view: hides the artwork and shows plain tables instead. Remembered per browser.
  const [cleanView, setCleanView] = useState<boolean>(() => {
    try { return typeof window !== 'undefined' && window.localStorage.getItem('dmx.cockpit.clean') === '1'; } catch { return false; }
  });
  const toggleClean = useCallback(() => {
    setCleanView((v) => {
      const nv = !v;
      try { window.localStorage.setItem('dmx.cockpit.clean', nv ? '1' : '0'); } catch { /* storage unavailable */ }
      return nv;
    });
  }, []);
  const totalStock = report.totalCurrentStock || 0;
  const totalSold = report.totalSold || 0;
  const sellThrough = useMemo(() => {
    const denom = totalSold + totalStock;
    return denom > 0 ? ((totalSold / denom) * 100).toFixed(1) : '0.0';
  }, [totalSold, totalStock]);

  const activeBranches = report.branchSummaries?.filter((b) => ((b as any).totalCurrentStock ?? 0) > 0).length || 0;

  const topItems = useMemo(() => {
    const items = report.weightSummaries || (report as any).skuSummaries || [];
    return [...items].sort((a: any, b: any) => ((b.soldQty ?? b.sold) || 0) - ((a.soldQty ?? a.sold) || 0)).slice(0, 5);
  }, [report]);

  const totalMoveIn = report.totalMoveIn ?? (report.branchSummaries || []).reduce((s, b) => s + ((b as any).moveIn || 0), 0);
  const totalMoveOut = report.totalMoveOut ?? (report.branchSummaries || []).reduce((s, b) => s + ((b as any).moveOut || 0), 0);
  const newBuy = report.totalNewStockToBuy ?? (report.weightSummaries || []).reduce(
    (s: number, w: any) => s + (w.buyQty || w.refillQty || w.newStockToBuy || 0), 0);
  const actionItems = report.variantsNeedingActionCount ?? (
    (report.actionAlerts || []).length ||
    (report.branchSummaries || []).filter((b) => ((b as any).moveIn || 0) > 0 || ((b as any).moveOut || 0) > 0).length);

  const reminders = useMemo(() => {
    const list: { title: string; detail: string; severity: 'high' | 'med' }[] = [];
    (report.actionAlerts || []).slice(0, 3).forEach((a: any) => {
      list.push({ title: a.title || a.message || a.type || 'Alert', detail: a.detail || a.description || a.message || '', severity: (a.severity === 'high' || a.priority === 'high') ? 'high' : 'med' });
    });
    if (list.length === 0) {
      (report.consignmentRecommendations || []).slice(0, 2).forEach((c: any) => {
        list.push({ title: c.title || `Consignment: ${c.weight || c.sku || ''}`, detail: c.detail || c.reason || '', severity: 'high' });
      });
    }
    if (list.length === 0) list.push({ title: 'All clear', detail: 'No urgent redistribution actions.', severity: 'med' });
    return list.slice(0, 3);
  }, [report]);

  const recentTransfers = useMemo(() => {
    const fromOrders = (report.transferOrders || []).slice(0, 4).map((t: any) => ({
      item: String(t.weight || t.sku || t.item || '—'), from: String(t.fromBranch || t.from || '—'),
      to: String(t.toBranch || t.to || '—'), qty: Number(t.qty || t.quantity || 1), status: String(t.priority || t.status || 'HIGH').toUpperCase(),
    }));
    if (fromOrders.length) return fromOrders;
    const rows: { item: string; from: string; to: string; qty: number; status: string }[] = [];
    (report.branchSummaries || []).forEach((b) => {
      if (((b as any).moveOut || 0) > 0) rows.push({ item: '—', from: b.branch, to: 'Network', qty: (b as any).moveOut || 0, status: 'HIGH' });
    });
    return rows.slice(0, 4);
  }, [report]);

  // Which modules currently have obstacles (drives the amber flow + red badge on the tree)
  const obstacles = useMemo<Record<string, Obstacle>>(() => {
    const weights: any[] = report.weightSummaries || [];
    const branches: any[] = (report.branchSummaries || []).filter((b: any) => !b.isWarehouse);
    const aged = branches.filter((b: any) => ((b.agingBreakdown?.oldPcs || 0) + (b.agingBreakdown?.dormantPcs || 0)) > 0).length;
    const overstocked = branches.filter((b: any) => b.status === 'OVERSTOCKED').length;
    const actions = report.variantsNeedingActionCount ?? branches.reduce((sum: number, b: any) => sum + (b.variantsNeedingAction || 0), 0);
    return {
      refill: { count: weights.filter((w) => (w.unmetShortage || 0) > 0).length, label: 'items need purchase' },
      design: { count: weights.filter((w) => (w.currentStock || 0) === 0 && (w.soldQty || 0) > 0).length, label: 'designs out of stock' },
      movement: { count: aged || overstocked, label: 'outlets with aged / excess stock' },
      showrooms: { count: branches.filter((b: any) => b.status === 'SHORTAGE').length, label: 'showrooms short of stock' },
      matrix: { count: actions || 0, label: 'variants need action' },
    };
  }, [report]);

  const heat = useMemo(() => {
    const matrix = report.matrix;
    const branches = (matrix?.branches?.length ? matrix.branches : (report.branchSummaries || []).map((b) => b.branch)).slice(0, 6);
    const weights = (matrix?.weights?.length ? matrix.weights : (report.weightSummaries || []).map((w: any) => String(w.weight || w.sku || ''))).slice(0, 8);
    let max = 1;
    const cells = branches.map((br) => weights.map((wt) => {
      const cell = matrix?.cells?.[br]?.[wt];
      const sold = cell?.sold || 0; const stock = cell?.stock || 0;
      if (sold > max) max = sold;
      return { sold, stock };
    }));
    return { rows: branches, cols: weights, cells, max };
  }, [report]);

  const spark = useMemo(() => {
    const vals = (report.branchSummaries || []).map((x) => x.totalCurrentStock || 0).slice(0, 14);
    if (vals.length < 2) return null;
    const mx = Math.max(...vals, 1);
    // Keep path inside the viewBox with padding so the line never clips card borders
    return vals.map((v, i) => `${(i / (vals.length - 1)) * 100},${32 - (v / mx) * 24}`).join(' ');
  }, [report]);

  return (
    <div className="flex flex-col gap-3 p-3 sm:p-4">
      {/* Operations cockpit — brand cyan neural tree is the hero */}
    <div className="min-w-0">
    <ShadowScope css={CSS}>
      <div className="dmxc">
        <div className="wrap">
          <div className="toolbar">
            <span className="lbl">Sales period:</span>
            {TF_OPTIONS.map((tf) => (
              <button key={tf} type="button" className={`btn${selectedTimeframe === tf ? ' on' : ''}`} onClick={() => onTimeframeChange(tf)} aria-pressed={selectedTimeframe === tf} disabled={readOnly}>{tf}</button>
            ))}
            <button type="button" className={`btn toggle${cleanView ? ' on' : ''}`} onClick={toggleClean} aria-pressed={cleanView} title="Hide the artwork and show plain data tables">
              <span className="sw" aria-hidden="true" />Clean view
            </button>
            {!readOnly && (
              <button type="button" className="btn primary" onClick={onOpenDailyUpload}>+ Daily Intake</button>
            )}
            {readOnly && (
              <span className="lbl" style={{ marginLeft: 8, opacity: 0.75 }}>View only</span>
            )}
          </div>

          <div className="grid">
            {/* LEFT KPIs */}
            <div className="col">
              <section className="panel">
                <div className="row">
                  <div>
                    <p className="kicker">Total stock</p>
                    <p className="big">{totalStock.toLocaleString()}</p>
                    <p className="note" style={{ marginTop: 4 }}>{activeBranches} active outlets</p>
                  </div>
                  <span className="iconbox"><Icon name="trend" /></span>
                </div>
                {spark ? (
                  <svg
                    viewBox="0 0 100 40"
                    preserveAspectRatio="none"
                    style={{ display: 'block', width: '100%', height: 48, marginTop: 12, marginBottom: 8, paddingBottom: 4 }}
                    aria-hidden="true"
                  >
                    <polygon points={`0,36 ${spark} 100,36`} fill="#22B8F0" fillOpacity="0.16" />
                    <polyline points={spark} fill="none" stroke="#0B57D0" strokeWidth="1.6" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" />
                  </svg>
                ) : (
                  <div style={{ height: 56, marginBottom: 8 }} />
                )}
              </section>

              <section className="panel">
                <h3 className="title">Distribution analysis · Stock × Sold</h3>
                <p className="note" style={{ marginTop: 2 }}>Where stock should move, stay, or need new buying.</p>
                <div className="tiles">
                  <div className="tile t-in" title="Stock arriving at outlets that need it. Always equals Move OUT because every unit transferred leaves one branch and arrives at another.">
                    <p className="k">Move in</p>
                    <p className="v">{Number(totalMoveIn).toLocaleString()}</p>
                    <p className="s">From other outlets</p>
                  </div>
                  <div className="tile t-out" title="Stock leaving surplus outlets. Always equals Move IN — closed redistribution (no stock is created or destroyed).">
                    <p className="k">Move out</p>
                    <p className="v">{Number(totalMoveOut).toLocaleString()}</p>
                    <p className="s">Surplus to transfer</p>
                  </div>
                  <div className="tile t-buy" title="Extra purchase required after redistribution — demand still exceeds total company stock.">
                    <p className="k">New buy</p>
                    <p className="v">{Number(newBuy).toLocaleString()}</p>
                    <p className="s">Procurement gap</p>
                  </div>
                  <div className="tile t-act"><p className="k">Action items</p><p className="v">{Number(actionItems).toLocaleString()}</p></div>
                </div>
              </section>

              <section className="panel">
                <div className="row" style={{ alignItems: 'center' }}>
                  <h3 className="title" style={{ display: 'flex', alignItems: 'center', gap: 6 }}><Icon name="bell" size={16} /> Reminders</h3>
                  <span className="chip chip-open">{reminders.length} open</span>
                </div>
                {reminders.map((r, i) => (
                  <div key={i} className={`rem sev-${r.severity}`}>
                    <span className="bang">!</span>
                    <div><p className="t">{r.title}</p>{r.detail && <p className="d">{r.detail}</p>}</div>
                  </div>
                ))}
              </section>
            </div>

            {/* CENTER — Neural tree (full size at 100% zoom) */}
            <div className="hub-wrap" style={{ minWidth: 0 }}>
              {cleanView
                ? <CleanCenter onNavigateView={onNavigateView} obstacles={obstacles} branches={(report.branchSummaries || []).filter((b: any) => !b.isWarehouse)} onSelectBranch={readOnly ? undefined : onSelectBranch} readOnly={readOnly} />
                : <CockpitHub onNavigateView={onNavigateView} activeBranches={activeBranches} obstacles={obstacles} readOnly={readOnly} />}
            </div>

            {/* RIGHT */}
            <div className="col">
              <div className="two">
                <section className="panel">
                  <p className="kicker">Units sold</p>
                  <p className="mid">{totalSold.toLocaleString()}</p>
                  <p className="note" style={{ marginTop: 4 }}>Selected period · {selectedTimeframe}</p>
                </section>
                <section className="panel">
                  <p className="kicker">Sell-through</p>
                  <p className="mid">{sellThrough}%</p>
                  <p className="note" style={{ marginTop: 4 }}>Sold ÷ (Sold + Closing)</p>
                </section>
              </div>

              <section className="panel">
                <h3 className="title">Top selling jewelry items</h3>
                {topItems.length === 0 && <p className="note" style={{ marginTop: 10 }}>Upload data to see top items.</p>}
                {topItems.map((item: any, i: number) => {
                  const sold = (item.soldQty ?? item.sold) || 0;
                  const pct = totalSold > 0 ? Math.round((sold / totalSold) * 100) : 0;
                  return (
                    <div key={i} className="top">
                      <span className="w">{item.weight || item.sku || '—'}</span>
                      <div>
                        <span className="n">{sold.toLocaleString()} sold</span>
                        <div className="bar"><i style={{ width: `${Math.min(100, pct * 2)}%` }} /></div>
                      </div>
                      <span className="p">{pct}%</span>
                    </div>
                  );
                })}
              </section>

              <section className="panel">
                <div className="row" style={{ alignItems: 'center' }}>
                  <h3 className="title">Recent transfers</h3>
                  {!readOnly && <button type="button" className="link" onClick={() => onNavigateView('movement_aging')}>View all →</button>}
                </div>
                <div style={{ marginTop: 8, overflowX: 'auto' }}>
                  <table>
                    <thead><tr><th>ITEM</th><th>FROM → TO</th><th className="r">QTY</th><th className="r">STATUS</th></tr></thead>
                    <tbody>
                      {recentTransfers.length === 0 && <tr><td colSpan={4} style={{ textAlign: 'center', color: '#3D5A78' }}>No pending transfers</td></tr>}
                      {recentTransfers.map((t, i) => (
                        <tr key={i}>
                          <td style={{ fontWeight: 700 }}>{t.item}</td>
                          <td>{t.from} → {t.to}</td>
                          <td className="r" style={{ fontVariantNumeric: 'tabular-nums' }}>{t.qty}</td>
                          <td className="r"><span className="badge">{t.status}</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>

              <section className="panel">
                <div className="row" style={{ alignItems: 'center', marginBottom: 10 }}>
                  <h3 className="title">Branch × Jewelry item heatmap</h3>
                  {!readOnly && <button type="button" className="link" onClick={() => onNavigateView('reports', 'excel_sheet')}>Open matrix →</button>}
                </div>
                {heat.rows.length > 0 && heat.cols.length > 0 ? (
                  <div style={{ overflowX: 'auto' }}>
                    <div className="heat" style={{ gridTemplateColumns: `minmax(64px, 96px) repeat(${heat.cols.length}, minmax(22px, 1fr))` }}>
                      <span />
                      {heat.cols.map((c) => <span key={c} className="ch" title={c}>{c}</span>)}
                      {heat.rows.map((r, ri) => (
                        <React.Fragment key={r}>
                          <button type="button" className="rowbtn" title={r} onClick={() => onSelectBranch?.(r)}>{r}</button>
                          {heat.cells[ri].map((cell, ci) => {
                            const bg = heatColor(cell.sold > 0 ? 0.1 + 0.9 * Math.sqrt(cell.sold / heat.max) : 0);
                            return (
                              <div key={ci} className="cell" style={{ background: bg, color: readableOn(bg) }} title={`${r} · ${heat.cols[ci]}: ${cell.sold} sold, ${cell.stock} stock`}>
                                {cell.sold > 0 ? cell.sold : '–'}
                              </div>
                            );
                          })}
                        </React.Fragment>
                      ))}
                    </div>
                    <div className="legend"><span>LOW</span><i /><span>HIGH · units sold</span></div>
                  </div>
                ) : <p className="note" style={{ padding: '18px 0', textAlign: 'center' }}>Upload stock + sold data to see the heatmap.</p>}
              </section>
            </div>
          </div>
        </div>
      </div>
    </ShadowScope>
    </div>

      {/* Below cockpit — collapsed by default; Expand opens full report-style panel */}
      <AIIntelligencePanel
        {...aiInsightsProps}
        currencySymbol={(report as any).categoryConfig?.currencySymbol || ''}
        onNavigate={readOnly ? undefined : ((view, subReport) => onNavigateView(view, subReport))}
        maxItems={4}
        defaultCollapsed
        expandToFullPage
      />
    </div>
  );
};

export default NetSuiteHomeDashboard;


