import React, { useMemo, useState } from 'react';
import { Building2, ImagePlus, RotateCcw, Save, Upload, Palette } from 'lucide-react';
import {
  DEFAULT_WHITE_LABEL,
  WhiteLabelSettings,
  applyWhiteLabelToDocument,
} from '../utils/settingsEngine';

interface WhiteLabelSettingsPanelProps {
  value: WhiteLabelSettings;
  onChange: (value: WhiteLabelSettings) => void;
}

const HEX_RE = /^#[0-9a-fA-F]{6}$/;

export const WhiteLabelSettingsPanel: React.FC<WhiteLabelSettingsPanelProps> = ({ value, onChange }) => {
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  const fields = useMemo(
    () => [
      ['primary', 'Primary', 'Main corporate/navy color'],
      ['secondary', 'Secondary', 'Secondary surfaces and headings'],
      ['accent', 'Accent', 'Buttons, active states and KPI highlights'],
      ['sidebarBackground', 'Sidebar Background', 'Navigation shell background'],
      ['sidebarForeground', 'Sidebar Text', 'Navigation text and icons'],
      ['surface', 'Surface', 'Cards and application panels'],
      ['surfaceMuted', 'Muted Surface', 'Table headers and subtle backgrounds'],
      ['text', 'Text', 'Primary application text'],
      ['border', 'Border', 'Cards, tables and separators'],
    ] as const,
    [],
  );

  const update = (key: keyof WhiteLabelSettings, next: string) => {
    if (key !== 'companyName' && key !== 'logoUrl' && !HEX_RE.test(next)) {
      setError(`${String(key)} must be a 6-digit hex value, e.g. #0B2545.`);
      return;
    }
    if (key === 'companyName' && !next.trim()) {
      setError('Company name is required.');
      return;
    }
    setSaved(false);
    setError('');
    const nextValue = { ...value, [key]: next };
    onChange(nextValue);
    applyWhiteLabelToDocument(nextValue);
  };

  const handleLogo = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Logo must be an image file.');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setError('Logo must be 2 MB or smaller.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const logoUrl = String(reader.result || '');
      const nextValue = { ...value, logoUrl };
      onChange(nextValue);
      applyWhiteLabelToDocument(nextValue);
      setError('');
      setSaved(false);
    };
    reader.readAsDataURL(file);
  };

  const reset = () => {
    onChange({ ...DEFAULT_WHITE_LABEL });
    applyWhiteLabelToDocument(DEFAULT_WHITE_LABEL);
    setError('');
    setSaved(false);
  };

  return (
    <section className="rounded-2xl border border-slate-200/80 bg-white/90 p-5 shadow-sm dark:border-slate-800 dark:bg-slate-950/60">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white">
            <Building2 className="h-4 w-4 text-[var(--brand-accent)]" />
            White-Label Corporate Identity
          </div>
          <p className="mt-1 max-w-2xl text-xs leading-5 text-slate-500 dark:text-slate-400">
            Configure the client company identity. Changes preview globally and persist in the ERP browser profile.
          </p>
        </div>
        <div className="flex gap-2">
          <button type="button" onClick={reset} className="inline-flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800">
            <RotateCcw className="h-3.5 w-3.5" /> Reset
          </button>
          <button type="button" onClick={() => setSaved(true)} className="inline-flex items-center gap-2 rounded-lg bg-[var(--brand-primary)] px-3 py-2 text-xs font-bold text-white shadow-sm">
            <Save className="h-3.5 w-3.5" /> Active & Saved
          </button>
        </div>
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[280px_1fr]">
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900/60">
          <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500">Company name</label>
          <input
            value={value.companyName}
            onChange={(e) => update('companyName', e.target.value)}
            className="mt-2 w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm font-semibold text-slate-800 outline-none focus:border-[var(--brand-accent)] dark:border-slate-700 dark:bg-slate-950 dark:text-white"
            placeholder="Corporate Client Ltd."
          />

          <div className="mt-5 rounded-xl border border-dashed border-slate-300 bg-white p-3 dark:border-slate-700 dark:bg-slate-950">
            <div className="flex min-h-[110px] items-center justify-center rounded-lg bg-slate-50 dark:bg-slate-900">
              {value.logoUrl ? (
                <img src={value.logoUrl} alt="Company logo preview" className="max-h-20 max-w-[220px] object-contain" />
              ) : (
                <div className="text-center text-slate-400"><ImagePlus className="mx-auto h-7 w-7" /><p className="mt-1 text-[10px]">No logo configured</p></div>
              )}
            </div>
            <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200">
              <Upload className="h-3.5 w-3.5" /> Upload Logo
              <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden" onChange={(e) => handleLogo(e.target.files?.[0])} />
            </label>
            <p className="mt-2 text-[10px] leading-4 text-slate-400">PNG/JPG/WebP/SVG · max 2 MB. Stored as a browser-safe data URL.</p>
          </div>
        </div>

        <div>
          <div className="mb-3 flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-200">
            <Palette className="h-4 w-4 text-[var(--brand-accent)]" /> Brand palette
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {fields.map(([key, label, hint]) => {
              const color = value[key];
              return (
                <div key={key} className="rounded-xl border border-slate-200 p-3 dark:border-slate-800">
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-200">{label}</label>
                    <input type="color" value={HEX_RE.test(color) ? color : '#000000'} onChange={(e) => update(key, e.target.value)} className="h-7 w-9 cursor-pointer rounded border-0 bg-transparent p-0" aria-label={`${label} color`} />
                  </div>
                  <input value={color} onChange={(e) => update(key, e.target.value)} className="mt-2 w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-2 font-mono text-xs uppercase text-slate-700 outline-none focus:border-[var(--brand-accent)] dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200" />
                  <p className="mt-1 text-[10px] leading-4 text-slate-400">{hint}</p>
                </div>
              );
            })}
          </div>
          {error && <p className="mt-3 text-xs font-semibold text-red-600">{error}</p>}
          {saved && !error && <p className="mt-3 text-xs font-semibold text-emerald-600">Brand configuration is active and persisted.</p>}
        </div>
      </div>
    </section>
  );
};
