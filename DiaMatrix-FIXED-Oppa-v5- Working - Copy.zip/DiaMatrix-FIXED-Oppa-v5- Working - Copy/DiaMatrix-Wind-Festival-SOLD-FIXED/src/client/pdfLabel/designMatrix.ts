/**
 * Branch × Carat matrix for "Stock vs Sold · Design Report".
 * Same logic as Design-wise Stock Analysis (Distribution = Contribution, by sales share):
 *
 *  For every carat column:
 *    pool   = DWL reserve + sum of all outlet stock   (full company pool)
 *    target = pool distributed by each outlet's sold share (largest-remainder rounding)
 *    Move   = target − current outlet stock
 *             + → Move IN (green)    − → Move OUT (pink)
 *  Columns with no sales at all are left untouched (Move = 0).
 *
 *  DWL (Diamond World LTD) is the warehouse reserve: shown once as the first row,
 *  never counted inside Total Stock / Total Sold of outlets.
 *
 *  Per outlet row:  Refill = sum of its positive Move cells (= IN column in Summary).
 */

import type { DesignCardDetail } from './designMatch';

export const DWL_CODE = 'DWL';

export type AllocationMode = 'contribution' | 'baseline' | 'hybrid';

/**
 * Per-carat allocator: returns target stock per outlet (integers, sum = pool).
 * `contribution` is built in. Plug baseline / hybrid from utils/redistributionEngine
 * through the `allocators` prop so numbers always match the rest of the app.
 */
export type AllocateFn = (pool: number, solds: number[], stks: number[], branches: string[]) => number[];

export const MODE_LABEL: Record<AllocationMode, string> = {
  contribution: 'Contribution — by sales share',
  baseline: 'Baseline',
  hybrid: 'Hybrid',
};

export interface MatrixCell {
  stk: number;
  sold: number;
  move: number;
  amount: number;
}

export interface MatrixRow {
  branch: string;
  rowStk: number;
  rowSold: number;
  rowIn: number;
  rowOut: number;
  byCol: Record<string, MatrixCell>;
}

export interface DesignMatrix {
  columns: string[];
  /** DWL reserve row (null when stock PDF has no DWL group) */
  dwl: { total: number; byCol: Record<string, number> } | null;
  /** Outlets only (no DWL) */
  rows: MatrixRow[];
  totalStk: number;
  totalSold: number;
  totalIn: number;
  totalOut: number;
  totalAmount: number;
  dwlStk: number;
  refillNeed: number;
  caratLines: number;
  sellThrough: number; // 0..100
}

export function caratKey(c: number): string {
  if (!c || !Number.isFinite(c)) return '0.00';
  return c.toFixed(2);
}

/** Largest-remainder allocation of `pool` over weights. Returns integer array summing to pool. */
export function allocateByShare(pool: number, weights: number[]): number[] {
  const total = weights.reduce((s, w) => s + w, 0);
  if (pool <= 0 || total <= 0) return weights.map(() => 0);
  const exact = weights.map((w) => (w * pool) / total);
  const base = exact.map((x) => Math.floor(x));
  let left = pool - base.reduce((s, x) => s + x, 0);
  const order = exact
    .map((x, i) => ({ i, frac: x - Math.floor(x), w: weights[i] }))
    .sort((a, b) => b.frac - a.frac || b.w - a.w || a.i - b.i);
  for (let k = 0; left > 0 && k < order.length; k++, left--) base[order[k].i] += 1;
  return base;
}

export function buildDesignMatrix(
  cards: DesignCardDetail[],
  mode: AllocationMode = 'contribution',
  allocators: Partial<Record<AllocationMode, AllocateFn>> = {},
): DesignMatrix {
  const allocate: AllocateFn | undefined =
    allocators[mode] || (mode === 'contribution' ? (pool, solds) => allocateByShare(pool, solds) : undefined);
  if (!allocate) throw new Error(`Allocator for mode "${mode}" not provided`);
  const colSet = new Set<string>();
  const branchSet = new Set<string>();
  const cells = new Map<string, { stk: number; sold: number; amount: number }>();
  const dwlByCol: Record<string, number> = {};
  let hasDwl = false;

  for (const c of cards) {
    const ck = caratKey(c.carat);
    const br = (c.branch || 'UNK').toUpperCase().trim();
    colSet.add(ck);

    if (br === DWL_CODE) {
      // warehouse: only stock counts
      if (c.source === 'stock') {
        hasDwl = true;
        dwlByCol[ck] = (dwlByCol[ck] || 0) + 1;
      }
      continue;
    }
    branchSet.add(br);
    const key = `${br}__${ck}`;
    const prev = cells.get(key) || { stk: 0, sold: 0, amount: 0 };
    if (c.source === 'stock') {
      prev.stk += 1;
      prev.amount += c.amount || 0;
    } else {
      prev.sold += 1;
    }
    cells.set(key, prev);
  }

  const columns = [...colSet].sort((a, b) => parseFloat(a) - parseFloat(b));
  const branches = [...branchSet].sort((a, b) => a.localeCompare(b));

  const rows: MatrixRow[] = branches.map((branch) => ({
    branch,
    rowStk: 0,
    rowSold: 0,
    rowIn: 0,
    rowOut: 0,
    byCol: {},
  }));

  for (const col of columns) {
    const stks = branches.map((b) => cells.get(`${b}__${col}`)?.stk || 0);
    const solds = branches.map((b) => cells.get(`${b}__${col}`)?.sold || 0);
    const totalSold = solds.reduce((s, x) => s + x, 0);
    const pool = (dwlByCol[col] || 0) + stks.reduce((s, x) => s + x, 0);
    const target = totalSold > 0 ? allocate(pool, solds, stks, branches) : stks;

    rows.forEach((r, i) => {
      const cell = cells.get(`${r.branch}__${col}`) || { stk: 0, sold: 0, amount: 0 };
      const move = target[i] - stks[i];
      r.byCol[col] = { stk: cell.stk, sold: cell.sold, move, amount: cell.amount };
      r.rowStk += cell.stk;
      r.rowSold += cell.sold;
      if (move > 0) r.rowIn += move;
      else if (move < 0) r.rowOut += -move;
    });
  }

  const totalStk = rows.reduce((s, r) => s + r.rowStk, 0);
  const totalSold = rows.reduce((s, r) => s + r.rowSold, 0);
  const totalIn = rows.reduce((s, r) => s + r.rowIn, 0);
  const totalOut = rows.reduce((s, r) => s + r.rowOut, 0);
  const totalAmount = rows.reduce(
    (s, r) => s + Object.values(r.byCol).reduce((a, c) => a + c.amount, 0),
    0,
  );
  const dwlStk = Object.values(dwlByCol).reduce((s, x) => s + x, 0);
  const denom = totalStk + totalSold; // 1459 / (1967+1459) = 43%

  return {
    columns,
    dwl: hasDwl ? { total: dwlStk, byCol: dwlByCol } : null,
    rows,
    totalStk,
    totalSold,
    totalIn,
    totalOut,
    totalAmount,
    dwlStk,
    // net pieces that must come out of the DWL reserve to satisfy the distribution
    refillNeed: Math.max(0, totalIn - totalOut),
    caratLines: columns.length,
    sellThrough: denom ? Math.round((totalSold / denom) * 100) : 0,
  };
}
