import { getServiceSupabase, isSupabaseConfigured } from '../config/supabase.js';
import { mapOutletRow, type Outlet, type OutletRow } from '../models/outlet.model.js';
import { WAREHOUSE_CODES, EXCLUDED_OUTLET_CODES } from '../config/constants.js';

/** In-memory fallback when Supabase is not configured (local bootstrap). */
const MEMORY_OUTLETS: Outlet[] = [
  { code: 'BCT', name: 'Bashundhara City', isWarehouse: false, isExcluded: false, parentCode: null, active: true },
  { code: 'CTG', name: 'Chittagong', isWarehouse: false, isExcluded: false, parentCode: null, active: true },
  { code: 'DWL', name: 'Central Warehouse', isWarehouse: true, isExcluded: false, parentCode: null, active: true },
  { code: 'GUL', name: 'Gulshan', isWarehouse: false, isExcluded: false, parentCode: null, active: true },
  { code: 'MIR', name: 'Mirpur', isWarehouse: false, isExcluded: false, parentCode: null, active: true },
];

export class OutletRepository {
  async listActive(): Promise<Outlet[]> {
    if (!isSupabaseConfigured()) {
      return MEMORY_OUTLETS.filter((o) => o.active && !o.isExcluded);
    }
    const { data, error } = await getServiceSupabase()
      .from('outlets')
      .select('*')
      .eq('active', true)
      .eq('is_excluded', false)
      .order('code');
    if (error) throw error;
    return (data as OutletRow[]).map(mapOutletRow);
  }

  async listRetail(): Promise<Outlet[]> {
    const all = await this.listActive();
    return all.filter((o) => !o.isWarehouse && !WAREHOUSE_CODES.includes(o.code as never));
  }

  isWarehouse(code: string): boolean {
    return WAREHOUSE_CODES.includes(code.toUpperCase() as never);
  }

  isExcluded(code: string): boolean {
    return EXCLUDED_OUTLET_CODES.includes(code.toUpperCase() as never);
  }
}

export const outletRepository = new OutletRepository();
