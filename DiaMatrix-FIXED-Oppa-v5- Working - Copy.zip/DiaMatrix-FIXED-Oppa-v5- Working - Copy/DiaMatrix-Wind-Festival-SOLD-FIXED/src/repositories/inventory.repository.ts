import { getServiceSupabase, isSupabaseConfigured } from '../config/supabase.js';
import {
  mapInventoryRow,
  mapSalesRow,
  type InventoryPosition,
  type InventoryPositionRow,
  type SalesFact,
  type SalesFactRow,
} from '../models/inventory.model.js';
import type { InventoryUploadBody } from '../schemas/inventory.schema.js';

/** Dev memory stores when Supabase is off */
const memStock: InventoryPosition[] = [];
const memSales: SalesFact[] = [];

export class InventoryRepository {
  async getStock(filters: {
    outlet?: string;
    design?: string;
    carat?: string;
  }): Promise<InventoryPosition[]> {
    if (!isSupabaseConfigured()) {
      return memStock.filter((r) => {
        if (filters.outlet && r.outletCode !== filters.outlet) return false;
        if (filters.design && r.designCode !== filters.design) return false;
        if (filters.carat && r.caratKey !== filters.carat) return false;
        return true;
      });
    }
    let q = getServiceSupabase().from('inventory_positions').select('*');
    if (filters.outlet) q = q.eq('outlet_code', filters.outlet);
    if (filters.design) q = q.eq('design_code', filters.design);
    if (filters.carat) q = q.eq('carat_key', filters.carat);
    const { data, error } = await q;
    if (error) throw error;
    return (data as InventoryPositionRow[]).map(mapInventoryRow);
  }

  async getSales(filters: {
    outlet?: string;
    design?: string;
    periodMonths?: number;
  }): Promise<SalesFact[]> {
    if (!isSupabaseConfigured()) {
      return memSales.filter((r) => {
        if (filters.outlet && r.outletCode !== filters.outlet) return false;
        if (filters.design && r.designCode !== filters.design) return false;
        if (filters.periodMonths && r.periodMonths !== filters.periodMonths) return false;
        return true;
      });
    }
    let q = getServiceSupabase().from('sales_facts').select('*');
    if (filters.outlet) q = q.eq('outlet_code', filters.outlet);
    if (filters.design) q = q.eq('design_code', filters.design);
    if (filters.periodMonths) q = q.eq('period_months', filters.periodMonths);
    const { data, error } = await q;
    if (error) throw error;
    return (data as SalesFactRow[]).map(mapSalesRow);
  }

  async upsertUpload(body: InventoryUploadBody): Promise<{ inserted: number }> {
    const asOf = new Date().toISOString();
    if (!isSupabaseConfigured()) {
      if (body.kind === 'stock') {
        for (const r of body.rows) {
          memStock.push({
            id: `mem-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            outletCode: r.outletCode,
            designCode: r.designCode,
            category: r.category ?? null,
            caratKey: r.caratKey,
            qty: r.qty,
            asOf,
            sourceFile: body.sourceFile ?? null,
          });
        }
      } else {
        for (const r of body.rows) {
          memSales.push({
            id: `mem-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            outletCode: r.outletCode,
            designCode: r.designCode,
            caratKey: r.caratKey,
            qty: r.qty,
            periodMonths: body.periodMonths ?? 9,
            asOf,
            sourceFile: body.sourceFile ?? null,
          });
        }
      }
      return { inserted: body.rows.length };
    }

    if (body.kind === 'stock') {
      const rows = body.rows.map((r) => ({
        outlet_code: r.outletCode,
        design_code: r.designCode,
        category: r.category ?? null,
        carat_key: r.caratKey,
        qty: r.qty,
        as_of: asOf,
        source_file: body.sourceFile ?? null,
      }));
      const { error } = await getServiceSupabase().from('inventory_positions').insert(rows);
      if (error) throw error;
    } else {
      const rows = body.rows.map((r) => ({
        outlet_code: r.outletCode,
        design_code: r.designCode,
        carat_key: r.caratKey,
        qty: r.qty,
        period_months: body.periodMonths ?? 9,
        as_of: asOf,
        source_file: body.sourceFile ?? null,
      }));
      const { error } = await getServiceSupabase().from('sales_facts').insert(rows);
      if (error) throw error;
    }
    return { inserted: body.rows.length };
  }
}

export const inventoryRepository = new InventoryRepository();
