import type { AuthUser, UserRole } from '../models/user.model.js';
import {
  hashPassword,
  verifyPassword,
  generateTotpSecret,
  totpUri,
} from '../lib/crypto.js';

export interface StoredUser {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  isOwner: boolean;
  branchCode: string | null;
  passwordHash: string;
  email: string | null;
  phone: string | null;
  mfaEnabled: boolean;
  totpSecret: string | null;
  totpConfirmed: boolean;
  createdAt: string;
}

/** In-memory user store (works without DB). Seeded with owner Shahadat. */
const users = new Map<string, StoredUser>();

function toAuthUser(u: StoredUser): AuthUser {
  return {
    id: u.id,
    username: u.username,
    name: u.name,
    role: u.role,
    isOwner: u.isOwner,
    branchCode: u.branchCode,
  };
}

/** Seed the system owner once. Password is hashed — never stored in plaintext. */
export function ensureOwnerSeed(opts?: {
  username?: string;
  password?: string;
  email?: string;
  phone?: string;
}): StoredUser {
  const username = (opts?.username || process.env.OWNER_USERNAME || 'shahadat').trim().toLowerCase();
  const password = opts?.password || process.env.OWNER_PASSWORD || '000000';
  const email = opts?.email || process.env.OWNER_EMAIL || 'shahadat@diamatrix.app';
  const phone = opts?.phone || process.env.OWNER_PHONE || '';

  const existing = [...users.values()].find((u) => u.username === username);
  if (existing) return existing;

  const totpSecret = generateTotpSecret();
  const user: StoredUser = {
    id: '00000000-0000-0000-0000-000000000001',
    username,
    name: 'MD Shahadat Hossen',
    role: 'owner',
    isOwner: true,
    branchCode: null,
    passwordHash: hashPassword(password),
    email,
    phone: phone || null,
    mfaEnabled: true,
    totpSecret,
    totpConfirmed: true, // ready for Google Authenticator immediately after setup
    createdAt: new Date().toISOString(),
  };
  users.set(user.id, user);
  return user;
}

// Auto-seed on module load
const seeded = ensureOwnerSeed();

export function getOwnerTotpSetup(): { username: string; secret: string; uri: string; email: string | null } {
  const u = seeded;
  return {
    username: u.username,
    secret: u.totpSecret || '',
    uri: totpUri(u.totpSecret || '', u.username, 'DiaMatrix'),
    email: u.email,
  };
}

export function findByUsername(username: string): StoredUser | null {
  const u = username.trim().toLowerCase();
  return [...users.values()].find((x) => x.username === u) || null;
}

export function findById(id: string): StoredUser | null {
  return users.get(id) || null;
}

export function checkPassword(user: StoredUser, password: string): boolean {
  return verifyPassword(password, user.passwordHash);
}

export function listUsers(): AuthUser[] {
  return [...users.values()].map(toAuthUser);
}

export function asAuthUser(user: StoredUser): AuthUser {
  return toAuthUser(user);
}

export function updateUser(id: string, patch: Partial<StoredUser>): StoredUser | null {
  const u = users.get(id);
  if (!u) return null;
  const next = { ...u, ...patch };
  users.set(id, next);
  return next;
}
