export interface OutletRow {
  code: string;
  name: string;
  is_warehouse: boolean;
  is_excluded: boolean;
  parent_code: string | null;
  active: boolean;
  created_at: string;
}

export interface Outlet {
  code: string;
  name: string;
  isWarehouse: boolean;
  isExcluded: boolean;
  parentCode: string | null;
  active: boolean;
}

export function mapOutletRow(row: OutletRow): Outlet {
  return {
    code: row.code,
    name: row.name,
    isWarehouse: row.is_warehouse,
    isExcluded: row.is_excluded,
    parentCode: row.parent_code,
    active: row.active,
  };
}
