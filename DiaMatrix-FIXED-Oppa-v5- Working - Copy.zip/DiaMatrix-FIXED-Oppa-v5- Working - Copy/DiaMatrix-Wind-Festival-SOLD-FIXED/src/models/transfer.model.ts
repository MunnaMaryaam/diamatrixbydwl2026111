export type TransferPriority = 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type TransferStatus = 'RECOMMENDED' | 'APPROVED' | 'DISPATCHED' | 'CANCELLED';

export interface TransferOrderRow {
  id: string;
  design_code: string;
  carat_key: string | null;
  from_outlet: string;
  to_outlet: string;
  qty: number;
  priority: TransferPriority;
  status: TransferStatus;
  reason: string | null;
  logic: string | null;
  created_at: string;
}

export interface TransferOrder {
  id: string;
  designCode: string;
  caratKey: string | null;
  fromOutlet: string;
  toOutlet: string;
  qty: number;
  priority: TransferPriority;
  status: TransferStatus;
  reason: string | null;
  logic: string | null;
  createdAt: string;
}

export function mapTransferRow(row: TransferOrderRow): TransferOrder {
  return {
    id: row.id,
    designCode: row.design_code,
    caratKey: row.carat_key,
    fromOutlet: row.from_outlet,
    toOutlet: row.to_outlet,
    qty: Number(row.qty),
    priority: row.priority,
    status: row.status,
    reason: row.reason,
    logic: row.logic,
    createdAt: row.created_at,
  };
}
