export type UserRole = 'owner' | 'admin' | 'merchandising' | 'branch' | 'readonly';

export interface AuthUser {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  isOwner: boolean;
  branchCode?: string | null;
}

export interface UserRow {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  is_owner: boolean;
  branch_code: string | null;
  password_hash: string;
  created_at: string;
  updated_at: string;
}

export function mapUserRow(row: UserRow): AuthUser {
  return {
    id: row.id,
    username: row.username,
    name: row.name,
    role: row.role,
    isOwner: row.is_owner,
    branchCode: row.branch_code,
  };
}
