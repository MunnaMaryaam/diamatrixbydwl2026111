import type { FestivalLogic } from '../config/constants.js';

export interface SchemeDesignRow {
  id: string;
  scheme_id: string;
  design_code: string;
  stock_pcs: number;
  g_wt: number | null;
  n_wt: number | null;
  d_wt: number | null;
}

export interface SchemeDesign {
  design: string;
  stock: number;
  gWt?: number;
  nWt?: number;
  dWt?: number;
}

export function mapSchemeDesign(row: SchemeDesignRow): SchemeDesign {
  return {
    design: row.design_code,
    stock: row.stock_pcs,
    gWt: row.g_wt ?? undefined,
    nWt: row.n_wt ?? undefined,
    dWt: row.d_wt ?? undefined,
  };
}

export interface FestivalAllocateResult {
  logic: FestivalLogic;
  outlets: string[];
  designs: string[];
  /** outlet → design → move (Target − Have) */
  moves: Record<string, Record<string, number>>;
  warnings: string[];
}
