export interface InventoryPositionRow {
  id: string;
  outlet_code: string;
  design_code: string;
  category: string | null;
  carat_key: string;
  qty: number;
  as_of: string;
  source_file: string | null;
  created_at: string;
}

export interface InventoryPosition {
  id: string;
  outletCode: string;
  designCode: string;
  category: string | null;
  caratKey: string;
  qty: number;
  asOf: string;
  sourceFile: string | null;
}

export function mapInventoryRow(row: InventoryPositionRow): InventoryPosition {
  return {
    id: row.id,
    outletCode: row.outlet_code,
    designCode: row.design_code,
    category: row.category,
    caratKey: row.carat_key,
    qty: Number(row.qty),
    asOf: row.as_of,
    sourceFile: row.source_file,
  };
}

export interface SalesFactRow {
  id: string;
  outlet_code: string;
  design_code: string;
  carat_key: string;
  qty: number;
  period_months: number;
  as_of: string;
  source_file: string | null;
  created_at: string;
}

export interface SalesFact {
  id: string;
  outletCode: string;
  designCode: string;
  caratKey: string;
  qty: number;
  periodMonths: number;
  asOf: string;
  sourceFile: string | null;
}

export function mapSalesRow(row: SalesFactRow): SalesFact {
  return {
    id: row.id,
    outletCode: row.outlet_code,
    designCode: row.design_code,
    caratKey: row.carat_key,
    qty: Number(row.qty),
    periodMonths: row.period_months,
    asOf: row.as_of,
    sourceFile: row.source_file,
  };
}
