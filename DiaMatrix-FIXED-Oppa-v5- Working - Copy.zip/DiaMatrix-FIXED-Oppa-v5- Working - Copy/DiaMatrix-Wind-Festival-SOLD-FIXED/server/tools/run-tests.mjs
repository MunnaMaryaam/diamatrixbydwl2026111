import { readdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join, relative } from 'node:path';

const root = fileURLToPath(new URL('../../', import.meta.url));
const testFiles = async (directory) => {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = await Promise.all(entries.map(async (entry) => {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) return testFiles(path);
    return entry.isFile() && entry.name.endsWith('.test.mjs') ? [path] : [];
  }));
  return files.flat();
};

const toolTests = await testFiles(join(root, 'server/tools'));
const typescriptTests = [
  'src/shared/app-data/app-data.test.ts',
  'src/shared/app-data/readiness-schedule.test.ts',
  'src/server/auth/gate-identity.test.ts',
  'src/client/auth/sign-in-gate.test.ts',
];

const run = (args) => {
  const result = spawnSync(process.execPath, args, { cwd: root, stdio: 'inherit' });
  return result.status ?? 1;
};

const toolsStatus = run(['--test', ...toolTests.map((path) => relative(root, path))]);
const typedStatus = run([
  '--experimental-strip-types',
  '--experimental-loader',
  './server/tools/tsconfig-path-loader.mjs',
  '--test',
  ...typescriptTests,
]);

process.exitCode = toolsStatus || typedStatus;
