import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve as resolvePath } from 'node:path';

const root = fileURLToPath(new URL('../../', import.meta.url));

function mapAlias(specifier) {
  if (specifier.startsWith('@server/')) return resolvePath(root, 'src/server', specifier.slice(8));
  if (specifier.startsWith('@shared/')) return resolvePath(root, 'src/shared', specifier.slice(8));
  if (specifier.startsWith('@/')) return resolvePath(root, 'src/client', specifier.slice(2));
  return null;
}

export async function resolve(specifier, context, nextResolve) {
  const aliasedPath = mapAlias(specifier);
  if (aliasedPath) {
    try {
      return await nextResolve(pathToFileURL(aliasedPath).href, context);
    } catch (error) {
      if (/\.(?:ts|tsx|js|mjs|json)$/i.test(aliasedPath)) throw error;
      for (const suffix of ['.ts', '.tsx', '.js', '.mjs', '.json', '/index.ts', '/index.js']) {
        try {
          return await nextResolve(pathToFileURL(`${aliasedPath}${suffix}`).href, context);
        } catch (candidateError) {
          if (!['ERR_MODULE_NOT_FOUND', 'ERR_UNSUPPORTED_DIR_IMPORT'].includes(candidateError.code)) {
            throw candidateError;
          }
        }
      }
      throw error;
    }
  }

  try {
    return await nextResolve(specifier, context);
  } catch (error) {
    if (!context.parentURL || !['ERR_MODULE_NOT_FOUND', 'ERR_UNSUPPORTED_DIR_IMPORT'].includes(error.code)) {
      throw error;
    }

    const basePath = specifier.startsWith('.')
      ? resolvePath(dirname(fileURLToPath(context.parentURL)), specifier)
      : null;
    if (!basePath || /\.(?:ts|tsx|js|mjs|json)$/i.test(basePath)) throw error;

    for (const suffix of ['.ts', '.tsx', '.js', '.mjs', '.json', '/index.ts', '/index.js']) {
      try {
        return await nextResolve(pathToFileURL(`${basePath}${suffix}`).href, context);
      } catch (candidateError) {
        if (!['ERR_MODULE_NOT_FOUND', 'ERR_UNSUPPORTED_DIR_IMPORT'].includes(candidateError.code)) {
          throw candidateError;
        }
      }
    }
    throw error;
  }
}
