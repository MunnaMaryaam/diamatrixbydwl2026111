@echo off
REM Test the desktop window without making an installer (needs build-exe.bat steps 1-3 done once).
cd /d "%~dp0desktop"
call npx electron .
