# DiaMatrix Security & Configuration Baseline

## Production requirements

Production deployments must use real authentication and a real persistent database. The application now refuses unsafe production configuration when its production mode is explicitly detected.

Required production environment values:

- `DIAMATRIX_ENV=production`
- `VITE_AUTH_ENABLED=true`
- `BETTER_AUTH_SECRET` — random, at least 32 characters
- `BETTER_AUTH_URL` — public HTTPS origin
- `DATABASE_URL` — private database connection string
- `GROK_PROJECT_ID`
- `GROK_AUTH_CLIENT_ID`
- `GROK_AUTH_CLIENT_SECRET`

Never put any of the server-only values above behind a `VITE_` prefix.

## HTTP security

Deployed responses receive baseline security headers including:

- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Permissions-Policy` disabling unused camera/microphone/geolocation/USB APIs
- HSTS on HTTPS responses
- `Cache-Control: no-store` for Better Auth endpoints

A static CSP/X-Frame-Options policy is intentionally not forced because the product has an authenticated embedded preview flow. Cross-site scripted request isolation remains enforced by `src/server/auth/isolation.server.ts`.

## Authentication

- Offline demo accounts are disabled in production builds. They run only in `npm run dev`, or when `VITE_ALLOW_OFFLINE_LOGIN=true` is set on purpose. A wrong password answered by the server (HTTP 400/401/403/429) never falls back to offline login.
- Database: all `public` tables have Row Level Security enabled with no policies (migration `20261010000000_enable_rls.sql`). Only the server (service-role key / `DATABASE_URL`) can read or write.

- `__Host-` session cookie names are used to prevent domain cookie tossing.
- Better Auth trusted origins are explicitly configured.
- Server functions that touch per-user data should use `authMiddleware` and scope queries by `context.userId`.
- Production cannot use the shared `dev-user` fallback.
- `VITE_AUTH_ENABLED=false` is rejected when `DATABASE_URL` is configured.

## Secrets and files

Real `.env*` files and `server/data/auth-users.json` are ignored. Only `.env.example` and `server/data/auth-users.example.json` may be committed as templates.

If a real secret was ever committed or exposed, rotate/revoke it first; deleting the file from the latest commit does not invalidate the old credential.

## Verification

Run:

```bash
npm run check:security
npm run check:auth
npm run typecheck
npm run lint
npm test
```

`check:security` is an environment/configuration audit. It does not print secret values.
