# DiaMatrix — Diamond Blue palette (diamond-blue-v3)

Matched to the Operations Cockpit design reference.

- Diamond cyan (primary) `#14B4E8`, bright cyan `#3AC6FF`
- Deep navy `#0B2545` / `#09203F`
- Ice page bg `#F6FAFD`, border `#D3E8F6`, muted text `#4F6B88`

Logo: DW swirl + diamond (public/diamatrix-mark.png, diamatrix-wordmark.png, favicon/icon PNGs), used on the
"Securing session…" splash, login, header, sidebar and About. Default theme: light (Diamond Light).

## Dashboard hub: swinging modules + water ripples
The six hanging modules are cut-out sprites (`src/client/lumina/assets/dashboard/tag-*.webp`: tag + golden thread + tassels) over
`scene-clean.webp` (the original scene with the modules removed). They swing like pendulums; "Refill Demand" hangs from
"Item Allocation Matrix". Showrooms and Refill Demand touch the water and send ripples across it.
Tune everything in the `SWING` table in `NetSuiteHomeDashboard.tsx` (amp = degrees, dur = seconds per swing, delay, ripple width).
Motion is switched off automatically when the OS has "reduce motion" enabled.
