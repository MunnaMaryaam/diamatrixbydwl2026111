@echo off
REM Builds the DiaMatrix Windows installer (.exe). Run on a Windows PC with Node 20+ and internet.
setlocal
cd /d "%~dp0"

echo [1/4] Installing app packages...
call npm install --legacy-peer-deps --no-audit --no-fund
if errorlevel 1 goto fail

echo [2/4] Building the app...
REM Login now goes through Supabase (see .env). The built-in offline demo login stays OFF.
call npm run build
if errorlevel 1 goto fail

echo [3/4] Installing the desktop packager (first time downloads Electron, ~100 MB)...
cd desktop
call npm install --no-audit --no-fund
if errorlevel 1 goto fail

echo [4/4] Creating the installer...
set CSC_IDENTITY_AUTO_DISCOVERY=false
call npx electron-builder --win nsis --x64
if errorlevel 1 goto fail

echo.
echo DONE. Your installer is in: %~dp0desktop\release\
echo   DiaMatrix-Setup-1.0.0.exe
pause
exit /b 0

:fail
echo.
echo FAILED. Scroll up to see the first error message and send it to your developer.
pause
exit /b 1
