# DiaMatrix — White-Label & Corporate Export Layer

## Included

### 1. Dynamic white-labeling
- `src/client/lumina/utils/settingsEngine.ts`
  - `WhiteLabelSettings`
  - persisted settings
  - runtime CSS variables
  - `applyWhiteLabelToDocument()`
- `src/client/lumina/components/WhiteLabelSettingsPanel.tsx`
  - company name
  - logo upload
  - primary / secondary / accent / sidebar / surface / text / border colors
  - 2 MB image guard
- `SettingsModal.tsx`
  - white-label panel integrated into the existing Theme & Appearance flow
- `App.tsx`, `NetSuiteTopHeader.tsx`, `AppSideNav.tsx`
  - configured identity and logo are applied to the application shell

Logo uploads are kept as browser-safe data URLs in the existing settings store. For a multi-user production deployment, move the logo asset to object storage and persist only its HTTPS URL in the tenant settings table.

## 2. Corporate exports

The project already includes:
- `exceljs` — native XLSX generation, merged title blocks, formatting and embedded images
- `jspdf` — real PDF generation
- `html2canvas` — chart / active-view rasterization for PDF export

New reusable layer:
- `src/client/lumina/utils/corporateExportEngine.ts`
- `src/client/lumina/utils/corporateExportDemo.ts`

The generic export contract supports:
- company logo
- company name
- title
- period
- generated timestamp
- financial / inventory columns
- number formats
- left / center / right alignment
- optional analytics chart element

Existing DiaMatrix report exports were also updated so the configured white-label logo and company metadata are used instead of the fixed DiaMatrix logo.

## Recommended production storage model

For a real SaaS / enterprise deployment, use tenant-scoped settings:

```text
TenantBrandSettings
-------------------
tenantId
companyName
logoUrl
primaryColor
secondaryColor
accentColor
sidebarBackground
sidebarForeground
surfaceColor
surfaceMutedColor
textColor
borderColor
updatedAt
updatedBy
```

The current browser-local implementation is intentionally compatible with the existing application architecture and can be replaced by a server-backed settings repository without changing the UI contract.

## Export usage

```ts
import { exportCorporateReport } from './utils/corporateExportEngine';

await exportCorporateReport({
  title: 'Inventory Valuation Report',
  period: '01-Oct-2026 to 03-Oct-2026',
  columns: [
    { key: 'branch', header: 'Branch', width: 28 },
    { key: 'stock', header: 'Stock', width: 12, align: 'right', numberFormat: '#,##0' },
    { key: 'value', header: 'Inventory Value', width: 18, align: 'right', numberFormat: '৳#,##0' },
  ],
  rows: [
    { branch: 'Dhaka', stock: 120, value: 4500000 },
  ],
});
```

For chart export, pass the chart container as `chartElement` or use `exportCorporateChartPdf()`.
