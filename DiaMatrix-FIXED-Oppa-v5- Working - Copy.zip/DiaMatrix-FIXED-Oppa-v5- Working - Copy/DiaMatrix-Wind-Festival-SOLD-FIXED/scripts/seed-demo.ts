/**
 * Demo seed notes — run inserts in Supabase SQL editor after schema apply.
 */
import { logger } from '../src/lib/logger.js';

const sampleOutlets = `
insert into public.outlets (code, name, is_warehouse, is_excluded) values
  ('BCT', 'Bashundhara City', false, false),
  ('CTG', 'Chittagong', false, false),
  ('GUL', 'Gulshan', false, false),
  ('MIR', 'Mirpur', false, false),
  ('RUP', 'Rupayan', false, false),
  ('DWL', 'Central Warehouse', true, false)
on conflict (code) do nothing;
`;

logger.info('Demo seed SQL (paste in Supabase SQL editor):');
console.log(sampleOutlets);
