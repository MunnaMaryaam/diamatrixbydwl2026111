/**
 * Apply SQL files in src/db/schema/ via DATABASE_URL (optional).
 * Prefer Supabase CLI: `supabase db push` with supabase/migrations.
 */
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { logger } from '../src/lib/logger.js';

async function main() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    logger.warn('DATABASE_URL not set — skip migrate. Use Supabase SQL editor or CLI.');
    logger.info('Schema files are under src/db/schema/*.sql');
    process.exit(0);
  }

  // Optional: use `pg` package when you add it
  logger.info('Install `pg` and wire this script, or run files in Supabase SQL editor.', {
    files: readdirSync(join(process.cwd(), 'src/db/schema')).filter((f) => f.endsWith('.sql')),
  });

  for (const f of readdirSync(join(process.cwd(), 'src/db/schema')).sort()) {
    if (!f.endsWith('.sql')) continue;
    const sql = readFileSync(join(process.cwd(), 'src/db/schema', f), 'utf8');
    logger.info(`Would apply ${f} (${sql.length} chars)`);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
