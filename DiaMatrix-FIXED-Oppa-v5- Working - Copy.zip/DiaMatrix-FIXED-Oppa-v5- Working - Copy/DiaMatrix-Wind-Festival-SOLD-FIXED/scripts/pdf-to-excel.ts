/**
 * CLI:  npx tsx scripts/pdf-to-excel.ts input.pdf [output.xlsx]
 */
import fs from 'node:fs';
import path from 'node:path';
import { labelPdfToExcelBuffer } from '../src/shared/label-pdf-report/node.js';

const [input, output] = process.argv.slice(2);
if (!input) {
  console.error('Usage: npx tsx scripts/pdf-to-excel.ts input.pdf [output.xlsx]');
  process.exit(1);
}
const out = output ?? path.join(path.dirname(input), `${path.basename(input, '.pdf')}_Branch_Report.xlsx`);
const { xlsx, report } = await labelPdfToExcelBuffer(fs.readFileSync(input));
fs.writeFileSync(out, xlsx);
for (const s of report.sections) console.log(`${s.branch.padEnd(6)} ${String(s.cards.length).padStart(3)} pcs`);
if (report.warnings.length) console.warn('\nWarnings:\n - ' + report.warnings.join('\n - '));
console.log(`\nSaved → ${out}`);
