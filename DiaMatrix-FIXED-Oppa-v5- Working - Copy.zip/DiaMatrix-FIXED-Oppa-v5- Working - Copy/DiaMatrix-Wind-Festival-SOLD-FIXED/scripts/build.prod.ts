import * as esbuild from 'esbuild';
import JavaScriptObfuscator from 'javascript-obfuscator';
import { mkdirSync, writeFileSync, rmSync, existsSync, readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = join(__dirname, '..');
const distDir = join(root, 'dist');
const entry = join(root, 'src', 'index.ts');
const outFile = join(distDir, 'index.js');

async function main() {
  if (existsSync(distDir)) {
    rmSync(distDir, { recursive: true, force: true });
  }
  mkdirSync(distDir, { recursive: true });

  const result = await esbuild.build({
    entryPoints: [entry],
    bundle: true,
    platform: 'node',
    target: 'node20',
    format: 'cjs',
    outfile: outFile,
    minify: true,
    minifyIdentifiers: true,
    minifySyntax: true,
    minifyWhitespace: true,
    treeShaking: true,
    sourcemap: false,
    legalComments: 'none',
    metafile: true,
    external: [
      'exceljs',
      'csv-parse',
      'csv-parse/sync',
      '@supabase/supabase-js',
      'express',
      'cors',
      'helmet',
      'morgan',
      'multer',
      'zod',
    ],
    logLevel: 'info',
  });

  let code = readFileSync(outFile, 'utf8');

  const obfuscated = JavaScriptObfuscator.obfuscate(code, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.6,
    deadCodeInjection: false,
    debugProtection: false,
    disableConsoleOutput: false,
    identifierNamesGenerator: 'hexadecimal',
    renameGlobals: false,
    selfDefending: false,
    simplify: true,
    splitStrings: true,
    splitStringsChunkLength: 8,
    stringArray: true,
    stringArrayCallsTransform: true,
    stringArrayEncoding: ['base64'],
    stringArrayThreshold: 0.75,
    transformObjectKeys: true,
    unicodeEscapeSequence: false,
    target: 'node',
  });

  writeFileSync(outFile, obfuscated.getObfuscatedCode(), 'utf8');

  const bytes = Buffer.byteLength(readFileSync(outFile));
  const inputs = result.metafile ? Object.keys(result.metafile.inputs).length : 0;

  console.log(JSON.stringify({
    ok: true,
    outfile: 'dist/index.js',
    bytes,
    bundledInputs: inputs,
    obfuscated: true,
  }, null, 2));
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
