#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if [[ ! -f dist/index.js ]]; then
  echo "ERROR: dist/index.js missing. Run: npm run build"
  exit 1
fi

STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT

mkdir -p "$STAGE/app"

cp dist/index.js "$STAGE/app/index.js"

node -e '
const fs = require("fs");
const pkg = JSON.parse(fs.readFileSync("package.json", "utf8"));
const out = {
  name: pkg.name,
  version: pkg.version,
  private: true,
  description: pkg.description,
  main: "index.js",
  scripts: { start: "node index.js" },
  engines: pkg.engines || { node: ">=20" },
  dependencies: pkg.dependencies || {},
};
fs.writeFileSync(process.argv[1], JSON.stringify(out, null, 2) + "\n");
' "$STAGE/app/package.json"

if [[ -f .env.example ]]; then
  cp .env.example "$STAGE/app/.env.example"
fi

if [[ -d supabase/migrations ]]; then
  mkdir -p "$STAGE/app/supabase/migrations"
  cp -R supabase/migrations/. "$STAGE/app/supabase/migrations/" 2>/dev/null || true
fi

cat > "$STAGE/app/README-DEPLOY.md" << 'EOF'
# DiaMatrix Server — Production Bundle

This package contains compiled, minified, and obfuscated server code.
Source TypeScript is not included.

## Run

```bash
cp .env.example .env
# fill secrets

npm install --omit=dev
node index.js
```

Requires Node.js 20+.
EOF

OUT="$ROOT/app-build.zip"
rm -f "$OUT"
(
  cd "$STAGE"
  zip -r -q "$OUT" app
)

echo "Created: $OUT"
unzip -l "$OUT"
