# PDF → Excel (Branch Wise) — Integration Guide

PDF (D.NOSEPIN label report) upload korle branch-wise Excel pabe:
**Image · Barcode · Carat · Gross Wt · Net Wt · Price** + branch total + grand total (formula).

## 1. Files copy korun (project er `src/` er bhetor)

| File | Kaj |
|---|---|
| `src/shared/label-pdf-report/core.ts` | PDF parser + Excel builder (browser & server duita-te cholbe) |
| `src/shared/label-pdf-report/browser.ts` | Browser wiring (pdf.js + exceljs + canvas PNG) |
| `src/shared/label-pdf-report/node.ts` | Server/CLI wiring (pdf.js legacy + exceljs + pngjs) |
| `src/client/lumina/components/PdfToExcelModal.tsx` | Upload → summary → "Download Excel" screen |
| `src/controllers/pdfReport.controller.ts`, `src/routes/pdfReport.routes.ts` | Optional API: `POST /api/v1/pdf-report/to-excel` |
| `scripts/pdf-to-excel.ts` | Command line: `npx tsx scripts/pdf-to-excel.ts in.pdf out.xlsx` |

## 2. Package install

```bash
npm i pdfjs-dist pngjs
npm i -D @types/pngjs
```
(`exceljs`, `multer`, `lucide-react` apnar project e already ache.)

## 3. Existing file e hook (left side-nav e "Festival Scheme" er thik niche "PDF → Excel" button + modal)

`src/` folder er bhetor theke:

```bash
patch -p1 < patches/hook-into-app.patch
```
Eta 3 ta file e ektu ektu change kore: `App.tsx`, `AppSideNav.tsx`, `routes/index.ts`.
Server API na lagle `routes/index.ts` er change ta skip korte paren.

## 4. Kivabe kaj kore (important)

- PDF er prottek card er **image position** theke card chena hoy, tarpor oi card er text (barcode, price, carat, weights) nea hoy.
- **Net Wt** = label er *upore* ra lekha weight (jemon `0.26`), **Gross Wt** = *niche* r weight (jemon `.2634`).
- Branch = card er upore je branch header (BSL, DMD...) ache.
- Header te lekha pcs count er sathe pawa card count milie dekhe; na mille "Please check" warning dey.
- Same image 1 bar-i Excel e save hoy (file chhoto thake).

## 5. Limit / jene rakhun

- Eta ei **ek dhoroner PDF template** er jonno (same ERP report). Template change hole (card er size, header font) `ParseOptions` ba `core.ts` e adjust lagte pare.
- Test kora hoyeche: ei sample PDF (32 item, 5 branch) — Excel er data 100% mile geche, server endpoint o test kora.
- Browser e (pdf.js worker + canvas PNG) ami real browser e chalate pari ni, shudhu type-check korechi. Prothom bar app e chalie dekhben.
