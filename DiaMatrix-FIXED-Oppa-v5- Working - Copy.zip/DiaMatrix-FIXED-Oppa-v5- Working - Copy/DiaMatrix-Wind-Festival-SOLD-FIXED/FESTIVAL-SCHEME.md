# Festival Scheme module

Sidebar → **Festival Scheme**. Standalone — does not use Daily Upload data.

## Files
- `src/client/lumina/festival/festivalParsers.ts` — scheme / sold / stock parsers
- `src/client/lumina/festival/festivalEngine.ts` — Have vs Deserve (Contribution / Baseline / Hybrid)
- `src/client/lumina/festival/festivalExport.ts` — weight-wise Excel download
- `src/client/lumina/festival/FestivalSchemeView.tsx` — UI

## 1) Scheme file (your Puja list)

Columns (S/L and P.IMAGE optional):

| S/L | P.IMAGE | DESIGN NO | STOCK |
|-----|---------|-----------|-------|
| 1   | (img)   | E654      | 20    |
| 2   | (img)   | WER18-09117 | 22  |
| …   | …       | …         | …     |

- Required: **DESIGN NO** + **STOCK** (or QTY / PCS)
- Hyphen codes OK: `WER18-09117`, `IPSER20-07017`
- TOTAL row is ignored

## 2) Sold files (one per design — multi-upload)

File name should include the design code:
- `E384 - 9 Month - Sold.xlsx` → design **E384**
- `WER18-09117 - Sold.xlsx`

| Branch | 0.03 | 0.05 | 0.07 | 0.10 |
|--------|------|------|------|------|
| RUP    | 45   | 95   | 30   | 7    |
| SAV    | 107  | 236  | 49   | 7    |

- Carat headers must be **numbers**
- Branch label: Branch / Brnch
- Set **Sales months** in UI (default 9)
- Multiple sold files supported — each design uses its own sold contribution; designs without a matching sold file fall back to equal share

## 3) Stock files (one per design — multi-upload)

File name must include design code:
- `E654 - Stock.xlsx`
- `WER18-09117_Stock.xlsx`

| Category Name | Brnch | 0.03 | 0.05 | 0.07 | Total |
|---------------|-------|------|------|------|-------|
| Diamond Earring | RUP | 2 | 5 | 1 | 8 |
| | DWL | 10 | 20 | 5 | 35 |

- Header: **Category Name**
- **DWL** = warehouse (info only)

## Design search
Use the **Search design** box on the report toolbar to filter the matrix to matching design(s). Clear the box to show all.

## Upload order
1. Scheme → 2. Sold (multiple) → 3. Stock (multiple) → pick logic → optional design search → download Excel
