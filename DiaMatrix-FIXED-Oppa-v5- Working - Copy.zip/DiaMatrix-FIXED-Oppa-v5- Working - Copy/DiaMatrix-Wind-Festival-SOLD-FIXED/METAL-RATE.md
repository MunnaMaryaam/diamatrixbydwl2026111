# Metal Rate (Gold) — DiaMatrix

Top header **METAL RATE** button shows live / daily gold rates:

| Tab | Source | What you see |
|-----|--------|----------------|
| **Bangladesh (BAJUS)** | Public BAJUS-based sites (scraped) + safe fallback | 22K / 21K / 18K ৳ per gram + Updated on date |
| **International** | XAU spot (USD/oz) + USD→BDT FX | 24/22/21/18 KT ৳/gm, Platinum when available, spot $/oz |

## Files to merge

```
netlify/functions/gold-rates.mjs          ← NEW
netlify.toml                              ← add /api/gold-rates redirect (or merge)
src/client/lumina/components/MetalRatePanel.tsx   ← NEW
src/client/lumina/components/NetSuiteTopHeader.tsx ← import + button
```

## Behaviour

- Rates refresh on open and every **30 minutes** in the background.
- Function caches responses ~30 min server-side.
- UI matches the jewellery-site pattern: teal vertical **METAL RATE** label, “Updated on: DD-MM-YYYY”, table of karat → ৳/gm.
- Works without API keys (public gold + FX endpoints).

## Notes

- BAJUS does not publish a public JSON API; the function scrapes known BD rate pages and falls back to the last known official gram rates if the scrape fails.
- International column is pure **spot conversion** (not jewellery retail / making charge). BD tab is the retail reference used in the market.

## HTTP 406 fix (2026-10-07)

Local Vite / missing Netlify function used to surface **HTTP 406**.
`MetalRatePanel` now:

1. Tries `/.netlify/functions/gold-rates` (optional)
2. On any failure → **client-side**:
   - International: Coinbase `XAU-USD` spot (CORS `*`) + open.er-api USD/BDT
   - Bangladesh: BAJUS snapshot (22/21/18 KT + Platinum) so the tab is never empty

No paid API keys required. Deploy the Netlify function when you want live BAJUS page scrape.
