# DiaMatrix Server

**See every outlet. Move every piece.**

Production-ready **3-tier** backend:

| Tier | Folder | Role |
|------|--------|------|
| Presentation | `routes/` + `controllers/` | HTTP only |
| Business | `services/` | Redistribution, festival, reports |
| Data | `repositories/` + `models/` + Supabase/PostgreSQL | Persistence |

## Quick start

```bash
cp .env.example .env
# fill SUPABASE_* and JWT_SECRET

npm install
npm run dev
```

Health: `GET http://localhost:4000/api/v1/health`

## Layout

```
src/
  config/         env, supabase client, constants
  db/schema/      SQL source of truth
  models/         row types + mappers
  schemas/        Zod request/response validation
  repositories/   Supabase queries only
  services/       business logic (engines)
  controllers/    thin HTTP adapters
  routes/         path → controller
  middleware/     auth, rbac, validate, errors
  lib/            logger, AppError, helpers
```

## API (v1)

- `POST /api/v1/auth/login`
- `GET  /api/v1/outlets`
- `GET  /api/v1/inventory/stock`
- `POST /api/v1/redistribution/report`
- `POST /api/v1/festival/allocate`
- `GET  /api/v1/reports/cockpit`
- `GET  /api/v1/metal-rates`
- `GET  /api/v1/health`

## Rules

1. Controllers never call Supabase directly.
2. Services never touch `req` / `res`.
3. Repositories never contain allocation formulas.
4. All external input validated with Zod (`schemas/`).


## Production build (source hidden)

```bash
npm install
npm run release
# → dist/index.js (minified + obfuscated)
# → app-build.zip  (dist + prod package.json, no src/)
```

Client IT receives **only** `app-build.zip`. Your `src/` never leaves your machine.
