-- DiaMatrix cloud schema: users (profiles), shared documents, daily inventory snapshots.
-- The browser talks to these tables with the PUBLISHABLE key + a signed-in user, so every
-- table is protected by Row Level Security. No secret/service key is ever needed by the app.

-- ---------------------------------------------------------------------------
-- profiles: one row per Supabase auth user (created automatically on sign-up)
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  username    text not null unique,
  name        text not null default '',
  designation text,
  role        text not null default 'user' check (role in ('admin', 'manager', 'analyst', 'user')),
  status      text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  is_owner    boolean not null default false,
  can_edit    boolean not null default false,
  can_upload  boolean not null default false,
  can_export  boolean not null default false,
  created_at  timestamptz not null default now()
);

-- Helper checks. SECURITY DEFINER so they can read profiles without recursing through RLS.
create or replace function public.dmx_is_approved() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.status = 'approved');
$$;

create or replace function public.dmx_is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.status = 'approved' and (p.role = 'admin' or p.is_owner)
  );
$$;

create or replace function public.dmx_can(permission text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.status = 'approved'
      and (p.role = 'admin' or p.is_owner
           or (permission = 'edit'   and p.can_edit)
           or (permission = 'upload' and p.can_upload)
           or (permission = 'export' and p.can_export))
  );
$$;

-- New sign-up -> profile. The very FIRST account becomes the approved owner/admin;
-- everyone after that is "pending" until an admin approves them.
create or replace function public.dmx_handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  uname text;
  first_user boolean;
begin
  uname := lower(coalesce(nullif(trim(new.raw_user_meta_data ->> 'username'), ''), split_part(new.email, '@', 1)));
  select not exists (select 1 from public.profiles) into first_user;
  insert into public.profiles (id, username, name, role, status, is_owner, can_edit, can_upload, can_export)
  values (
    new.id,
    uname,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'name'), ''), uname),
    case when first_user then 'admin' else 'user' end,
    case when first_user then 'approved' else 'pending' end,
    first_user, first_user, first_user, first_user
  );
  return new;
end;
$$;

drop trigger if exists dmx_on_auth_user_created on auth.users;
create trigger dmx_on_auth_user_created
  after insert on auth.users
  for each row execute function public.dmx_handle_new_user();

-- Non-admins may only change their own name / designation, never role, status or permissions.
create or replace function public.dmx_profiles_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not public.dmx_is_admin() then
    if new.id is distinct from old.id
       or new.username is distinct from old.username
       or new.role is distinct from old.role
       or new.status is distinct from old.status
       or new.is_owner is distinct from old.is_owner
       or new.can_edit is distinct from old.can_edit
       or new.can_upload is distinct from old.can_upload
       or new.can_export is distinct from old.can_export then
      raise exception 'Only an administrator can change role, status or permissions';
    end if;
  end if;
  if old.is_owner and (new.is_owner is distinct from old.is_owner or new.status is distinct from old.status or new.role is distinct from old.role) then
    raise exception 'The owner account cannot be demoted, rejected or changed this way';
  end if;
  return new;
end;
$$;

drop trigger if exists dmx_profiles_guard_trg on public.profiles;
create trigger dmx_profiles_guard_trg
  before update on public.profiles
  for each row execute function public.dmx_profiles_guard();

alter table public.profiles enable row level security;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.dmx_is_admin());

drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid() or public.dmx_is_admin())
  with check (id = auth.uid() or public.dmx_is_admin());

drop policy if exists profiles_delete on public.profiles;
create policy profiles_delete on public.profiles for delete to authenticated
  using (public.dmx_is_admin() and not is_owner);

-- ---------------------------------------------------------------------------
-- app_documents: small shared JSON documents (settings, refill orders, festival scheme, ...)
-- ---------------------------------------------------------------------------
create table if not exists public.app_documents (
  key        text primary key,
  value      jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users (id) on delete set null
);

alter table public.app_documents enable row level security;

drop policy if exists app_documents_select on public.app_documents;
create policy app_documents_select on public.app_documents for select to authenticated
  using (public.dmx_is_approved());

drop policy if exists app_documents_insert on public.app_documents;
create policy app_documents_insert on public.app_documents for insert to authenticated
  with check (public.dmx_can('edit'));

drop policy if exists app_documents_update on public.app_documents;
create policy app_documents_update on public.app_documents for update to authenticated
  using (public.dmx_can('edit')) with check (public.dmx_can('edit'));

drop policy if exists app_documents_delete on public.app_documents;
create policy app_documents_delete on public.app_documents for delete to authenticated
  using (public.dmx_is_admin());

-- ---------------------------------------------------------------------------
-- daily snapshots: header row + records split into chunks (keeps each request small)
-- ---------------------------------------------------------------------------
create table if not exists public.daily_snapshots (
  id          text primary key,
  snapshot_date text not null,
  label       text not null default '',
  meta        jsonb not null default '{}'::jsonb,
  chunk_count integer not null default 0,
  updated_at  timestamptz not null default now(),
  created_by  uuid references auth.users (id) on delete set null
);

create table if not exists public.daily_snapshot_chunks (
  snapshot_id text not null references public.daily_snapshots (id) on delete cascade,
  idx         integer not null,
  records     jsonb not null,
  primary key (snapshot_id, idx)
);

alter table public.daily_snapshots enable row level security;
alter table public.daily_snapshot_chunks enable row level security;

drop policy if exists daily_snapshots_select on public.daily_snapshots;
create policy daily_snapshots_select on public.daily_snapshots for select to authenticated
  using (public.dmx_is_approved());
drop policy if exists daily_snapshots_insert on public.daily_snapshots;
create policy daily_snapshots_insert on public.daily_snapshots for insert to authenticated
  with check (public.dmx_can('upload'));
drop policy if exists daily_snapshots_update on public.daily_snapshots;
create policy daily_snapshots_update on public.daily_snapshots for update to authenticated
  using (public.dmx_can('upload')) with check (public.dmx_can('upload'));
drop policy if exists daily_snapshots_delete on public.daily_snapshots;
create policy daily_snapshots_delete on public.daily_snapshots for delete to authenticated
  using (public.dmx_can('upload'));

drop policy if exists daily_snapshot_chunks_select on public.daily_snapshot_chunks;
create policy daily_snapshot_chunks_select on public.daily_snapshot_chunks for select to authenticated
  using (public.dmx_is_approved());
drop policy if exists daily_snapshot_chunks_insert on public.daily_snapshot_chunks;
create policy daily_snapshot_chunks_insert on public.daily_snapshot_chunks for insert to authenticated
  with check (public.dmx_can('upload'));
drop policy if exists daily_snapshot_chunks_update on public.daily_snapshot_chunks;
create policy daily_snapshot_chunks_update on public.daily_snapshot_chunks for update to authenticated
  using (public.dmx_can('upload')) with check (public.dmx_can('upload'));
drop policy if exists daily_snapshot_chunks_delete on public.daily_snapshot_chunks;
create policy daily_snapshot_chunks_delete on public.daily_snapshot_chunks for delete to authenticated
  using (public.dmx_can('upload'));

-- ---------------------------------------------------------------------------
-- Privileges: signed-in users get table access (RLS above decides which rows); anon gets nothing.
-- (An earlier migration revoked default privileges, so grants must be explicit.)
-- ---------------------------------------------------------------------------
grant usage on schema public to authenticated;
grant select, insert, update, delete on public.profiles, public.app_documents,
  public.daily_snapshots, public.daily_snapshot_chunks to authenticated;
grant execute on function public.dmx_is_approved(), public.dmx_is_admin(), public.dmx_can(text) to authenticated;
revoke all on public.profiles, public.app_documents, public.daily_snapshots, public.daily_snapshot_chunks from anon;
