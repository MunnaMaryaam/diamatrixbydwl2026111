-- Mirror of src/db/schema for Supabase CLI
-- Run: supabase db push

create extension if not exists "pgcrypto";

create table if not exists public.outlets (
  code text primary key,
  name text not null,
  is_warehouse boolean not null default false,
  is_excluded boolean not null default false,
  parent_code text references public.outlets(code),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.inventory_positions (
  id uuid primary key default gen_random_uuid(),
  outlet_code text not null references public.outlets(code),
  design_code text not null,
  category text,
  carat_key text not null default 'ALL',
  qty numeric not null check (qty >= 0),
  as_of timestamptz not null default now(),
  source_file text,
  created_at timestamptz not null default now()
);

create table if not exists public.sales_facts (
  id uuid primary key default gen_random_uuid(),
  outlet_code text not null references public.outlets(code),
  design_code text not null,
  carat_key text not null default 'ALL',
  qty numeric not null check (qty >= 0),
  period_months int not null default 9 check (period_months between 1 and 36),
  as_of timestamptz not null default now(),
  source_file text,
  created_at timestamptz not null default now()
);

create table if not exists public.transfer_orders (
  id text primary key,
  design_code text not null,
  carat_key text,
  from_outlet text not null references public.outlets(code),
  to_outlet text not null references public.outlets(code),
  qty numeric not null check (qty > 0),
  priority text not null default 'MEDIUM',
  status text not null default 'RECOMMENDED',
  reason text,
  logic text,
  created_at timestamptz not null default now()
);

create table if not exists public.festival_schemes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  file_name text,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.festival_scheme_designs (
  id uuid primary key default gen_random_uuid(),
  scheme_id uuid not null references public.festival_schemes(id) on delete cascade,
  design_code text not null,
  stock_pcs int not null check (stock_pcs >= 0),
  g_wt numeric,
  n_wt numeric,
  d_wt numeric,
  unique (scheme_id, design_code)
);

create table if not exists public.app_users (
  id uuid primary key default gen_random_uuid(),
  username text not null unique,
  name text not null,
  role text not null default 'readonly',
  is_owner boolean not null default false,
  branch_code text references public.outlets(code),
  password_hash text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
