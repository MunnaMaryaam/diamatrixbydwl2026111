-- Lock the database down for the public (anon / authenticated) API keys.
--
-- The DiaMatrix server talks to Postgres with the service-role key / DATABASE_URL, and the
-- service role bypasses Row Level Security, so the app keeps working exactly as before.
-- With RLS on and NO policies, the anon key (which ships to browsers) can read or write nothing.
-- If you ever want the browser to read a table directly, add an explicit policy for that table.

do $$
declare t record;
begin
  for t in
    select schemaname, tablename
    from pg_tables
    where schemaname = 'public'
  loop
    execute format('alter table %I.%I enable row level security', t.schemaname, t.tablename);
  end loop;
end $$;

-- Also make sure the anon / authenticated roles do not get table privileges by default.
revoke all on all tables in schema public from anon, authenticated;
alter default privileges in schema public revoke all on tables from anon, authenticated;
