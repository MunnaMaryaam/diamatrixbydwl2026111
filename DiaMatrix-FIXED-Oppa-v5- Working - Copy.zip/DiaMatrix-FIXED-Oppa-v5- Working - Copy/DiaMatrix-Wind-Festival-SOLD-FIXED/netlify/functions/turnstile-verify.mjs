const SITEVERIFY = "https://challenges.cloudflare.com/turnstile/v0/siteverify";
const TEST_SECRET = "1x0000000000000000000000000000000AA";

export default async (request, context) => {
  if (request.method !== "POST") {
    return Response.json({ success: false, error: "Method not allowed" }, { status: 405 });
  }

  let token = "";
  try {
    const body = await request.json();
    token = String(body?.token || body?.["cf-turnstile-response"] || body?.turnstileToken || "");
  } catch {
    return Response.json({ success: false, error: "Missing Turnstile token" }, { status: 400 });
  }
  if (!token) {
    return Response.json({ success: false, error: "Missing Turnstile token" }, { status: 400 });
  }

  const form = new URLSearchParams({
    secret: process.env.TURNSTILE_SECRET_KEY || process.env.CF_TURNSTILE_SECRET_KEY || TEST_SECRET,
    response: token,
  });
  if (context.ip) form.set("remoteip", context.ip);

  try {
    const verification = await fetch(SITEVERIFY, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: form,
    });
    const result = await verification.json();
    if (result.success) return Response.json({ success: true });
    return Response.json(
      { success: false, error: "Cloudflare security check failed", codes: result["error-codes"] },
      { status: 403 },
    );
  } catch {
    return Response.json({ success: false, error: "Could not reach Cloudflare siteverify" }, { status: 502 });
  }
};
