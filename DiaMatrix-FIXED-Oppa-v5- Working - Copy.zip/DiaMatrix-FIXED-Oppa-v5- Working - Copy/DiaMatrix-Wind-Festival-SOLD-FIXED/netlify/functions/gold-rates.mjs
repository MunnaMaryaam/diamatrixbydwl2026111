/**
 * DiaMatrix — live metal rates
 * - International: XAU spot (USD/oz) + USD→BDT FX → per-gram karat prices
 * - Bangladesh: scrape latest BAJUS-style rates from public BD sources
 * Cached ~30 min in-memory on the function instance.
 */

const TROY_OZ_TO_G = 31.1034768;
const CACHE_MS = 30 * 60 * 1000;

/** @type {{ at: number, payload: any } | null} */
let cache = null;

const json = (body, status = 200, extra = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'public, max-age=300',
      'Access-Control-Allow-Origin': '*',
      ...extra,
    },
  });

async function fetchJson(url, timeoutMs = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { Accept: '*/*', 'User-Agent': 'DiaMatrix-GoldRates/1.0' },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

async function fetchText(url, timeoutMs = 10000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: {
        Accept: '*/*',
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    clearTimeout(t);
  }
}

/** International spot gold → BDT/gram for each karat */
async function getInternational() {
  let usdPerOz = null;
  let computedAt = null;
  try {
    const data = await fetchJson('https://api.goldprice.dev/v1/prices?symbol=XAU-USD-SPOT');
    const row = data?.symbols?.[0] || data?.[0];
    usdPerOz = Number(row?.price || row?.bid);
    computedAt = row?.computed_at || null;
  } catch {
    /* fallback below */
  }
  if (!usdPerOz || !Number.isFinite(usdPerOz)) {
    // metals.live style fallback (no key)
    try {
      const arr = await fetchJson('https://api.metals.live/v1/spot/gold');
      const row = Array.isArray(arr) ? arr.find((x) => x.gold != null) : arr;
      usdPerOz = Number(row?.gold);
    } catch {
      /* ignore */
    }
  }

  let usdBdt = 122.5;
  try {
    const fx = await fetchJson('https://open.er-api.com/v6/latest/USD');
    if (fx?.rates?.BDT) usdBdt = Number(fx.rates.BDT);
  } catch {
    try {
      const fx2 = await fetchJson('https://api.exchangerate-api.com/v4/latest/USD');
      if (fx2?.rates?.BDT) usdBdt = Number(fx2.rates.BDT);
    } catch {
      /* keep default */
    }
  }

  if (!usdPerOz || !Number.isFinite(usdPerOz)) {
    return null;
  }

  const purePerGramUsd = usdPerOz / TROY_OZ_TO_G;
  const purePerGramBdt = purePerGramUsd * usdBdt;
  const karat = (k) => Math.round(purePerGramBdt * (k / 24));

  // Platinum approximate from a secondary free source if available
  let platinumPerGramBdt = null;
  try {
    const pt = await fetchJson('https://api.goldprice.dev/v1/prices?symbol=XPT-USD-SPOT');
    const row = pt?.symbols?.[0];
    const ptOz = Number(row?.price);
    if (ptOz > 0) platinumPerGramBdt = Math.round((ptOz / TROY_OZ_TO_G) * usdBdt);
  } catch {
    /* optional */
  }

  return {
    source: 'International spot (XAU) + USD/BDT FX',
    updatedAt: computedAt || new Date().toISOString(),
    usdPerOz: Math.round(usdPerOz * 100) / 100,
    usdBdt: Math.round(usdBdt * 100) / 100,
    pure24kPerGramBdt: Math.round(purePerGramBdt),
    rates: [
      { label: '24 KT', purity: 24, perGramBdt: karat(24) },
      { label: '22 KT', purity: 22, perGramBdt: karat(22) },
      { label: '21 KT', purity: 21, perGramBdt: karat(21) },
      { label: '18 KT', purity: 18, perGramBdt: karat(18) },
      ...(platinumPerGramBdt
        ? [{ label: 'Platinum', purity: null, perGramBdt: platinumPerGramBdt }]
        : []),
    ],
  };
}

/** Parse BAJUS-style rates from goldpricebangladesh / alamin pages */
function parseBdRates(html) {
  // Prefer explicit per-gram numbers near 22K/21K/18K
  const rates = [];
  const patterns = [
    { label: '22 KT', re: /22\s*[Kk][^\d]{0,40}?৳?\s*([\d,]+)\s*(?:\/?\s*g(?:ram)?|per\s*gram)/i },
    { label: '21 KT', re: /21\s*[Kk][^\d]{0,40}?৳?\s*([\d,]+)\s*(?:\/?\s*g(?:ram)?|per\s*gram)/i },
    { label: '18 KT', re: /18\s*[Kk][^\d]{0,40}?৳?\s*([\d,]+)\s*(?:\/?\s*g(?:ram)?|per\s*gram)/i },
  ];
  for (const p of patterns) {
    const m = html.match(p.re);
    if (m) rates.push({ label: p.label, perGramBdt: Number(m[1].replace(/,/g, '')) });
  }

  // Table style: ৳ 19,640 near 22K context — also try bhori÷11.664
  if (rates.length < 3) {
    const bhori = {
      '22 KT': html.match(/22\s*[Kk][^\d]{0,80}?৳\s*([\d,]+)/i),
      '21 KT': html.match(/21\s*[Kk][^\d]{0,80}?৳\s*([\d,]+)/i),
      '18 KT': html.match(/18\s*[Kk][^\d]{0,80}?৳\s*([\d,]+)/i),
    };
    for (const [label, m] of Object.entries(bhori)) {
      if (!m) continue;
      const b = Number(m[1].replace(/,/g, ''));
      // BAJUS bhori values are typically > 50,000; convert to per gram
      const perGram = b > 50000 ? Math.round(b / 11.664) : b;
      if (!rates.find((r) => r.label === label)) rates.push({ label, perGramBdt: perGram });
    }
  }

  // Hard-coded known structure from goldpricebangladesh table cells
  if (rates.length < 3) {
    const grams = [...html.matchAll(/৳\s*([\d,]+)\s*(?=\s*<\/)/g)].map((m) =>
      Number(m[1].replace(/,/g, '')),
    );
    // Heuristic: look for typical gram range 10000–30000
    const gramish = grams.filter((n) => n >= 10000 && n <= 35000);
    if (gramish.length >= 3) {
      // Often ordered 22, 21, 18
      const uniq = [...new Set(gramish)].sort((a, b) => b - a);
      if (uniq[0] && uniq[1] && uniq[2]) {
        rates.length = 0;
        rates.push(
          { label: '22 KT', perGramBdt: uniq[0] },
          { label: '21 KT', perGramBdt: uniq[1] },
          { label: '18 KT', perGramBdt: uniq[2] },
        );
      }
    }
  }

  let updatedOn = null;
  const dateM =
    html.match(/Effective date:\s*\*?\*?(\d{1,2}\s+\w+\s+\d{4})/i) ||
    html.match(/Updated on:\s*(\d{2}[-/]\d{2}[-/]\d{4})/i) ||
    html.match(/(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})/i);
  if (dateM) updatedOn = dateM[1];

  if (rates.length === 0) return null;
  return { rates, updatedOn };
}

async function getBangladesh() {
  const urls = [
    'https://goldpricebangladesh.com/',
    'https://www.alaminjewellers.com/gold-price/',
  ];
  for (const url of urls) {
    try {
      const html = await fetchText(url);
      const parsed = parseBdRates(html);
      if (parsed?.rates?.length) {
        return {
          source: 'BAJUS (via public BD rate sites)',
          sourceUrl: url,
          updatedAt: parsed.updatedOn || new Date().toISOString(),
          rates: parsed.rates.map((r) => ({
            label: r.label,
            purity: Number(r.label) || null,
            perGramBdt: r.perGramBdt,
          })),
        };
      }
    } catch {
      /* try next */
    }
  }
  return null;
}

export default async (request) => {
  if (request.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    });
  }
  if (request.method !== 'GET') {
    return json({ error: 'Method not allowed' }, 405);
  }

  if (cache && Date.now() - cache.at < CACHE_MS) {
    return json({ ...cache.payload, cached: true });
  }

  const [international, bangladesh] = await Promise.all([getInternational(), getBangladesh()]);

  // Fallback BD rates from latest known BAJUS (Oct 2026) if scrape fails
  const bdFallback = {
    source: 'BAJUS reference (cached snapshot — live scrape unavailable)',
    updatedAt: '05-10-2026',
    rates: [
      { label: '22 KT', purity: 22, perGramBdt: 19640 },
      { label: '21 KT', purity: 21, perGramBdt: 18760 },
      { label: '18 KT', purity: 18, perGramBdt: 16110 },
      { label: 'Platinum', purity: null, perGramBdt: 15500 },
    ],
  };

  const payload = {
    ok: true,
    fetchedAt: new Date().toISOString(),
    bangladesh: bangladesh || bdFallback,
    international,
  };

  cache = { at: Date.now(), payload };
  return json({ ...payload, cached: false });
};
